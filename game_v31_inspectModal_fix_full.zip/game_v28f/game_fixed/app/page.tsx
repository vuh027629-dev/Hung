"use client"

import { useState } from "react"
import { GameProvider } from "@/lib/game/store"
import { GameShell } from "@/components/game/game-shell"
import { GameLoadingScreen } from "@/components/game/game-loading-screen"

export default function Page() {
  const [loaded, setLoaded] = useState(false)

  return (
    <>
      {!loaded && <GameLoadingScreen onComplete={() => setLoaded(true)} />}
      {loaded && (
        <GameProvider>
          <GameShell />
        </GameProvider>
      )}
    </>
  )
}
