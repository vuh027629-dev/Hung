import { NextRequest, NextResponse } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { prompt } = body

    if (!prompt || typeof prompt !== "string") {
      return NextResponse.json({ error: "Missing prompt" }, { status: 400 })
    }

    const apiKey = process.env.ANTHROPIC_API_KEY
    if (!apiKey) {
      return NextResponse.json({ error: "ANTHROPIC_API_KEY not configured" }, { status: 500 })
    }

    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001", // dùng Haiku cho nhanh & rẻ
        max_tokens: 400,
        messages: [{ role: "user", content: prompt }],
      }),
    })

    if (!res.ok) {
      const errText = await res.text()
      console.error("Anthropic API error:", res.status, errText)
      return NextResponse.json({ error: `Anthropic error: ${res.status}` }, { status: 502 })
    }

    const data = await res.json()
    const text = (data.content as { type: string; text?: string }[])
      ?.map(c => c.text ?? "")
      .join("") ?? ""

    return NextResponse.json({ text })
  } catch (err) {
    console.error("generate-boss route error:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
