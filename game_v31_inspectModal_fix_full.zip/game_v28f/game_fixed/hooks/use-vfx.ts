"use client"

import { useCallback, useEffect, useRef } from "react"

export type VfxEvent =
  | "attack"
  | "crit"
  | "skill"
  | "skill_dark"
  | "heal"
  | "heal_self"
  | "dot_burn"
  | "dot_poison"
  | "dot_bleed"
  | "miss"
  | "death"
  | "shield_hit"
  | "shield_gain"
  | "buff"
  | "debuff"
  | "stun"
  | "victory"
  | "defeat"
  | "fire_nova"
  | "ice_shatter"
  | "thunder"
  | "void_rift"
  | "holy_light"
  | "slash_heavy"
  | "multi_hit"
  | "soul_drain"
  | "earth_quake"
  | "arrow_volley"
  | "poison_cloud"
  | "resurrection"
  | "dragon_roar"
  | "shadow_step"
  | "time_warp"
  | "cyber_blast"

interface Particle {
  x: number; y: number
  vx: number; vy: number
  life: number; maxLife: number
  size: number
  color: string
  color2?: string
  alpha: number
  shape: "circle" | "spark" | "drop" | "blade" | "bolt" | "ring" | "beam" | "crack" | "arc" | "smoke" | "wave" | "rune"
  rotation?: number
  rotationSpeed?: number
  gravity?: number
  shrink?: number
  len?: number
  width?: number
  zigzag?: number
  segments?: number
  expand?: number
  tail?: number
  innerR?: number
  softness?: number
  waveH?: number
  _pts?: [number, number][]  // pre-baked points for bolt/crack (avoid per-frame random)
}

const allCanvases = new Set<() => void>()
let rafId: number | null = null

// ── Global particle budget ──────────────────────────────────────────────────
// Hard cap across ALL canvases. When exceeded, new particles are dropped so
// simultaneous heavy VFX (victory, defeat, AOE) don't stall the main thread.
const GLOBAL_PARTICLE_CAP = 300
let globalParticleCount = 0

function startRAF() {
  if (rafId !== null) return
  function loop() {
    allCanvases.forEach(fn => fn())
    rafId = allCanvases.size > 0 ? requestAnimationFrame(loop) : null
  }
  rafId = requestAnimationFrame(loop)
}

function spawnParticles(event: VfxEvent, cx: number, cy: number, w: number, h: number): Particle[] {
  const ps: Particle[] = []
  const rand = (a: number, b: number) => a + Math.random() * (b - a)
  const ri   = (a: number, b: number) => Math.floor(rand(a, b + 1))
  const pick = <T,>(arr: T[]): T => arr[ri(0, arr.length - 1)]

  switch (event) {

    case "attack": {
      for (let i = 0; i < 3; i++) {
        const angle = -Math.PI / 4 + rand(-0.25, 0.25)
        ps.push({ x: cx+rand(-10,10), y: cy+rand(-8,8), vx: Math.cos(angle)*rand(1.5,3), vy: Math.sin(angle)*rand(1.5,3),
          life: rand(0.18,0.32), maxLife: 0.32, size: rand(20,34), len: rand(28,42),
          color: "#ffffff", color2: "#fbbf24", alpha: 1, shape: "blade", gravity: 0, shrink: 0.88,
          rotation: angle, width: rand(2.5,4) })
      }
      for (let i = 0; i < 12; i++) {
        const a = rand(-Math.PI*0.6, -Math.PI*0.1)
        ps.push({ x: cx+rand(-8,8), y: cy+rand(-4,4), vx: Math.cos(a)*rand(2,5.5), vy: Math.sin(a)*rand(2,5.5),
          life: rand(0.15,0.4), maxLife: 0.4, size: rand(1.5,3),
          color: pick(["#fbbf24","#f87171","#ffffff"]), alpha: 1, shape: "spark", gravity: 0.12, shrink: 0.92 })
      }
      break
    }

    case "crit": {
      for (let k = 0; k < 2; k++) {
        const base = k === 0 ? -Math.PI/4 : Math.PI/4
        for (let i = 0; i < 2; i++) {
          ps.push({ x: cx+rand(-6,6), y: cy+rand(-6,6), vx: Math.cos(base)*rand(0.5,1.5), vy: Math.sin(base)*rand(0.5,1.5),
            life: rand(0.3,0.5), maxLife: 0.5, size: rand(32,46), len: rand(40,58),
            color: k===0?"#ffffff":"#fbbf24", color2: "#f97316", alpha: 1, shape: "blade", gravity: 0, shrink: 0.9,
            rotation: base+rand(-0.1,0.1), width: rand(3,5.5) })
        }
      }
      for (let r = 0; r < 2; r++) {
        ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.35+r*0.1, maxLife: 0.35+r*0.1,
          size: 4+r*3, color: r===0?"#ffffff":"#fbbf24", alpha: 0.95-r*0.2,
          shape: "ring", gravity: 0, expand: 5+r*3, width: 3-r*0.5 })
      }
      for (let i = 0; i < 12; i++) {
        const a = (i/12)*Math.PI*2
        ps.push({ x: cx, y: cy, vx: Math.cos(a)*rand(3,7), vy: Math.sin(a)*rand(3,7),
          life: rand(0.3,0.6), maxLife: 0.6, size: rand(1.5,3.5),
          color: pick(["#fbbf24","#ef4444","#ffffff"]), alpha: 1, shape: "spark", gravity: 0.08, shrink: 0.92 })
      }
      break
    }

    case "skill": {
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.8, maxLife: 0.8,
        size: 28, color: "#818cf8", color2: "#a78bfa", alpha: 0.85, shape: "rune",
        gravity: 0, rotation: 0, rotationSpeed: 0.06, innerR: 0.6, width: 2 })
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.5, maxLife: 0.5,
        size: 12, color: "#c4b5fd", alpha: 0.8, shape: "ring", gravity: 0, expand: 4, width: 2.5 })
      for (let i = 0; i < 10; i++) {
        const a = (i/10)*Math.PI*2
        ps.push({ x: cx+Math.cos(a)*14, y: cy+Math.sin(a)*14, vx: Math.cos(a)*rand(2,4.5), vy: Math.sin(a)*rand(2,4.5),
          life: rand(0.4,0.8), maxLife: 0.8, size: rand(3,6),
          color: pick(["#a78bfa","#818cf8","#c4b5fd"]), alpha: 1, shape: "circle", gravity: 0, shrink: 0.92 })
      }
      for (let i = 0; i < 16; i++) {
        const a = rand(0, Math.PI*2)
        ps.push({ x: cx+rand(-18,18), y: cy+rand(-18,18), vx: Math.cos(a)*rand(0.5,2), vy: Math.sin(a)*rand(0.5,2)-rand(0.5,2),
          life: rand(0.4,0.9), maxLife: 0.9, size: rand(2,4),
          color: pick(["#e0e7ff","#818cf8"]), alpha: 1, shape: "spark", gravity: -0.01, shrink: 0.95, rotation: a })
      }
      break
    }

    case "skill_dark": {
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.45, maxLife: 0.45,
        size: 40, color: "#7c3aed", alpha: 0.7, shape: "ring", gravity: 0, expand: -4, width: 3.5 })
      for (let i = 0; i < 8; i++) {
        const a = (i/8)*Math.PI*2
        ps.push({ x: cx+Math.cos(a)*rand(8,20), y: cy+Math.sin(a)*rand(8,20), vx: Math.cos(a)*rand(1,3), vy: Math.sin(a)*rand(1,3),
          life: rand(0.5,1.0), maxLife: 1.0, size: rand(22,38), len: rand(18,30),
          color: "#4c1d95", color2: "#dc2626", alpha: 0.8, shape: "blade", gravity: 0.01, shrink: 0.93,
          rotation: a, width: rand(2,3.5) })
      }
      for (let i = 0; i < 10; i++) {
        const a = rand(0, Math.PI*2)
        ps.push({ x: cx+rand(-15,15), y: cy+rand(-15,15), vx: Math.cos(a)*rand(0.5,2), vy: Math.sin(a)*rand(0.5,2),
          life: rand(0.5,1.0), maxLife: 1.0, size: rand(8,16),
          color: pick(["#1e1b4b","#4c1d95"]), alpha: 0.7, shape: "smoke", gravity: -0.01, shrink: 1.01, softness: 0.8 })
      }
      break
    }

    case "heal": {
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.5, maxLife: 0.5,
        size: 10, color: "#4ade80", alpha: 0.6, shape: "ring", gravity: 0, expand: 3.5, width: 3 })
      for (let i = 0; i < 12; i++) {
        ps.push({ x: cx+rand(-22,22), y: cy+rand(-5,20), vx: rand(-1,1), vy: rand(-3.5,-1.2),
          life: rand(0.6,1.1), maxLife: 1.1, size: rand(2.5,5),
          color: pick(["#4ade80","#86efac","#6ee7b7"]), alpha: 1,
          shape: i%4===0?"spark":"circle", gravity: -0.04, shrink: 0.96, rotation: rand(0,Math.PI*2) })
      }
      break
    }

    case "heal_self": {
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.6, maxLife: 0.6,
        size: 20, color: "#4ade80", color2: "#86efac", alpha: 0.75, shape: "rune",
        gravity: 0, rotation: 0, rotationSpeed: 0.05, innerR: 0.55, width: 2 })
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.45, maxLife: 0.45,
        size: 8, color: "#4ade80", alpha: 0.9, shape: "ring", gravity: 0, expand: 4.5, width: 2.5 })
      for (let i = 0; i < 16; i++) {
        const a = (i/16)*Math.PI*2
        ps.push({ x: cx, y: cy, vx: Math.cos(a)*rand(1.5,3.5), vy: Math.sin(a)*rand(1.5,3.5),
          life: rand(0.4,0.8), maxLife: 0.8, size: rand(2.5,5.5), color: "#4ade80",
          alpha: 1, shape: "circle", gravity: 0, shrink: 0.93 })
      }
      break
    }

    case "dot_burn": {
      for (let i = 0; i < 10; i++) {
        ps.push({ x: cx+rand(-14,14), y: cy+rand(0,12), vx: rand(-0.8,0.8), vy: rand(-3.5,-1.5),
          life: rand(0.4,0.75), maxLife: 0.75, size: rand(6,12),
          color: pick(["#f97316","#ef4444","#fbbf24"]),
          alpha: 0.85, shape: "smoke", gravity: -0.05, shrink: 1.005, softness: 0.65 })
      }
      for (let i = 0; i < 7; i++) {
        ps.push({ x: cx+rand(-10,10), y: cy+rand(-5,10), vx: rand(-1.5,1.5), vy: rand(-3,-0.5),
          life: rand(0.3,0.6), maxLife: 0.6, size: rand(1.5,3), color: "#fbbf24",
          alpha: 1, shape: "spark", gravity: 0.04, shrink: 0.92, rotation: rand(0,Math.PI*2) })
      }
      break
    }

    case "dot_poison": {
      for (let i = 0; i < 9; i++) {
        ps.push({ x: cx+rand(-12,12), y: cy+rand(-10,5), vx: rand(-0.5,0.5), vy: rand(0.5,2),
          life: rand(0.4,0.8), maxLife: 0.8, size: rand(2.5,5),
          color: pick(["#22c55e","#16a34a","#86efac"]), alpha: 1, shape: "drop", gravity: 0.08, shrink: 0.95 })
      }
      break
    }

    case "dot_bleed": {
      for (let i = 0; i < 9; i++) {
        ps.push({ x: cx+rand(-10,10), y: cy+rand(-8,5), vx: rand(-0.4,0.4), vy: rand(0.3,1.5),
          life: rand(0.5,0.9), maxLife: 0.9, size: rand(2.5,5),
          color: pick(["#dc2626","#b91c1c","#ef4444"]), alpha: 1, shape: "drop", gravity: 0.15, shrink: 0.96 })
      }
      break
    }

    case "miss": {
      for (let i = 0; i < 4; i++) {
        ps.push({ x: cx+rand(-8,8), y: cy+rand(-6,6), vx: rand(-5,-3), vy: rand(-0.5,0.5),
          life: rand(0.18,0.3), maxLife: 0.3, size: rand(3,5), len: rand(30,50),
          color: "#93c5fd", color2: "#60a5fa", alpha: 0.85, shape: "arc",
          gravity: 0, shrink: 0.85, rotation: rand(-0.1,0.1), tail: 0.7 })
      }
      break
    }

    case "death": {
      for (let i = 0; i < 8; i++) {
        const a = rand(0, Math.PI*2)
        ps.push({ x: cx+rand(-12,12), y: cy+rand(-8,8), vx: Math.cos(a)*rand(0.8,2.5), vy: Math.sin(a)*rand(0.8,2.5)-rand(0.5,1.5),
          life: rand(0.8,1.6), maxLife: 1.6, size: rand(8,18),
          color: pick(["#44403c","#78716c","#292524"]),
          alpha: 0.85, shape: "smoke", gravity: -0.02, shrink: 1.008, softness: 0.75 })
      }
      for (let i = 0; i < 6; i++) {
        const a = rand(0, Math.PI*2)
        ps.push({ x: cx, y: cy, vx: Math.cos(a)*rand(2,5.5), vy: Math.sin(a)*rand(2,5.5)-1.5,
          life: rand(0.4,0.8), maxLife: 0.8, size: rand(2,4), color: "#ef4444",
          alpha: 1, shape: "spark", gravity: -0.06, shrink: 0.9, rotation: a })
      }
      break
    }

    case "shield_hit": {
      for (let i = 0; i < 6; i++) {
        const a = (i/6)*Math.PI*2+rand(-0.2,0.2)
        ps.push({ x: cx, y: cy, vx: Math.cos(a)*rand(0.5,1.5), vy: Math.sin(a)*rand(0.5,1.5),
          life: rand(0.4,0.7), maxLife: 0.7, size: rand(20,35), len: rand(24,38),
          color: pick(["#38bdf8","#e0f2fe","#ffffff"]),
          alpha: 0.9, shape: "crack", gravity: 0, shrink: 0.97,
          rotation: a, segments: ri(3,5), width: rand(1.5,2.5) })
      }
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.28, maxLife: 0.28,
        size: 5, color: "#38bdf8", alpha: 0.95, shape: "ring", gravity: 0, expand: 6, width: 3.5 })
      for (let i = 0; i < 12; i++) {
        const a = rand(0, Math.PI*2)
        ps.push({ x: cx+rand(-5,5), y: cy+rand(-5,5), vx: Math.cos(a)*rand(2,5), vy: Math.sin(a)*rand(2,5),
          life: rand(0.3,0.6), maxLife: 0.6, size: rand(14,22), len: rand(8,14),
          color: pick(["#7dd3fc","#e0f2fe"]),
          alpha: 0.95, shape: "blade", gravity: 0.06, shrink: 0.91,
          rotation: a, width: rand(1.5,2.5) })
      }
      break
    }

    case "shield_gain": {
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.6, maxLife: 0.6,
        size: 22, color: "#0ea5e9", color2: "#bae6fd", alpha: 0.8, shape: "rune",
        gravity: 0, rotation: 0, rotationSpeed: -0.05, innerR: 0.65, width: 2.5 })
      for (let r = 0; r < 3; r++) {
        ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.25+r*0.12, maxLife: 0.25+r*0.12,
          size: 6+r*5, color: "#38bdf8", alpha: 0.8-r*0.2, shape: "ring",
          gravity: 0, expand: 4.5+r, width: 2.5-r*0.5 })
      }
      for (let i = 0; i < 10; i++) {
        const a = (i/10)*Math.PI*2
        ps.push({ x: cx, y: cy, vx: Math.cos(a)*rand(2,4), vy: Math.sin(a)*rand(2,4),
          life: rand(0.4,0.8), maxLife: 0.8, size: rand(2.5,5),
          color: pick(["#38bdf8","#bae6fd"]), alpha: 1, shape: "circle", gravity: 0, shrink: 0.94 })
      }
      break
    }

    case "buff": {
      ps.push({ x: cx, y: cy+20, vx: 0, vy: -2.5, life: 0.35, maxLife: 0.35,
        size: 36, color: "#fbbf24", alpha: 0.5, shape: "wave", gravity: 0, waveH: 10, width: 2 })
      for (let i = 0; i < 10; i++) {
        ps.push({ x: cx+rand(-18,18), y: cy+rand(5,28), vx: rand(-0.8,0.8), vy: rand(-3,-1),
          life: rand(0.6,1.2), maxLife: 1.2, size: rand(2.5,5.5),
          color: pick(["#fbbf24","#fef08a","#f59e0b"]),
          alpha: 1, shape: "spark", gravity: -0.05, shrink: 0.97, rotation: rand(0,Math.PI*2) })
      }
      break
    }

    case "debuff": {
      ps.push({ x: cx, y: cy, vx: 0, vy: 0.5, life: 0.4, maxLife: 0.4,
        size: 32, color: "#7c3aed", alpha: 0.45, shape: "wave", gravity: 0, waveH: 8, width: 2 })
      for (let i = 0; i < 8; i++) {
        const a = rand(0, Math.PI*2)
        ps.push({ x: cx+rand(-16,16), y: cy+rand(-10,10), vx: Math.cos(a)*rand(0.8,2), vy: Math.sin(a)*rand(0.8,2),
          life: rand(0.5,1.0), maxLife: 1.0, size: rand(6,12),
          color: pick(["#4c1d95","#7c3aed"]),
          alpha: 0.7, shape: "smoke", gravity: 0.03, shrink: 0.99, softness: 0.8 })
      }
      break
    }

    case "stun": {
      ps.push({ x: cx, y: cy-10, vx: 0, vy: 0, life: 0.4, maxLife: 0.4,
        size: 8, color: "#fbbf24", alpha: 0.85, shape: "ring", gravity: 0, expand: 3, width: 2.5 })
      for (let i = 0; i < 6; i++) {
        const a = (i/6)*Math.PI*2
        ps.push({ x: cx+Math.cos(a)*18, y: cy+Math.sin(a)*10-8,
          vx: Math.cos(a+Math.PI/4)*0.8, vy: -rand(0.3,0.8),
          life: rand(0.8,1.4), maxLife: 1.4, size: rand(5,9),
          color: pick(["#fbbf24","#fef08a"]),
          alpha: 1, shape: "spark", gravity: 0, shrink: 0.99,
          rotation: rand(0,Math.PI*2), rotationSpeed: rand(0.1,0.2) })
      }
      break
    }

    case "victory": {
      for (let i = 0; i < 20; i++) {
        const a = rand(-Math.PI*0.7, -Math.PI*0.3)
        ps.push({ x: cx+rand(-30,30), y: h,
          vx: Math.cos(a)*rand(2,6), vy: Math.sin(a)*rand(4,9),
          life: rand(0.8,1.6), maxLife: 1.6, size: rand(6,14), len: rand(3,7),
          color: pick(["#fbbf24","#f59e0b","#fef08a","#f97316","#ffffff"]),
          alpha: 1, shape: "blade", gravity: 0.15, shrink: 0.99,
          rotation: rand(0,Math.PI*2), rotationSpeed: rand(-0.2,0.2), width: rand(2,4) })
      }
      break
    }

    case "defeat": {
      for (let i = 0; i < 14; i++) {
        ps.push({ x: cx+rand(-22,22), y: cy+rand(-10,10), vx: rand(-1,1), vy: rand(-2,-0.3),
          life: rand(1.2,2.2), maxLife: 2.2, size: rand(10,20),
          color: pick(["#1c1917","#292524","#44403c"]),
          alpha: 0.85, shape: "smoke", gravity: -0.015, shrink: 1.005, softness: 0.8 })
      }
      break
    }

    // ══ PER-SKILL VFX ══════════════════════════════════════════════════════

    case "fire_nova": {
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.35, maxLife: 0.35,
        size: 8, color: "#f97316", alpha: 1, shape: "ring", gravity: 0, expand: 7, width: 4 })
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.5, maxLife: 0.5,
        size: 5, color: "#ef4444", alpha: 0.7, shape: "ring", gravity: 0, expand: 4.5, width: 2.5 })
      for (let i = 0; i < 8; i++) {
        const a = (i/8)*Math.PI*2
        ps.push({ x: cx, y: cy, vx: Math.cos(a)*rand(3,5.5), vy: Math.sin(a)*rand(3,5.5),
          life: rand(0.3,0.55), maxLife: 0.55, size: rand(3,5), len: rand(20,32),
          color: pick(["#f97316","#fbbf24","#ef4444"]), color2: "#f97316",
          alpha: 1, shape: "arc", gravity: 0.05, shrink: 0.9, rotation: a, tail: 0.8 })
      }
      for (let i = 0; i < 8; i++) {
        const a = rand(0, Math.PI*2)
        ps.push({ x: cx+rand(-10,10), y: cy+rand(-10,10), vx: Math.cos(a)*rand(1,3), vy: Math.sin(a)*rand(1,3),
          life: rand(0.5,1.0), maxLife: 1.0, size: rand(8,16),
          color: pick(["#f97316","#dc2626","#92400e"]),
          alpha: 0.8, shape: "smoke", gravity: -0.03, shrink: 1.01, softness: 0.7 })
      }
      break
    }

    case "ice_shatter": {
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.45, maxLife: 0.45,
        size: 6, color: "#38bdf8", alpha: 0.9, shape: "ring", gravity: 0, expand: 5.5, width: 3.5 })
      for (let i = 0; i < 6; i++) {
        const a = (i/6)*Math.PI*2+rand(-0.15,0.15)
        ps.push({ x: cx, y: cy, vx: Math.cos(a)*rand(0.3,0.8), vy: Math.sin(a)*rand(0.3,0.8),
          life: rand(0.5,0.9), maxLife: 0.9, size: rand(25,40), len: rand(28,42),
          color: pick(["#7dd3fc","#e0f2fe","#bae6fd"]),
          alpha: 0.95, shape: "crack", gravity: 0, shrink: 0.98,
          rotation: a, segments: ri(3,5), width: rand(1.5,2.5) })
      }
      for (let i = 0; i < 14; i++) {
        const a = rand(0, Math.PI*2)
        ps.push({ x: cx+rand(-6,6), y: cy+rand(-6,6), vx: Math.cos(a)*rand(2.5,6), vy: Math.sin(a)*rand(2.5,6),
          life: rand(0.35,0.65), maxLife: 0.65, size: rand(12,22), len: rand(10,18),
          color: pick(["#7dd3fc","#e0f2fe","#ffffff"]),
          alpha: 1, shape: "blade", gravity: 0.08, shrink: 0.91, rotation: a, width: rand(1.5,3) })
      }
      for (let i = 0; i < 6; i++) {
        ps.push({ x: cx+rand(-18,18), y: cy+rand(-10,10), vx: rand(-1,1), vy: rand(-1.5,0.5),
          life: rand(0.6,1.2), maxLife: 1.2, size: rand(10,20), color: "#bae6fd",
          alpha: 0.5, shape: "smoke", gravity: -0.01, shrink: 1.01, softness: 0.85 })
      }
      break
    }

    case "thunder": {
      for (let i = 0; i < 5; i++) {
        const a = rand(-Math.PI*0.4, Math.PI*0.4)-Math.PI/2
        ps.push({ x: cx+rand(-10,10), y: cy+rand(-10,10), vx: Math.cos(a)*rand(0,1), vy: Math.sin(a)*rand(0,1),
          life: rand(0.15,0.3), maxLife: 0.3, size: rand(30,55), len: rand(25,45),
          color: pick(["#fef08a","#ffffff","#fbbf24"]),
          alpha: 1, shape: "bolt", gravity: 0, shrink: 0.9,
          rotation: a, zigzag: rand(4,10), segments: ri(4,7), width: rand(2,4) })
      }
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.25, maxLife: 0.25,
        size: 6, color: "#fef08a", alpha: 0.95, shape: "ring", gravity: 0, expand: 8, width: 4 })
      for (let i = 0; i < 10; i++) {
        const a = rand(0, Math.PI*2)
        ps.push({ x: cx+rand(-8,8), y: cy+rand(-8,8), vx: Math.cos(a)*rand(2.5,7), vy: Math.sin(a)*rand(2.5,7),
          life: rand(0.1,0.3), maxLife: 0.3, size: rand(1.5,3.5),
          color: pick(["#fef08a","#ffffff"]),
          alpha: 1, shape: "spark", gravity: 0, shrink: 0.87, rotation: a })
      }
      break
    }

    case "void_rift": {
      for (let r = 0; r < 3; r++) {
        ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.4+r*0.08, maxLife: 0.4+r*0.08,
          size: 35-r*8, color: pick(["#6d28d9","#4c1d95"]),
          alpha: 0.75-r*0.15, shape: "ring", gravity: 0, expand: -3.5-r, width: 3-r*0.5 })
      }
      for (let i = 0; i < 12; i++) {
        const a = (i/12)*Math.PI*2, r = rand(25,45)
        ps.push({ x: cx+Math.cos(a)*r, y: cy+Math.sin(a)*r,
          vx: -Math.cos(a)*rand(2,4.5), vy: -Math.sin(a)*rand(2,4.5),
          life: rand(0.3,0.6), maxLife: 0.6, size: rand(18,30), len: rand(15,25),
          color: pick(["#4c1d95","#7c3aed"]),
          alpha: 0.85, shape: "blade", gravity: 0, shrink: 0.92,
          rotation: a+Math.PI, width: rand(1.5,3) })
      }
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.2, maxLife: 0.2,
        size: 14, color: "#a78bfa", alpha: 0.9, shape: "ring", gravity: 0, expand: 12, width: 5 })
      for (let i = 0; i < 8; i++) {
        const a = rand(0, Math.PI*2)
        ps.push({ x: cx+rand(-10,10), y: cy+rand(-10,10), vx: Math.cos(a)*rand(0.5,2), vy: Math.sin(a)*rand(0.5,2),
          life: rand(0.6,1.2), maxLife: 1.2, size: rand(10,18),
          color: pick(["#1e1b4b","#2e1065"]),
          alpha: 0.75, shape: "smoke", gravity: -0.01, shrink: 1.01, softness: 0.85 })
      }
      break
    }

    case "holy_light": {
      ps.push({ x: cx, y: cy+30, vx: 0, vy: -4, life: 0.55, maxLife: 0.55,
        size: 22, len: 60, color: "#fef9c3", color2: "#fbbf24",
        alpha: 0.85, shape: "beam", gravity: 0, shrink: 0.97, width: 4 })
      for (let r = 0; r < 2; r++) {
        ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.45+r*0.15, maxLife: 0.45+r*0.15,
          size: 8+r*6, color: r===0?"#ffffff":"#fef08a", alpha: 0.9-r*0.3,
          shape: "ring", gravity: 0, expand: 4+r*2, width: 3-r*0.5 })
      }
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.8, maxLife: 0.8,
        size: 30, color: "#fef9c3", color2: "#fbbf24", alpha: 0.7, shape: "rune",
        gravity: 0, rotation: 0, rotationSpeed: 0.04, innerR: 0.6, width: 2 })
      for (let i = 0; i < 10; i++) {
        ps.push({ x: cx+rand(-20,20), y: cy+rand(0,25), vx: rand(-0.8,0.8), vy: rand(-4.5,-1.5),
          life: rand(0.6,1.2), maxLife: 1.2, size: rand(2,5),
          color: pick(["#fef08a","#fbbf24","#ffffff"]),
          alpha: 1, shape: "spark", gravity: -0.05, shrink: 0.97, rotation: rand(0,Math.PI*2) })
      }
      break
    }

    case "slash_heavy": {
      for (let k = 0; k < 2; k++) {
        const base = k===0 ? -Math.PI/4 : Math.PI/4
        ps.push({ x: cx+rand(-8,8), y: cy+rand(-8,8), vx: Math.cos(base)*rand(1,2.5), vy: Math.sin(base)*rand(1,2.5),
          life: rand(0.4,0.65), maxLife: 0.65, size: rand(38,52), len: rand(48,64),
          color: k===0?"#ffffff":"#ef4444", color2: "#dc2626",
          alpha: 1, shape: "blade", gravity: 0, shrink: 0.88,
          rotation: base, width: rand(5,8) })
      }
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.3, maxLife: 0.3,
        size: 8, color: "#ef4444", alpha: 0.85, shape: "ring", gravity: 0, expand: 7, width: 4 })
      for (let i = 0; i < 10; i++) {
        const a = rand(0, Math.PI*2)
        ps.push({ x: cx+rand(-10,10), y: cy+rand(-10,10), vx: Math.cos(a)*rand(1.5,5), vy: Math.sin(a)*rand(1.5,5),
          life: rand(0.4,0.8), maxLife: 0.8, size: rand(2.5,5.5),
          color: pick(["#dc2626","#b91c1c","#ef4444"]),
          alpha: 1, shape: "drop", gravity: 0.12, shrink: 0.95 })
      }
      break
    }

    case "multi_hit": {
      const hitCount = ri(3,4)
      for (let i = 0; i < hitCount; i++) {
        const a = rand(-Math.PI/3, Math.PI/3)-Math.PI/2
        const offsetX = (i-hitCount/2)*12+rand(-5,5)
        ps.push({ x: cx+offsetX, y: cy+rand(-8,8), vx: Math.cos(a)*rand(1,2.5), vy: Math.sin(a)*rand(1,2.5),
          life: rand(0.15,0.28)+i*0.04, maxLife: 0.28+i*0.04,
          size: rand(18,28), len: rand(22,34),
          color: pick(["#ffffff","#fbbf24","#f87171"]), color2: "#f97316",
          alpha: 1, shape: "blade", gravity: 0, shrink: 0.87,
          rotation: a+rand(-0.2,0.2), width: rand(2,3.5) })
      }
      for (let i = 0; i < 8; i++) {
        const a = rand(-Math.PI/2, Math.PI/2)-Math.PI/2
        ps.push({ x: cx+rand(-15,15), y: cy+rand(-6,6), vx: Math.cos(a)*rand(2,6), vy: Math.sin(a)*rand(2,6),
          life: rand(0.1,0.3), maxLife: 0.3, size: rand(1.5,3),
          color: pick(["#fbbf24","#ffffff","#f87171"]),
          alpha: 1, shape: "spark", gravity: 0.1, shrink: 0.9, rotation: a })
      }
      break
    }

    case "soul_drain": {
      for (let i = 0; i < 6; i++) {
        const a = (i/6)*Math.PI*2
        ps.push({ x: cx+Math.cos(a)*rand(28,45), y: cy+Math.sin(a)*rand(20,35),
          vx: -Math.cos(a)*rand(1.5,3), vy: -Math.sin(a)*rand(1.5,3),
          life: rand(0.45,0.8), maxLife: 0.8, size: rand(2.5,4), len: rand(28,42),
          color: pick(["#7c3aed","#a78bfa"]), color2: "#4c1d95",
          alpha: 0.9, shape: "arc", gravity: 0, shrink: 0.94,
          rotation: a+Math.PI, tail: 0.9 })
      }
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.6, maxLife: 0.6,
        size: 32, color: "#6d28d9", alpha: 0.5, shape: "ring", gravity: 0, expand: -2, width: 3 })
      for (let i = 0; i < 8; i++) {
        const a = rand(0, Math.PI*2), r = rand(18,40)
        ps.push({ x: cx+Math.cos(a)*r, y: cy+Math.sin(a)*r,
          vx: -Math.cos(a)*rand(2,4), vy: -Math.sin(a)*rand(2,4),
          life: rand(0.3,0.6), maxLife: 0.6, size: rand(2.5,5), color: "#4ade80",
          alpha: 1, shape: "circle", gravity: 0, shrink: 0.93 })
      }
      break
    }

    case "earth_quake": {
      ps.push({ x: cx, y: cy+15, vx: 0, vy: 0, life: 0.45, maxLife: 0.45,
        size: 40, color: "#92400e", alpha: 0.6, shape: "wave", gravity: 0, expand: 4, waveH: 12, width: 3 })
      ps.push({ x: cx, y: cy+15, vx: 0, vy: 0, life: 0.3, maxLife: 0.3,
        size: 20, color: "#d97706", alpha: 0.5, shape: "wave", gravity: 0, expand: 7, waveH: 8, width: 2 })
      for (let i = 0; i < 5; i++) {
        const a = (i/5)*Math.PI-Math.PI/2+rand(-0.2,0.2)
        ps.push({ x: cx, y: cy+10, vx: Math.cos(a)*rand(0.5,1), vy: Math.sin(a)*rand(0.5,1),
          life: rand(0.5,0.9), maxLife: 0.9, size: rand(28,42), len: rand(32,48),
          color: pick(["#92400e","#78350f","#b45309"]),
          alpha: 0.9, shape: "crack", gravity: 0, shrink: 0.98,
          rotation: a, segments: ri(4,6), width: rand(2,3.5) })
      }
      for (let i = 0; i < 10; i++) {
        const a = rand(-Math.PI, 0)
        ps.push({ x: cx+rand(-20,20), y: cy+rand(5,18), vx: Math.cos(a)*rand(2,5.5), vy: Math.sin(a)*rand(3,7),
          life: rand(0.5,1.0), maxLife: 1.0, size: rand(4,10),
          color: pick(["#92400e","#78350f","#a16207"]),
          alpha: 1, shape: "circle", gravity: 0.18, shrink: 0.96 })
      }
      break
    }

    case "arrow_volley": {
      const numArrows = ri(3,5)
      for (let i = 0; i < numArrows; i++) {
        const spread = (i-numArrows/2)*0.18
        const a = -Math.PI/2+spread+rand(-0.05,0.05)
        ps.push({ x: cx+rand(-16,16), y: cy+rand(-4,4), vx: Math.cos(a)*rand(6,10), vy: Math.sin(a)*rand(6,10),
          life: rand(0.2,0.4), maxLife: 0.4, size: rand(2.5,4), len: rand(22,36),
          color: pick(["#22d3ee","#67e8f9","#a5f3fc"]), color2: "#0891b2",
          alpha: 1, shape: "arc", gravity: 0.04, shrink: 0.9, rotation: a, tail: 0.85 })
      }
      for (let i = 0; i < 8; i++) {
        const a = rand(-Math.PI, 0)
        ps.push({ x: cx+rand(-18,18), y: cy+rand(-5,5), vx: Math.cos(a)*rand(1.5,5), vy: Math.sin(a)*rand(1.5,5),
          life: rand(0.2,0.5), maxLife: 0.5, size: rand(1.5,3.5),
          color: pick(["#22d3ee","#e0f2fe","#ffffff"]),
          alpha: 1, shape: "spark", gravity: 0.06, shrink: 0.91, rotation: a })
      }
      break
    }

    case "poison_cloud": {
      for (let i = 0; i < 12; i++) {
        const a = rand(0, Math.PI*2)
        ps.push({ x: cx+rand(-16,16), y: cy+rand(-10,10), vx: Math.cos(a)*rand(0.5,2), vy: Math.sin(a)*rand(0.5,2)-rand(0.3,1),
          life: rand(0.8,1.6), maxLife: 1.6, size: rand(12,22),
          color: pick(["#166534","#15803d","#14532d"]),
          alpha: 0.75, shape: "smoke", gravity: -0.02, shrink: 1.008, softness: 0.85 })
      }
      for (let i = 0; i < 12; i++) {
        ps.push({ x: cx+rand(-22,22), y: cy+rand(-15,8), vx: rand(-0.5,0.5), vy: rand(1.5,3.5),
          life: rand(0.4,0.8), maxLife: 0.8, size: rand(2.5,5),
          color: pick(["#4ade80","#86efac","#22c55e"]),
          alpha: 0.9, shape: "drop", gravity: 0.06, shrink: 0.96 })
      }
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.5, maxLife: 0.5,
        size: 8, color: "#22c55e", alpha: 0.7, shape: "ring", gravity: 0, expand: 3, width: 3 })
      break
    }

    case "resurrection": {
      ps.push({ x: cx, y: cy+40, vx: 0, vy: -5, life: 0.8, maxLife: 0.8,
        size: 28, len: 80, color: "#ffffff", color2: "#fef9c3",
        alpha: 0.9, shape: "beam", gravity: 0, shrink: 0.97, width: 5 })
      for (let k = 0; k < 4; k++) {
        const a = (k/4)*Math.PI*2
        ps.push({ x: cx, y: cy, vx: Math.cos(a)*rand(1,2), vy: Math.sin(a)*rand(1,2),
          life: rand(0.5,0.8), maxLife: 0.8, size: rand(4,6), len: rand(32,50),
          color: pick(["#fef9c3","#fbbf24"]), color2: "#ffffff",
          alpha: 0.8, shape: "beam", gravity: 0, shrink: 0.96, width: 3, rotation: a })
      }
      for (let r = 0; r < 3; r++) {
        ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.4+r*0.15, maxLife: 0.4+r*0.15,
          size: 6+r*8, color: r===0?"#ffffff":"#fef08a", alpha: 0.85-r*0.2,
          shape: "ring", gravity: 0, expand: 4+r*1.5, width: 3-r*0.5 })
      }
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 1.0, maxLife: 1.0,
        size: 35, color: "#fef9c3", color2: "#fbbf24", alpha: 0.65, shape: "rune",
        gravity: 0, rotation: 0, rotationSpeed: 0.03, innerR: 0.55, width: 2 })
      for (let i = 0; i < 12; i++) {
        ps.push({ x: cx+rand(-20,20), y: cy+rand(0,35), vx: rand(-0.8,0.8), vy: rand(-5,-2),
          life: rand(0.7,1.4), maxLife: 1.4, size: rand(2.5,6),
          color: pick(["#fef9c3","#fbbf24","#ffffff"]),
          alpha: 1, shape: "spark", gravity: -0.06, shrink: 0.97, rotation: rand(0,Math.PI*2) })
      }
      break
    }

    case "dragon_roar": {
      for (let i = 0; i < 7; i++) {
        const spread = (i-3)*0.2
        const a = -Math.PI/2+spread
        ps.push({ x: cx+rand(-6,6), y: cy, vx: Math.cos(a)*rand(5,8), vy: Math.sin(a)*rand(5,8),
          life: rand(0.3,0.55), maxLife: 0.55, size: rand(4,7), len: rand(28,45),
          color: pick(["#f97316","#fbbf24","#ef4444"]), color2: "#dc2626",
          alpha: 1, shape: "arc", gravity: 0.03, shrink: 0.9, rotation: a, tail: 0.85 })
      }
      for (let r = 0; r < 2; r++) {
        ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.35+r*0.15, maxLife: 0.35+r*0.15,
          size: 5+r*8, color: r===0?"#f97316":"#fde047", alpha: 0.85-r*0.2,
          shape: "ring", gravity: 0, expand: 6+r*2, width: 4-r })
      }
      for (let i = 0; i < 8; i++) {
        const a = rand(0, Math.PI*2)
        ps.push({ x: cx+rand(-8,8), y: cy+rand(-8,8), vx: Math.cos(a)*rand(3,7), vy: Math.sin(a)*rand(3,7),
          life: rand(0.4,0.8), maxLife: 0.8, size: rand(12,22), len: rand(10,18),
          color: pick(["#fbbf24","#f97316","#dc2626"]),
          alpha: 1, shape: "blade", gravity: 0.08, shrink: 0.91,
          rotation: a, width: rand(2.5,4) })
      }
      for (let i = 0; i < 7; i++) {
        const a = rand(-Math.PI/3, Math.PI/3)-Math.PI/2
        ps.push({ x: cx+rand(-10,10), y: cy, vx: Math.cos(a)*rand(1.5,3), vy: Math.sin(a)*rand(1.5,3),
          life: rand(0.5,1.0), maxLife: 1.0, size: rand(10,18),
          color: pick(["#f97316","#92400e","#dc2626"]),
          alpha: 0.7, shape: "smoke", gravity: -0.03, shrink: 1.01, softness: 0.75 })
      }
      break
    }

    case "shadow_step": {
      for (let r = 0; r < 2; r++) {
        ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.3+r*0.1, maxLife: 0.3+r*0.1,
          size: 38-r*10, color: pick(["#4c1d95","#1e1b4b"]),
          alpha: 0.8-r*0.2, shape: "ring", gravity: 0, expand: -5-r*2, width: 3.5-r })
      }
      for (let i = 0; i < 10; i++) {
        const a = (i/10)*Math.PI*2, r = rand(20,40)
        ps.push({ x: cx+Math.cos(a)*r, y: cy+Math.sin(a)*r,
          vx: -Math.cos(a)*rand(3,6), vy: -Math.sin(a)*rand(3,6),
          life: rand(0.2,0.4), maxLife: 0.4, size: rand(14,24), len: rand(12,20),
          color: pick(["#4c1d95","#6d28d9"]),
          alpha: 0.9, shape: "blade", gravity: 0, shrink: 0.88,
          rotation: a+Math.PI, width: rand(2,3.5) })
      }
      for (let i = 0; i < 10; i++) {
        const a = rand(0, Math.PI*2)
        ps.push({ x: cx+rand(-12,12), y: cy+rand(-12,12), vx: Math.cos(a)*rand(0.5,2), vy: Math.sin(a)*rand(0.5,2),
          life: rand(0.5,1.1), maxLife: 1.1, size: rand(8,16),
          color: pick(["#1e1b4b","#0f0a1e","#3b0764"]),
          alpha: 0.8, shape: "smoke", gravity: -0.01, shrink: 1.01, softness: 0.88 })
      }
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.18, maxLife: 0.18,
        size: 6, color: "#e0e7ff", alpha: 0.95, shape: "ring", gravity: 0, expand: 10, width: 4 })
      break
    }

    case "time_warp": {
      for (let r = 0; r < 3; r++) {
        ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.7+r*0.12, maxLife: 0.7+r*0.12,
          size: 14+r*10, color: pick(["#14b8a6","#2dd4bf"]), color2: "#0d9488",
          alpha: 0.7-r*0.15, shape: "rune", gravity: 0,
          rotation: r*(Math.PI/3), rotationSpeed: r%2===0 ? 0.06 : -0.06,
          innerR: 0.7, width: 1.8 })
      }
      for (let i = 0; i < 4; i++) {
        const a = (i/4)*Math.PI*2
        ps.push({ x: cx, y: cy, vx: Math.cos(a)*rand(1.5,3), vy: Math.sin(a)*rand(1.5,3),
          life: rand(0.4,0.8), maxLife: 0.8, size: rand(2.5,4.5), len: rand(18,30),
          color: pick(["#2dd4bf","#99f6e4"]), color2: "#14b8a6",
          alpha: 0.9, shape: "arc", gravity: 0, shrink: 0.95, rotation: a, tail: 0.7 })
      }
      ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.45, maxLife: 0.45,
        size: 10, color: "#14b8a6", alpha: 0.8, shape: "ring", gravity: 0, expand: 4, width: 2.5 })
      break
    }

    case "cyber_blast": {
      ps.push({ x: cx+rand(-5,5), y: cy+rand(-5,5), vx: rand(-0.5,0.5), vy: rand(-1,-3),
        life: 0.4, maxLife: 0.4, size: 8, len: 50,
        color: "#22d3ee", color2: "#4ade80",
        alpha: 0.95, shape: "beam", gravity: 0, shrink: 0.97, width: 4,
        rotation: rand(-0.15,0.15)-Math.PI/2 })
      for (let r = 0; r < 3; r++) {
        ps.push({ x: cx, y: cy, vx: 0, vy: 0, life: 0.2+r*0.1, maxLife: 0.2+r*0.1,
          size: 4+r*6, color: r%2===0?"#22d3ee":"#4ade80", alpha: 0.9-r*0.2,
          shape: "ring", gravity: 0, expand: 7-r, width: 2.5-r*0.5 })
      }
      for (let i = 0; i < 12; i++) {
        const a = rand(0, Math.PI*2)
        ps.push({ x: cx+rand(-8,8), y: cy+rand(-8,8), vx: Math.cos(a)*rand(2.5,7), vy: Math.sin(a)*rand(2.5,7),
          life: rand(0.15,0.4), maxLife: 0.4, size: rand(1.5,3.5),
          color: pick(["#22d3ee","#4ade80","#a5f3fc"]),
          alpha: 1, shape: "spark", gravity: 0, shrink: 0.88, rotation: a })
      }
      break
    }
  }

  return ps
}

// ── Skill → VFX mapping ────────────────────────────────────────────────────
export function getSkillVfx(skillId: string): VfxEvent {
  switch (skillId) {
    case "fireball": case "arcaneBolt": case "infernalCore": case "infernalCore_evo":
    case "arcaneNova": case "arcaneNova_evo": return "fire_nova"
    case "iceLance": case "iceAge": case "iceAge_evo": case "glacialTrap":
    case "glacialTrap_evo": case "frozenField": case "glacialPrison":
    case "absoluteZero": case "glacialPrison_evo": return "ice_shatter"
    case "chainLightning": case "chainLightning_evo": case "thunderOath":
    case "thunderOath_evo": case "thunderMantle": case "stormjudgment":
    case "stormjudgment_evo": case "stormEclipse": case "stormEclipse_evo":
    case "thunderCyclone": case "thunderCyclone_evo": case "tempestBlast":
    case "tempestBlast_evo": case "cycloneStrike": return "thunder"
    case "voidRift": case "voidRift_evo": case "voidPulse": case "voidPulse_evo":
    case "finalEclipse": case "voidEclipse": case "voidEclipse_evo":
    case "oblivionPulse": case "oblivionPulse_evo": case "singularityCollapse":
    case "singularityCollapse_evo": case "soulRend": case "soulRend_evo":
    case "abyssalHarvest": case "abyssalHarvest_evo": case "doomCurse":
    case "tombCurse": case "tombCurse_evo": case "nightmareStep": return "void_rift"
    case "judgment": case "judgment_evo": case "divineWrath": case "divineWrath_evo":
    case "divineAscension": case "divineAscension_evo": case "divineStrike":
    case "holyBarrier": case "prayerShield": case "moonlightSurge":
    case "moonlightSurge_evo": case "dawnRebirth": case "dawnRebirth_evo":
    case "blessing": case "blessing_evo": case "cleanse": return "holy_light"
    case "resurrection": case "resurrection_evo": case "undyingDance":
    case "undyingDance_evo": case "worldTreeBloom": case "worldTreeBloom_evo": return "resurrection"
    case "dragonRoar": case "dragonRoar_evo": case "dragonBreath":
    case "dragonBreath_evo": case "ancestralRage": case "ancestralRage_evo":
    case "ancientDragonRoar": return "dragon_roar"
    case "executioner": case "executioner_evo": case "whirlwind": case "whirlwind_evo":
    case "ironBulwark": case "ironBulwark_evo": case "fortressBreaker":
    case "shieldBash": case "shieldBash_evo": case "taunt":
    case "cosmicShatter": case "cosmicShatter_evo": case "infiniteBlade":
    case "infiniteBlade_evo": return "slash_heavy"
    case "doubleStrike": case "bladeDance": case "bladeDance_evo":
    case "rapidFire": case "rapidFire_evo": case "stormBarrage": case "stormBarrage_evo":
    case "hurricaneBarrage": case "hurricaneBarrage_evo": case "demonFlicker":
    case "demonFlicker_evo": case "infiniteLoop": case "infiniteLoop_evo":
    case "droneSalvo": case "droneSalvo_evo": case "rainDeath": case "starRain": return "multi_hit"
    case "soulDrain": case "soulDrain_evo": case "soulChain": case "soulChain_evo":
    case "soulHarvest": case "bloodFrenzy": case "bloodFrenzy_evo":
    case "deathMark": case "deathMark_evo": case "cursedBlade": return "soul_drain"
    case "earthquake": case "earthquake_evo": return "earth_quake"
    case "pierceShot": case "trueShot": case "trueShot_evo":
    case "volley": case "volley_evo": case "galeShot": case "galeShot_evo":
    case "constellationArrow": case "constellationArrow_evo": case "starfall":
    case "starfall_evo": case "windArrow": case "phantomArrow":
    case "phantomArrow_evo": case "deadEyeShot": case "scatterBomb": return "arrow_volley"
    case "poisonDart": case "poisonDart_evo": case "plagueCloud": case "plagueCloud_evo":
    case "plaguePulse": case "plaguePulse_evo": case "plagueNova": case "plagueNova_evo":
    case "pestilenceField": case "pestilenceField_evo": case "pandemicWave":
    case "pandemicWave_evo": case "venomBlade": case "venomBlade_evo":
    case "woundDeepen": return "poison_cloud"
    case "cyberRailgun": case "cyberRailgun_evo": case "cyberOverdrive":
    case "cyberOverdrive_evo": case "nanotechStrike": case "overclock":
    case "manaShatter": case "spellMirror": case "mirrorRealm":
    case "mirrorRealm_evo": case "mirrorKill": return "cyber_blast"
    case "shadowStrike": case "shadowStrike_evo": case "phantomStep":
    case "phantomStep_evo": case "phantomEcho": case "smokeBomb":
    case "outlawAmbush": case "outlawAmbush_evo": return "shadow_step"
    case "timeWarp": return "time_warp"
    case "heal": case "heal_evo": case "groupHeal": case "groupHeal_evo": return "heal"
    default: return "skill"
  }
}

// ── Renderer ───────────────────────────────────────────────────────────────
function makeTickFn(
  canvasRef: React.RefObject<HTMLCanvasElement>,
  particlesRef: React.MutableRefObject<Particle[]>,
  DT: number,
) {
  let lastTime = 0
  // Cache ctx — getContext("2d") is cheap but no reason to call every frame
  let cachedCtx: CanvasRenderingContext2D | null = null

  return function tick(time: number) {
    const dt = Math.min((time - lastTime) / 1000, 0.1) || DT
    lastTime = time

    const canvas = canvasRef.current
    if (!canvas) return
    if (!cachedCtx) {
      cachedCtx = canvas.getContext("2d", { alpha: true }) ?? null
    }
    const ctx = cachedCtx
    if (!ctx) return

    ctx.clearRect(0, 0, canvas.width, canvas.height)

    const alive: Particle[] = []
    for (const p of particlesRef.current) {
      p.life -= dt
      if (p.life <= 0) continue

      p.x  += p.vx
      p.y  += p.vy
      p.vy += (p.gravity ?? 0)
      if (p.rotation !== undefined && p.rotationSpeed !== undefined) {
        p.rotation += p.rotationSpeed
      }
      const t = p.life / p.maxLife
      p.alpha = t
      if (p.shrink !== undefined) p.size *= p.shrink

      ctx.save()
      ctx.globalAlpha = Math.max(0, p.alpha)
      ctx.translate(p.x, p.y)
      if (p.rotation !== undefined) ctx.rotate(p.rotation)

      switch (p.shape) {

        case "circle": {
          ctx.beginPath()
          ctx.arc(0, 0, Math.max(p.size, 0.1), 0, Math.PI * 2)
          ctx.fillStyle = p.color
          ctx.fill()
          break
        }

        case "spark": {
          ctx.beginPath()
          ctx.moveTo(0, 0)
          ctx.lineTo(-p.vx * 3.5, -p.vy * 3.5)
          ctx.strokeStyle = p.color
          ctx.lineWidth = Math.max(p.size * 0.55, 0.5)
          ctx.lineCap = "round"
          ctx.stroke()
          break
        }

        case "drop": {
          const s = Math.max(p.size, 0.5)
          ctx.beginPath()
          ctx.moveTo(0, -s)
          ctx.bezierCurveTo(s*0.6, -s*0.3, s*0.6, s*0.7, 0, s)
          ctx.bezierCurveTo(-s*0.6, s*0.7, -s*0.6, -s*0.3, 0, -s)
          ctx.fillStyle = p.color
          ctx.fill()
          break
        }

        // ── BLADE — tapered slash with bright leading tip ───────────────────
        case "blade": {
          const len  = p.len  ?? p.size * 3
          const half = len / 2
          const w    = p.width ?? Math.max(p.size * 0.45, 1)

          const grad = ctx.createLinearGradient(-half, 0, half, 0)
          grad.addColorStop(0,   "transparent")
          grad.addColorStop(0.35, (p.color) + "55")
          grad.addColorStop(0.75, p.color)
          grad.addColorStop(1,   "#ffffff")

          ctx.beginPath()
          ctx.moveTo(-half, 0)
          ctx.lineTo(half * 0.5, -w * 0.5)
          ctx.lineTo(half, 0)
          ctx.lineTo(half * 0.5, w * 0.5)
          ctx.closePath()
          ctx.fillStyle = grad
          ctx.fill()

          // Bright white tip flash
          ctx.beginPath()
          ctx.arc(half, 0, Math.max(w * 0.4, 0.5), 0, Math.PI * 2)
          ctx.fillStyle = "#ffffff"
          ctx.globalAlpha = p.alpha * 0.9
          ctx.fill()
          break
        }

        // ── BOLT — zigzag lightning (points pre-baked at spawn) ────────────
        case "bolt": {
          const len  = p.len      ?? p.size * 2
          const segs = p.segments ?? 5
          const zz   = p.zigzag   ?? 6
          const lw   = p.width    ?? 2

          // Use stored pre-baked points if available, else generate once and cache
          if (!p._pts) {
            const pts: [number, number][] = [[0, 0]]
            for (let i = 1; i <= segs; i++) {
              const px = (i / segs) * len
              const py = i % 2 === 0 ? -(zz * 0.5 + Math.random() * zz * 0.5) : (zz * 0.5 + Math.random() * zz * 0.5)
              pts.push([px, py])
            }
            p._pts = pts
          }
          const points = p._pts as [number, number][]

          // Outer glow
          ctx.beginPath()
          ctx.moveTo(points[0][0], points[0][1])
          for (let i = 1; i < points.length; i++) ctx.lineTo(points[i][0], points[i][1])
          ctx.strokeStyle = (p.color2 ?? p.color) + "66"
          ctx.lineWidth = lw * 3
          ctx.lineJoin = "round"
          ctx.lineCap = "round"
          ctx.stroke()

          // Inner bright core
          ctx.beginPath()
          ctx.moveTo(points[0][0], points[0][1])
          for (let i = 1; i < points.length; i++) ctx.lineTo(points[i][0], points[i][1])
          ctx.strokeStyle = p.color
          ctx.lineWidth = lw
          ctx.stroke()

          // Bright tip dot
          const last = points[points.length - 1]
          ctx.beginPath()
          ctx.arc(last[0], last[1], lw * 1.5, 0, Math.PI * 2)
          ctx.fillStyle = "#ffffff"
          ctx.fill()
          break
        }

        // ── RING — expanding/contracting circle ─────────────────────────────
        case "ring": {
          const expandDelta = (p.expand ?? 0) * dt * 60
          p.size = Math.max(0.1, p.size + expandDelta)
          const lw = p.width ?? 2
          ctx.beginPath()
          ctx.arc(0, 0, Math.max(p.size, 0.1), 0, Math.PI * 2)
          ctx.strokeStyle = p.color
          ctx.lineWidth = lw * t + 0.3
          ctx.stroke()
          break
        }

        // ── BEAM — glowing directional ray ──────────────────────────────────
        case "beam": {
          const len = p.len ?? 40
          const w   = p.width ?? 4

          // Glow via wide semi-transparent stroke (no shadowBlur — too expensive)
          const grad = ctx.createLinearGradient(0, 0, len, 0)
          grad.addColorStop(0,    "transparent")
          grad.addColorStop(0.15, p.color + "55")
          grad.addColorStop(0.65, p.color)
          grad.addColorStop(1,    "#ffffff")

          ctx.beginPath()
          ctx.moveTo(0, 0)
          ctx.lineTo(len, 0)
          ctx.strokeStyle = p.color + "44"
          ctx.lineWidth = w * 5
          ctx.lineCap = "round"
          ctx.stroke()

          ctx.beginPath()
          ctx.moveTo(0, 0)
          ctx.lineTo(len, 0)
          ctx.strokeStyle = grad
          ctx.lineWidth = w * 1.8
          ctx.stroke()

          ctx.beginPath()
          ctx.moveTo(0, 0)
          ctx.lineTo(len, 0)
          ctx.strokeStyle = "#ffffff"
          ctx.lineWidth = w * 0.35
          ctx.stroke()
          break
        }

        // ── CRACK — jagged radial fracture (points pre-baked at spawn) ──────
        case "crack": {
          const len  = p.len  ?? p.size * 2
          const segs = p.segments ?? 4
          const lw   = p.width ?? 2

          if (!p._pts) {
            const pts: [number, number][] = [[0, 0]]
            for (let i = 1; i <= segs; i++) {
              const prog = i / segs
              const jitter = (Math.random() - 0.5) * len * 0.3
              pts.push([prog * len, jitter])
            }
            p._pts = pts
          }
          const points = p._pts as [number, number][]

          ctx.beginPath()
          ctx.moveTo(0, 0)
          for (let i = 1; i < points.length; i++) ctx.lineTo(points[i][0], points[i][1])
          ctx.strokeStyle = p.color
          ctx.lineWidth = Math.max(lw * (1 + t), 0.5)
          ctx.lineCap = "round"
          ctx.lineJoin = "round"
          ctx.stroke()

          // Fork at tip
          const last = points[points.length - 1]
          ctx.beginPath()
          ctx.moveTo(last[0], last[1])
          ctx.lineTo(last[0] + 6, last[1] - 5)
          ctx.moveTo(last[0], last[1])
          ctx.lineTo(last[0] + 5, last[1] + 5)
          ctx.lineWidth = lw * 0.6
          ctx.stroke()
          break
        }

        // ── ARC — projectile with glowing head and long tail ────────────────
        case "arc": {
          const len  = p.len  ?? 30
          const tail = p.tail ?? 0.7
          const w    = p.width ?? Math.max(p.size * 0.5, 1)

          const grad = ctx.createLinearGradient(-len * tail, 0, 0, 0)
          grad.addColorStop(0,   "transparent")
          grad.addColorStop(0.5, p.color + "55")
          grad.addColorStop(1,   p.color2 ?? p.color)

          ctx.beginPath()
          ctx.moveTo(-len * tail, 0)
          ctx.lineTo(0, 0)
          ctx.strokeStyle = grad
          ctx.lineWidth = w * 1.5
          ctx.lineCap = "round"
          ctx.stroke()

          // Glow head — no shadowBlur, use two concentric circles instead
          ctx.beginPath()
          ctx.arc(0, 0, Math.max(w * 2.2, 1.5), 0, Math.PI * 2)
          ctx.fillStyle = p.color + "44"
          ctx.fill()

          ctx.beginPath()
          ctx.arc(0, 0, Math.max(w * 0.9, 0.5), 0, Math.PI * 2)
          ctx.fillStyle = p.color2 ?? p.color
          ctx.fill()

          // Bright core dot
          ctx.beginPath()
          ctx.arc(0, 0, Math.max(w * 0.4, 0.3), 0, Math.PI * 2)
          ctx.fillStyle = "#ffffff"
          ctx.fill()
          break
        }

        // ── SMOKE — two-circle soft approximation (no per-frame gradient) ──
        case "smoke": {
          const r = Math.max(p.size, 0.5)
          // Outer soft ring at 50% alpha, inner solid fill — visually close to radial gradient
          // but avoids creating a new CanvasGradient object every frame per particle
          ctx.beginPath()
          ctx.arc(0, 0, r, 0, Math.PI * 2)
          ctx.fillStyle = p.color
          ctx.globalAlpha = Math.max(0, p.alpha * 0.35)
          ctx.fill()
          ctx.beginPath()
          ctx.arc(0, 0, r * 0.55, 0, Math.PI * 2)
          ctx.globalAlpha = Math.max(0, p.alpha * 0.75)
          ctx.fill()
          break
        }

        // ── WAVE — horizontal ellipse AOE sweep ─────────────────────────────
        case "wave": {
          const expandDelta = (p.expand ?? 0) * dt * 60
          p.size += expandDelta
          const hW  = Math.max(p.size, 1)
          const hH  = p.waveH ?? 8

          const grad = ctx.createLinearGradient(-hW, 0, hW, 0)
          grad.addColorStop(0,    "transparent")
          grad.addColorStop(0.2,  p.color + "88")
          grad.addColorStop(0.5,  p.color)
          grad.addColorStop(0.8,  p.color + "88")
          grad.addColorStop(1,    "transparent")

          ctx.beginPath()
          ctx.ellipse(0, 0, hW, hH, 0, 0, Math.PI * 2)
          ctx.fillStyle = grad
          ctx.fill()
          break
        }

        // ── RUNE — double ring with cross spokes ────────────────────────────
        case "rune": {
          const r   = Math.max(p.size, 1)
          const iR  = r * (p.innerR ?? 0.6)
          const lw  = p.width ?? 1.5

          ctx.beginPath()
          ctx.arc(0, 0, r, 0, Math.PI * 2)
          ctx.strokeStyle = p.color
          ctx.lineWidth = lw
          ctx.stroke()

          ctx.beginPath()
          ctx.arc(0, 0, iR, 0, Math.PI * 2)
          ctx.strokeStyle = p.color2 ?? p.color
          ctx.lineWidth = lw * 0.7
          ctx.stroke()

          for (let i = 0; i < 4; i++) {
            const a2 = (i / 4) * Math.PI * 2
            ctx.beginPath()
            ctx.moveTo(Math.cos(a2) * iR, Math.sin(a2) * iR)
            ctx.lineTo(Math.cos(a2) * r,  Math.sin(a2) * r)
            ctx.strokeStyle = p.color
            ctx.lineWidth = lw * 0.5
            ctx.stroke()
          }
          break
        }
      }

      ctx.restore()
      alive.push(p)
    }

    // Update global counter by how many died this frame
    globalParticleCount = Math.max(0, globalParticleCount - (particlesRef.current.length - alive.length))
    particlesRef.current = alive
  }
}

// ── Hook ───────────────────────────────────────────────────────────────────
export interface VfxHandle {
  trigger: (event: VfxEvent, x?: number, y?: number) => void
  canvasRef: React.RefObject<HTMLCanvasElement>
}

// Max lifetime any particle can have — hard safety cap
const MAX_PARTICLE_LIFE = 3.0

export function useVfx(): VfxHandle {
  const canvasRef    = useRef<HTMLCanvasElement>(null!)
  const particlesRef = useRef<Particle[]>([])
  const tickRef      = useRef<((t: number) => void) | null>(null)
  const fnRef        = useRef<((t: number) => void) | null>(null)
  const safetyTimer  = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Sync canvas internal resolution to its CSS display size.
  // Without this, a small width/height (e.g. 120) stretched over a large card
  // causes particles to appear distorted/scaled.
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const syncSize = () => {
      const w = Math.round(canvas.offsetWidth)  || 160
      const h = Math.round(canvas.offsetHeight) || 160
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width  = w
        canvas.height = h
      }
    }

    syncSize()
    const ro = new ResizeObserver(syncSize)
    ro.observe(canvas)
    return () => ro.disconnect()
  }, [])

  const trigger = useCallback((event: VfxEvent, _x?: number, _y?: number) => {
    const canvas = canvasRef.current
    // Guard: don't spawn on disconnected canvas (stale ref from old render)
    if (!canvas || !canvas.isConnected) return

    const w  = canvas.width  || canvas.offsetWidth
    const h  = canvas.height || canvas.offsetHeight
    const cx = _x ?? w / 2
    const cy = _y ?? h / 2

    // Drop entirely if global budget is exceeded
    if (globalParticleCount >= GLOBAL_PARTICLE_CAP) return

    const newPs = spawnParticles(event, cx, cy, w, h)
    // Cap all particle lifetimes so nothing can live beyond MAX_PARTICLE_LIFE
    for (const p of newPs) {
      p.life    = Math.min(p.life,    MAX_PARTICLE_LIFE)
      p.maxLife = Math.min(p.maxLife, MAX_PARTICLE_LIFE)
    }
    // Per-canvas cap: max 60 live particles per unit
    const PER_CANVAS_CAP = 60
    const prevCount = particlesRef.current.length
    const combined = [...particlesRef.current, ...newPs].slice(-PER_CANVAS_CAP)
    globalParticleCount = Math.max(0, globalParticleCount + combined.length - prevCount)
    particlesRef.current = combined

    if (!tickRef.current) {
      tickRef.current = makeTickFn(canvasRef as React.RefObject<HTMLCanvasElement>, particlesRef, 1/60)
      const fn = (time: number) => {
        // Self-remove if canvas is gone (unmounted / key change)
        if (!canvasRef.current?.isConnected) {
          allCanvases.delete(fn)
          fnRef.current = null
          tickRef.current = null
          particlesRef.current = []
          return
        }
        tickRef.current?.(time)
        // Self-remove when all particles have naturally died
        if (particlesRef.current.length === 0) {
          allCanvases.delete(fn)
          fnRef.current = null
          tickRef.current = null
        }
      }
      fnRef.current = fn
      allCanvases.add(fn)
      startRAF()
    }

    // Hard safety timeout: force-wipe particles after max possible lifetime
    if (safetyTimer.current) clearTimeout(safetyTimer.current)
    safetyTimer.current = setTimeout(() => {
      globalParticleCount = Math.max(0, globalParticleCount - particlesRef.current.length)
      particlesRef.current = []
      const c = canvasRef.current
      if (c) {
        const ctx = c.getContext("2d")
        ctx?.clearRect(0, 0, c.width, c.height)
      }
      if (fnRef.current) {
        allCanvases.delete(fnRef.current)
        fnRef.current = null
      }
      tickRef.current = null
    }, MAX_PARTICLE_LIFE * 1000 + 300)
  }, [])

  return { trigger, canvasRef }
}
