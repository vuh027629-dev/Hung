"use client"

import { useCallback, useRef, useEffect } from "react"

// ═══════════════════════════════════════════════════════════════════════════
//  DARK FANTASY RPG — PROCEDURAL AUDIO ENGINE v2
//  Toàn bộ âm thanh tổng hợp bằng Web Audio API.
//  Signal chain: source → filter → distortion → gain → reverb → compressor
// ═══════════════════════════════════════════════════════════════════════════

export type SoundName =
  | "attack"
  | "attack_heavy"
  | "crit"
  | "skill"
  | "skill_dark"
  | "heal"
  | "miss"
  | "death"
  | "death_boss"
  | "victory"
  | "defeat"
  | "buy"
  | "levelup"
  | "ui_click"
  | "dot"
  | "shield_block"
  | "stun"

// ── AudioContext factory ──────────────────────────────────────────────────────
function createAudioContext(): AudioContext | null {
  if (typeof window === "undefined") return null
  try {
    return new (window.AudioContext || (window as any).webkitAudioContext)()
  } catch {
    return null
  }
}

// ── Master bus: compressor → destination (shared per context) ─────────────────
// Giữ tất cả sound trong ngưỡng, tạo cảm giác "punchy" và chuyên nghiệp
function getMasterBus(ctx: AudioContext): DynamicsCompressorNode {
  const key = "__dfMaster__"
  if ((ctx as any)[key]) return (ctx as any)[key]
  const comp = ctx.createDynamicsCompressor()
  comp.threshold.value = -14
  comp.knee.value      = 8
  comp.ratio.value     = 5
  comp.attack.value    = 0.003
  comp.release.value   = 0.18
  comp.connect(ctx.destination)
  ;(ctx as any)[key] = comp
  return comp
}

// ── Reverb: impulse response tự sinh — giả lập không gian dungeon/cave ───────
function buildReverb(ctx: AudioContext, decayTime: number): ConvolverNode {
  const len     = Math.ceil(ctx.sampleRate * decayTime)
  const impulse = ctx.createBuffer(2, len, ctx.sampleRate)
  for (let ch = 0; ch < 2; ch++) {
    const d = impulse.getChannelData(ch)
    for (let i = 0; i < len; i++)
      d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.8)
  }
  const conv = ctx.createConvolver()
  conv.buffer = impulse
  return conv
}

// Cache reverb để không rebuild mỗi frame
const reverbCache = new WeakMap<AudioContext, Map<number, ConvolverNode>>()
function getReverb(ctx: AudioContext, decayTime: number): ConvolverNode {
  if (!reverbCache.has(ctx)) reverbCache.set(ctx, new Map())
  const cache = reverbCache.get(ctx)!
  const key   = Math.round(decayTime * 10)
  if (!cache.has(key)) cache.set(key, buildReverb(ctx, decayTime))
  return cache.get(key)!
}

// Tạo wet/dry mix nối vào master
function makeBus(ctx: AudioContext, dryVol: number, wetVol: number, reverbTime: number) {
  const master = getMasterBus(ctx)
  const dry    = ctx.createGain(); dry.gain.value = dryVol; dry.connect(master)
  const rev    = getReverb(ctx, reverbTime)
  const wet    = ctx.createGain(); wet.gain.value = wetVol; wet.connect(rev); rev.connect(master)
  return { dry, wet }
}

// ── Distortion waveshaper ─────────────────────────────────────────────────────
function makeDistCurve(amount: number): Float32Array {
  const n = 512, curve = new Float32Array(n)
  for (let i = 0; i < n; i++) {
    const x = (i * 2) / n - 1
    curve[i] = ((Math.PI + amount) * x) / (Math.PI + amount * Math.abs(x))
  }
  return curve
}
function makeDistNode(ctx: AudioContext, amount: number): WaveShaperNode {
  const ws = ctx.createWaveShaper()
  ws.curve    = makeDistCurve(amount)
  ws.oversample = "4x"
  return ws
}

// ── Primitive builders ────────────────────────────────────────────────────────

/** Sub-bass thump — cảm giác va chạm vật lý */
function thump(ctx: AudioContext, out: AudioNode, freq: number, vol: number, dur: number, delay = 0) {
  const t   = ctx.currentTime + delay
  const osc = ctx.createOscillator()
  const g   = ctx.createGain()
  osc.type = "sine"
  osc.frequency.setValueAtTime(freq, t)
  osc.frequency.exponentialRampToValueAtTime(Math.max(freq * 0.12, 20), t + dur * 0.85)
  g.gain.setValueAtTime(vol, t)
  g.gain.exponentialRampToValueAtTime(0.001, t + dur)
  osc.connect(g); g.connect(out)
  osc.start(t); osc.stop(t + dur + 0.01)
}

/** Filtered noise burst — transient, impact, whoosh */
function noise(
  ctx: AudioContext, out: AudioNode,
  dur: number, vol: number,
  lpFreq: number, hpFreq: number,
  delay = 0, decay = 2.5
) {
  const t   = ctx.currentTime + delay
  const len = Math.max(2, Math.ceil(ctx.sampleRate * dur))
  const buf = ctx.createBuffer(1, len, ctx.sampleRate)
  const d   = buf.getChannelData(0)
  for (let i = 0; i < len; i++)
    d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay)

  const src = ctx.createBufferSource(); src.buffer = buf
  const lp  = ctx.createBiquadFilter(); lp.type = "lowpass";  lp.frequency.value = lpFreq
  const hp  = ctx.createBiquadFilter(); hp.type = "highpass"; hp.frequency.value = hpFreq
  const g   = ctx.createGain(); g.gain.setValueAtTime(vol, t)

  src.connect(hp); hp.connect(lp); lp.connect(g); g.connect(out)
  src.start(t); src.stop(t + dur + 0.01)
}

/** Inharmonic metal ring — kim loại va chạm */
function metalRing(ctx: AudioContext, out: AudioNode, freq: number, vol: number, dur: number, delay = 0) {
  const t        = ctx.currentTime + delay
  const partials = [1, 2.756, 5.404, 8.933, 13.41]
  partials.forEach(r => {
    const osc = ctx.createOscillator()
    const g   = ctx.createGain()
    osc.type  = "sine"
    osc.frequency.value = freq * r
    const pv  = vol / (r * 0.9 + 0.1)
    g.gain.setValueAtTime(pv, t)
    g.gain.exponentialRampToValueAtTime(0.001, t + dur / Math.sqrt(r))
    osc.connect(g); g.connect(out)
    osc.start(t); osc.stop(t + dur + 0.01)
  })
}

/** Band-pass noise sweep — air whoosh */
function swoosh(
  ctx: AudioContext, out: AudioNode,
  fStart: number, fEnd: number,
  vol: number, dur: number, delay = 0, q = 3
) {
  const t   = ctx.currentTime + delay
  const len = Math.max(2, Math.ceil(ctx.sampleRate * dur))
  const buf = ctx.createBuffer(1, len, ctx.sampleRate)
  const d   = buf.getChannelData(0)
  for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1
  const src = ctx.createBufferSource(); src.buffer = buf

  const bp  = ctx.createBiquadFilter(); bp.type = "bandpass"; bp.Q.value = q
  bp.frequency.setValueAtTime(fStart, t)
  bp.frequency.exponentialRampToValueAtTime(Math.max(fEnd, 20), t + dur)

  const g = ctx.createGain()
  g.gain.setValueAtTime(0, t)
  g.gain.linearRampToValueAtTime(vol, t + dur * 0.25)
  g.gain.exponentialRampToValueAtTime(0.001, t + dur)

  src.connect(bp); bp.connect(g); g.connect(out)
  src.start(t); src.stop(t + dur + 0.01)
}

/** Minor chord stab — bất hòa, tối tăm */
function darkChord(ctx: AudioContext, out: AudioNode, root: number, vol: number, dur: number, delay = 0) {
  const t      = ctx.currentTime + delay
  // minor triad + ♭7
  const ratios = [1, 1.189, 1.498, 1.782]
  ratios.forEach((r, i) => {
    const osc = ctx.createOscillator()
    const g   = ctx.createGain()
    osc.type  = i === 0 ? "sawtooth" : "triangle"
    osc.frequency.value = root * r
    g.gain.setValueAtTime(0, t)
    g.gain.linearRampToValueAtTime(vol / (i + 1), t + 0.025)
    g.gain.exponentialRampToValueAtTime(0.001, t + dur)
    osc.connect(g); g.connect(out)
    osc.start(t); osc.stop(t + dur + 0.05)
  })
}

/** Double heartbeat pulse — sub-bass rhythm */
function heartbeat(ctx: AudioContext, out: AudioNode, delay = 0) {
  const beat = (d: number) => {
    thump(ctx, out, 58, 0.55, 0.13, delay + d)
    thump(ctx, out, 46, 0.32, 0.2,  delay + d + 0.11)
  }
  beat(0); beat(0.38)
}

// ══════════════════════════════════════════════════════════════════════════════
//  SOUND DEFINITIONS
// ══════════════════════════════════════════════════════════════════════════════

const SOUNDS: Record<SoundName, (ctx: AudioContext) => void> = {

  // ── ATTACK — Kiếm chém sắc, gọn ─────────────────────────────────────────
  attack: (ctx) => {
    const { dry, wet } = makeBus(ctx, 0.7, 0.3, 0.55)
    swoosh(ctx, dry,  1400, 3800, 0.38, 0.065)
    noise (ctx, dry,  0.055, 0.65, 5500, 900,  0.042, 3.5)
    metalRing(ctx, wet, 1900, 0.14, 0.22, 0.042)
    thump (ctx, dry,  125,  0.28, 0.16, 0.042)
  },

  // ── ATTACK HEAVY — Búa/rìu, nặng và chậm ────────────────────────────────
  attack_heavy: (ctx) => {
    const { dry, wet } = makeBus(ctx, 0.65, 0.42, 0.9)
    swoosh(ctx, dry, 500, 2200, 0.45, 0.11)
    noise (ctx, dry, 0.14, 0.85, 2800, 150, 0.09, 2.2)
    thump (ctx, dry, 85,  0.65, 0.45, 0.09)
    thump (ctx, dry, 55,  0.42, 0.65, 0.13)
    metalRing(ctx, wet, 850, 0.22, 0.7, 0.09)
  },

  // ── CRIT — Đòn chí mạng, brutal, vỡ xương ───────────────────────────────
  crit: (ctx) => {
    const { dry, wet } = makeBus(ctx, 0.58, 0.55, 1.1)

    // Distortion layer — brutal impact
    const dist  = makeDistNode(ctx, 200)
    const distG = ctx.createGain(); distG.gain.value = 0.42
    dist.connect(distG); distG.connect(dry)

    swoosh(ctx, dry,  900, 4500, 0.55, 0.075)
    // High crack — tiếng nứt vỡ
    noise(ctx, distG, 0.03, 1.1,  14000, 4500, 0.052, 6)
    // Body impact — low
    noise(ctx, dry,   0.22, 0.95, 900,   55,   0.052, 2)
    thump(ctx, dry,   170,  0.88, 0.38,  0.052)
    thump(ctx, dry,   82,   0.65, 0.55,  0.075)
    // Metal ring — tiếng vang dài sau đòn
    metalRing(ctx, wet, 2600, 0.38, 0.9, 0.052)
  },

  // ── SKILL — Phép thuật, năng lượng tụ và phóng ──────────────────────────
  skill: (ctx) => {
    const { dry, wet } = makeBus(ctx, 0.48, 0.65, 1.4)
    const t = ctx.currentTime

    // Charge — tần số dâng lên
    const charge  = ctx.createOscillator()
    const chargeG = ctx.createGain()
    charge.type = "sawtooth"
    charge.frequency.setValueAtTime(55, t)
    charge.frequency.exponentialRampToValueAtTime(440, t + 0.2)
    chargeG.gain.setValueAtTime(0, t)
    chargeG.gain.linearRampToValueAtTime(0.28, t + 0.12)
    chargeG.gain.exponentialRampToValueAtTime(0.001, t + 0.22)
    charge.connect(chargeG); chargeG.connect(wet)
    charge.start(t); charge.stop(t + 0.24)

    // Release burst
    swoosh(ctx, wet, 220, 3500, 0.55, 0.22, 0.17)
    noise (ctx, dry, 0.18, 0.5, 4500, 350, 0.19, 1.6)

    // Harmonic shimmer — phép thuật tỏa ra
    ;[220, 440, 660, 880, 1100, 1320].forEach((f, i) => {
      const osc = ctx.createOscillator()
      const g   = ctx.createGain()
      osc.type  = "sine"
      osc.frequency.setValueAtTime(f, t + 0.21)
      osc.frequency.linearRampToValueAtTime(f * 1.04, t + 0.35)
      g.gain.setValueAtTime(0, t + 0.19)
      g.gain.linearRampToValueAtTime(0.13 / (i * 0.6 + 1), t + 0.23)
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.75 + i * 0.09)
      osc.connect(g); g.connect(wet)
      osc.start(t + 0.19); osc.stop(t + 0.85 + i * 0.09)
    })
  },

  // ── SKILL DARK — Bóng tối, máu, hắc ám ─────────────────────────────────
  skill_dark: (ctx) => {
    const { dry, wet } = makeBus(ctx, 0.42, 0.72, 2.0)
    const t   = ctx.currentTime
    const dist = makeDistNode(ctx, 320)
    const distG = ctx.createGain(); distG.gain.value = 0.5
    dist.connect(distG); distG.connect(dry)

    darkChord(ctx, wet, 55, 0.32, 1.1)
    noise(ctx, dist, 0.35, 0.65, 550, 35, 0, 1.5)
    thump(ctx, dry,  48,  0.52, 0.9)
    thump(ctx, dry,  36,  0.32, 1.3, 0.12)

    // Ma quái overtones — giọng từ bóng tối
    ;[175, 262, 350].forEach((f, i) => {
      const osc = ctx.createOscillator()
      const g   = ctx.createGain()
      osc.type  = "sine"
      osc.frequency.setValueAtTime(f, t + i * 0.06)
      osc.frequency.linearRampToValueAtTime(f * 0.68, t + 0.95)
      g.gain.setValueAtTime(0.09, t + i * 0.06)
      g.gain.exponentialRampToValueAtTime(0.001, t + 1.1)
      osc.connect(g); g.connect(wet)
      osc.start(t + i * 0.06); osc.stop(t + 1.15)
    })
  },

  // ── HEAL — Hồi phục, ấm áp và huyền bí ─────────────────────────────────
  heal: (ctx) => {
    const { wet } = makeBus(ctx, 0.3, 0.75, 1.8)
    const t = ctx.currentTime
    // C minor pentatonic — vừa hy vọng vừa huyền bí
    ;[261, 311, 392, 466, 622, 784].forEach((freq, i) => {
      const osc  = ctx.createOscillator()
      const g    = ctx.createGain()
      // Vibrato nhẹ
      const lfo  = ctx.createOscillator()
      const lfoG = ctx.createGain()
      lfo.frequency.value = 5.2
      lfoG.gain.value     = 5
      lfo.connect(lfoG); lfoG.connect(osc.frequency)
      osc.type            = "sine"
      osc.frequency.value = freq
      const d = i * 0.095
      g.gain.setValueAtTime(0, t + d)
      g.gain.linearRampToValueAtTime(0.2, t + d + 0.035)
      g.gain.exponentialRampToValueAtTime(0.001, t + d + 0.55)
      osc.connect(g); g.connect(wet)
      osc.start(t + d); lfo.start(t + d)
      osc.stop(t + d + 0.6); lfo.stop(t + d + 0.6)
    })
    // Sparkle noise
    noise(ctx, wet, 0.35, 0.13, 9000, 3500, 0.1, 1.2)
    metalRing(ctx, wet, 1400, 0.1, 1.5, 0.12)
  },

  // ── MISS — Né tránh, gió vút qua ────────────────────────────────────────
  miss: (ctx) => {
    const { dry } = makeBus(ctx, 0.6, 0.0, 0.4)
    swoosh(ctx, dry, 2200, 650,  0.28, 0.13)
    noise (ctx, dry, 0.09, 0.18, 2200, 500, 0.025, 3.5)
  },

  // ── DEATH — Unit thường chết, nặng nề ───────────────────────────────────
  death: (ctx) => {
    const { dry, wet } = makeBus(ctx, 0.45, 0.72, 2.2)
    const t = ctx.currentTime

    // Impact cuối
    noise(ctx, dry, 0.1,  0.72, 2200, 75, 0,    2.2)
    thump(ctx, dry, 105,  0.55, 0.32, 0)
    // Ngã xuống
    noise(ctx, dry, 0.22, 0.55, 850,  55, 0.18, 2)
    thump(ctx, dry, 72,   0.65, 0.55, 0.2)
    // Hơi thở cuối — low drone tắt dần
    const breath  = ctx.createOscillator()
    const breathG = ctx.createGain()
    breath.type   = "sine"
    breath.frequency.setValueAtTime(115, t + 0.32)
    breath.frequency.exponentialRampToValueAtTime(52, t + 1.3)
    breathG.gain.setValueAtTime(0, t + 0.32)
    breathG.gain.linearRampToValueAtTime(0.2, t + 0.48)
    breathG.gain.exponentialRampToValueAtTime(0.001, t + 1.5)
    breath.connect(breathG); breathG.connect(wet)
    breath.start(t + 0.32); breath.stop(t + 1.55)
    // Noise tail tối
    const dist  = makeDistNode(ctx, 110)
    const distG = ctx.createGain(); distG.gain.value = 0.28
    dist.connect(distG); distG.connect(wet)
    noise(ctx, dist, 0.65, 0.35, 280, 38, 0.22, 1.2)
  },

  // ── DEATH BOSS — Boss chết, địa chấn ───────────────────────────────────
  death_boss: (ctx) => {
    const { dry, wet } = makeBus(ctx, 0.42, 0.85, 3.5)
    heartbeat(ctx, wet, 0)
    // Massive impact
    noise(ctx, dry, 0.18, 1.0,  3500, 28, 0.42, 1.5)
    thump(ctx, dry, 130,  0.95, 0.65, 0.42)
    thump(ctx, dry, 55,   0.75, 1.6,  0.46)
    darkChord(ctx, wet, 55, 0.42, 3.2, 0.52)
    // Tiếng rơi — sweep xuống đáy
    const t    = ctx.currentTime
    const fall = ctx.createOscillator()
    const fG   = ctx.createGain()
    fall.type  = "sawtooth"
    fall.frequency.setValueAtTime(210, t + 0.52)
    fall.frequency.exponentialRampToValueAtTime(18,  t + 2.8)
    fG.gain.setValueAtTime(0.38, t + 0.52)
    fG.gain.exponentialRampToValueAtTime(0.001, t + 3.0)
    fall.connect(fG); fG.connect(wet)
    fall.start(t + 0.52); fall.stop(t + 3.05)
    noise(ctx, wet, 2.2, 0.55, 520, 28, 0.62, 1)
  },

  // ── VICTORY — Chiến thắng, fanfare dark fantasy ──────────────────────────
  victory: (ctx) => {
    const { dry, wet } = makeBus(ctx, 0.48, 0.65, 2.2)
    const t = ctx.currentTime

    // Percussion hit mở đầu
    noise(ctx, dry, 0.09, 0.65, 4500, 180, 0, 3.5)
    thump(ctx, dry, 145, 0.65, 0.28)
    metalRing(ctx, wet, 950, 0.18, 1.2, 0.02)

    // Brass fanfare — sawtooth qua lowpass filter sweep
    const fanfare = [
      [220, 0.12], [277, 0.25], [330, 0.38],
      [440, 0.52], [554, 0.67], [659, 0.82],
    ] as [number, number][]
    fanfare.forEach(([f, d]) => {
      const osc  = ctx.createOscillator()
      const filt = ctx.createBiquadFilter()
      const g    = ctx.createGain()
      osc.type   = "sawtooth"
      osc.frequency.value = f
      filt.type  = "lowpass"
      filt.frequency.setValueAtTime(750, t + d)
      filt.frequency.linearRampToValueAtTime(3200, t + d + 0.055)
      filt.frequency.exponentialRampToValueAtTime(380, t + d + 0.42)
      g.gain.setValueAtTime(0, t + d)
      g.gain.linearRampToValueAtTime(0.26, t + d + 0.022)
      g.gain.exponentialRampToValueAtTime(0.001, t + d + 0.48)
      osc.connect(filt); filt.connect(g); g.connect(wet)
      osc.start(t + d); osc.stop(t + d + 0.52)
    })

    // Final chord swell
    ;[220, 277, 330, 440].forEach((f, i) => {
      const osc = ctx.createOscillator()
      const g   = ctx.createGain()
      osc.type  = i === 0 ? "sawtooth" : "triangle"
      osc.frequency.value = f
      g.gain.setValueAtTime(0, t + 1.05)
      g.gain.linearRampToValueAtTime(0.22 / (i * 0.5 + 1), t + 1.15)
      g.gain.exponentialRampToValueAtTime(0.001, t + 2.8)
      osc.connect(g); g.connect(wet)
      osc.start(t + 1.05); osc.stop(t + 2.85)
    })
    metalRing(ctx, wet, 880,  0.22, 3.2, 0.98)
    metalRing(ctx, wet, 1320, 0.16, 2.5, 1.02)
  },

  // ── DEFEAT — Thất bại, bi thương, heartbeat dừng lại ────────────────────
  defeat: (ctx) => {
    const { dry, wet } = makeBus(ctx, 0.35, 0.82, 3.2)
    const t = ctx.currentTime

    // Heartbeat chậm dần rồi dừng
    heartbeat(ctx, wet, 0)
    heartbeat(ctx, wet, 0.85)
    thump(ctx, wet, 52, 0.3, 0.22, 1.82)   // nhịp yếu dần
    thump(ctx, wet, 42, 0.15, 0.3, 1.94)   // rồi im

    // Elegy — giai điệu bi thương đi xuống
    ;[330, 294, 262, 233, 196, 175, 147].forEach((f, i) => {
      const osc = ctx.createOscillator()
      const g   = ctx.createGain()
      osc.type  = "triangle"
      osc.frequency.value = f
      const d   = 0.45 + i * 0.24
      g.gain.setValueAtTime(0, t + d)
      g.gain.linearRampToValueAtTime(0.19, t + d + 0.04)
      g.gain.exponentialRampToValueAtTime(0.001, t + d + 0.9)
      osc.connect(g); g.connect(wet)
      osc.start(t + d); osc.stop(t + d + 0.95)
    })

    darkChord(ctx, wet, 55, 0.28, 3.5, 1.9)

    // Sub drone — màn đêm buông xuống
    const drone  = ctx.createOscillator()
    const droneG = ctx.createGain()
    drone.type   = "sawtooth"
    drone.frequency.value = 55
    droneG.gain.setValueAtTime(0, t + 2.1)
    droneG.gain.linearRampToValueAtTime(0.22, t + 2.6)
    droneG.gain.exponentialRampToValueAtTime(0.001, t + 5.0)
    drone.connect(droneG); droneG.connect(wet)
    drone.start(t + 2.1); drone.stop(t + 5.1)

    noise(ctx, wet, 2.2, 0.22, 280, 28, 2.6, 1)
  },

  // ── BUY — Vàng, coin jingle ──────────────────────────────────────────────
  buy: (ctx) => {
    const { dry, wet } = makeBus(ctx, 0.48, 0.55, 0.7)
    ;[1650, 1980, 2310, 1820, 2145].forEach((f, i) =>
      metalRing(ctx, wet, f, 0.16, 0.55, i * 0.052)
    )
    thump(ctx, dry, 210, 0.22, 0.16, 0.02)
  },

  // ── LEVEL UP — Power surge, sức mạnh mới bùng phát ──────────────────────
  levelup: (ctx) => {
    const { dry, wet } = makeBus(ctx, 0.44, 0.68, 1.9)
    const t = ctx.currentTime

    // Sub surge — năng lượng dâng
    const surge  = ctx.createOscillator()
    const surgeG = ctx.createGain()
    surge.type   = "sine"
    surge.frequency.setValueAtTime(38, t)
    surge.frequency.exponentialRampToValueAtTime(165, t + 0.52)
    surgeG.gain.setValueAtTime(0.42, t)
    surgeG.gain.exponentialRampToValueAtTime(0.001, t + 0.58)
    surge.connect(surgeG); surgeG.connect(dry)
    surge.start(t); surge.stop(t + 0.62)

    noise(ctx, wet, 0.42, 0.42, 6500, 180, 0, 1.6)

    // Major chord bùng lên
    ;[220, 277, 330, 415, 554].forEach((f, i) => {
      const osc = ctx.createOscillator()
      const g   = ctx.createGain()
      osc.type  = i < 2 ? "sawtooth" : "triangle"
      osc.frequency.setValueAtTime(f * 0.48, t + 0.32)
      osc.frequency.exponentialRampToValueAtTime(f, t + 0.47)
      g.gain.setValueAtTime(0, t + 0.3)
      g.gain.linearRampToValueAtTime(0.24 / (i * 0.42 + 1), t + 0.44)
      g.gain.exponentialRampToValueAtTime(0.001, t + 1.6 + i * 0.1)
      osc.connect(g); g.connect(wet)
      osc.start(t + 0.3); osc.stop(t + 1.7 + i * 0.1)
    })
    metalRing(ctx, wet, 1100, 0.22, 2.2, 0.52)
    metalRing(ctx, wet, 1650, 0.16, 1.7, 0.57)
  },

  // ── UI CLICK — Đá/kim loại nhẹ ──────────────────────────────────────────
  ui_click: (ctx) => {
    const { dry, wet } = makeBus(ctx, 0.5, 0.38, 0.28)
    metalRing(ctx, wet, 1250, 0.12, 0.18)
    noise(ctx, dry, 0.022, 0.28, 5500, 1100, 0, 5.5)
  },

  // ── DOT — Burn/Poison/Bleed tick — đau âm ỉ ─────────────────────────────
  dot: (ctx) => {
    const { dry, wet } = makeBus(ctx, 0.48, 0.42, 0.45)
    noise(ctx, dry, 0.09, 0.32, 3200, 650, 0, 3.2)
    thump(ctx, wet, 92, 0.22, 0.12)
  },

  // ── SHIELD BLOCK — Giáp chắn đòn ────────────────────────────────────────
  shield_block: (ctx) => {
    const { dry, wet } = makeBus(ctx, 0.55, 0.52, 0.75)
    noise(ctx, dry, 0.07, 0.75, 6500, 550, 0, 4.2)
    thump(ctx, dry, 185, 0.55, 0.22)
    metalRing(ctx, wet, 1150, 0.32, 0.65)
    metalRing(ctx, wet, 820,  0.22, 0.85, 0.022)
  },

  // ── STUN — Choáng váng, tiếng trong đầu ─────────────────────────────────
  stun: (ctx) => {
    const { dry, wet } = makeBus(ctx, 0.38, 0.72, 0.95)
    const t = ctx.currentTime

    metalRing(ctx, wet, 2100, 0.32, 1.6)
    // Wobble — tiếng vang trong đầu khi bị choáng
    const wob    = ctx.createOscillator()
    const wobLFO = ctx.createOscillator()
    const wobG   = ctx.createGain()
    const lfoG   = ctx.createGain()
    wob.type     = "sine"
    wob.frequency.value  = 450
    wobLFO.frequency.value = 14
    lfoG.gain.value      = 90
    wobLFO.connect(lfoG); lfoG.connect(wob.frequency)
    wobG.gain.setValueAtTime(0, t)
    wobG.gain.linearRampToValueAtTime(0.22, t + 0.055)
    wobG.gain.exponentialRampToValueAtTime(0.001, t + 0.85)
    wob.connect(wobG); wobG.connect(wet)
    wob.start(t); wobLFO.start(t)
    wob.stop(t + 0.9); wobLFO.stop(t + 0.9)

    thump(ctx, dry, 210, 0.42, 0.16)
    noise(ctx, dry, 0.045, 0.42, 4200, 850, 0, 5.5)
  },
}

// ══════════════════════════════════════════════════════════════════════════════
//  GLOBAL MUTE
// ══════════════════════════════════════════════════════════════════════════════
let _globalMuted = false
export function getSoundMuted()  { return _globalMuted }
export function setSoundMuted(v: boolean) { _globalMuted = v }
export function toggleSoundMuted() { _globalMuted = !_globalMuted; return _globalMuted }

// ══════════════════════════════════════════════════════════════════════════════
//  HOOK
// ══════════════════════════════════════════════════════════════════════════════
export function useSound() {
  const ctxRef     = useRef<AudioContext | null>(null)
  const enabledRef = useRef(true)

  const ensureCtx = useCallback(() => {
    if (!ctxRef.current) ctxRef.current = createAudioContext()
    if (ctxRef.current?.state === "suspended") ctxRef.current.resume()
    return ctxRef.current
  }, [])

  const play = useCallback((name: SoundName) => {
    if (!enabledRef.current || _globalMuted) return
    try {
      const ctx = ensureCtx()
      if (!ctx) return
      SOUNDS[name]?.(ctx)
    } catch {
      // Lỗi audio không crash game
    }
  }, [ensureCtx])

  const setEnabled  = useCallback((v: boolean) => { enabledRef.current = v }, [])
  const isEnabled   = useCallback(() => enabledRef.current, [])

  useEffect(() => () => { ctxRef.current?.close() }, [])

  return { play, setEnabled, isEnabled }
}
