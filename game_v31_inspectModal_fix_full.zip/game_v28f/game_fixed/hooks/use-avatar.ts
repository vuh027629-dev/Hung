"use client"

import { useMemo } from "react"
import { getAvatar, svgToDataUrl, type AvatarRequest } from "@/lib/game/avatar-cache"
import { getAvatar2 } from "@/lib/game/avatar2"

/**
 * Hook that returns an img src for a unit's avatar.
 * Checks avatar2 (static images) first, then falls back to avatar-cache SVGs.
 */
export function useAvatar(req: AvatarRequest | null): string | null {
  return useMemo(() => {
    if (!req) return null
    // Ưu tiên file avatar thứ 2 (ảnh tĩnh)
    const static2 = getAvatar2(req.templateId)
    if (static2) return static2
    // Fallback: avatar-cache
    const svg = getAvatar(req)
    return svg ? svgToDataUrl(svg) : null
  }, [req?.templateId, req?.isEnemy]) // eslint-disable-line react-hooks/exhaustive-deps
}
