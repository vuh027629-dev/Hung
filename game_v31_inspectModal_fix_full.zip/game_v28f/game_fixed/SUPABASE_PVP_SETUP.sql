-- ============================================================
-- Aetheria PvP — Supabase Setup SQL
-- Chạy trong Supabase Dashboard > SQL Editor
-- ============================================================

-- 1. Bảng lời mời PvP
CREATE TABLE IF NOT EXISTS public.pvp_invites (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_user    text NOT NULL,   -- username của người gửi
  to_user      text NOT NULL,   -- username của người nhận
  from_team    jsonb NOT NULL,  -- team (OwnedHero[]) của người gửi
  from_stats   jsonb NOT NULL,  -- playerStats của người gửi
  status       text NOT NULL DEFAULT 'pending',  -- pending | accepted | declined | expired
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- 2. Tự xóa các invite cũ hơn 5 phút
CREATE OR REPLACE FUNCTION public.cleanup_pvp_invites()
RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  DELETE FROM public.pvp_invites
  WHERE created_at < now() - INTERVAL '5 minutes';
END;
$$;

-- 3. RLS
ALTER TABLE public.pvp_invites ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can read pvp invites" ON public.pvp_invites;
DROP POLICY IF EXISTS "Anyone can insert pvp invites" ON public.pvp_invites;
DROP POLICY IF EXISTS "Anyone can update pvp invites" ON public.pvp_invites;

CREATE POLICY "Anyone can read pvp invites"
  ON public.pvp_invites FOR SELECT USING (true);

CREATE POLICY "Anyone can insert pvp invites"
  ON public.pvp_invites FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can update pvp invites"
  ON public.pvp_invites FOR UPDATE USING (true);

-- 4. Enable Realtime cho bảng pvp_invites
ALTER PUBLICATION supabase_realtime ADD TABLE public.pvp_invites;
