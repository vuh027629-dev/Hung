import type { HeroTemplate, Rarity, Stats } from "./types"
import { getOrderInnateForHero } from "./order-innates"

// Default zero stat block helper
const z: Stats = {
  hp: 0,
  atk: 0,
  mag: 0,
  def: 0,
  res: 0,
  spd: 0,
  crit: 0,
  critDmg: 0,
  acc: 0,
  eva: 0,
  lifesteal: 0,
}

const s = (over: Partial<Stats>): Stats => ({ ...z, ...over })

// 48 heroes across 6 rarities (common 5, rare 8, epic 10, legendary 11, mythic 7, celestial 7)
export const HEROES: HeroTemplate[] = [
  // ============================================================
  // COMMON (5)
  // ============================================================
  {
    id: "h_borin",
    name: "Borin Thạch Phủ",
    title: "Lính Đánh Thuê Vùng Biên",
    rarity: "common",
    range: "melee",
    role: "warrior",
    origins: ["human"],
    baseStats: s({ hp: 2450, atk: 66, def: 140, res: 80, spd: 90, crit: 5, critDmg: 150, acc: 95 }),
    growth: { hp: 162, atk: 5.4, def: 10, res: 6, spd: 1 },
    skills: ["slash", "doubleStrike", "whirlwind"],
    bonusSkills: [
      { skillId: "executioner", unlockCondition: { type: "heroLevel", level: 30 } },
      { skillId: "bleedSlash", unlockCondition: { type: "allSkillsLevel", level: 3 } },
    ],
    passive: "ironWill",
    build: "bruiser",
    flavor: "Một cựu lính đánh thuê dày dạn, với chiếc rìu đôi và lời thề bảo vệ kẻ yếu.",
  },
  {
    id: "h_lyrra",
    name: "Lyrra Thanh Phong",
    title: "Cung Thủ Rừng Xanh",
    rarity: "common",
    range: "ranged",
    role: "marksman",
    origins: ["human"],
    baseStats: s({ hp: 2000, atk: 63, def: 84, res: 70, spd: 115, crit: 12, critDmg: 158, acc: 100 }),
    growth: { hp: 125, atk: 6.0, spd: 2, crit: 0.5 , def: 4, res: 4 },
    skills: ["pierceShot", "rapidFire", "volley"],
        bonusSkills: [
      { skillId: "windArrow", unlockCondition: { type: "heroLevel", level: 20 } },
      { skillId: "phantomArrow", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "marksmanship",
    build: "attack-speed",
    flavor: "Cung thủ trẻ tuổi với mũi tên không bao giờ chệch hướng giữa làn gió rừng.",
  },
  {
    id: "h_grom",
    name: "Grom Răng Sói",
    title: "Chiến Binh Bộ Lạc",
    rarity: "common",
    range: "melee",
    role: "warrior",
    origins: ["beastkin"],
    baseStats: s({ hp: 2650, atk: 71, def: 130, res: 60, spd: 100, crit: 8, critDmg: 150, acc: 95 }),
    growth: { hp: 175, atk: 6.0, def: 8, spd: 1 , res: 4 },
    skills: ["slash", "feralLeap", "whirlwind"],
        bonusSkills: [
      { skillId: "packHowl", unlockCondition: { type: "heroLevel", level: 20 } },
      { skillId: "berserkerRage", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "feralInstinct",
    build: "bruiser",
    flavor: "Hậu duệ bộ lạc sói tuyết, săn dữ thú từ tuổi mười ba.",
  },
  {
    id: "h_mirelle",
    name: "Mirelle Hồ Bích",
    title: "Học Trò Pháp Sư",
    rarity: "common",
    range: "ranged",
    role: "mage",
    origins: ["human"],
    baseStats: s({ hp: 1775, atk: 30, mag: 71, def: 76, res: 130, spd: 95, crit: 10, critDmg: 150 , acc: 85 }),
    growth: { hp: 112, mag: 7.2, res: 6 , def: 4 },
    skills: ["arcaneBolt", "fireball", "chainLightning"],
        bonusSkills: [
      { skillId: "manaShatter", unlockCondition: { type: "heroLevel", level: 18 } },
      { skillId: "spellMirror", unlockCondition: { type: "allSkillsLevel", level: 3 } },
    ],
    passive: "arcaneAffinity",
    build: "burst",
    flavor: "Cô gái ham hiểu biết, học tinh thuật từ một quyển sách cũ trong rừng.",
  },
  {
    id: "h_otto",
    name: "Otto Khiên Sắt",
    title: "Cận Vệ Thành Phố",
    rarity: "common",
    range: "melee",
    role: "tank",
    origins: ["human"],
    baseStats: s({ hp: 3625, atk: 48, def: 224, res: 164, spd: 70, crit: 3, critDmg: 150, acc: 95 }),
    growth: { hp: 250, atk: 3.6, def: 16, res: 8 },
    skills: ["shieldBash", "ironBulwark", "taunt"],
        bonusSkills: [
      { skillId: "immovableStance", unlockCondition: { type: "heroLevel", level: 20 } },
      { skillId: "fortressBreaker", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "fortress",
    build: "tank",
    flavor: "Lính cận vệ trung thành, chiếc khiên đã chặn cả ngàn mũi tên.",
  },

  // ============================================================
  // RARE (5)
  // ============================================================
  {
    id: "h_zara",
    name: "Zara Lưỡi Bóng",
    title: "Sát Thủ Hội Trăng",
    rarity: "rare",
    range: "melee",
    role: "assassin",
    origins: ["human", "outlaw"],
    baseStats: s({ hp: 2200, atk: 87, def: 104, res: 96, spd: 130, crit: 20, critDmg: 170, acc: 100 }),
    growth: { hp: 138, atk: 7.8, spd: 2, crit: 1 , def: 4, res: 4 },
    skills: ["shadowStrike", "bladeDance", "deathMark"],
    bonusSkills: [
      { skillId: "finalEclipse", unlockCondition: { type: "twoSkillsMaxLevel" } },
      { skillId: "poisonDart", unlockCondition: { type: "heroLevel", level: 25 } },
    ],
    passive: "shadowblade",
    build: "carry",
    flavor: "Cô lưu lạc giữa mạng lưới ngầm thành phố, chuyên xử lý quý tộc thối nát.",
  },
  {
    id: "h_thalas",
    name: "Thalas Lửa Ngàn",
    title: "Pyromancer Tha Hương",
    rarity: "rare",
    range: "ranged",
    role: "mage",
    origins: ["human", "elemental"],
    baseStats: s({ hp: 1925, atk: 30, mag: 91, def: 84, res: 152, spd: 100, crit: 12, critDmg: 160 , acc: 85 }),
    growth: { hp: 125, mag: 9.0, res: 6 , def: 4 },
    skills: ["fireball", "iceLance", "meteor"],
        bonusSkills: [
      { skillId: "glacialTrap", unlockCondition: { type: "heroLevel", level: 22 } },
      { skillId: "infernalCore", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "elementalSurge",
    build: "burst",
    flavor: "Cha mẹ mất trong trận hỏa hoạn, anh học cách điều khiển ngọn lửa của định mệnh.",
  },
  {
    id: "h_ravi",
    name: "Ravi Móng Hổ",
    title: "Đấu Sĩ Hổ Tộc",
    rarity: "rare",
    range: "melee",
    role: "warrior",
    origins: ["beastkin"],
    baseStats: s({ hp: 2875, atk: 84, def: 164, res: 80, spd: 110, crit: 12, critDmg: 160, acc: 95, lifesteal: 10 }),
    growth: { hp: 200, atk: 7.2, def: 10, lifesteal: 0.5 , res: 4 },
    skills: ["bleedSlash", "feralLeap", "whirlwind"],
        bonusSkills: [
      { skillId: "woundDeepen", unlockCondition: { type: "heroLevel", level: 20 } },
      { skillId: "tigerPounce", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "bloodthirst",
    build: "bruiser",
    flavor: "Lãnh chúa mới của bộ lạc Hổ Vàng, vuốt anh sắc như lưỡi dao tử thần.",
  },
  {
    id: "h_ember",
    name: "Ember Núi Khói",
    title: "Pháo Thủ Lưu Vong",
    rarity: "rare",
    range: "ranged",
    role: "marksman",
    origins: ["human", "outlaw"],
    baseStats: s({ hp: 2075, atk: 81, def: 96, res: 96, spd: 125, crit: 20, critDmg: 170, acc: 100 }),
    growth: { hp: 138, atk: 6.6, spd: 2 , def: 4, res: 4 },
    skills: ["pierceShot", "rapidFire", "trueShot"],
        bonusSkills: [
      { skillId: "scatterBomb", unlockCondition: { type: "heroLevel", level: 20 } },
      { skillId: "deadEyeShot", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "marksmanship",
    build: "attack-speed",
    flavor: "Một xạ thủ bị truy nã, súng trường cô không bao giờ rời tay.",
  },
  {
    id: "h_priestess",
    name: "Aelinor Ánh Bạc",
    title: "Nữ Tu Vầng Trăng",
    rarity: "rare",
    range: "ranged",
    role: "support",
    origins: ["human", "celestial"],
    baseStats: s({ hp: 2200, atk: 30, mag: 72, def: 116, res: 180, spd: 95, crit: 5, critDmg: 150 , acc: 85 }),
    growth: { hp: 162, mag: 7.2, res: 10 , def: 4 },
    skills: ["heal", "blessing", "groupHeal"],
        bonusSkills: [
      { skillId: "prayerShield", unlockCondition: { type: "heroLevel", level: 22 } },
      { skillId: "moonlightSurge", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "guardianAura",
    build: "support",
    flavor: "Người được ban phước bởi Nữ Thần Trăng, ánh sáng cô chữa lành mọi vết thương.",
  },

  // ============================================================
  // EPIC (5)
  // ============================================================
  {
    id: "h_kael",
    name: "Kael Thiên Lôi",
    title: "Hoàng Tử Sấm",
    rarity: "epic",
    range: "melee",
    role: "warrior",
    origins: ["human", "elemental"],
    baseStats: s({ hp: 3300, atk: 99, mag: 36, def: 188, res: 136, spd: 115, crit: 18, critDmg: 170 }),
    growth: { hp: 225, atk: 8.4, def: 12, spd: 2 , res: 6 },
    skills: ["slash", "chainLightning", "thunderOath"],
    bonusSkills: [
      { skillId: "executioner", unlockCondition: { type: "heroLevel", level: 25 } },
      { skillId: "bleedSlash", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "lightningRod",
    build: "bruiser",
    flavor: "Mang trong mình huyết thống thần sấm, mỗi đòn chém đều nổ tung như tia chớp — và anh hấp thụ mọi sét để đánh trở lại mạnh hơn.",
  },
  {
    id: "h_nyx",
    name: "Nyx Vũ Bóng",
    title: "Sát Thủ Hư Vô",
    rarity: "epic",
    range: "melee",
    role: "assassin",
    origins: ["demon", "outlaw"],
    baseStats: s({ hp: 2400, atk: 105, def: 116, res: 116, spd: 145, crit: 28, critDmg: 185, acc: 100, lifesteal: 15 }),
    growth: { hp: 150, atk: 9.0, spd: 2, crit: 1.5 , def: 6, res: 6 },
    skills: ["shadowStrike", "deathMark", "voidEclipse"],
    bonusSkills: [
      { skillId: "bloodFrenzy", unlockCondition: { type: "twoSkillsMaxLevel" } },
      { skillId: "bladeDance", unlockCondition: { type: "skillCombo", skillIds: ["shadowStrike", "deathMark"] } },
    ],
    passive: "voidPredator",
    build: "carry",
    flavor: "Bóng tối là vũ khí, nỗi sợ là thuốc độc — Nyx hòa vào hư vô rồi gặt hái linh hồn trước khi nạn nhân kịp nhận ra.",
  },
  {
    id: "h_ozric",
    name: "Ozric Mắt Bão",
    title: "Đại Pháp Sư Băng",
    rarity: "epic",
    range: "ranged",
    role: "mage",
    origins: ["ancient", "elemental"],
    baseStats: s({ hp: 2200, atk: 30, mag: 107, def: 108, res: 180, spd: 105, crit: 15, critDmg: 170 , acc: 85 }),
    growth: { hp: 150, mag: 10.8, res: 8 , def: 6 },
    skills: ["iceLance", "chainLightning", "glacialPrison"],
    bonusSkills: [
      { skillId: "meteor", unlockCondition: { type: "allSkillsLevel", level: 4 } },
      { skillId: "iceAge", unlockCondition: { type: "battlesWon", count: 50 } },
    ],
    passive: "stormEye",
    build: "burst",
    flavor: "Một học giả 300 tuổi trong tháp băng — mắt anh quan sát cả vũ trụ như trận bão, và anh là tâm điểm tĩnh lặng của nó.",
  },
  {
    id: "h_vex",
    name: "Vex Cánh Sắt",
    title: "Lính Đánh Thuê Tương Lai",
    rarity: "epic",
    range: "ranged",
    role: "marksman",
    origins: ["cyber", "outlaw"],
    baseStats: s({ hp: 2425, atk: 102, def: 130, res: 116, spd: 135, crit: 22, critDmg: 180, acc: 100 }),
    growth: { hp: 162, atk: 7.8, spd: 2 , def: 6, res: 6 },
    skills: ["pierceShot", "cyberOverdrive", "droneSalvo"],
    bonusSkills: [
      { skillId: "cyberRailgun", unlockCondition: { type: "heroLevel", level: 25 } },
      { skillId: "rapidFire", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "combatProtocol",
    build: "carry",
    flavor: "Bán mình cho tập đoàn công nghệ cổ, giờ cánh tay máy của Vex triển khai bầy drone tử thần trước khi đối thủ kịp nhắm súng.",
  },
  {
    id: "h_morgath",
    name: "Morgath Vĩnh Cửu",
    title: "Hộ Vệ Lăng Mộ",
    rarity: "epic",
    range: "melee",
    role: "tank",
    origins: ["undead", "ancient"],
    baseStats: s({ hp: 5250, atk: 57, def: 336, res: 224, spd: 75, crit: 5, critDmg: 150, lifesteal: 20 }),
    growth: { hp: 325, atk: 4.2, def: 18, res: 10 },
    skills: ["shieldBash", "ironBulwark", "tombCurse"],
    bonusSkills: [
      { skillId: "soulChain", unlockCondition: { type: "heroLevel", level: 25 } },
      { skillId: "earthquake", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "deathlessGuard",
    build: "tank",
    flavor: "Một hiệp sĩ chết hàng ngàn năm trước, vẫn đứng gác lăng mộ chủ nhân — và lời nguyền cổ đại trong người anh sẽ không bao giờ để anh ngã.",
  },

  // ============================================================
  // LEGENDARY (5)
  // ============================================================
  {
    id: "h_seraphine",
    name: "Seraphine Bình Minh",
    title: "Thiên Thần Trừng Phạt",
    rarity: "legendary",
    range: "ranged",
    role: "support",
    origins: ["celestial", "human"],
    baseStats: s({ hp: 3025, atk: 42, mag: 120, def: 160, res: 240, spd: 115, crit: 12, critDmg: 170 , acc: 85 }),
    growth: { hp: 225, mag: 13.2, res: 12 , def: 8 },
    skills: ["heal", "blessing", "divineAscension"],
    bonusSkills: [
      { skillId: "groupHeal", unlockCondition: { type: "heroLevel", level: 28 } },
      { skillId: "resurrection", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "absoluteLight",
    build: "support",
    flavor: "Thiên thần được phái xuống trần để gìn giữ ánh sáng cuối cùng — và khi đồng đội gần chết, cô sẽ không để họ ra đi.",
  },
  {
    id: "h_drakthar",
    name: "Drakthar Long Nhãn",
    title: "Đại Đế Long Tộc",
    rarity: "legendary",
    range: "melee",
    role: "warrior",
    origins: ["dragon", "ancient"],
    baseStats: s({ hp: 4162, atk: 120, mag: 60, def: 236, res: 180, spd: 110, crit: 20, critDmg: 180 }),
    growth: { hp: 275, atk: 10.2, def: 14, spd: 2 , res: 8 },
    skills: ["bleedSlash", "dragonRoar", "ancestralRage"],
    bonusSkills: [
      { skillId: "dragonBreath", unlockCondition: { type: "heroLevel", level: 30 } },
      { skillId: "executioner", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "dragonbloodHeir",
    build: "bruiser",
    flavor: "Vị vua cuối cùng của Long Tộc — vảy ngài cứng hơn thép thần, và khi thịnh nộ, ngài giải phóng hình rồng cổ đại hủy diệt mọi thứ trước mặt.",
  },
  {
    id: "h_velka",
    name: "Velka Tử Thi Vũ",
    title: "Nữ Hoàng Bất Tử",
    rarity: "legendary",
    range: "ranged",
    role: "mage",
    origins: ["undead", "demon"],
    baseStats: s({ hp: 2750, atk: 36, mag: 126, def: 150, res: 190, spd: 110, crit: 18, critDmg: 180, lifesteal: 14 , acc: 85 }),
    growth: { hp: 188, mag: 13.8, res: 10, lifesteal: 0.5 , def: 6 },
    skills: ["soulDrain", "fireball", "undyingDance"],
    bonusSkills: [
      { skillId: "undeadArmy", unlockCondition: { type: "heroLevel", level: 28 } },
      { skillId: "doomCurse", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "necrodancer",
    build: "burst",
    flavor: "Vũ điệu của Velka đánh thức nghìn xác chết — mỗi linh hồn địch chết đi lại khiến cô trở nên mạnh hơn.",
  },
  {
    id: "h_silvanir",
    name: "Silvanir Cung Sao",
    title: "Vua Bắn Trên Đỉnh Núi",
    rarity: "legendary",
    range: "ranged",
    role: "marksman",
    origins: ["ancient", "celestial"],
    baseStats: s({ hp: 2750, atk: 120, def: 156, res: 160, spd: 150, crit: 30, critDmg: 200, acc: 110 }),
    growth: { hp: 188, atk: 9.6, spd: 3, crit: 1 , def: 6, res: 6 },
    skills: ["pierceShot", "rapidFire", "constellationArrow"],
    bonusSkills: [
      { skillId: "trueShot", unlockCondition: { type: "battlesWon", count: 30 } },
      { skillId: "volley", unlockCondition: { type: "skillCombo", skillIds: ["pierceShot", "rapidFire"] } },
    ],
    passive: "celestialAim",
    build: "attack-speed",
    flavor: "Cung của Silvanir được rèn bằng tia sáng đầu tiên của vũ trụ — mỗi mũi tên là một ngôi sao tắt đánh dấu tử huyệt.",
  },
  {
    id: "h_kazumi",
    name: "Kazumi Lưỡi Mưa",
    title: "Sát Thủ Sương Mù",
    rarity: "legendary",
    range: "melee",
    role: "assassin",
    origins: ["beastkin", "outlaw"],
    baseStats: s({ hp: 2675, atk: 117, def: 140, res: 130, spd: 148, crit: 25, critDmg: 200, acc: 105, lifesteal: 20 }),
    growth: { hp: 175, atk: 10.8, spd: 3, crit: 1.5 , def: 6, res: 6 },
    skills: ["bladeDance", "outlawAmbush", "rainDeath"],
    bonusSkills: [
      { skillId: "mirrorKill", unlockCondition: { type: "heroLevel", level: 28 } },
      { skillId: "finalEclipse", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "rainbladeMaster",
    build: "carry",
    flavor: "Một bóng đen giữa làn mưa — Kazumi nhân bản chớp mắt, 5 phân thân từ 5 hướng, không ai biết đâu là thật.",
  },

  // ============================================================
  // MYTHIC (5)
  // ============================================================
  {
    id: "h_zerathus",
    name: "Zerathus Hủy Thế",
    title: "Vị Thần Quên Lãng",
    rarity: "mythic",
    range: "ranged",
    role: "mage",
    origins: ["ancient", "demon", "elemental"],
    baseStats: s({ hp: 5362, atk: 29, mag: 110, def: 276, res: 390, spd: 125, crit: 25, critDmg: 200 , acc: 85 }),
    growth: { hp: 357.0, mag: 11.8, res: 18.0 , def: 12.0 },
    skills: ["voidRift", "meteor", "oblivionPulse"],
    bonusSkills: [
      { skillId: "chainLightning", unlockCondition: { type: "heroLevel", level: 40 } },
      { skillId: "arcaneNova", unlockCondition: { type: "twoSkillsMaxLevel" } },
      { skillId: "divineWrath", unlockCondition: { type: "battlesWon", count: 80 } },
    ],
    passive: "ancientAnnihilator",
    build: "burst",
    flavor: "Bị các vị thần nhốt trong giếng hư vô ngàn năm — giờ Zerathus trở lại, mỗi lượt tước đoạt sức mạnh địch rồi xóa sổ tất cả.",
  },
  {
    id: "h_orin",
    name: "Orin Lưỡi Vô Cực",
    title: "Hiệp Sĩ Cuối Cùng",
    rarity: "mythic",
    range: "melee",
    role: "warrior",
    origins: ["human", "celestial", "ancient"],
    baseStats: s({ hp: 7332, atk: 103, def: 456, res: 372, spd: 120, crit: 25, critDmg: 200, acc: 100 }),
    growth: { hp: 487.5, atk: 8.4, def: 24.0, spd: 2 , res: 15.0 },
    skills: ["bleedSlash", "executioner", "infiniteBlade"],
    bonusSkills: [
      { skillId: "whirlwind", unlockCondition: { type: "heroLevel", level: 35 } },
      { skillId: "ironBulwark", unlockCondition: { type: "allSkillsLevel", level: 3 } },
      { skillId: "judgment", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "boundlessSwordWill",
    build: "bruiser",
    flavor: "Người duy nhất sống sót sau Đại Thiên Kiếp — mỗi kẻ địch ngã xuống dưới lưỡi kiếm Orin lại khắc thêm một vết khắc vĩnh cửu trên thân anh.",
  },
  {
    id: "h_xara",
    name: "Xara Bóng Quỷ",
    title: "Công Chúa Vực Sâu",
    rarity: "mythic",
    range: "melee",
    role: "assassin",
    origins: ["demon", "undead", "outlaw"],
    baseStats: s({ hp: 5062, atk: 113, def: 264, res: 276, spd: 160, crit: 45, critDmg: 220, acc: 110, lifesteal: 15 }),
    growth: { hp: 318.0, atk: 9.2, spd: 3, crit: 2 , def: 12.0, res: 12.0 },
    skills: ["bladeDance", "deathMark", "demonFlicker"],
    bonusSkills: [
      { skillId: "shadowStrike", unlockCondition: { type: "heroLevel", level: 40 } },
      { skillId: "bloodFrenzy", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "demonTeleport",
    build: "carry",
    flavor: "Sinh ra từ địa ngục và lăng mộ — Xara nhấp nháy như quỷ lửa, 4 lần dịch chuyển, 4 nhát chém, không ai kịp phản ứng.",
  },
  {
    id: "h_tianlong",
    name: "Tianlong Vạn Cổ",
    title: "Long Đế Thái Sơ",
    rarity: "mythic",
    range: "melee",
    role: "tank",
    origins: ["dragon", "celestial", "ancient"],
    baseStats: s({ hp: 9900, atk: 76, mag: 63, def: 576, res: 474, spd: 95, crit: 15, critDmg: 180, lifesteal: 15 }),
    growth: { hp: 637.5, atk: 5.5, def: 33.0, res: 21.0 },
    skills: ["dragonBreath", "ironBulwark", "primordalCoil"],
    bonusSkills: [
      { skillId: "earthquake", unlockCondition: { type: "heroLevel", level: 45 } },
      { skillId: "ancientDragonRoar", unlockCondition: { type: "allSkillsLevel", level: 4 } },
    ],
    passive: "primordialDominance",
    build: "tank",
    flavor: "Sinh ra cùng vũ trụ, Long Đế đã ngủ vạn năm — khi thức dậy, ngài cuộn mình bảo vệ đồng minh và phá tan đội hình địch bằng uy rồng cổ đại.",
  },
  {
    id: "h_riven",
    name: "Riven Tỷ Hạt",
    title: "Phù Thủy Thiên Hà",
    rarity: "mythic",
    range: "ranged",
    role: "mage",
    origins: ["cyber", "celestial"],
    baseStats: s({ hp: 5157, atk: 29, mag: 118, def: 258, res: 420, spd: 140, crit: 30, critDmg: 210, acc: 105 }),
    growth: { hp: 337.5, mag: 12.6, res: 18.0 , def: 12.0 },
    skills: ["arcaneBolt", "arcaneNova", "singularityCollapse"],
    bonusSkills: [
      { skillId: "voidRift", unlockCondition: { type: "heroLevel", level: 40 } },
      { skillId: "starfall", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "constantCollapse",
    build: "burst",
    flavor: "Riven thao túng cả hằng số vật lý — ultimate của cô tạo điểm kỳ dị hút toàn địch và cắt ngắn CD đồng đội, mỗi kỹ năng thứ 3 liên tiếp tự động kích hoạt thêm một phép miễn phí.",
  },

  // ============================================================
  // CELESTIAL (5)
  // ============================================================
  {
    id: "h_aurion",
    name: "Aurion Bình Minh Vô Tận",
    title: "Đấng Sáng Tạo Ánh Sáng",
    rarity: "celestial",
    range: "ranged",
    role: "support",
    origins: ["celestial", "ancient", "elemental"],
    baseStats: s({ hp: 8415, atk: 29, mag: 117, def: 414, res: 648, spd: 135, crit: 18, critDmg: 200 , acc: 85 }),
    growth: { hp: 585.0, mag: 12.6, res: 32.4 , def: 21.6 },
    skills: ["groupHeal", "blessing", "dawnRebirth"],
    bonusSkills: [
      { skillId: "resurrection", unlockCondition: { type: "heroLevel", level: 50 } },
      { skillId: "divineWrath", unlockCondition: { type: "allSkillsLevel", level: 4 } },
    ],
    passive: "primordialLight",
    build: "support",
    flavor: "Người đầu tiên thắp lên mặt trời — ultimate của ngài hồi sống toàn bộ đồng đội đã ngã, và nội tại ban Miễn Chết cho cả đội từ đầu trận.",
  },
  {
    id: "h_morwen",
    name: "Morwen Vực Tối",
    title: "Hoàng Hậu Bóng Đêm Vô Cùng",
    rarity: "celestial",
    range: "melee",
    role: "assassin",
    origins: ["demon", "undead", "celestial"],
    baseStats: s({ hp: 7560, atk: 103, def: 403, res: 450, spd: 195, crit: 55, critDmg: 250, acc: 115, lifesteal: 22 }),
    growth: { hp: 471.6, atk: 9.4, spd: 4, crit: 2.5 , def: 18.0, res: 18.0 },
    skills: ["bladeDance", "bloodFrenzy", "abyssalHarvest"],
    bonusSkills: [
      { skillId: "shadowStrike", unlockCondition: { type: "heroLevel", level: 45 } },
      { skillId: "doomCurse", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "eternalDarkness",
    build: "carry",
    flavor: "Khi hoàng hôn cuối cùng buông xuống, Morwen gặt linh hồn từ địch máu thấp nhất — nếu giết xong còn lướt ngay sang mục tiêu tiếp theo không nghỉ.",
  },
  {
    id: "h_aetherion",
    name: "Aetherion Vô Hạn",
    title: "Long Thần Của Vũ Trụ",
    rarity: "celestial",
    range: "melee",
    role: "warrior",
    origins: ["dragon", "celestial", "elemental"],
    baseStats: s({ hp: 10350, atk: 108, mag: 72, def: 630, res: 605, spd: 140, crit: 30, critDmg: 220, lifesteal: 20 }),
    growth: { hp: 675.0, atk: 8.6, def: 32.4, spd: 3 , res: 21.6 },
    skills: ["dragonBreath", "executioner", "cosmicShatter"],
    bonusSkills: [
      { skillId: "voidRift", unlockCondition: { type: "heroLevel", level: 50 } },
      { skillId: "ancestralRage", unlockCondition: { type: "allSkillsLevel", level: 5 } },
    ],
    passive: "infiniteElement",
    build: "bruiser",
    flavor: "Thân hình ngài bao trùm dải Ngân Hà — kỹ năng tự luân phiên Lửa, Băng, Sét theo từng lượt, và ultimate đập vỡ vũ trụ xóa sạch mọi khiên địch.",
  },
  {
    id: "h_calix",
    name: "Calix Mã Nguồn Vô Tận",
    title: "Tâm Trí Tương Lai",
    rarity: "celestial",
    range: "ranged",
    role: "marksman",
    origins: ["cyber", "ancient", "celestial"],
    baseStats: s({ hp: 7425, atk: 115, def: 389, res: 450, spd: 150, crit: 40, critDmg: 240, acc: 120 }),
    growth: { hp: 450.0, atk: 9.0, spd: 4, crit: 2 , def: 18.0, res: 18.0 },
    skills: ["pierceShot", "cyberOverdrive", "infiniteLoop"],
    bonusSkills: [
      { skillId: "cyberRailgun", unlockCondition: { type: "heroLevel", level: 45 } },
      { skillId: "voidPulse", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "hyperCalculation",
    build: "carry",
    flavor: "Một AI vượt giới hạn — Calix tích Tính Toán mỗi lượt để buff kỹ năng tiếp theo, và ultimate bắn đạn lặp 3 vòng qua toàn địch với 50% cơ hội hành động thêm.",
  },
  {
    id: "h_yggdra",
    name: "Yggdra Cây Vũ Trụ",
    title: "Mẹ Của Vạn Vật",
    rarity: "celestial",
    range: "ranged",
    role: "tank",
    origins: ["ancient", "elemental", "celestial"],
    baseStats: s({ hp: 15120, atk: 54, mag: 101, def: 821, res: 810, spd: 100, crit: 15, critDmg: 180, lifesteal: 20 , acc: 85 }),
    growth: { hp: 990.0, atk: 4.0, mag: 9.0, def: 43.2, res: 32.4 },
    skills: ["groupHeal", "earthquake", "worldTreeBloom"],
    bonusSkills: [
      { skillId: "blessing", unlockCondition: { type: "heroLevel", level: 45 } },
      { skillId: "pandemicWave", unlockCondition: { type: "allSkillsLevel", level: 4 } },
    ],
    passive: "cosmicRoot",
    build: "tank",
    flavor: "Mỗi chiếc lá là một hành tinh, mỗi rễ là một dòng thời gian — Yggdra hồi máu đội mỗi lượt, và rễ cây tự phản công kẻ dám tấn công ngài.",
  },

  // ============================================================
  // NEW HEROES — Tộc Mới & Nội Tại Đặc Biệt
  // ============================================================

  // RARE — Phantom Support
  {
    id: "h_vesper",
    name: "Vesper Bóng Lặng",
    title: "Linh Hồn Giữ Đội",
    rarity: "rare",
    range: "ranged",
    role: "support",
    origins: ["phantom", "undead"],
    baseStats: s({ hp: 2100, atk: 27, mag: 69, def: 96, res: 160, spd: 110, crit: 8, critDmg: 150, eva: 20 , acc: 85 }),
    growth: { hp: 138, mag: 6.6, res: 8, eva: 0.5 , def: 4 },
    skills: ["heal", "soulDrain", "groupHeal"],
    bonusSkills: [
      { skillId: "phantomStep", unlockCondition: { type: "heroLevel", level: 25 } },
    ],
    passive: "ghostVeil",
    build: "support",
    flavor: "Linh hồn nửa người nửa ma — Vesper bảo vệ đồng đội từ phía bóng tối, không ai thấy cô ấy cho đến khi quá muộn.",
  },

  // RARE — Plague Mage
  {
    id: "h_morbus",
    name: "Morbus Mục Nát",
    title: "Bác Sĩ Dịch Hạch",
    rarity: "rare",
    range: "ranged",
    role: "mage",
    origins: ["plague", "human"],
    baseStats: s({ hp: 1875, atk: 27, mag: 85, def: 76, res: 130, spd: 98, crit: 12, critDmg: 160 , acc: 85 }),
    growth: { hp: 120, mag: 8.4, res: 6 , def: 4 },
    skills: ["plagueCloud", "fireball", "plagueNova"],
    bonusSkills: [
      { skillId: "pestilenceField", unlockCondition: { type: "heroLevel", level: 30 } },
      { skillId: "doomCurse", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "infectiousAura",
    build: "burst",
    flavor: "Từng là bác sĩ giỏi nhất vương quốc, Morbus tự nhiễm dịch hạch để hiểu nó — và giờ coi bệnh tật như nghệ thuật.",
  },

  // EPIC — Storm Marksman
  {
    id: "h_zephyr",
    name: "Zephyr Lưỡi Gió",
    title: "Tiễn Thủ Bão Cát",
    rarity: "epic",
    range: "ranged",
    role: "marksman",
    origins: ["storm", "beastkin"],
    baseStats: s({ hp: 2312, atk: 96, def: 120, res: 108, spd: 145, crit: 24, critDmg: 185, acc: 100, eva: 12 }),
    growth: { hp: 155, atk: 7.8, spd: 3, crit: 1 , def: 6, res: 6 },
    skills: ["rapidFire", "galeShot", "hurricaneBarrage"],
    bonusSkills: [
      { skillId: "cycloneStrike", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "windBreaker",
    build: "attack-speed",
    flavor: "Sinh ra trong lốc xoáy, Zephyr chạy nhanh hơn gió và phóng 8 đạn bão liên tiếp — mỗi đòn chậm địch lại, mỗi đòn trúng tăng tốc bản thân vĩnh viễn.",
  },

  // EPIC — Phantom Assassin
  {
    id: "h_lynx",
    name: "Lynx Bóng Đêm",
    title: "Sát Thủ Không Hình",
    rarity: "epic",
    range: "melee",
    role: "assassin",
    origins: ["phantom", "outlaw"],
    baseStats: s({ hp: 2300, atk: 101, def: 110, res: 112, spd: 150, crit: 28, critDmg: 185, acc: 105, eva: 25, lifesteal: 12 }),
    growth: { hp: 145, atk: 8.4, spd: 2, crit: 1.5, eva: 0.3 , def: 6, res: 6 },
    skills: ["shadowStrike", "phantomStep", "phaseKill"],
    bonusSkills: [
      { skillId: "deathMark", unlockCondition: { type: "allSkillsLevel", level: 4 } },
    ],
    passive: "illusoryKiller",
    build: "carry",
    flavor: "Lynx bước qua chiều không gian — tàng hình hoàn toàn, rồi xuất hiện với đòn 350% ATK không thể né, và nếu giết được thì tàng hình lại ngay.",
  },

  // LEGENDARY — Plague Tank (unique: tank that spreads disease)
  {
    id: "h_pestis",
    name: "Pestis Hủ Thân",
    title: "Thần Dịch Bất Tử",
    rarity: "legendary",
    range: "melee",
    role: "tank",
    origins: ["plague", "undead", "demon"],
    baseStats: s({ hp: 4800, atk: 60, mag: 48, def: 310, res: 240, spd: 72, crit: 6, critDmg: 155, lifesteal: 18 }),
    growth: { hp: 295, atk: 4.8, def: 18, res: 10 },
    skills: ["shieldBash", "plaguePulse", "plagueExplosion"],
    bonusSkills: [
      { skillId: "pestilenceField", unlockCondition: { type: "battlesWon", count: 40 } },
    ],
    passive: "plagueTitan",
    build: "tank",
    flavor: "Cơ thể Pestis là ổ dịch di động — ultimate cho phép hắn phát nổ thân xác, đổi HP lấy sát thương true toàn địch, rồi tự hồi lại toàn bộ HP đã mất.",
  },

  // LEGENDARY — Storm Warrior
  {
    id: "h_raijin",
    name: "Raijin Thiên Lôi Phong",
    title: "Thống Soái Bão Sấm",
    rarity: "legendary",
    range: "melee",
    role: "warrior",
    origins: ["storm", "elemental", "ancient"],
    baseStats: s({ hp: 3962, atk: 117, mag: 48, def: 224, res: 170, spd: 130, crit: 22, critDmg: 185, acc: 100 }),
    growth: { hp: 262, atk: 9.6, def: 14, spd: 2 , res: 8 },
    skills: ["bleedSlash", "galeSlash", "stormKing"],
    bonusSkills: [
      { skillId: "chainLightning", unlockCondition: { type: "twoSkillsMaxLevel" } },
      { skillId: "thunderCyclone", unlockCondition: { type: "heroLevel", level: 35 } },
    ],
    passive: "thunderLord",
    build: "bruiser",
    flavor: "Raijin cưỡi bão chứ không cưỡi ngựa — ultimate triệu 5 tia sét đánh 5 địch riêng biệt, và kỹ năng Sấm/Bão có 40% tự động phóng sét phụ miễn phí.",
  },

  // MYTHIC — Phantom Mage (mirror-damage caster)
  {
    id: "h_spectra",
    name: "Spectra Hư Ảnh Vạn Hóa",
    title: "Đại Huyễn Pháp Sư",
    rarity: "mythic",
    range: "ranged",
    role: "mage",
    origins: ["phantom", "celestial", "ancient"],
    baseStats: s({ hp: 4875, atk: 27, mag: 108, def: 240, res: 390, spd: 128, crit: 28, critDmg: 205, eva: 20 , acc: 85 }),
    growth: { hp: 330.0, mag: 11.3, res: 18.0, eva: 0.5 , def: 12.0 },
    skills: ["phantomEcho", "arcaneNova", "infiniteMirror"],
    bonusSkills: [
      { skillId: "voidRift", unlockCondition: { type: "allSkillsLevel", level: 4 } },
      { skillId: "starfall", unlockCondition: { type: "battlesWon", count: 70 } },
    ],
    passive: "infiniteSoul",
    build: "burst",
    flavor: "Spectra sao chép kỹ năng mạnh nhất địch rồi dùng ngay với 150% hiệu lực — và mỗi lần né thành công, kích hoạt thêm 1 kỹ năng miễn phí.",
  },

  // MYTHIC — Storm Marksman (dual-carry)
  {
    id: "h_typhon",
    name: "Typhon Bão Khổng Lồ",
    title: "Pháo Thủ Lốc Xoáy",
    rarity: "mythic",
    range: "ranged",
    role: "marksman",
    origins: ["storm", "cyber", "elemental"],
    baseStats: s({ hp: 5280, atk: 111, def: 285, res: 294, spd: 155, crit: 35, critDmg: 220, acc: 115, eva: 15 }),
    growth: { hp: 345.0, atk: 8.8, spd: 3, crit: 1.5 , def: 12.0, res: 12.0 },
    skills: ["stormBarrage", "cyberOverdrive", "vortexCannon"],
    bonusSkills: [
      { skillId: "cyberRailgun", unlockCondition: { type: "twoSkillsMaxLevel" } },
      { skillId: "cycloneStrike", unlockCondition: { type: "battlesWon", count: 60 } },
    ],
    passive: "stormFusion",
    build: "carry",
    flavor: "Typhon ghép railgun vào lốc xoáy — ultimate xuyên toàn địch, hút tất cả vào tâm, Stun 1 lượt, và mỗi đạn có 30% kéo theo sét phụ miễn phí.",
  },

  // CELESTIAL — Plague Support (anti-heal, epidemic lord)
  {
    id: "h_nemesis_plague",
    name: "Nemesis Đại Dịch",
    title: "Mẹ Của Mọi Bệnh Tật",
    rarity: "celestial",
    range: "ranged",
    role: "support",
    origins: ["plague", "demon", "celestial"],
    baseStats: s({ hp: 9158, atk: 31, mag: 113, def: 450, res: 612, spd: 128, crit: 20, critDmg: 200 , acc: 85 }),
    growth: { hp: 630.0, mag: 12.2, res: 28.8 , def: 21.6 },
    skills: ["plagueNova", "groupHeal", "apotheosisPlague"],
    bonusSkills: [
      { skillId: "pandemicWave", unlockCondition: { type: "heroLevel", level: 50 } },
      { skillId: "voidRift", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "plagueMatriarch",
    build: "support",
    flavor: "Nemesis cai trị tế bào — ultimate của cô nhân đôi Độc/Bỏng toàn đội, khóa hồi phục địch 80%, và nội tại cho phép địch chết vì dịch đồng thời hồi đội cô.",
  },

  // CELESTIAL — Storm/Phantom hybrid (ultimate evasion carry)
  {
    id: "h_mirage",
    name: "Mirage Bão Ảo Vô Hình",
    title: "Hoàng Đế Không Ai Thấy",
    rarity: "celestial",
    range: "melee",
    role: "assassin",
    origins: ["phantom", "storm", "outlaw"],
    baseStats: s({ hp: 8168, atk: 106, def: 425, res: 414, spd: 205, crit: 55, critDmg: 250, acc: 120, eva: 55, lifesteal: 28 }),
    growth: { hp: 518.4, atk: 9.7, spd: 4, crit: 2.5, eva: 1 , def: 18.0, res: 18.0 },
    passive: "stormPhantom",
    build: "carry",
    flavor: "Mirage nhân bản 8 lần tấn công 8 mục tiêu — EVA 100% trong lượt ultimate, mỗi lần né tích Bão, ra khỏi tàng hình đòn đó mang thêm 50% sát thương/lớp.",
    skills: ["phantomStep", "bladeDance", "phantomTempest"],
    bonusSkills: [
      { skillId: "finalEclipse", unlockCondition: { type: "twoSkillsMaxLevel" } },
      { skillId: "cycloneStrike", unlockCondition: { type: "skillCombo", skillIds: ["phantomStep", "bladeDance"] } },
    ],
  },
  // ============================================================
  // ADDITIONAL HEROES — Completing faction minimums (5 per faction)
  // ============================================================

  // DRAGON faction — need 2 more (currently 3: drakthar, tianlong, aetherion)
  {
    id: "h_scalebreaker",
    name: "Scalebreaker Hồng Diệm",
    title: "Thợ Săn Long Tộc",
    rarity: "epic",
    range: "melee",
    role: "assassin",
    origins: ["dragon", "outlaw"],
    baseStats: s({ hp: 2525, atk: 97, def: 136, res: 116, spd: 148, crit: 28, critDmg: 185, acc: 105, lifesteal: 14 }),
    growth: { hp: 170, atk: 9.0, spd: 2, crit: 1.5 , def: 6, res: 6 },
    skills: ["bladeDance", "earthquake", "dragonSlayer"],
    bonusSkills: [
      { skillId: "dragonScaleMoult", unlockCondition: { type: "heroLevel", level: 28 } },
      { skillId: "finalEclipse", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "dragonbane",
    build: "carry",
    flavor: "Kẻ duy nhất từng hạ một con rồng tay không — giờ anh mang vảy nó như chiến tích, và sát thương lên Dragon/Ancient tăng 50%.",
  },
  {
    id: "h_wyrmcaller",
    name: "Wyrmcaller Hỏa Linh",
    title: "Pháp Sư Triệu Hồi Rồng",
    rarity: "legendary",
    range: "ranged",
    role: "mage",
    origins: ["dragon", "elemental", "ancient"],
    baseStats: s({ hp: 2888, atk: 33, mag: 119, def: 160, res: 190, spd: 112, crit: 16, critDmg: 175 , acc: 85 }),
    growth: { hp: 200, mag: 12.6, res: 8 , def: 6 },
    skills: ["fireball", "dragonBreath", "dragonSummon"],
    bonusSkills: [
      { skillId: "ancientDragonRoar", unlockCondition: { type: "heroLevel", level: 32 } },
      { skillId: "arcaneNova", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "wyrmwhisperer",
    build: "burst",
    flavor: "Cô ấy không điều khiển rồng — cô ấy là rồng mặc lốt người, và khi hát triệu hồi, rồng tổ tiên đáp lời với lửa thiêu toàn địch 4 lượt.",
  },

  // PLAGUE faction — need 2 more (currently 3: morbus, pestis, nemesis_plague)
  {
    id: "h_rotweaver",
    name: "Rotweaver Thối Hóa",
    title: "Phù Thủy Mục Nát",
    rarity: "rare",
    range: "ranged",
    role: "mage",
    origins: ["plague", "undead"],
    baseStats: s({ hp: 1825, atk: 25, mag: 82, def: 70, res: 124, spd: 97, crit: 11, critDmg: 158 , acc: 85 }),
    growth: { hp: 115, mag: 7.8, res: 6 , def: 4 },
    skills: ["plagueCloud", "soulDrain", "plagueNova"],
    bonusSkills: [
      { skillId: "fireball", unlockCondition: { type: "heroLevel", level: 18 } },
      { skillId: "pestilenceField", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "infectiousAura",
    build: "burst",
    flavor: "Xương ngón tay Rotweaver đã mục từ lâu — nhưng phép thuật từ đó lại mạnh hơn bao giờ.",
  },
  {
    id: "h_carrier",
    name: "Carrier Ký Sinh",
    title: "Vật Chủ Đại Dịch",
    rarity: "epic",
    range: "melee",
    role: "warrior",
    origins: ["plague", "beastkin"],
    baseStats: s({ hp: 3162, atk: 93, def: 184, res: 110, spd: 108, crit: 14, critDmg: 168, lifesteal: 12 }),
    growth: { hp: 210, atk: 7.8, def: 12, lifesteal: 0.3 , res: 6 },
    skills: ["bleedSlash", "plaguePulse", "infestationBurst"],
    bonusSkills: [
      { skillId: "woundDeepen", unlockCondition: { type: "heroLevel", level: 25 } },
      { skillId: "pestilenceField", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "perfectHost",
    build: "bruiser",
    flavor: "Người sói nhiễm dịch hạch — miễn nhiễm Độc và Bỏng, tự biến chúng thành hồi máu, và có thể phát nổ thân xác để lan virus toàn địch.",
  },

  // BEASTKIN faction — need 1 more (currently 4: grom, ravi, kazumi, zephyr)
  {
    id: "h_thornmaw",
    name: "Thornmaw Gai Nhọn",
    title: "Chiến Binh Kền Kền",
    rarity: "epic",
    range: "melee",
    role: "tank",
    origins: ["beastkin", "ancient"],
    baseStats: s({ hp: 4800, atk: 63, def: 324, res: 192, spd: 82, crit: 8, critDmg: 155, lifesteal: 16 }),
    growth: { hp: 262, atk: 4.8, def: 18, res: 8 },
    skills: ["shieldBash", "ironBulwark", "ironNest"],
    bonusSkills: [
      { skillId: "immovableStance", unlockCondition: { type: "heroLevel", level: 25 } },
      { skillId: "earthquake", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "thornArmor",
    build: "tank",
    flavor: "Chim ưng khổng lồ già nhất bộ lạc — lớp lông gai cứng như thép phản 30% sát thương nhận, và ultimate trải cánh thành tổ pháo đài bất khả xâm.",
  },

  // CYBER faction — need 1 more (currently 4: vex, riven, calix, typhon)
  {
    id: "h_ghostcode",
    name: "Ghostcode Mã Bóng",
    title: "Hacker Hư Vô",
    rarity: "legendary",
    range: "ranged",
    role: "support",
    origins: ["cyber", "phantom"],
    baseStats: s({ hp: 2700, atk: 36, mag: 96, def: 140, res: 240, spd: 145, crit: 14, critDmg: 172, eva: 20 , acc: 85 }),
    growth: { hp: 188, mag: 10.2, res: 10, eva: 0.3 , def: 8 },
    skills: ["heal", "nanotechStrike", "cyberGhost"],
    bonusSkills: [
      { skillId: "phantomStep", unlockCondition: { type: "heroLevel", level: 30 } },
      { skillId: "overclock", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "dualExistence",
    build: "support",
    flavor: "Một AI tải mình vào thực tại — ultimate đánh cắp 50% ATK/MAG địch mạnh nhất tặng toàn đội, và 30% đòn tấn công vào Ghostcode bị chiều số hóa (né hoàn toàn).",
  },

  // PHANTOM faction — need 1 more (currently 4: vesper, lynx, spectra, mirage)
  {
    id: "h_wraithblade",
    name: "Wraithblade Hồn Kiếm",
    title: "Hiệp Sĩ Ma Giới",
    rarity: "legendary",
    range: "melee",
    role: "warrior",
    origins: ["phantom", "undead", "ancient"],
    baseStats: s({ hp: 3588, atk: 115, def: 208, res: 184, spd: 122, crit: 20, critDmg: 185, eva: 18, lifesteal: 15 }),
    growth: { hp: 240, atk: 9.6, def: 12, spd: 2, eva: 0.2 , res: 8 },
    skills: ["shadowStrike", "ironBulwark", "soulSever"],
    bonusSkills: [
      { skillId: "soulChain", unlockCondition: { type: "heroLevel", level: 30 } },
      { skillId: "judgment", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "wraithedge",
    build: "bruiser",
    flavor: "Kiếm của Wraithblade rèn từ xương linh hồn — ultimate đánh cắp bóng địch, giảm toàn bộ chỉ số họ và tặng lại cho bản thân trong 3 lượt.",
  },

  // STORM faction — need 1 more (currently 4: zephyr, raijin, typhon, mirage)
  {
    id: "h_tempestrix",
    name: "Tempestrix Lốc Tố",
    title: "Phù Thủy Bão Điện",
    rarity: "legendary",
    range: "ranged",
    role: "mage",
    origins: ["storm", "elemental", "celestial"],
    baseStats: s({ hp: 2812, atk: 33, mag: 113, def: 140, res: 176, spd: 128, crit: 19, critDmg: 178, acc: 105 }),
    growth: { hp: 195, mag: 12.0, res: 8 , def: 6 },
    skills: ["chainLightning", "stormBarrage", "stormSong"],
    bonusSkills: [
      { skillId: "frozenField", unlockCondition: { type: "heroLevel", level: 32 } },
      { skillId: "thunderCyclone", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "stormsong",
    build: "burst",
    flavor: "Tempestrix gọi sét bằng cách hát — bài ca phong thần Stun toàn địch lượt đầu, 3 sét đánh liên tiếp, và đội Storm nhận buff SPD mỗi khi cô cất giọng.",
  },

  // ============================================================
  // FLOREN WALKER — Rare, melee warrior
  // ============================================================
  {
    id: "h_florenwalker",
    name: "Floren Đi Bộ",
    title: "Lãng Khách Casanova",
    rarity: "rare",
    range: "melee",
    role: "warrior",
    origins: ["human", "ancient"],
    baseStats: s({ hp: 2800, atk: 93, def: 152, res: 100, spd: 105, crit: 12, critDmg: 165, acc: 98 }),
    growth: { hp: 180, atk: 8.4, def: 10, res: 6, spd: 1 },
    skills: ["florenJab", "florenSlash", "florenImmunity"],
    bonusSkills: [
      { skillId: "executioner", unlockCondition: { type: "heroLevel", level: 28 } },
      { skillId: "bleedSlash", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "florenWalker",
    build: "bruiser",
    flavor: "Lãng khách không tên lang thang khắp Casanova — mỗi bước chân để lại dấu vết của kẻ không thể bị khuất phục.",
  },

  // ============================================================
  // KSAN — Legendary, melee tank (2 Forms: Shield → Sword)
  // ============================================================
  {
    id: "h_ksan",
    name: "Ksan",
    title: "Khiên Thánh Bất Khuất",
    rarity: "mythic",
    range: "melee",
    role: "tank",
    origins: ["ancient", "human"],
    baseStats: s({ hp: 8100, atk: 34, def: 520, res: 525, spd: 85, crit: 10, critDmg: 150, acc: 95, eva: 10, lifesteal: 5 }),
    growth: { hp: 600.0, atk: 2.1, def: 38.0, res: 20.0, spd: 0 },
    skills: ["ksanThethy", "ksanAnhHungKhien", "ksanKhienThanh"],
    bonusSkills: [
      { skillId: "ksanBucTuongPhongHo", unlockCondition: { type: "heroLevel", level: 20 } },
    ],
    passive: "ksanBatKhuat",
    build: "tank",
    flavor: "Ksan không chiến đấu để tấn công — Ksan chiến đấu để mọi người khác không bị tấn công. Và khi khiên vỡ, kiếm sẽ nói thay.",
  },

  // ============================================================
  // 🏴‍☠️ TỘC HỆ CƯỚP BIỂN (PIRATE) — 6 tướng
  // Cơ chế: Doubloon tích từ crit/kill → +ATK vĩnh viễn, cướp buff địch
  // ============================================================

  // RARE — Pirate Warrior
  // Balance: ATK hạ từ 138→128 (Ravi rare warrior là 140, Rax có lifesteal nên trade ATK)
  // lifesteal 10→8 (rare tier không nên có lifesteal cao)
  {
    id: "h_deckhand_rax",
    name: "Rax Thủy Thủ Máu",
    title: "Tay Kiếm Tàu Trộm",
    rarity: "rare",
    range: "melee",
    role: "warrior",
    origins: ["pirate", "outlaw"],
    baseStats: s({ hp: 2375, atk: 77, def: 124, res: 76, spd: 112, crit: 18, critDmg: 170, acc: 98, lifesteal: 8 }),
    growth: { hp: 180, atk: 6.6, def: 10, lifesteal: 0.2 , res: 4 },
    skills: ["cutlassSlash", "grapplingHook", "drunkenBrawl"],
    bonusSkills: [
      { skillId: "bleedSlash", unlockCondition: { type: "heroLevel", level: 20 } },
      { skillId: "plunderAll", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "seaDogInstinct",
    build: "bruiser",
    avatarUrl: "/avatars/pirate/rax_thuy_thu_mau.webp",
    flavor: "Từng là thủy thủ lương thiện, cho đến khi tàu bị cướp — giờ Rax trở thành kẻ cướp giỏi nhất đại dương, tích Doubloon từng cú chí mạng.",
  },

  // RARE — Pirate Marksman
  // Balance: Ngang Belle cũ (ember rare: atk:135 spd:125 crit:20) — hợp lý
  {
    id: "h_ironside_belle",
    name: "Belle Sắt Hông",
    title: "Xạ Thủ Tàu Cướp",
    rarity: "rare",
    range: "ranged",
    role: "marksman",
    origins: ["pirate", "human"],
    baseStats: s({ hp: 1850, atk: 78, def: 76, res: 76, spd: 126, crit: 20, critDmg: 170, acc: 105 }),
    growth: { hp: 138, atk: 6.6, spd: 2, crit: 0.8 , def: 4, res: 4 },
    skills: ["pierceShot", "cannonBlast", "powderKeg"],
    bonusSkills: [
      { skillId: "rapidFire", unlockCondition: { type: "heroLevel", level: 22 } },
      { skillId: "blackFlag", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "marksmanship",
    build: "attack-speed",
    avatarUrl: "/avatars/pirate/belle_sat_hong.webp",
    flavor: "Belle không bao giờ nhắm bằng mắt — cô nhắm bằng tiếng vang Doubloon rơi xuống sàn tàu. Mỗi cú chính xác là một đồng vàng đổ vào túi.",
  },

  // EPIC — Pirate Assassin
  // Balance: critDmg 212→202 (Nyx epic 200), HP 860→900 để survive đủ dùng kit
  {
    id: "h_redrogue",
    name: "Redrogue Gươm Đỏ",
    title: "Thuyền Phó Bóng Tối",
    rarity: "epic",
    range: "melee",
    role: "assassin",
    origins: ["pirate", "outlaw", "demon"],
    baseStats: s({ hp: 2250, atk: 102, def: 96, res: 104, spd: 146, crit: 28, critDmg: 185, acc: 105, lifesteal: 14 }),
    growth: { hp: 162, atk: 8.4, spd: 2, crit: 1.2 , def: 6, res: 6 },
    skills: ["shadowStrike", "grapplingHook", "plunderAll"],
    bonusSkills: [
      { skillId: "bladeDance", unlockCondition: { type: "twoSkillsMaxLevel" } },
      { skillId: "blackFlag", unlockCondition: { type: "heroLevel", level: 28 } },
    ],
    passive: "marauderSoul",
    build: "carry",
    avatarUrl: "/avatars/pirate/redrogue_guom_do.webp",
    flavor: "Redrogue không chiến đấu để thắng — hắn chiến đấu để cướp. Mỗi buff địch bị hắn lấy đi là một bước gần hơn đến bất bại.",
  },

  // EPIC — Pirate Support
  // Balance: Voss là support/utility — stats đã cân đối với epic support tier (Ozric support mag:148 ok)
  {
    id: "h_navigator_voss",
    name: "Voss Hoa Tiêu",
    title: "Nhà Hàng Hải Tuyệt Đỉnh",
    rarity: "epic",
    range: "ranged",
    role: "support",
    origins: ["pirate", "ancient"],
    baseStats: s({ hp: 2050, atk: 33, mag: 87, def: 104, res: 184, spd: 115, crit: 10, critDmg: 155, acc: 92 }),
    growth: { hp: 155, mag: 7.8, res: 10 , def: 6 },
    skills: ["heal", "ironDiscipline", "maelstromBomb"],
    bonusSkills: [
      { skillId: "groupHeal", unlockCondition: { type: "heroLevel", level: 26 } },
      { skillId: "plunderAll", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "crewBonding",
    build: "support",
    avatarUrl: "/avatars/pirate/voss_hoa_tieu.webp",
    flavor: "Voss đọc gió, sóng, và tâm lý đối thủ như đọc bản đồ. Hắn không cầm kiếm — hắn giữ cho cả đội cầm kiếm được lâu hơn.",
  },

  // LEGENDARY — Pirate Mage (Ghost Ship)
  // Balance: Capitão legendary mage — mag:210 so với Velka legendary mag:210 → ngang nhau, hợp lý
  // eva:20 bù lại cho hp/def thấp hơn do là ghost
  {
    id: "h_ghostcaptain",
    name: "Capitão Hồn Ma",
    title: "Thuyền Trưởng Tàu Ma",
    rarity: "legendary",
    range: "ranged",
    role: "mage",
    origins: ["pirate", "undead", "phantom"],
    baseStats: s({ hp: 2550, atk: 35, mag: 123, def: 130, res: 216, spd: 122, crit: 16, critDmg: 175, eva: 18, acc: 88 }),
    growth: { hp: 190, mag: 11.4, res: 10, eva: 0.2 , def: 6 },
    skills: ["soulDrain", "powderKeg", "blackFlag"],
    bonusSkills: [
      { skillId: "maelstromBomb", unlockCondition: { type: "twoSkillsMaxLevel" } },
      { skillId: "plagueCloud", unlockCondition: { type: "battlesWon", count: 40 } },
    ],
    passive: "ghostShipCurse",
    build: "burst",
    avatarUrl: "/avatars/pirate/capitao_hon_ma.webp",
    flavor: "Đã chết từ 200 năm trước nhưng con tàu ma của ông vẫn xuất hiện trong sương đêm. Lời nguyền của Capitão theo địch đến tận khi chúng tắt thở.",
  },

  // MYTHIC — Pirate King
  // Balance: HP 1620→1480 (Orin mythic warrior hp:1955, Zerathus mythic mage hp:1430)
  // Darios là warrior/bruiser → HP 1480 hợp lý. ATK giữ 252 (Orin 245, ok)
  {
    id: "h_pirateking_darios",
    name: "Darios Đại Hải Vương",
    title: "Vua Cướp Biển Bất Bại",
    rarity: "mythic",
    range: "melee",
    role: "warrior",
    origins: ["pirate", "ancient", "demon"],
    baseStats: s({ hp: 5550, atk: 104, def: 312, res: 255, spd: 136, crit: 36, critDmg: 220, acc: 105, lifesteal: 20 }),
    growth: { hp: 432.0, atk: 8.0, def: 21.0, spd: 2, crit: 1.2 , res: 15.0 },
    skills: ["cutlassSlash", "pirateKingDive", "maelstromBomb"],
    bonusSkills: [
      { skillId: "plunderAll", unlockCondition: { type: "heroLevel", level: 40 } },
      { skillId: "blackFlag", unlockCondition: { type: "twoSkillsMaxLevel" } },
      { skillId: "drunkenBrawl", unlockCondition: { type: "battlesWon", count: 60 } },
    ],
    passive: "pirateKingBlood",
    build: "bruiser",
    avatarUrl: "/avatars/pirate/darios_dai_hai_vuong.webp",
    flavor: "Không có đại dương nào Darios chưa vượt, không có kho báu nào hắn chưa cướp. Doubloon của hắn không đo bằng vàng — đo bằng máu địch.",
  },

  // ============================================================
  // 🧜 TỘC HỆ NHÂN NGƯ (MERFOLK) — 6 tướng
  // Cơ chế: Triều Dâng — tích Triều mỗi lượt, giải phóng Sóng Thần heal+AoE
  // ============================================================

  // RARE — Merfolk Support
  // Balance: MAG 138→122 (Aelinor rare support mag:120), HP 780→850 để survive
  {
    id: "h_coralwarden",
    name: "Corala Thủ San Hô",
    title: "Y Sĩ Rạn San Hô",
    rarity: "rare",
    range: "ranged",
    role: "support",
    origins: ["merfolk", "elemental"],
    baseStats: s({ hp: 2125, atk: 29, mag: 73, def: 92, res: 180, spd: 102, crit: 8, critDmg: 152, acc: 88 }),
    growth: { hp: 150, mag: 6.6, res: 10 , def: 4 },
    skills: ["tidalStrike", "coralBarrier", "tidalResurgence"],
    bonusSkills: [
      { skillId: "groupHeal", unlockCondition: { type: "heroLevel", level: 20 } },
      { skillId: "tsunamiRoar", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "tidalHeart",
    build: "support",
    flavor: "Corala lớn lên giữa rạn san hô — mỗi Triều dâng là một nhịp thở của đại dương, và cô chia sẻ hơi thở đó với đồng đội.",
  },

  // RARE — Merfolk Warrior
  // Balance: Ngang Ravi rare warrior (hp:1150 atk:140) — Tidus hp:970 atk:142 ok vì lifesteal cao hơn
  // Lifesteal 12→10 cho rare tier
  {
    id: "h_tideblade",
    name: "Tidus Lưỡi Triều",
    title: "Chiến Binh Hải Lưu",
    rarity: "rare",
    range: "melee",
    role: "warrior",
    origins: ["merfolk", "beastkin"],
    baseStats: s({ hp: 2425, atk: 83, def: 130, res: 84, spd: 116, crit: 14, critDmg: 165, acc: 95, lifesteal: 10 }),
    growth: { hp: 180, atk: 6.6, def: 10, lifesteal: 0.3 , res: 4 },
    skills: ["deepCurrentDash", "tidalStrike", "depthChargeStrike"],
    bonusSkills: [
      { skillId: "feralLeap", unlockCondition: { type: "heroLevel", level: 22 } },
      { skillId: "seaSerpentSummon", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "scalesMythic",
    build: "bruiser",
    flavor: "Tidus lao theo dòng hải lưu nhanh hơn cá heo — mỗi Triều anh tích được là cú lao tiếp theo mạnh bạo hơn.",
  },

  // EPIC — Merfolk Mage
  // Balance: MAG 188→178 (ngang Ozric epic mag:178) — Sirenia không nên vượt benchmark epic
  {
    id: "h_abyssalwitch",
    name: "Sirenia Mực Vực",
    title: "Phù Thủy Mực Đen",
    rarity: "epic",
    range: "ranged",
    role: "mage",
    origins: ["merfolk", "undead"],
    baseStats: s({ hp: 2075, atk: 31, mag: 107, def: 84, res: 176, spd: 106, crit: 15, critDmg: 172, acc: 88 }),
    growth: { hp: 155, mag: 9.6, res: 8 , def: 6 },
    skills: ["inkCloud", "abyssalSong", "tsunamiRoar"],
    bonusSkills: [
      { skillId: "soulDrain", unlockCondition: { type: "twoSkillsMaxLevel" } },
      { skillId: "seaSerpentSummon", unlockCondition: { type: "heroLevel", level: 28 } },
    ],
    passive: "oceanSiren",
    build: "burst",
    flavor: "Sirenia hát những bài ca từ tầng sâu nhất đại dương — giọng ca phun mực che phủ địch và Triều dâng theo từng nốt nhạc.",
  },

  // EPIC — Merfolk Tank
  // Balance: HP 1720→1900 — Gargos là tank chính của Nhân Ngư, cần cao hơn (Morgath epic: 2100)
  // HP 1900 là hợp lý — thấp hơn Morgath nhưng có Lifesteal + passive heal bù lại
  {
    id: "h_tideguard",
    name: "Gargos Giáp Triều",
    title: "Hộ Vệ Thủy Cung",
    rarity: "epic",
    range: "melee",
    role: "tank",
    origins: ["merfolk", "ancient"],
    baseStats: s({ hp: 4750, atk: 57, def: 310, res: 220, spd: 76, crit: 6, critDmg: 150, lifesteal: 18 }),
    growth: { hp: 338, atk: 4.2, def: 18, res: 10 },
    skills: ["coralBarrier", "scaleArmorBuff", "seaSerpentSummon"],
    bonusSkills: [
      { skillId: "taunt", unlockCondition: { type: "heroLevel", level: 25 } },
      { skillId: "tidalResurgence", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "depthsGuardian",
    build: "tank",
    flavor: "Gargos là bức tường sống của Thủy Cung — vảy ngài dày bằng tàu thép, và mỗi Triều dâng đều khiến vảy cứng thêm một lớp.",
  },

  // LEGENDARY — Merfolk Assassin
  // Balance: Nyx'alis so với Kazumi legendary assassin (atk:195 crit:40 spd:148)
  // Nyx'alis: atk:195→190, crit:42→38 (bù lại bởi Triều mechanic scale)
  // eva:20 là nét đặc trưng, giữ nguyên
  {
    id: "h_deepstrike",
    name: "Nyx'alis Vực Tối",
    title: "Sát Thủ Áp Lực Sâu",
    rarity: "legendary",
    range: "melee",
    role: "assassin",
    origins: ["merfolk", "phantom", "demon"],
    baseStats: s({ hp: 2450, atk: 114, def: 116, res: 130, spd: 148, crit: 35, critDmg: 200, acc: 108, lifesteal: 17, eva: 18 }),
    growth: { hp: 180, atk: 9.6, spd: 2.5, crit: 1.2, eva: 0.2 , def: 6, res: 6 },
    skills: ["deepCurrentDash", "inkCloud", "depthChargeStrike"],
    bonusSkills: [
      { skillId: "shadowStrike", unlockCondition: { type: "twoSkillsMaxLevel" } },
      { skillId: "tsunamiRoar", unlockCondition: { type: "battlesWon", count: 45 } },
    ],
    passive: "tidecallerPact",
    build: "carry",
    flavor: "Nyx'alis lặn xuống tầng sâu nhất trước mỗi trận — áp lực vực thẳm làm đòn đánh cô mạnh gấp bội, và Triều theo cô không bao giờ tắt.",
  },

  // MYTHIC — Merfolk Lord
  // Balance: MAG 298→272 — kéo về gần Zerathus mythic (mag:262) + 10 bonus vì có Triều mechanic
  // HP 1420 ok (Zerathus 1430, Riven 1375)
  {
    id: "h_leviathan_rex",
    name: "Leviax Quân Vương Vực",
    title: "Đại Vương Vực Thẳm",
    rarity: "mythic",
    range: "ranged",
    role: "mage",
    origins: ["merfolk", "ancient", "elemental"],
    baseStats: s({ hp: 5325, atk: 30, mag: 114, def: 264, res: 435, spd: 120, crit: 26, critDmg: 205, acc: 92 }),
    growth: { hp: 397.5, mag: 10.9, res: 21.0 , def: 12.0 },
    skills: ["abyssalSong", "seaSerpentSummon", "tsunamiRoar"],
    bonusSkills: [
      { skillId: "tidalResurgence", unlockCondition: { type: "heroLevel", level: 42 } },
      { skillId: "iceAge", unlockCondition: { type: "twoSkillsMaxLevel" } },
      { skillId: "depthChargeStrike", unlockCondition: { type: "battlesWon", count: 65 } },
    ],
    passive: "abyssLord",
    build: "burst",
    flavor: "Leviax không phải Nhân Ngư — ngài là Leviathan trong hình hài nhân ngư. Mỗi Triều ngài giải phóng là con sóng hủy diệt một thế giới.",
  },

  // ============================================================
  // ⚓ TỘC HỆ HẢI QUÂN (NAVY) — 6 tướng
  // Cơ chế: Volley Pháo Hạm mỗi 3 lượt, tank hứng sát thương thay đồng đội
  // ============================================================

  // RARE — Navy Tank
  // Balance: Ferro rare tank — hp:1180 def:118 vs Otto common tank (hp:1450 def:112)
  // Ferro có thêm utility (hứng đỡ) nên HP thấp hơn là ok
  {
    id: "h_deckguard_ferro",
    name: "Ferro Giáp Sắt",
    title: "Lính Tiên Phong Hải Quân",
    rarity: "rare",
    range: "melee",
    role: "tank",
    origins: ["navy", "human"],
    baseStats: s({ hp: 3000, atk: 53, def: 192, res: 148, spd: 74, crit: 5, critDmg: 150, acc: 95 }),
    growth: { hp: 235, atk: 4.2, def: 14, res: 8 },
    skills: ["disciplinedStrike", "navalBlockade", "navalRamming"],
    bonusSkills: [
      { skillId: "shieldBash", unlockCondition: { type: "heroLevel", level: 20 } },
      { skillId: "fullBroadside", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "navalVanguard",
    build: "tank",
    flavor: "Ferro đứng trước mũi tàu trong bão — ngực hứng đạn, tay hứng sóng, và không bao giờ lùi một bước.",
  },

  // RARE — Navy Marksman
  // Balance: Ngang Ember rare marksman (atk:135 spd:125 crit:20) — Cross tương đương
  {
    id: "h_rifleman_cross",
    name: "Cross Pháo Thủ",
    title: "Pháo Thủ Đệ Nhất",
    rarity: "rare",
    range: "ranged",
    role: "marksman",
    origins: ["navy", "human"],
    baseStats: s({ hp: 1880, atk: 80, def: 80, res: 80, spd: 122, crit: 20, critDmg: 170, acc: 108 }),
    growth: { hp: 140, atk: 6.6, spd: 2, crit: 0.8 , def: 4, res: 4 },
    skills: ["broadsideCannon", "pierceShot", "fullBroadside"],
    bonusSkills: [
      { skillId: "rapidFire", unlockCondition: { type: "heroLevel", level: 20 } },
      { skillId: "siegeBombardment", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "gunneryOfficer",
    build: "attack-speed",
    flavor: "Cross đã bắn 10,000 phát pháo trước khi tròn 20 tuổi. Volley của hắn luôn khai hỏa sớm nhất — và chuẩn nhất.",
  },

  // EPIC — Navy Warrior (team buffer)
  // Balance: Steel epic warrior — ngang Kael (hp:1320 atk:165), Steel hp:1280 atk:158
  // Steel trade ATK lấy DEF (102) vì role buffer/bruiser
  {
    id: "h_commodore_steel",
    name: "Steel Hạm Trưởng Thép",
    title: "Hạm Trưởng Kỷ Luật",
    rarity: "epic",
    range: "melee",
    role: "warrior",
    origins: ["navy", "ancient"],
    baseStats: s({ hp: 3200, atk: 95, def: 204, res: 144, spd: 106, crit: 16, critDmg: 178, acc: 100 }),
    growth: { hp: 240, atk: 7.8, def: 14, spd: 1 , res: 6 },
    skills: ["disciplinedStrike", "ironDiscipline", "admiralCommand"],
    bonusSkills: [
      { skillId: "whirlwind", unlockCondition: { type: "twoSkillsMaxLevel" } },
      { skillId: "fullBroadside", unlockCondition: { type: "heroLevel", level: 28 } },
    ],
    passive: "flagshipCaptain",
    build: "bruiser",
    flavor: "Steel không hét lệnh — hắn thì thầm và cả hạm đội nghe theo. Mỗi Volley dưới quyền hắn đều là phép thử của kỷ luật tuyệt đối.",
  },

  // EPIC — Navy Support (Medic)
  // Balance: Aidela epic support — mag:148 ok (Seraphine legendary mag:200, khoảng cách hợp lý)
  {
    id: "h_shipsurgeon",
    name: "Aidela Y Tá Hạm",
    title: "Y Sĩ Chiến Trận Hải Quân",
    rarity: "epic",
    range: "ranged",
    role: "support",
    origins: ["navy", "human"],
    baseStats: s({ hp: 2112, atk: 31, mag: 89, def: 112, res: 190, spd: 112, crit: 8, critDmg: 152, acc: 92 }),
    growth: { hp: 160, mag: 7.8, res: 10 , def: 6 },
    skills: ["heal", "ironDiscipline", "siegeBombardment"],
    bonusSkills: [
      { skillId: "groupHeal", unlockCondition: { type: "heroLevel", level: 24 } },
      { skillId: "admiralCommand", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "navyMedic",
    build: "support",
    flavor: "Aidela vá vết thương ngay giữa làn pháo — sau mỗi Volley cô chạy khắp boong tàu hồi phục đồng đội, không kể bản thân đang chảy máu.",
  },

  // LEGENDARY — Navy Tank (Ironhull)
  // Balance: Kira legendary tank — HP 2050→2180 (Pestis legendary 2340, khoảng cách ok)
  // def:188 là cao nhất legendary tier — bù lại SPD cực chậm
  {
    id: "h_dreadnought_kira",
    name: "Kira Pháo Đài Thép",
    title: "Chiến Hạm Bất Khả Xâm",
    rarity: "legendary",
    range: "melee",
    role: "tank",
    origins: ["navy", "cyber", "ancient"],
    baseStats: s({ hp: 5450, atk: 63, def: 340, res: 260, spd: 68, crit: 7, critDmg: 155, lifesteal: 14 }),
    growth: { hp: 330, atk: 4.8, def: 20, res: 12 },
    skills: ["anchorSmash", "navalBlockade", "navalRamming"],
    bonusSkills: [
      { skillId: "ironBulwark", unlockCondition: { type: "heroLevel", level: 30 } },
      { skillId: "fullBroadside", unlockCondition: { type: "twoSkillsMaxLevel" } },
    ],
    passive: "ironhullBody",
    build: "tank",
    flavor: "Kira là tàu chiến được đặt vào thân người — giáp sắt fused với xương, pháo ở ngực, và ý chí thép không bao giờ để tàu chìm.",
  },

  // MYTHIC — Admiral Vayne
  // Balance: Vayne mythic marksman — ngang Silvanir legendary (atk:200 crit:30 spd:150)
  // Vayne mythic nên mạnh hơn: atk:255 crit:33 spd:145 — hơi thấp hơn Xara (atk:270 crit:50)
  // Vayne là utility carry (Volley leader) nên tradeoff crit lấy utility passive
  {
    id: "h_admiral_vayne",
    name: "Vayne Đô Đốc Vô Bại",
    title: "Đô Đốc Thống Lĩnh Đại Dương",
    rarity: "mythic",
    range: "ranged",
    role: "marksman",
    origins: ["navy", "celestial", "ancient"],
    baseStats: s({ hp: 5100, atk: 107, def: 270, res: 276, spd: 145, crit: 33, critDmg: 218, acc: 115 }),
    growth: { hp: 375.0, atk: 8.4, spd: 2.5, crit: 1.2 , def: 12.0, res: 12.0 },
    skills: ["broadsideCannon", "admiralCommand", "siegeBombardment"],
    bonusSkills: [
      { skillId: "fullBroadside", unlockCondition: { type: "heroLevel", level: 45 } },
      { skillId: "navalRamming", unlockCondition: { type: "twoSkillsMaxLevel" } },
      { skillId: "ironDiscipline", unlockCondition: { type: "battlesWon", count: 70 } },
    ],
    passive: "admiralPresence",
    build: "carry",
    flavor: "Vayne chưa bao giờ thua một trận hải chiến. Dưới quyền chỉ huy của ngài, Volley không phải pháo lệnh — đó là bản nhạc tử thần hòa tấu hoàn hảo.",
  },

]

export const HEROES_BY_ID: Record<string, HeroTemplate> = HEROES.reduce(
  (acc, h) => {
    acc[h.id] = h
    return acc
  },
  {} as Record<string, HeroTemplate>,
)

export const HEROES_BY_RARITY: Record<Rarity, HeroTemplate[]> = HEROES.reduce(
  (acc, h) => {
    if (!acc[h.rarity]) acc[h.rarity] = []
    acc[h.rarity].push(h)
    return acc
  },
  {} as Record<Rarity, HeroTemplate[]>,
)

// ── Inject order innates into each hero template at module load ──
for (const h of HEROES) {
  const oi = getOrderInnateForHero(h.id)
  if (oi) (h as any).orderInnate = oi
}

