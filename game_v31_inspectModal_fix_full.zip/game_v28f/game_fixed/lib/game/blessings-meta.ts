// Lightweight blessing/pact metadata — no hooks, safe to import in UI components
import { BLESSINGS, PACTS } from "./blessings"

export type BlessingMeta = {
  id: string
  name: string
  kind: "blessing" | "pact"
  tier: 1 | 2 | 3
  description: string
  curseSuffix?: string
}

const _meta: Record<string, BlessingMeta> = {}
for (const b of [...BLESSINGS, ...PACTS]) {
  _meta[b.id] = { id: b.id, name: b.name, kind: b.kind, tier: b.tier, description: b.description, curseSuffix: (b as any).curseSuffix }
}

export function getBlessingMeta(id: string | undefined): BlessingMeta | null {
  if (!id) return null
  return _meta[id] ?? null
}
