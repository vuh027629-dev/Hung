// ============================================================
// PvP Session Service — Supabase realtime turn-based sync
// ============================================================

import { supabase } from "./cloud-save"
import type { CombatState } from "./types"

export interface PvpSession {
  id: string
  player1: string    // challenger (sent invite) — sees their team as "player"
  player2: string    // accepter — must flip perspective
  turn_owner: string // username of who acts next
  combat_state: CombatState  // always stored in player1 POV
  updated_at: string
}

// Called by player2 (accepter) — creates the session with initial combat
export async function createPvpSession(
  player1: string,
  player2: string,
  initialCombat: CombatState
): Promise<{ ok: boolean; id?: string; error?: string }> {
  const { data, error } = await supabase
    .from("pvp_sessions")
    .insert({
      player1,
      player2,
      turn_owner: player1,   // player1 (challenger) always goes first
      combat_state: initialCombat,
    })
    .select("id")
    .single()

  if (error) return { ok: false, error: error.message }
  return { ok: true, id: data.id }
}

// Push updated combat state after a player acts
// IMPORTANT: always store in player1 POV — player2 flips before calling this
export async function pushPvpTurn(
  sessionId: string,
  nextTurnOwner: string,
  newCombatState: CombatState
): Promise<{ ok: boolean; error?: string }> {
  const { error } = await supabase
    .from("pvp_sessions")
    .update({
      turn_owner: nextTurnOwner,
      combat_state: newCombatState,
      updated_at: new Date().toISOString(),
    })
    .eq("id", sessionId)

  if (error) return { ok: false, error: error.message }
  return { ok: true }
}

// Subscribe realtime to receive opponent's moves
export function subscribePvpSession(
  sessionId: string,
  onUpdate: (session: PvpSession) => void
) {
  const channel = supabase
    .channel(`pvp_session:${sessionId}`)
    .on(
      "postgres_changes",
      {
        event: "UPDATE",
        schema: "public",
        table: "pvp_sessions",
        filter: `id=eq.${sessionId}`,
      },
      (payload) => onUpdate(payload.new as PvpSession)
    )
    .subscribe()

  return () => supabase.removeChannel(channel)
}
