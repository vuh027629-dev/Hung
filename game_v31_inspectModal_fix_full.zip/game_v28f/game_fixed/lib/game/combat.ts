import { HEROES, HEROES_BY_ID } from "./heroes"
import { ORDER_INNATES } from "./order-innates"
import { SYNERGIES } from "./factions"
import { ITEMS_BY_ID, generateEnemyEquipment } from "./items"
import { PASSIVES, SKILLS, SKILL_EVOLUTION_MAP } from "./skills"
import { RARITY_STAT_MULT, rarityRank } from "./rarity"
import { ALL_BY_ID, BLESSINGS, PACTS } from "./blessings"
import type { BlessingPactContext } from "./blessings"
import type {
  BattleRow,
  BattleSide,
  BattleUnit,
  CombatLogEntry,
  CombatState,
  GameState,
  HeroTemplate,
  ItemPassive,
  Rarity,
  OwnedHero,
  Skill,
  SkillEffect,
  Stats,
  StatusEffect,
  Trait,
} from "./types"

// Energy system constants
const ENERGY_MAX = 100
const ENERGY_TURN_GAIN = 20 // per own turn
const ENERGY_ON_HIT = 8 // when taking damage
const ENERGY_ON_DEAL = 3 // when dealing damage
const ULTIMATE_ENERGY_COST = 100

// FIX: Skill damage/heal scale multiplier by caster rarity.
// Legendary hero with scale=1.0 skill now effectively hits at 1.38×,
// vs Common hero at 1.0×. Eliminates the problem of high-rarity heroes
// sharing the same low-scale skills without feeling stronger.
const RARITY_SKILL_MULT: Record<string, number> = {
  common:    1.00,
  rare:      1.10,
  uncommon:  1.10, // enemy rarity alias
  epic:      1.22,
  legendary: 1.38,
  mythic:    1.58,
  celestial: 1.82,
}

// Keep log bounded to avoid memory + render cost in long fights
const LOG_MAX = 300
const LOG_TRIM_TO = 200

/** Trim log in-place if it exceeds LOG_MAX entries */
function trimLog(log: CombatLogEntry[]) {
  if (log.length > LOG_MAX) {
    log.splice(0, log.length - LOG_TRIM_TO)
  }
}

// ============================================================
// Helpers
// ============================================================

const uid = () => Math.random().toString(36).slice(2, 11)

// ============================================================
// Blessing/Pact hook dispatcher
// ============================================================
// ============================================================
// Blessing/Pact hook dispatcher (also exported for store use)
// ============================================================
export function _fireHook(
  hookName: keyof import("./blessings").BlessingPactHooks,
  state: CombatState,
  bearer: BattleUnit,
  extras: Partial<Omit<BlessingPactContext, "state"|"bearer"|"log">> = {}
) {
  fireHook(hookName, state, bearer, extras)
}

function fireHook(
  hookName: keyof import("./blessings").BlessingPactHooks,
  state: CombatState,
  bearer: BattleUnit,
  extras: Partial<Omit<BlessingPactContext, "state"|"bearer"|"log">> = {}
) {
  if (!bearer.blessingPactId) return
  const bp = ALL_BY_ID[bearer.blessingPactId]
  if (!bp) return
  const hook = bp.hooks[hookName] as ((ctx: BlessingPactContext) => void) | undefined
  if (!hook) return
  hook({
    state,
    bearer,
    log: state.log,
    allies: state.units.filter(u => u.side === bearer.side && u.hp > 0),
    enemies: state.units.filter(u => u.side !== bearer.side && u.hp > 0),
    ...extras,
  })
}

function emptyStats(): Stats {
  return {
    hp: 0, atk: 0, mag: 0, def: 0, res: 0,
    spd: 0, crit: 0, critDmg: 0, acc: 0, eva: 0, lifesteal: 0,
  }
}

function addStats(a: Stats, b: Partial<Stats>): Stats {
  const out = { ...a }
  for (const k in b) {
    const key = k as keyof Stats
    out[key] = (out[key] || 0) + (b[key] || 0)
  }
  return out
}

function multiplyStatsByPct(base: Stats, pct: Partial<Stats>): Stats {
  // Used for synergy modifiers where values are percentages (0.2 = +20%)
  // NOTE: only called for in-battle blessings now; pre-battle stats use applyModifierPool
  const out = { ...base }
  for (const k in pct) {
    const key = k as keyof Stats
    const mult = pct[key] || 0
    if (key === "crit" || key === "critDmg" || key === "acc" || key === "eva" || key === "lifesteal") {
      out[key] = (out[key] || 0) + mult
    } else {
      out[key] = Math.round((out[key] || 0) * (1 + mult))
    }
  }
  return out
}

// Merge two % modifier pools additively
function mergeModifiers(a: Partial<Stats>, b: Partial<Stats>): Partial<Stats> {
  const out = { ...a }
  for (const k in b) {
    const key = k as keyof Stats
    out[key] = (out[key] || 0) + (b[key] || 0)
  }
  return out
}

// Apply a collected pool of % modifiers to base stats in ONE pass (additive semantics)
// FIX: prevents ×1.3 × 1.25 × 1.45 multiplicative chain; instead (1 + 0.30+0.25+0.45)
function applyModifierPool(base: Stats, pool: Partial<Stats>): Stats {
  const out = { ...base }
  for (const k in pool) {
    const key = k as keyof Stats
    const val = pool[key] || 0
    if (key === "crit" || key === "critDmg" || key === "acc" || key === "eva" || key === "lifesteal") {
      out[key] = (out[key] || 0) + val
    } else {
      out[key] = Math.round((out[key] || 0) * (1 + val))
    }
  }
  return out
}

// Compute final stats for an owned hero at its level + equipment
export function computeHeroStats(owned: OwnedHero, template?: HeroTemplate, inventory?: GameState["inventory"]): Stats {
  const tpl = template || HEROES_BY_ID[owned.templateId]
  if (!tpl) return emptyStats()

  const lvl = owned.level
  const mult = RARITY_STAT_MULT[tpl.rarity]

  // Higher rarity heroes grow faster per level — ensures late-game mythic+
  // feel meaningfully tankier than lower tiers even before stat multipliers.
  const RARITY_GROWTH_MULT: Record<string, number> = {
    common: 1.00, rare: 1.06, uncommon: 1.06,
    epic: 1.14, legendary: 1.28, mythic: 1.50, celestial: 1.78,
    transcendent: 2.10, divine: 2.50, primordial: 3.00,
  }
  const growthMult = RARITY_GROWTH_MULT[tpl.rarity] ?? 1.0

  // Step 1: Base + growth*level (growth now amplified by rarity)
  // Step 1: Base + growth*level
  // growthMult VÀ mult CHỈ áp dụng cho: hp, atk, mag, def, res
  // crit, critDmg, spd, acc, lifesteal, eva: chỉ dùng base, KHÔNG tăng theo level
  const RAW_STATS = new Set(["hp", "atk", "mag", "def", "res"])
  let stats: Stats = { ...emptyStats() }
  for (const key in tpl.baseStats) {
    const k = key as keyof Stats
    const base = tpl.baseStats[k] || 0
    const grow = (tpl.growth as Stats)[k] || 0
    if (RAW_STATS.has(k)) {
      stats[k] = Math.round((base + grow * (lvl - 1) * growthMult) * mult)
    } else {
      stats[k] = base  // giữ nguyên base, không tăng theo level
    }
  }

  // Step 2: Equipment — flat additive (always correct)
  for (const slot of ["weapon", "armor", "trinket"] as const) {
    const itemId = owned.equipment[slot]
    if (!itemId) continue
    const item = ITEMS_BY_ID[itemId]
    if (!item || !item.stats) continue
    stats = addStats(stats, item.stats)
    // Apply innate bonus from inventory if present
    if (inventory) {
      const invEntry = inventory.find(i => i.itemId === itemId && i.innate)
      if (invEntry?.innate) {
        const { stat, value } = invEntry.innate
        stats[stat] = (stats[stat] || 0) + value
      }
    }
  }

  // Step 3: Collect skill-level % bonus into pool (do NOT apply yet)
  // Each skill level gives +2% to primary stat, max 15 levels → up to +30%
  // Only hp, atk, mag, def, res are affected — no spd/crit/etc from skill levels
  let pctPool: Partial<Stats> = {}
  const sLvlSum = owned.skillLevels.reduce((a, b) => a + b, 0)
  if (tpl.role === "mage" || tpl.role === "support") {
    pctPool = mergeModifiers(pctPool, { mag: sLvlSum * 0.02, res: sLvlSum * 0.01 })
  } else if (tpl.role === "tank") {
    pctPool = mergeModifiers(pctPool, { def: sLvlSum * 0.02, hp: sLvlSum * 0.01 })
  } else {
    // carry / assassin / ranger — atk only (no spd)
    pctPool = mergeModifiers(pctPool, { atk: sLvlSum * 0.02 })
  }

  // Step 4: Add passive modifier into the same pool (additive with skill levels)
  const passive = PASSIVES[tpl.passive]
  if (passive?.modifier) {
    pctPool = mergeModifiers(pctPool, passive.modifier as Partial<Stats>)
  }

  // Step 5: Apply entire pool in one pass (additive semantics)
  stats = applyModifierPool(stats, pctPool)

  return stats
}

export function xpToNextLevel(level: number) {
  return Math.round(80 + level * 60 + level * level * 8)
}

export function playerXpToNextLevel(level: number) {
  return Math.round(120 + level * 100 + level * level * 12)
}

// ============================================================
// Synergy computation
// ============================================================

export type AppliedSynergy = {
  trait: Trait
  name: string
  count: number
  tier: { count: number; description: string; modifiers: Partial<Stats>; bonusId?: string }
}

export function computeSynergies(team: HeroTemplate[]): AppliedSynergy[] {
  const counts: Record<string, number> = {}
  for (const h of team) {
    counts[h.role] = (counts[h.role] || 0) + 1
    for (const o of h.origins) counts[o] = (counts[o] || 0) + 1
  }
  const applied: AppliedSynergy[] = []
  for (const syn of SYNERGIES) {
    const c = counts[syn.trait] || 0
    if (c < 2) continue
    // Pick highest tier whose count threshold is satisfied
    let best = syn.tiers[0]
    for (const t of syn.tiers) {
      if (c >= t.count) best = t
    }
    applied.push({ trait: syn.trait, name: syn.name, count: c, tier: best })
  }
  return applied
}

// ============================================================
// Build BattleUnit from owned hero
// ============================================================

function ownedToUnit(
  owned: OwnedHero,
  side: BattleSide,
  playerStatBonuses: Partial<Stats> = {},
): BattleUnit {
  const tpl = HEROES_BY_ID[owned.templateId]
  let stats = computeHeroStats(owned, tpl)
  // Player stat bonuses (account-wide) only apply to player side
  // Bonuses are % of hero's own stats so they stay meaningful at all stages.
  // Each point in store = 1 unit of bonus; here 1 unit → +2% of that stat.
  // crit/spd treated as flat (they are % stats, not raw values).
  if (side === "player") {
    const pctBonus: Partial<Stats> = {}
    for (const k in playerStatBonuses) {
      const key = k as keyof Stats
      const pts = playerStatBonuses[key] ?? 0
      if (pts === 0) continue
      if (key === "crit" || key === "spd") {
        // flat additive for percent-style stats
        pctBonus[key] = pts
      } else {
        // convert flat points → % multiplier (each 4 atk pts = 1 unit = 2%)
        // pts already represents the accumulated flat value from store,
        // so we reinterpret: bonus% = pts / perPointValue * 0.02
        // perPointValue: atk=4, mag=5, def=4, hp=30, spd=2, crit=1
        const PER_POINT: Record<string, number> = { atk: 4, mag: 5, def: 4, hp: 30 }
        const perPt = PER_POINT[key] ?? 4
        const numPoints = pts / perPt        // how many stat points were spent
        const pctMult = numPoints * 0.02     // each point = +2% of hero base stat
        pctBonus[key] = Math.round((stats[key] || 0) * pctMult)
      }
    }
    stats = addStats(stats, pctBonus)
  }
  // Passive flat modifiers are now collected into the additive pool inside
  // computeHeroStats — do NOT apply again here to avoid double-counting.
  // Aggregate item passives from equipment
  const itemPassives: ItemPassive[] = []
  for (const slot of ["weapon", "armor", "trinket"] as const) {
    const itemId = owned.equipment[slot]
    if (!itemId) continue
    const item = ITEMS_BY_ID[itemId]
    if (item?.passive) itemPassives.push(item.passive)
  }
  const hpMax = stats.hp
  return {
    uid: uid(),
    side,
    row: "front" as BattleRow, // default; overridden by buildCombatState
    templateId: tpl.id,
    name: tpl.name,
    rarity: tpl.rarity,
    range: tpl.range,
    role: tpl.role,
    origins: tpl.origins,
    level: owned.level,
    hp: hpMax,
    hpMax,
    energy: 0,
    energyMax: ENERGY_MAX,
    stats,
    skills: (owned.equippedSkillIds ?? tpl.skills).map((sid, i) => {
      const isBonus = !tpl.skills.includes(sid as any)
      const lvl = isBonus ? ((owned.bonusSkillLevels ?? {})[sid] ?? 1) : owned.skillLevels[i]
      const evoId = SKILL_EVOLUTION_MAP[sid]
      const useId = lvl >= 5 && evoId ? evoId : sid
      return SKILLS[useId] ?? SKILLS[sid]
    }),
    skillLevels: (owned.equippedSkillIds ?? tpl.skills).map((sid, i) => {
      const isBonus = !tpl.skills.includes(sid as any)
      return isBonus ? ((owned.bonusSkillLevels ?? {})[sid] ?? 1) : owned.skillLevels[i]
    }) as [number, number, number],
    passiveId: tpl.passive,
    orderInnateId: tpl.orderInnate?.id,
    slotIndex: 0,
    cooldowns: [0, 0, 0],
    statuses: [],
    build: tpl.build,
    synergyText: [],
    itemPassives,
    equipment: { ...owned.equipment },
    blessingPactId: owned.blessingPactId,
    lowHpTriggered: false,
  }
}

function applySynergyToUnit(unit: BattleUnit, syn: AppliedSynergy[]): BattleUnit {
  // FIX: collect all synergy % modifiers into one additive pool, apply once.
  // Previously each synergy multiplied sequentially (×1.3 × 1.45 etc).
  let pool: Partial<Stats> = {}
  const log: string[] = []
  for (const a of syn) {
    pool = mergeModifiers(pool, a.tier.modifiers)
    log.push(`${a.name}(${a.count}): ${a.tier.description}`)
  }
  const stats = applyModifierPool({ ...unit.stats }, pool)
  const hpMax = stats.hp
  return { ...unit, stats, hpMax, hp: hpMax, synergyText: log }
}

// ============================================================
// Enemy generation (procedural per stage)
// ============================================================

function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]
}

/**
 * Pick a rarity for an enemy slot based on stage thresholds:
 *
 * Common:    always available
 * Rare:      stage 5–15, chance fades from 100%→0% linearly over that range
 * Epic:      stage 10–30
 * Legendary: stage 25–50
 * Mythic:    stage 50+
 *
 * Celestial: ultra-rare special case (handled separately, see below)
 */
function pickEnemyRarity(stage: number): Rarity {
  // Weight for each non-celestial rarity at this stage
  const weights: Record<Rarity, number> = {
    common: 0,
    rare: 0,
    epic: 0,
    legendary: 0,
    mythic: 0,
    celestial: 0,
    transcendent: 0,
    divine: 0,
    primordial: 0,
  }

  // Common is allowed only below stage 15 (tầng 15+: không còn Common)
  if (stage < 15) {
    weights.common = 1
  }

  // Rare: stage 5 (100%) -> stage 15 (0%), linear fade
  // Special: stage 15-24 fixed 40% Rare / 60% Epic (no Common)
  if (stage >= 5 && stage < 15) {
    weights.rare = 1 - (stage - 5) / 10
  } else if (stage >= 15 && stage < 25) {
    // Rare 40% / Epic 60% mix at stage 15-24
    weights.rare = 0.67
  }

  // Epic: stage 10 (0%) -> stage 20 (100%) ramp up, then stays until stage 30
  // Special: stage 15-24 fixed weight 1.0 (pairs with Rare 0.67 => 40/60 split)
  if (stage >= 10 && stage <= 30) {
    if (stage >= 15 && stage < 25) {
      weights.epic = 1
    } else if (stage < 20) {
      weights.epic = (stage - 10) / 10
    } else {
      weights.epic = 1
    }
  }

  // Legendary: stage 25 (0%) → stage 40 (100%) ramp up, then stays until stage 50
  if (stage >= 25 && stage <= 50) {
    if (stage < 40) {
      weights.legendary = (stage - 25) / 15
    } else {
      weights.legendary = 1
    }
  }

  // Mythic: stage 50+, ramps in from 50 (0%) → 65 (100%)
  if (stage >= 50) {
    weights.mythic = Math.min(1, (stage - 50) / 15)
  }

  // Normalize and roll
  const entries = (["common", "rare", "epic", "legendary", "mythic"] as Rarity[]).filter(
    (r) => weights[r] > 0
  )
  const total = entries.reduce((s, r) => s + weights[r], 0)
  const roll = Math.random() * total
  let acc = 0
  for (const r of entries) {
    acc += weights[r]
    if (roll < acc) return r
  }
  return entries[entries.length - 1]
}

/**
 * How many celestial enemies can appear in one battle, by stage:
 *   stage < 70   → max 1
 *   stage 70–99  → max 2
 *   stage 100+   → max 4
 */
function celestialMaxCount(stage: number): number {
  if (stage >= 100) return 4
  if (stage >= 70) return 2
  return 1
}

/**
 * Probability that a single slot gets replaced by a celestial enemy:
 *   stage < 5      → 0.005 (0.5%) — always present as a tiny surprise
 *   stage 5–69     → 0.005 linear approach toward 25% at stage 70
 *   stage 70–99    → 0.25 (25%) — jumps at 70, grows toward 50% at 100
 *   stage 100+     → 0.50 (50%)
 */
function celestialChance(stage: number): number {
  if (stage >= 100) return 0.50
  if (stage >= 70) {
    // 25% at stage 70 → 50% at stage 100
    return 0.25 + (stage - 70) / 30 * 0.25
  }
  // stage 0–69: 0.5% flat (ultra rare surprise at low floors)
  return 0.005
}

// ── Enemy Blessing/Pact generation ──────────────────────────────────────────
// Chance that a single enemy unit gets a blessing or pact — mirrors equipment
// chance table. Starts from stage 5, ramps steadily.
function enemyBlessingChance(stage: number): number {
  if (stage < 5)   return 0.00  // tầng 1-4: thuần túy không có phúc/kèo
  if (stage < 10)  return 0.08  // tầng 5-9: hiếm gặp (1 trong ~12 unit)
  if (stage < 15)  return 0.15  // tầng 10-14: thỉnh thoảng
  if (stage < 25)  return 0.25  // tầng 15-24: đáng chú ý
  if (stage < 40)  return 0.40  // tầng 25-39: gần nửa đội
  if (stage < 55)  return 0.58  // tầng 40-54: đa số
  if (stage < 70)  return 0.72  // tầng 55-69: phần lớn
  if (stage < 85)  return 0.85  // tầng 70-84: gần hết
  return 0.95                   // tầng 85+: gần như toàn bộ
}

// [tier1, tier2, tier3] weights — low stages only Tier 1; high stages mostly Tier 3
function enemyBlessingTierWeights(stage: number): [number, number, number] {
  if (stage < 15)  return [100,  0,  0]
  if (stage < 30)  return [ 75, 22,  3]
  if (stage < 45)  return [ 50, 38, 12]
  if (stage < 60)  return [ 25, 48, 27]
  if (stage < 75)  return [ 10, 40, 50]
  if (stage < 90)  return [  3, 27, 70]
  return                  [  0, 10, 90]
}

function pickBlessingTier(stage: number): 1 | 2 | 3 {
  const [w1, w2, w3] = enemyBlessingTierWeights(stage)
  const r = Math.random() * (w1 + w2 + w3)
  if (r < w1) return 1
  if (r < w1 + w2) return 2
  return 3
}

// Assign a blessing or pact (60/40) to one enemy, avoiding duplicates in team
function generateEnemyBlessingPact(stage: number, usedIds: Set<string>): string | undefined {
  if (Math.random() >= enemyBlessingChance(stage)) return undefined
  const tier = pickBlessingTier(stage)
  // 60% blessing, 40% pact — pacts are scarier and rarer
  const pool = Math.random() < 0.60 ? BLESSINGS : PACTS
  const candidates = pool.filter(bp => bp.tier === tier && !usedIds.has(bp.id))
  // Fallback: any from pool not yet used
  const fallbackPool = candidates.length > 0 ? candidates : pool.filter(bp => !usedIds.has(bp.id))
  if (fallbackPool.length === 0) return undefined
  const pick = fallbackPool[Math.floor(Math.random() * fallbackPool.length)]
  usedIds.add(pick.id)
  return pick.id
}
// ────────────────────────────────────────────────────────────────────────────

// Role categories for composition balancing
const DAMAGE_ROLES = new Set(["warrior", "assassin", "marksman", "mage"])
const PASSIVE_ROLES = new Set(["tank", "support"])

// Glass-cannon roles that cannot fill ALL slots (marksman + mage squishies)
const SQUISHY_ROLES = new Set(["marksman", "mage"])

/**
 * Pick a hero template by rarity for a given slot, with an optional role constraint.
 * If a role filter is provided, tries to find a hero matching that role at the desired rarity;
 * falls back to any hero at that rarity, then any hero overall.
 */
function pickHeroByRarityAndRole(
  stage: number,
  celestialHeroes: HeroTemplate[],
  celestialSpawned: number,
  maxCelestials: number,
  celChance: number,
  allowedRoles?: Set<string>,
): { tpl: HeroTemplate; isCelestial: boolean } {
  // Attempt to spawn a celestial for this slot
  if (celestialSpawned < maxCelestials && celestialHeroes.length > 0 && Math.random() < celChance) {
    const celPool = allowedRoles
      ? celestialHeroes.filter((h) => allowedRoles.has(h.role))
      : celestialHeroes
    const pool = celPool.length > 0 ? celPool : celestialHeroes
    return { tpl: pickRandom(pool), isCelestial: true }
  }

  const rarity = pickEnemyRarity(stage)
  const rarityPool = HEROES.filter((h) => h.rarity === rarity)
  const fallbackPool = rarityPool.length > 0 ? rarityPool : HEROES.filter((h) => h.rarity === "common")

  if (allowedRoles) {
    const filtered = fallbackPool.filter((h) => allowedRoles.has(h.role))
    if (filtered.length > 0) return { tpl: pickRandom(filtered), isCelestial: false }
    // Softer fallback: any rarity with allowed role
    const anyRarityFiltered = HEROES.filter((h) => allowedRoles.has(h.role))
    if (anyRarityFiltered.length > 0) return { tpl: pickRandom(anyRarityFiltered), isCelestial: false }
  }

  return { tpl: pickRandom(fallbackPool), isCelestial: false }
}

export function generateEnemyTeam(stage: number): OwnedHero[] {
  const count = Math.min(5, 2 + Math.floor(stage / 3))
  const enemyLevel = Math.max(1, Math.floor(stage * 1.3))

  const celestialHeroes = HEROES.filter((h) => h.rarity === "celestial")
  const maxCelestials = celestialMaxCount(stage)
  const celChance = celestialChance(stage)

  // ── Role-balance constraints ──────────────────────────────────────────────
  // Rules to prevent mono-role teams:
  //   1. At least 1 damage dealer (warrior/assassin/marksman/mage) — always
  //   2. At least 1 tank OR warrior (frontline) — for teams of 3+
  //   3. Max passive (tank+support) = floor(count / 2), so never all-passive
  //   4. Max squishy glass-cannons (marksman+mage) = floor(count * 0.6),
  //      so never a full team of paper heroes
  //
  // Strategy: pre-assign "forced" roles for the first slots to satisfy
  // constraints, then fill remaining slots freely (still filtered by role caps).

  const maxPassive = Math.floor(count / 2)           // e.g. 2 for 5-man, 1 for 3-man
  const maxSquishy = Math.floor(count * 0.6)         // e.g. 3 for 5-man

  // We'll track counts as we build
  let passiveCount = 0
  let squishyCount = 0
  let damageCount = 0

  const team: OwnedHero[] = []
  let celestialSpawned = 0
  const usedBlessingIds = new Set<string>()

  const enemySkillLv = Math.min(5,
    stage >= 75 ? 5 :
    stage >= 50 ? 4 :
    stage >= 30 ? 3 :
    stage >= 15 ? 2 : 1
  ) as 1 | 2 | 3 | 4 | 5
  const skillLevels: [number, number, number] = [enemySkillLv, enemySkillLv, enemySkillLv]

  for (let i = 0; i < count; i++) {
    const slotsLeft = count - i
    const damageLeft = damageCount  // damage heroes picked so far

    // Determine role filter for this slot
    let allowedRoles: Set<string> | undefined

    const needsDamage = damageLeft === 0 && slotsLeft === 1  // last slot, still no damage dealer
    const passiveFull = passiveCount >= maxPassive
    const squishyFull = squishyCount >= maxSquishy

    if (needsDamage) {
      // Force a damage dealer on the last slot if we haven't picked any
      allowedRoles = DAMAGE_ROLES
    } else if (passiveFull && squishyFull) {
      // Can't add more tank/support OR more squishy — only warrior/assassin allowed
      allowedRoles = new Set(["warrior", "assassin"])
    } else if (passiveFull) {
      // No more tanks/supports — pick any damage role (including marksman/mage if not full)
      allowedRoles = DAMAGE_ROLES
    } else if (squishyFull) {
      // No more glass-cannons — pick warrior, assassin, tank, or support
      allowedRoles = new Set(["warrior", "assassin", "tank", "support"])
    }
    // else: no constraint, any role is fine

    const { tpl, isCelestial } = pickHeroByRarityAndRole(
      stage,
      celestialHeroes,
      celestialSpawned,
      maxCelestials,
      celChance,
      allowedRoles,
    )

    if (isCelestial) celestialSpawned++

    // Update role counters
    if (PASSIVE_ROLES.has(tpl.role)) passiveCount++
    if (SQUISHY_ROLES.has(tpl.role)) squishyCount++
    if (DAMAGE_ROLES.has(tpl.role)) damageCount++

    const blessingPactId = generateEnemyBlessingPact(stage, usedBlessingIds)

    team.push({
      uid: uid(),
      templateId: tpl.id,
      level: enemyLevel,
      xp: 0,
      skillLevels,
      equipment: generateEnemyEquipment(stage),
      ...(blessingPactId ? { blessingPactId } : {}),
    })
  }
  return team
}

/**
 * Sinh tuong du bi cho ke dich.
 * Stage 5+: 0-1 (40% chance) | Stage 15+: 1-2 (60%) | Stage 30+: 1-3 (80%)
 */
export function generateEnemyReserve(stage: number): OwnedHero[] {
  if (stage < 5) return []
  const chance = stage >= 30 ? 0.80 : stage >= 15 ? 0.60 : 0.40
  if (Math.random() > chance) return []

  const maxReserve = stage >= 30 ? 3 : stage >= 15 ? 2 : 1
  const count = Math.floor(Math.random() * maxReserve) + 1
  const enemyLevel = Math.max(1, Math.floor(stage * 1.2))
  const celestialHeroes = HEROES.filter((h) => h.rarity === "celestial")
  const maxCelestials = Math.min(1, celestialMaxCount(stage))
  const celChance = celestialChance(stage) * 0.5

  const enemySkillLv = Math.min(4,
    stage >= 50 ? 4 : stage >= 30 ? 3 : stage >= 15 ? 2 : 1
  ) as 1 | 2 | 3 | 4 | 5
  const skillLevels: [number, number, number] = [enemySkillLv, enemySkillLv, enemySkillLv]

  const reserve: OwnedHero[] = []
  let celestialSpawned = 0
  for (let i = 0; i < count; i++) {
    const { tpl, isCelestial } = pickHeroByRarityAndRole(
      stage, celestialHeroes, celestialSpawned, maxCelestials, celChance, undefined
    )
    if (isCelestial) celestialSpawned++
    reserve.push({
      uid: uid(),
      templateId: tpl.id,
      level: enemyLevel,
      xp: 0,
      skillLevels,
      equipment: generateEnemyEquipment(stage),
    })
  }
  return reserve
}

// ============================================================
// Combat state setup
// ============================================================

export function buildCombatState(state: GameState): CombatState {
  const stage = state.currentStage
  // Player team
  const playerSlots = state.team
    .map((id, idx) => ({ id, idx }))
    .filter((s): s is { id: string; idx: number } => !!s.id)

  const playerOwned: OwnedHero[] = playerSlots
    .map(s => state.heroes.find(h => h.uid === s.id))
    .filter((h): h is OwnedHero => !!h)

  const playerRows = playerSlots.map((s, i) => {
    const rows = state.teamRows ?? []
    return (rows[s.idx] ?? (playerOwned[i] && HEROES_BY_ID[playerOwned[i].templateId]?.range === "melee" ? "front" : "back")) as BattleRow
  })

  const playerTpls = playerOwned.map((h) => HEROES_BY_ID[h.templateId])
  const playerSyn = computeSynergies(playerTpls)
  // Use cached enemy team if available (ensures scout preview == actual combat enemies)
  const enemyOwned = state.cachedEnemyTeam ?? generateEnemyTeam(stage)
  const enemyTpls = enemyOwned.map((h) => HEROES_BY_ID[h.templateId])
  const enemySyn = computeSynergies(enemyTpls)

  const playerBonuses: Partial<Stats> = {
    atk: state.playerStats.attackBonus,
    mag: state.playerStats.magicBonus,
    def: state.playerStats.defenseBonus,
    hp: state.playerStats.hpBonus,
    spd: state.playerStats.speedBonus,
    crit: state.playerStats.critBonus,
  }

  const playerUnits = playerOwned
    .map((o, i) => ({ ...ownedToUnit(o, "player", playerBonuses), row: playerRows[i], slotIndex: i }))
    .map((u) => applySynergyToUnit(u, playerSyn))

  // Enemy stat bonus scales with stage — mirrors player's % system so
  // every tầng feels meaningfully harder. Each stat gets +4% per "tier"
  // where tier = floor(stage / 5). Caps at +160% (tier 40 = stage 200).
  const enemyStatTier = Math.min(40, Math.floor(stage / 5))
  const enemyPctBonus = enemyStatTier * 0.04   // 0% at stage 0 → +160% at stage 200

  const enemyUnits = enemyOwned
    .map((o, i) => {
      const tpl = HEROES_BY_ID[o.templateId]
      const autoRow: BattleRow = tpl?.range === "melee" ? "front" : "back"
      const unit = { ...ownedToUnit(o, "enemy"), slotIndex: i }
      // Apply stage-scaling % bonus to enemy stats
      // Only scale raw power stats + spd (at half rate). Never scale crit/critDmg/acc/lifesteal
      // — those are already set by hero base and should not inflate unboundedly with stage.
      if (enemyPctBonus > 0) {
        unit.stats = {
          ...unit.stats,
          atk: Math.round(unit.stats.atk * (1 + enemyPctBonus)),
          mag: Math.round(unit.stats.mag * (1 + enemyPctBonus)),
          def: Math.round(unit.stats.def * (1 + enemyPctBonus)),
          res: Math.round(unit.stats.res * (1 + enemyPctBonus)),
          spd: Math.round(unit.stats.spd * (1 + enemyPctBonus * 0.5)), // spd tăng chậm hơn
          // crit, critDmg, acc, lifesteal: KHÔNG scale — tránh enemy crit 300%+ ở tầng cao
        }
        unit.hpMax = Math.round(unit.hpMax * (1 + enemyPctBonus))
        unit.hp = unit.hpMax
      }
      // BALANCE FIX: Giảm từ x2 xuống x1.65 — x2 quá mạnh kết hợp với high-scale true damage skills
      unit.stats = {
        ...unit.stats,
        atk: Math.round(unit.stats.atk * 1.65),
        mag: Math.round(unit.stats.mag * 1.65),
      }
      // ── Role-based defensive stat multipliers ──────────────────────────────
      // BALANCE FIX: Giảm HP/DEF/RES multiplier — trước đây quá trâu khiến true dmg heroes bị ép scale
      // Tank: ×3.2 (từ 4.0) | Warrior: ×2.5 (từ 3.0) | Others: ×1.8 (từ 2.0)
      // Kết hợp với tăng Rarity DR, tank vẫn đủ trâu nhưng không bất tử với physical/magic thuần
      const defMult = unit.role === "tank" ? 3.2 : unit.role === "warrior" ? 2.5 : 1.8
      unit.stats = {
        ...unit.stats,
        hp:  Math.round(unit.stats.hp  * defMult),
        def: Math.round(unit.stats.def * defMult),
        res: Math.round(unit.stats.res * defMult),
      }
      unit.hpMax = Math.round(unit.hpMax * defMult)
      unit.hp = unit.hpMax
      return { ...unit, row: autoRow }
    })
    .map((u) => applySynergyToUnit(u, enemySyn))

  // Event-based enemy stat scaling: blood_moon, ancient_curse, storm_of_chaos
  // FIX: previously only blood_moon was handled; ancient_curse and storm_of_chaos had no effect on combat.
  // storm_of_chaos chaosRoll is fixed HERE (not in a re-called helper) so multiplier is consistent for the whole fight.
  const activeEventIds = (state.activeEvents ?? []).map(e => e.eventId)
  const bloodMoonActive  = activeEventIds.includes("blood_moon")
  const ancientCurseActive = activeEventIds.includes("ancient_curse")
  const stormChaosActive = activeEventIds.includes("storm_of_chaos")
  const chaosRoll = stormChaosActive ? 1.1 + Math.random() * 0.4 : 1.0 // fixed once per combat build

  if (bloodMoonActive || ancientCurseActive || stormChaosActive) {
    let enemyAtkMult = 1.0
    let enemyDefMult = 1.0
    let enemyHpMult  = 1.0
    if (bloodMoonActive)   { enemyAtkMult *= 1.25; enemyDefMult *= 1.25; enemyHpMult *= 1.25 }
    if (ancientCurseActive){ enemyAtkMult *= 1.20 }  // +20% ATK only (curse: enemy ATK up, our DEF down handled below)
    if (stormChaosActive)  { enemyAtkMult *= chaosRoll; enemyDefMult *= chaosRoll; enemyHpMult *= chaosRoll }

    for (const u of enemyUnits) {
      u.stats = {
        ...u.stats,
        atk: Math.round(u.stats.atk * enemyAtkMult),
        mag: Math.round(u.stats.mag * enemyAtkMult),
        def: Math.round(u.stats.def * enemyDefMult),
        res: Math.round(u.stats.res * enemyDefMult),
      }
      u.hpMax = Math.round(u.hpMax * enemyHpMult)
      u.hp = u.hpMax
    }

    // ancient_curse: player DEF -10%
    if (ancientCurseActive) {
      for (const u of playerUnits) {
        u.stats = { ...u.stats, def: Math.round(u.stats.def * 0.90), res: Math.round(u.stats.res * 0.90) }
      }
    }
  }

  // Apply origin-based start-of-battle effects
  for (const u of [...playerUnits, ...enemyUnits]) {
    applyStartOfBattleEffects(u)
  }

  // Apply outlaw (armor break) on opposite team
  applyCrossTeamStartEffects(playerUnits, enemyUnits, playerSyn, enemySyn)
  const all = [...playerUnits, ...enemyUnits]
  const order = computeTurnOrder(all)
  const initialLog: CombatLogEntry[] = [
    { id: uid(), text: `⚔️ Tầng ${stage} bắt đầu! ${enemyUnits.length} kẻ địch xuất hiện.`, kind: "system" },
  ]

  // Announce enemy blessings/pacts at battle start so players can react
  for (const u of enemyUnits) {
    if (!u.blessingPactId) continue
    const bp = ALL_BY_ID[u.blessingPactId]
    if (!bp) continue
    const icon  = bp.kind === "blessing" ? "✦" : "🔥"
    const label = bp.kind === "blessing" ? "Chúc Phúc" : "Giao Kèo"
    initialLog.push({ id: uid(), text: `${icon} ${u.name} mang ${label} [T${bp.tier}]: ${bp.name}`, kind: "system" })
  }

  // Apply ancient cdr effect — uses initialLog so entries appear in the battle log
  applyAncientCdr(playerUnits, playerSyn, initialLog)
  applyAncientCdr(enemyUnits, enemySyn, initialLog)

  // Storm synergy: add initial SPD boost (per-turn growth handled in onEndOfTurn)
  // Phantom synergy: EVA boost already applied via modifiers in applySynergyToUnit
  // Plague synergy: damage spread handled in onEndOfTurn tick

  // FIX: awaitingPlayerInput must check the FIRST unit in turn ORDER (sorted by
  // speed), NOT all[0] which is always a player unit. When an enemy has higher
  // speed they appear first in `order` and must act automatically — the old
  // code forced awaitingPlayerInput=true in that case, causing the AI to
  // never be triggered and the "Đang tính toán..." spinner to loop forever.
  const firstInOrder = all.find((u) => u.uid === order[0])

  // ── Build reserve units (waiting to enter when a front/back hero dies) ──
  const reserveOwned: OwnedHero[] = (state.teamReserve ?? [])
    .map(id => id ? state.heroes.find(h => h.uid === id) ?? null : null)
    .filter((h): h is OwnedHero => !!h)
  const reserveRows: BattleRow[] = (state.teamReserveRows ?? [])
  const reserveUnits: BattleUnit[] = reserveOwned.map((o, i) => {
    const row = reserveRows[i] ?? (HEROES_BY_ID[o.templateId]?.range === "melee" ? "front" : "back")
    const unit = { ...ownedToUnit(o, "player", playerBonuses), row: row as BattleRow }
    return applySynergyToUnit(unit, playerSyn)
  })

  // ── Build enemy reserve units ──
  const enemyReserveOwned: OwnedHero[] = generateEnemyReserve(stage)
  const enemyReserveUnits: BattleUnit[] = enemyReserveOwned.map((o) => {
    const tpl = HEROES_BY_ID[o.templateId]
    const autoRow: BattleRow = tpl?.range === "melee" ? "front" : "back"
    const unit = { ...ownedToUnit(o, "enemy"), row: autoRow }
    if (enemyPctBonus > 0) {
      unit.stats = {
        ...unit.stats,
        atk: Math.round(unit.stats.atk * (1 + enemyPctBonus)),
        mag: Math.round(unit.stats.mag * (1 + enemyPctBonus)),
        def: Math.round(unit.stats.def * (1 + enemyPctBonus)),
        res: Math.round(unit.stats.res * (1 + enemyPctBonus)),
        spd: Math.round(unit.stats.spd * (1 + enemyPctBonus * 0.5)),
      }
      unit.hpMax = Math.round(unit.hpMax * (1 + enemyPctBonus))
      unit.hp = unit.hpMax
    }
    // x2 base damage for enemy reserve — tăng damage enemy lên gấp đôi
    unit.stats = {
      ...unit.stats,
      atk: Math.round(unit.stats.atk * 2),
      mag: Math.round(unit.stats.mag * 2),
    }
    // ── Role-based defensive stat multipliers (reserve) ──
    // QUAN TRỌNG: phải nhân cả stats.hp để applySynergyToUnit không reset hpMax về giá trị cũ
    // BALANCE FIX: Đồng bộ với defMult chính
    const reserveDefMult = unit.role === "tank" ? 3.2 : unit.role === "warrior" ? 2.5 : 1.8
    unit.stats = {
      ...unit.stats,
      hp:  Math.round(unit.stats.hp  * reserveDefMult),
      def: Math.round(unit.stats.def * reserveDefMult),
      res: Math.round(unit.stats.res * reserveDefMult),
    }
    unit.hpMax = Math.round(unit.hpMax * reserveDefMult)
    unit.hp = unit.hpMax
    return applySynergyToUnit(unit, enemySyn)
  })

  const cs: CombatState = {
    stage,
    turn: 0,
    units: all,
    order,
    activeUnitIndex: 0,
    round: 1,
    log: initialLog,
    ended: null,
    awaitingPlayerInput: firstInOrder?.side === "player",
    watchMode: false,
    watchSpeed: 1,
    potionLastUsedRound: -99, // FIX: init far in past so first use is always available
    reserveUnits,
    enemyReserveUnits,
  }
  // Fire onBattleStart for all units — players AND enemies with blessings/pacts
  for (const u of all) {
    fireHook("onBattleStart", cs, u)
  }
  return cs
}

function computeTurnOrder(units: BattleUnit[]): string[] {
  const alive = units.filter((u) => u.hp > 0)
  return alive
    .slice()
    .sort((a, b) => {
      const sa = effectiveSpd(a)
      const sb = effectiveSpd(b)
      if (sb === sa) return a.side === "player" ? -1 : 1
      return sb - sa
    })
    .map((u) => u.uid)
}

export function effectiveSpd(u: BattleUnit): number {
  let spd = u.stats.spd
  for (const st of u.statuses) {
    // FIX: exclude internal __ trackers to prevent SPD explosion from misused status kinds
    if (st.name.startsWith("__")) continue
    if (st.kind === "spdUp") spd += spd * (st.value / 100)
    if (st.kind === "spdDown") spd -= spd * (st.value / 100)
  }
  return spd
}

// ============================================================
// Speed passive bonuses
// ============================================================

/**
 * How many cooldown turns to shave off when a skill resolves,
 * based on attacker's effective speed.
 *
 * Thresholds (effective spd → reduction applied to ALL own cooldowns after casting):
 *   spd >= 150  → -1 lượt
 *   spd >= 200  → -2 lượt
 *   spd >= 250  → -3 lượt  (cap)
 */
export function spdCooldownReduction(spd: number): number {
  if (spd >= 250) return 3
  if (spd >= 200) return 2
  if (spd >= 150) return 1
  return 0
}

/**
 * How many EXTRA basic-attack hits a unit gets, determined
 * probabilistically from speed.
 *
 * Each extra hit has an independent chance based on (spd - 100) / 50,
 * capped at 4 extra hits (5 total).  
 *   spd 100 → 0% per roll   (no extras)
 *   spd 150 → 100% first hit, then 0% second  → guaranteed 1 extra
 *   spd 200 → 200% → guaranteed 2 extras, 0% third
 *   spd 250 → 300% → guaranteed 3 extras, 0% fourth
 *   spd 300 → 400% → guaranteed 4 extras
 *
 * In practice fractional portions are kept as probabilistic:
 *   e.g. spd 170 → ratio = 1.4 → 1 guaranteed + 40% chance of 2nd
 */
export function spdExtraHits(spd: number): number {
  const MAX_EXTRA = 4
  const ratio = Math.max(0, (spd - 100) / 50) // 0 at spd=100, 1.0 at 150, 4.0 at 300
  const guaranteed = Math.min(MAX_EXTRA, Math.floor(ratio))
  const chance = ratio - guaranteed          // fractional remainder as probability
  const bonus = chance > 0 && Math.random() < chance ? 1 : 0
  return Math.min(MAX_EXTRA, guaranteed + bonus)
}

/** Cuồng Đao variant — extra hits uncapped by speed but hard-capped at 20 total hits to prevent billion damage */
export function spdExtraHitsUncapped(spd: number): number {
  const ratio = Math.max(0, (spd - 100) / 50)
  const guaranteed = Math.floor(ratio)
  const chance = ratio - guaranteed
  const bonus = chance > 0 && Math.random() < chance ? 1 : 0
  // FIX: Hard cap at 20 extra hits — frenzySword primordial (+40 SPD/hit) could reach 50+ hits
  // Without cap: 20+ hits × high ATK × cursedBlade × bloodPact = million damage/turn
  return Math.min(20, guaranteed + bonus)
}

// ============================================================
// Start-of-battle effects (synergy/passive based)
// ============================================================

function applyStartOfBattleEffects(u: BattleUnit) {
  const passive = PASSIVES[u.passiveId]
  if (passive?.signatureId === "celestial-shield") {
    u.statuses.push({
      id: uid(),
      kind: "shield",
      value: 0.2,
      turns: 99,
      name: "Khiên Thiên Quang",
    })
  }
  // KSAN: Initialize turn tracker for Tích Lực
  if (passive?.signatureId === "ksan-batkhuat") {
    u.statuses.push({ id: uid(), kind: "__tracker", value: 0, turns: 9999, name: "__ksan_turns" })
  }
  // Item passive: battleStart effects
  for (const ip of u.itemPassives) {
    if (ip.kind === "battleStart") {
      if (ip.effect === "shield") {
        u.statuses.push({ id: uid(), kind: "shield", value: ip.value, turns: ip.turns, name: "Khiên Trang Bị" })
      } else if (ip.effect === "regen") {
        u.statuses.push({ id: uid(), kind: "regen", value: ip.value, turns: ip.turns, name: "Hồi Sinh" })
      } else if (ip.effect === "atkUp") {
        u.statuses.push({ id: uid(), kind: "atkUp", value: ip.value, turns: ip.turns, name: "Khích Lệ" })
      } else if (ip.effect === "defUp") {
        u.statuses.push({ id: uid(), kind: "defUp", value: ip.value, turns: ip.turns, name: "Vững Chãi" })
      }
    }
  }
}

function applyCrossTeamStartEffects(
  player: BattleUnit[],
  enemies: BattleUnit[],
  playerSyn: AppliedSynergy[],
  enemySyn: AppliedSynergy[],
) {
  // Outlaw: armor break opposite team — tối đa giảm 50% DEF
  const playerOutlaw = playerSyn.find((s) => s.trait === "outlaw")
  if (playerOutlaw?.tier.bonusId === "outlaw-armorbreak-1") {
    for (const e of enemies) e.stats.def = Math.round(e.stats.def * 0.8)  // -20%
  } else if (playerOutlaw?.tier.bonusId === "outlaw-armorbreak-2") {
    for (const e of enemies) e.stats.def = Math.round(e.stats.def * 0.5)  // -50% (cap)
  }
  const enemyOutlaw = enemySyn.find((s) => s.trait === "outlaw")
  if (enemyOutlaw?.tier.bonusId === "outlaw-armorbreak-1") {
    for (const p of player) p.stats.def = Math.round(p.stats.def * 0.8)
  } else if (enemyOutlaw?.tier.bonusId === "outlaw-armorbreak-2") {
    for (const p of player) p.stats.def = Math.round(p.stats.def * 0.5)
  }

  // Celestial team shield (synergy)
  const applyCelestialShield = (units: BattleUnit[], syn: AppliedSynergy[]) => {
    const cel = syn.find((s) => s.trait === "celestial")
    if (!cel) return
    const pct = cel.tier.bonusId === "celestial-shield-2" ? 0.3 : 0.15
    for (const u of units) {
      u.statuses.push({ id: uid(), kind: "shield", value: pct, turns: 99, name: "Khiên Thiên Đoàn" })
    }
  }
  applyCelestialShield(player, playerSyn)
  applyCelestialShield(enemies, enemySyn)
}

function applyAncientCdr(units: BattleUnit[], syn: AppliedSynergy[], log: CombatLogEntry[]) {
  const ancient = syn.find((s) => s.trait === "ancient")
  let amt = 0
  if (ancient?.tier.bonusId === "ancient-cdr-1") amt = 1
  if (ancient?.tier.bonusId === "ancient-cdr-2") amt = 2
  for (const u of units) {
    const passive = PASSIVES[u.passiveId]
    if (passive?.signatureId === "ancient-cdr") amt = Math.max(amt, 1)
  }
  if (amt > 0) {
    for (const u of units) {
      u.cooldowns = u.cooldowns.map((cd) => Math.max(0, cd - amt)) as [number, number, number]
    }
  }
}

// ============================================================
// Damage / heal application
// ============================================================

function alivesOf(state: CombatState, side: BattleSide): BattleUnit[] {
  return state.units.filter((u) => u.side === side && u.hp > 0)
}

function rollDamage(
  caster: BattleUnit,
  target: BattleUnit,
  ef: NonNullable<SkillEffect["damage"]>,
  log: CombatLogEntry[],
  state?: CombatState,
): { dmg: number; isCrit: boolean } {
  // Attack/dodge check — né tối đa 70% mỗi lần nhận damage (per-hit)
  if (ef.type !== "true") {
    const acc = caster.stats.acc
    const eva = Math.min(70, target.stats.eva) // cap 70% dodge rate
    const hitChance = Math.max(0.30, Math.min(1, (acc - eva + 100) / 100))
    if (Math.random() > hitChance) {
      log.push({
        id: uid(),
        text: `${caster.name} bị ${target.name} né tránh!`,
        kind: "info",
      })
      return { dmg: 0, isCrit: false }
    }
  }

  const sourceStat = caster.stats[ef.stat as keyof Stats] || 0
  let raw = sourceStat * ef.scale

  // ── DEF / RES: trừ vào damage GỐC trước — trước mọi buff/scale ────────────
  // Công thức mới: dmg_nhận = max(1, (raw - finalDef)) * buffMult * critMult ...
  // DEF/RES trừ thẳng vào base damage (sourceStat * scale), TRƯỚC khi atkUp,
  // crit, hay bất kỳ buff damage nào được tính.
  // → Giáp ảnh hưởng tới chỉ số damage gốc, buff chỉ nhân vào phần còn lại.
  if (ef.type === "physical") {
    const defBase = target.stats.def
    const defUp   = target.statuses.filter(s => s.kind === "defUp" && !s.name.startsWith("__")).reduce((a, s) => a + s.value, 0)
    const defDown = Math.min(50, target.statuses.filter(s => s.kind === "defDown" && !s.name.startsWith("__")).reduce((a, s) => a + s.value, 0)) // cap 50%
    const finalDef = Math.max(0, defBase * (1 + (defUp - defDown) / 100))
    // BALANCE FIX: Cap DEF reduction tại 80% max damage reduction
    // Trước đây DEF có thể xóa 100% damage → ép hero phải dùng true damage để có ý nghĩa
    // Giờ DEF trừ flat nhưng bảo đảm còn ít nhất 20% damage đến được → physical/magic vẫn scale
    const cappedDef = Math.min(finalDef, raw * 0.80)
    raw = Math.max(1, raw - cappedDef)
  } else if (ef.type === "magic") {
    const resBase = Math.max(0, target.stats.res)
    const resDown = Math.min(50, target.statuses.filter(s => s.kind === "resDown" && !s.name.startsWith("__")).reduce((a, s) => a + s.value, 0)) // cap 50%
    const finalRes = Math.max(0, resBase * (1 - resDown / 100))
    // BALANCE FIX: Tương tự physical — RES cap ở 80% reduction
    const cappedRes = Math.min(finalRes, raw * 0.80)
    raw = Math.max(1, raw - cappedRes)
  }
  // "true" damage bỏ qua def/res hoàn toàn

  // Apply attack/atk-up status — nhân vào sau khi DEF/RES đã trừ
  // FIX: Chỉ sum các status kind="atkUp" THỰC SỰ (không phải __tracker disguised as atkUp)
  // Tất cả internal trackers đã được chuyển sang kind="__tracker", nhưng thêm guard name-check cho an toàn
  const atkUp = caster.statuses
    .filter((s) => s.kind === "atkUp" && !s.name.startsWith("__"))
    .reduce((a, s) => a + s.value, 0)
  const atkDown = caster.statuses
    .filter((s) => s.kind === "atkDown" && !s.name.startsWith("__"))
    .reduce((a, s) => a + s.value, 0)
  raw *= 1 + (atkUp - atkDown) / 100

  // Crit
  let isCrit = false
  if (ef.type !== "true") {
    if (Math.random() * 100 < caster.stats.crit) {
      isCrit = true
      raw *= caster.stats.critDmg / 100
    }
  }

  // ── Rarity DR (Damage Reduction) — áp sau crit, trước execute ─────────────
  // DR theo rarity giúp unit bậc cao có lớp trâu bò nội tại.
  // true damage vẫn bị DR (50% hiệu quả) — không thể bypass hoàn toàn.
  // Physical/magic đã bị flat def/res trừ ở trên, DR là lớp bổ sung.
  {
    const RARITY_DR: Record<string, number> = {
      // BALANCE FIX: Tăng DR để tank cao rarity chịu được true damage tốt hơn
      legendary: 0.06, mythic: 0.14, celestial: 0.22,
      transcendent: 0.30, divine: 0.38, primordial: 0.45,
    }
    const dr = RARITY_DR[target.rarity] ?? 0
    if (dr > 0) {
      // BALANCE FIX: true damage bị DR ở 75% thay vì 50% — tank cao rarity có ý nghĩa hơn vs true dmg
      const effectiveDr = ef.type === "true" ? dr * 0.75 : dr
      raw = Math.max(1, raw * (1 - effectiveDr))
    }
  }

  // Item passive: execute (extra damage on low-HP targets)
  for (const ip of caster.itemPassives) {
    if (ip.kind === "execute") {
      if (target.hp / target.hpMax <= ip.threshold) {
        raw *= 1 + ip.bonus
      }
    }
  }

  let dmg = Math.max(1, Math.round(raw))

  // Shield absorb — hấp thụ damage cho đến khi khiên cạn kiệt (standard RPG behavior)
  // FIX: Removed the broken __shieldUsedThisTurn flag. The old condition
  // (dmg < 1% hpMax) meant large hits never set the flag, so shield absorbed
  // every hit. Small hits set it too early blocking future hits entirely.
  // Now shield simply absorbs each hit normally, draining its value until gone.
  for (const status of target.statuses.filter((s) => s.kind === "shield")) {
    if (dmg <= 0) break
    const shieldHp = Math.round(target.hpMax * Math.max(0, status.value))
    const absorb = Math.min(dmg, shieldHp)
    dmg -= absorb
    status.value = Math.max(0, status.value - absorb / target.hpMax)
    if (status.value <= 0) {
      status.turns = 0
      log.push({ id: uid(), text: `🛡 Khiên của ${target.name} bị phá vỡ!`, kind: "status" })
    } else if (absorb > 0) {
      log.push({ id: uid(), text: `🛡 ${target.name} chặn ${absorb} sát thương bằng khiên!`, kind: "status" })
    }
  }

  // ── KSAN: Khiên Thánh — redirect damage from marked allies to Ksan ──
  if (dmg > 0 && state) {
    const redirectStatus = target.statuses.find(s => s.name === "__ksan_redirect")
    if (redirectStatus) {
      // Find Ksan on same side
      const ksan = state.units.find(u =>
        u.side === target.side && u.hp > 0 &&
        PASSIVES[u.passiveId]?.signatureId === "ksan-batkhuat"
      )
      if (ksan && ksan.uid !== target.uid) {
        // Absorb damage into Ksan's shield (Khiên Thánh)
        const ksanShield = ksan.statuses.find(s => s.name === "Khiên Thánh")
        if (ksanShield) {
          const shieldHp = Math.round(ksan.hpMax * Math.max(0, ksanShield.value))
          const absorb2 = Math.min(dmg, shieldHp)
          dmg -= absorb2
          ksanShield.value = Math.max(0, ksanShield.value - absorb2 / ksan.hpMax)
          if (ksanShield.value <= 0) {
            ksanShield.turns = 0
            log.push({ id: uid(), text: `💥🛡 KHIÊN THÁNH VỠ! Bức Tường Thánh của ${ksan.name} sụp đổ!`, kind: "system" })
            // Remove redirect from all allies
            for (const u of state.units) {
              u.statuses = u.statuses.filter(s => s.name !== "__ksan_redirect")
            }
          } else if (absorb2 > 0) {
            ksan.hp = Math.max(0, ksan.hp - absorb2)
            log.push({ id: uid(), text: `🛡 Khiên Thánh hấp thụ ${absorb2} cho ${target.name}! Ksan nhận thay!`, kind: "status" })
            dmg = 0 // fully redirected
          }
        }
      }
    }
  }

  // ── lifeLink: đỡ đòn khi target dưới 20% HP ──
  if (dmg > 0 && state && target.hp / target.hpMax < 0.2) {
    const alliesWithLifeLink = state.units.filter(u =>
      u.side === target.side && u.hp > 0 && u.uid !== target.uid &&
      u.itemPassives.some(ip => ip.kind === "lifeLink" && ip.pct >= 0.3)  // only Giáp Liên Kết Linh Hồn
    )
    for (const protector of alliesWithLifeLink) {
      const intercepted = Math.round(dmg * 0.7)
      const selfCost = Math.round(dmg * 0.3)
      dmg -= intercepted
      target.hp = Math.max(0, target.hp - selfCost)
      protector.hp = Math.max(0, protector.hp - intercepted)
      log.push({ id: uid(), text: `🔗 [Liên Kết Linh Hồn] ${protector.name} đỡ đòn thay ${target.name}! Hấp thụ ${intercepted} sát thương!`, kind: "status" })
      break  // only one protector
    }
  }

  // ── TANK INTERCEPT: Tank chịu hộ 15% damage cho đồng đội không phải tank ──
  // Quy tắc:
  //   • Chỉ áp dụng khi target KHÔNG phải tank
  //   • Các tank sống trong cùng đội chia đều 15% damage (7.5% mỗi con nếu 2 tank, 5% nếu 3 tank...)
  //   • Nếu target LÀ tank bị đánh trực tiếp (kể cả bị intercept từ tank khác) → KHÔNG chia tiếp
  //   • Intercept chỉ từ đòn TRỰC TIẾP của kẻ địch (dmg > 0, chưa trừ HP target)
  if (dmg > 0 && state && target.role !== "tank") {
    const aliveTanks = state.units.filter(u =>
      u.side === target.side &&
      u.hp > 0 &&
      u.uid !== target.uid &&
      u.role === "tank"
    )
    if (aliveTanks.length > 0) {
      const totalInterceptPct = 0.15
      const perTankPct = totalInterceptPct / aliveTanks.length
      for (const tank of aliveTanks) {
        const intercepted = Math.max(1, Math.round(dmg * perTankPct))
        tank.hp = Math.max(0, tank.hp - intercepted)
        log.push({
          id: uid(),
          text: `🛡 ${tank.name} chịu hộ ${intercepted} sát thương cho ${target.name}! (${Math.round(perTankPct * 100)}%)`,
          kind: "status",
        })
      }
      const totalIntercepted = Math.round(dmg * totalInterceptPct)
      dmg = Math.max(0, dmg - totalIntercepted)
    }
  }

  // FIX: Global damage cap — 1 đòn tối đa 5× hpMax target
  // Safety net chống mọi bug nhân damage không lường trước (atkUp tracker, stacking, v.v.)
  dmg = Math.min(dmg, target.hpMax * 5)
  target.hp = Math.max(0, target.hp - dmg)

  // ── KSAN: Bất Tử Nhất Kích (Undying — cannot be one-shot) ──
  if (target.hp <= 0 && dmg > 0) {
    const ksanUndying = target.statuses.find(s => s.name === "__ksan_undying")
    if (ksanUndying) {
      target.hp = 1
      log.push({ id: uid(), text: `🛡⚡ ${target.name} BẤT TỬ NHẤT KÍCH! Ksan sống sót với 1 HP!`, kind: "system" })
    }
  }

  // ── KSAN: Cấp Cứu — check after taking damage ──
  if (dmg > 0 && state) {
    const ksanPassive = PASSIVES[target.passiveId]
    if (ksanPassive?.signatureId === "ksan-batkhuat") {
      const wasAboveHalf = (target.hp + dmg) / target.hpMax >= 0.5
      ksanCapCuuCheck(state, target, dmg, !wasAboveHalf)
    }
  }

  // ── KSAN: Phản Uy — attacker gets -30% ATK for 3 turns (stackable: refreshes & stacks up to 3x) ──
  if (dmg > 0 && state) {
    const ksanPassive = PASSIVES[target.passiveId]
    if (ksanPassive?.signatureId === "ksan-batkhuat" && target.hp > 0) {
      // Check not in sword form
      if (!target.statuses.some(s => s.name === "__ksan_sword")) {
        const existing = caster.statuses.find(s => s.name === `__phanuy_${target.uid}`)
        if (existing) {
          // Refresh turns and stack value (cap at 3 stacks = 90% ATK reduction)
          existing.turns = 3
          existing.value = Math.min(90, existing.value + 30)
          log.push({ id: uid(), text: `🛡⚔ Phản Uy! ${caster.name} cộng dồn — mất thêm 30% Công (tổng ${existing.value}%)!`, kind: "status" })
        } else {
          caster.statuses.push({ id: uid(), kind: "atkDown", value: 30, turns: 3, name: `__phanuy_${target.uid}` })
          log.push({ id: uid(), text: `🛡⚔ Phản Uy! ${caster.name} tấn công Ksan — mất 30% Công trong 3 lượt!`, kind: "status" })
        }
      }
    }
  }

  // phoenixCore: revive once when HP hits 0
  if (target.hp <= 0 && dmg > 0 && !(target as any).__phoenixUsed) {
    const phoenix = target.itemPassives.find(ip => ip.kind === "phoenixCore")
    if (phoenix) {
      ;(target as any).__phoenixUsed = true
      target.hp = Math.round(target.hpMax * phoenix.revivePct)
      target.energy = target.energyMax
      log.push({ id: uid(), text: `🔥 ${target.name} Lõi Phượng Hoàng! Hồi sống với ${Math.round(phoenix.revivePct * 100)}% HP và đầy năng lượng!`, kind: "heal" })
    }
  }

  // Bounty passive: when target dies from this hit, grant stat bonus to caster
  if (target.hp <= 0 && dmg > 0) {
    for (const ip of caster.itemPassives) {
      if (ip.kind === "bounty") {
        // FIX: enforce maxKills cap — track kills per bounty passive via __tracker
        const bountyKey = `__bounty_${ip.statBonus}_kills`
        const killTracker = caster.statuses.find(s => s.name === bountyKey)
        // Nếu không có maxKills trong passive, dùng default cap = 30 để tránh vô hạn
        const maxKillsAllowed = (ip as any).maxKills ?? 30
        const currentKillCount = killTracker ? killTracker.value : 0
        if (currentKillCount < maxKillsAllowed) {
          caster.stats[ip.statBonus] = (caster.stats[ip.statBonus] || 0) + ip.bonusPerKill
          log.push({ id: uid(), text: `💰 ${caster.name} nhận thưởng đầu! +${ip.bonusPerKill} ${ip.statBonus.toUpperCase()} (${currentKillCount+1}/${maxKillsAllowed})`, kind: "status" })
          if (killTracker) { killTracker.value += 1 }
          else { caster.statuses.push({ id: uid(), kind: "__tracker" as const, value: 1, turns: 9999, name: bountyKey }) }
        }
      }
    }
    // lifeLink: heal allies when a teammate dies
    if (state && target.side === caster.side) {
      const survivors = state.units.filter(u => u.side === target.side && u.hp > 0)
      for (const ally of survivors) {
        for (const ip of ally.itemPassives) {
          if (ip.kind === "lifeLink") {
            const heal = Math.round(ally.hpMax * ip.pct)
            ally.hp = Math.min(ally.hpMax, ally.hp + heal)
            log.push({ id: uid(), text: `🔗 [Liên Kết Linh Hồn] ${ally.name} hồi ${heal} HP khi ${target.name} ngã xuống!`, kind: "heal" })
          }
        }
      }
      // Fire onAllyDeath blessing/pact hook for all surviving allies
      fireHook("onAllyDeath", state, caster)
      for (const ally of survivors) {
        if (ally.uid !== caster.uid) fireHook("onAllyDeath", state, ally)
      }
    }
  }

  // Lifesteal
  if (caster.stats.lifesteal > 0 && dmg > 0 && ef.type !== "true") {
    const heal = Math.round((dmg * caster.stats.lifesteal) / 100)
    caster.hp = Math.min(caster.hpMax, caster.hp + heal)
  }

  // Energy gain — caster gains for dealing, target gains for being hit
  caster.energy = Math.min(caster.energyMax, caster.energy + ENERGY_ON_DEAL)
  if (target.hp > 0) {
    target.energy = Math.min(target.energyMax, target.energy + ENERGY_ON_HIT)
  }

  // Item passive: thorns — reflect a portion of physical damage back to caster
  if (ef.type === "physical" && dmg > 0) {
    for (const ip of target.itemPassives) {
      if (ip.kind === "thorns") {
        const reflect = Math.max(1, Math.round(dmg * ip.pct))
        caster.hp = Math.max(0, caster.hp - reflect)
        log.push({
          id: uid(),
          text: `🛡️ ${target.name} phản đòn — ${caster.name} mất ${reflect}`,
          kind: "damage",
        })
      }
    }
  }

  log.push({
    id: uid(),
    text: `${caster.name} ${ef.type === "magic" ? "✦" : ef.type === "true" ? "✯" : "⚔"} ${target.name} -${dmg}${isCrit ? " (CRIT!)" : ""}`,
    kind: "damage",
  })

  // ── Blessing/Pact hooks ──
  if (dmg > 0 && state) {
    // onDealDamage for caster
    fireHook("onDealDamage", state, caster, { target, dmg })
    // onTakeDamage for target
    fireHook("onTakeDamage", state, target, { attacker: caster, dmg })
    // onLowHp for target (one-shot per battle)
    if (!target.lowHpTriggered && target.hp / target.hpMax < 0.3 && target.hp > 0) {
      target.lowHpTriggered = true
      fireHook("onLowHp", state, target, { attacker: caster, dmg })
    }
    // onKill
    if (target.hp <= 0) {
      fireHook("onKill", state, caster, { target, dmg })
    }
  }

  // NOTE: counterstrike is called by callers (performBasicAttack) to avoid double-proc on multi-hit
  return { dmg, isCrit }
}

function healUnit(
  caster: BattleUnit,
  target: BattleUnit,
  ef: NonNullable<SkillEffect["heal"]>,
  log: CombatLogEntry[],
) {
  const stat = caster.stats[ef.stat as keyof Stats] || 0
  let amt = Math.round(stat * ef.scale)
  // 🔥 Bỏng: giảm 40% lượng heal nhận được
  if (target.statuses.some(s => s.kind === "burn")) {
    amt = Math.round(amt * 0.6)
    log.push({ id: uid(), text: `🔥 ${target.name} đang bỏng — heal giảm 40%!`, kind: "status" })
  }
  // ⚔️ Chiến Hỏa: giảm heal thêm theo cấp độ
  const warFire = target.statuses.find(s => s.kind === "warFire")
  if (warFire && warFire.value > 0) {
    const before = amt
    amt = Math.round(amt * (1 - warFire.value))
    if (before !== amt) {
      log.push({ id: uid(), text: `🔥⚔️ Chiến Hỏa giảm heal ${Math.round(warFire.value * 100)}% (${before}→${amt})`, kind: "status" })
    }
  }
  target.hp = Math.min(target.hpMax, target.hp + amt)
  log.push({ id: uid(), text: `${caster.name} hồi ${amt} HP cho ${target.name}`, kind: "heal" })
}

function applyStatus(target: BattleUnit, status: Omit<StatusEffect, "id">, log: CombatLogEntry[], casterUid?: string) {
  // ── KSAN: CC Immunity (Cấp Cứu / Hóa Kiếm immunity frame) ──
  if (target.statuses.some(s => s.name === "__ksan_ccimmune")) {
    const ccKinds = ["stun", "spdDown", "atkDown", "defDown", "burn", "poison", "bleed"]
    if (ccKinds.includes(status.kind)) {
      log.push({ id: uid(), text: `🛡✨ ${target.name} MIỄN NHIỄM — CC bị chặn bởi Bất Khuất!`, kind: "status" })
      return
    }
  }

  // ── 🔥 Burn: không stack, tối đa 2 lượt, refresh nếu đã có ──
  if (status.kind === "burn") {
    const ex = target.statuses.find(s => s.kind === "burn")
    if (ex) {
      ex.turns = Math.min(2, Math.max(ex.turns, status.turns))
      ex.value = Math.max(ex.value, status.value)
      if (casterUid) ex.appliedBy = casterUid
      log.push({ id: uid(), text: `🔥 ${target.name}: Bỏng làm mới (${ex.turns} lượt)`, kind: "status" })
      return
    }
    target.statuses.push({ ...status, id: uid(), turns: Math.min(2, status.turns), appliedBy: casterUid })
    log.push({ id: uid(), text: `🔥 ${target.name} bị Bỏng (${Math.min(2, status.turns)} lượt)`, kind: "status" })
    return
  }
  // ── 🩸 Bleed: không stack, refresh turns nếu đã có ──
  if (status.kind === "bleed") {
    const ex = target.statuses.find(s => s.kind === "bleed")
    if (ex) {
      ex.turns = Math.max(ex.turns, status.turns)
      if (casterUid) ex.appliedBy = casterUid
      log.push({ id: uid(), text: `🩸 ${target.name}: Chảy máu duy trì (${ex.turns} lượt)`, kind: "status" })
      return
    }
    target.statuses.push({ ...status, id: uid(), appliedBy: casterUid })
    log.push({ id: uid(), text: `🩸 ${target.name} bắt đầu Chảy máu (${status.turns} lượt)`, kind: "status" })
    return
  }
  // ── ☠️ Poison: stack được, value mỗi stack = ½ gốc ──
  if (status.kind === "poison") {
    const half = Math.max(1, Math.round(status.value * 0.5))
    target.statuses.push({ ...status, id: uid(), value: half, appliedBy: casterUid })
    const stacks = target.statuses.filter(s => s.kind === "poison").length
    log.push({ id: uid(), text: `☠️ ${target.name} bị Độc×${stacks} (${status.turns} lượt)`, kind: "status" })
    return
  }
  // ── Mọi loại khác: push bình thường ──
  target.statuses.push({ ...status, id: uid() })
  // Don't log internal tracker statuses (names starting with __)
  if (!status.name.startsWith("__")) {
    log.push({ id: uid(), text: `${target.name} bị áp ${status.name}`, kind: "status" })
  }
}

// ============================================================
// Action resolution
// ============================================================

// Apply item-passive onHit procs from caster onto target
function applyOnHitProcs(caster: BattleUnit, target: BattleUnit, log: CombatLogEntry[]) {
  if (target.hp <= 0) return
  for (const ip of caster.itemPassives) {
    if (ip.kind === "onHit") {
      if (Math.random() < ip.chance) {
        applyStatus(
          target,
          { kind: ip.status as "defDown", value: ip.value, turns: ip.turns, name: ip.name },
          log,
          caster.uid,
        )
      }
    } else if (ip.kind === "armorBreak") {
      if (Math.random() < ip.chance) {
        const breakAmt = Math.round(target.stats.def * ip.pct)
        target.stats.def = Math.max(0, target.stats.def - breakAmt)
        target.stats.res = Math.max(0, target.stats.res - Math.round(target.stats.res * ip.pct * 0.5))
        log.push({ id: uid(), text: `🔨 ${caster.name} phá ${breakAmt} DEF của ${target.name}!`, kind: "status" })
      }
    }
  }
}

function applyCounterstrike(attacker: BattleUnit, victim: BattleUnit, dmgDealt: number, log: CombatLogEntry[]) {
  if (victim.hp <= 0) return
  for (const ip of victim.itemPassives) {
    if (ip.kind === "counterstrike" && Math.random() < ip.chance) {
      const reflect = Math.max(1, Math.round(dmgDealt * ip.pct))
      attacker.hp = Math.max(0, attacker.hp - reflect)
      log.push({ id: uid(), text: `⚡ ${victim.name} phản đòn! ${attacker.name} mất ${reflect}!`, kind: "damage" })
    }
  }
}

function applyMirrorShield(attacker: BattleUnit, victim: BattleUnit, dmgDealt: number, log: CombatLogEntry[]) {
  if (victim.hp <= 0) return
  for (const ip of victim.itemPassives) {
    if (ip.kind === "mirrorShield") {
      // Determine reflect amount based on damage type (simplified: use reflectPhys as base)
      const reflect = Math.max(1, Math.round(dmgDealt * ip.reflectPhys))
      attacker.hp = Math.max(0, attacker.hp - reflect)
      log.push({ id: uid(), text: `🪞 ${victim.name} phản gương! ${attacker.name} mất ${reflect} HP!`, kind: "damage" })
    }
  }
}

function applyManaShield(victim: BattleUnit, dmgDealt: number, log: CombatLogEntry[]) {
  for (const ip of victim.itemPassives) {
    if (ip.kind === "manaShield") {
      const energyGain = Math.round(dmgDealt * ip.dmgToEnergy)
      const prev = victim.energy
      victim.energy = Math.min(victim.energyMax, victim.energy + energyGain)
      if (victim.energy > prev) {
        log.push({ id: uid(), text: `⚡ ${victim.name} hấp thụ ${victim.energy - prev} năng lượng từ sát thương!`, kind: "status" })
      }
    }
  }
}

export function performBasicAttack(
  state: CombatState,
  attacker: BattleUnit,
  target: BattleUnit,
): void {
  // Tướng cận chiến đang nghỉ ngơi ở hàng sau không thể tấn công thường
  if (attacker.isResting && attacker.range === "melee") {
    state.log.push({ id: uid(), text: `💤 ${attacker.name} đang nghỉ ngơi — không thể tấn công thường!`, kind: "info", casterUid: attacker.uid })
    return
  }
  // ── KSAN DẠNG KIẾM: AoE basic attack hits all enemies in same row ──
  const ksanPassive = PASSIVES[attacker.passiveId]
  if (ksanPassive?.signatureId === "ksan-batkhuat" && attacker.statuses.some(s => s.name === "__ksan_sword")) {
    // Công cơ bản = DEF + 30% HP tối đa
    const ksanAtk = attacker.stats.def + Math.round(attacker.hpMax * 0.3)
    // AoE — hit all enemies in same row as target (or all if target row unknown)
    const rowEnemies = state.units.filter(u => u.side === target.side && u.hp > 0 && u.row === target.row)
    const targets = rowEnemies.length > 0 ? rowEnemies : [target]
    state.log.push({ id: uid(), text: `🗡 ${attacker.name} DẠNG KIẾM — AoE hàng ${target.row}!`, kind: "info" })
    for (const t of targets) {
      // Bỏ qua 50% giáp — temporarily halve target def
      const origDef = t.stats.def
      t.stats.def = Math.round(origDef * 0.5)
      const { dmg, isCrit } = rollDamage(
        attacker, t,
        { scale: 1.0, stat: "def", type: "physical" },
        state.log, state,
      )
      t.stats.def = origDef
      // Lifesteal with +30% bonus from sword form (already included in stats.lifesteal via activation)
      if (attacker.stats.lifesteal > 0 && dmg > 0) {
        const heal = Math.round(dmg * attacker.stats.lifesteal / 100)
        attacker.hp = Math.min(attacker.hpMax, attacker.hp + heal)
        state.log.push({ id: uid(), text: `🩸 ${attacker.name} hút ${heal} HP (Cuồng Huyết)!`, kind: "heal" })
      }
      // Inovar crit double damage (Đập Vỡ Nitro x2 on crit handled in performSkill via scale)
      applyOnHitProcs(attacker, t, state.log)
      if (dmg > 0) applyCounterstrike(attacker, t, dmg, state.log)
    }
    attacker.energy = Math.min(attacker.energyMax, attacker.energy + ENERGY_ON_DEAL)
    return
  }

  const spd = effectiveSpd(attacker)

  // frenzySword: uncapped extra hits
  const frenzyPassive = attacker.itemPassives.find(ip => ip.kind === "frenzySword")
  const extraHits = frenzyPassive ? spdExtraHitsUncapped(spd) : spdExtraHits(spd)

  // cursedBlade: multiply damage, deal self-damage
  const cursedBlade = attacker.itemPassives.find(ip => ip.kind === "cursedBlade")
  // bloodPact: stacking damage bonus
  const bloodPactPassive = attacker.itemPassives.find(ip => ip.kind === "bloodPact")
  const bloodPactStacks = bloodPactPassive
    ? Math.min(3, attacker.statuses.find(s => s.name === "__bloodpact_stacks")?.value ?? 0)
    : 0
  // FIX: bloodPact với dmgBonus cao (≥1.0, e.g. w_lastbreath dmgBonus:2.5) chỉ kích hoạt khi HP < 20%
  // Các bloodPact thường (dmgBonus ≤ 0.6) vẫn hoạt động bình thường theo stack
  const bloodPactBonus = bloodPactPassive
    ? (bloodPactPassive.dmgBonus >= 1.0
        ? (attacker.hp / attacker.hpMax < 0.20 ? 1 + bloodPactStacks * bloodPactPassive.dmgBonus : 1)
        : 1 + bloodPactStacks * bloodPactPassive.dmgBonus)
    : 1
  // deathMark: bonus dmg + energy refill vs low-HP target
  const deathMark = attacker.itemPassives.find(ip => ip.kind === "deathMark")
  // FIX: deathMark threshold > 0.5 (e.g. 0.99 = "silentedge") → kích hoạt khi địch CÓ DEBUFF
  // deathMark threshold ≤ 0.5 → kích hoạt khi địch HP thấp (design gốc)
  const deathMarkActive = deathMark && (
    deathMark.threshold > 0.5
      ? target.statuses.some(s => ["atkDown","defDown","resDown","spdDown","poison","bleed","burn","stun"].includes(s.kind))
      : target.hp / target.hpMax < deathMark.threshold
  )

  const rawDmgScale = (cursedBlade ? cursedBlade.dmgMult : 1) * bloodPactBonus * (deathMarkActive && deathMark ? (1 + deathMark.dmgAmp) : 1)
  // FIX: Hard cap tổng dmgScale ×6 để cursedBlade(1.7) × bloodPact(2.5) × deathMark(1.4) không vượt ×6
  const dmgScale = Math.min(6.0, rawDmgScale)
  // FIX: Extra hits không nhân cursedBlade.dmgMult (×1.7 chỉ cho first hit để tránh damage nhân lũy thừa)
  // bloodPact và deathMark vẫn áp dụng cho extra hits vì đó là buff của caster
  const dmgScaleExtra = Math.min(4.0, bloodPactBonus * (deathMarkActive && deathMark ? (1 + deathMark.dmgAmp) : 1))

  // First hit
  // FIX: Support role uses MAG (not ATK) for basic attacks, same as mage
  const usesMag = attacker.role === "mage" || attacker.role === "support"
  const { dmg } = rollDamage(
    attacker, target,
    { scale: 1.0 * dmgScale, stat: usesMag ? "mag" : "atk", type: usesMag ? "magic" : "physical" },
    state.log, state,
  )

  // deathMark proc: restore full energy
  if (deathMarkActive && deathMark && dmg > 0) {
    attacker.energy = attacker.energyMax
    state.log.push({ id: uid(), text: `💀 ${attacker.name} Tử Thần Ấn! +${Math.round(deathMark.dmgAmp * 100)}% sát thương & đầy năng lượng!`, kind: "info" })
  }
  // cursedBlade: self-damage
  if (cursedBlade && dmg > 0) {
    const selfDmg = Math.round(dmg * cursedBlade.selfDmgPct)
    attacker.hp = Math.max(1, attacker.hp - selfDmg)
    state.log.push({ id: uid(), text: `🗡️ ${attacker.name} Kiếm Nguyền — tự nhận ${selfDmg} sát thương!`, kind: "damage" })
  }
  // soulDrain: steal ATK from target
  const soulDrain = attacker.itemPassives.find(ip => ip.kind === "soulDrain")
  if (soulDrain && dmg > 0 && target.stats.atk > 0) {
    // FIX: Cap total stolen ATK at 150% of attacker's original ATK to prevent infinite scaling
    const soulDrainBase = attacker.statuses.find(s => s.name === "__souldrain_base_atk")
    if (!soulDrainBase) {
      attacker.statuses.push({ id: uid(), kind: "__tracker" as const, value: attacker.stats.atk, turns: 9999, name: "__souldrain_base_atk" })
    }
    const baseAtk = soulDrainBase?.value ?? attacker.stats.atk
    const maxAtk = Math.round(baseAtk * 2.5) // cap at +150% of base
    if (attacker.stats.atk < maxAtk) {
      const steal = Math.min(
        Math.max(1, Math.round(target.stats.atk * soulDrain.stealPct)),
        maxAtk - attacker.stats.atk
      )
      target.stats.atk = Math.max(0, target.stats.atk - steal)
      attacker.stats.atk += steal
      state.log.push({ id: uid(), text: `👻 ${attacker.name} Hút Linh Hồn! +${steal} ATK từ ${target.name}!`, kind: "status" })
    }
  }
  // frenzySword: gain SPD on hit
  if (frenzyPassive) {
    attacker.stats.spd += frenzyPassive.spdPerHit
    state.log.push({ id: uid(), text: `⚔️ ${attacker.name} Cuồng Đao! +${frenzyPassive.spdPerHit} SPD (→${Math.round(attacker.stats.spd)})`, kind: "info" })
  }

  // Elemental/Demon passive burns
  const passive = PASSIVES[attacker.passiveId]
  if (passive?.signatureId === "elem-passive-burn" || passive?.signatureId === "demon-passive-burn") {
    const flatBurn = Math.max(1, Math.round(attacker.stats.mag * 0.18))
    applyStatus(target, { kind: "burn", value: flatBurn, turns: 2, name: "Bỏng Nhỏ" }, state.log, attacker.uid)
  }
  // florenWalker: hồi 5% HP tối đa sau mỗi đánh thường
  if (passive?.signatureId === "floren-regen-on-attack") {
    const healAmt = Math.round(attacker.hpMax * 0.05)
    attacker.hp = Math.min(attacker.hpMax, attacker.hp + healAmt)
    state.log.push({ id: uid(), text: `🌿 ${attacker.name} Lãng Khách Bất Diệt — hồi ${healAmt} HP!`, kind: "heal" })
  }
  applyOnHitProcs(attacker, target, state.log)
  if (dmg > 0) applyCounterstrike(attacker, target, dmg, state.log)
  if (dmg > 0) applyMirrorShield(attacker, target, dmg, state.log)
  if (dmg > 0) applyManaShield(target, dmg, state.log)

  // stormStrike: chain lightning to random other enemy
  const stormStrike = attacker.itemPassives.find(ip => ip.kind === "stormStrike")
  if (stormStrike && dmg > 0 && Math.random() < stormStrike.chainChance) {
    const others = state.units.filter(u => u.side === target.side && u.hp > 0 && u.uid !== target.uid)
    if (others.length > 0) {
      const chainTarget = others[Math.floor(Math.random() * others.length)]
      const chainDmg = Math.round(dmg * stormStrike.dmgDecay)
      chainTarget.hp = Math.max(0, chainTarget.hp - chainDmg)
      state.log.push({ id: uid(), text: `⚡ Sét Liên Hoàn nhảy sang ${chainTarget.name} — ${chainDmg} sát thương!`, kind: "damage" })
    }
  }

  // echoStrike: immediate echo hit (echoDelay=0) — fires once after first hit
  // FIX: echo hits do NOT chain (no echoStrike re-proc, no cursedBlade self-dmg, no frenzySword SPD gain)
  const echoStrike = attacker.itemPassives.find(ip => ip.kind === "echoStrike")
  if (echoStrike && dmg > 0 && target.hp > 0 && echoStrike.echoDelay === 0) {
    const echoProc = echoStrike.echoPct <= 1.0 ? true : Math.random() < 0.5 // echoPct>1 uses 50% chance
    if (echoProc) {
      const echoDmg = Math.round(dmg * Math.min(echoStrike.echoPct, 1.5)) // cap echo at 150% to prevent extreme cases
      // Echo hits as true damage (bypass DEF — it's a phantom/echo)
      target.hp = Math.max(0, target.hp - echoDmg)
      state.log.push({ id: uid(), text: `🔮 ${attacker.name} Vang Âm! ${target.name} nhận thêm ${echoDmg} từ bóng ma!`, kind: "damage" })
      // Award energy for echo hit
      attacker.energy = Math.min(attacker.energyMax, attacker.energy + ENERGY_ON_DEAL)
    }
  }

  // Extra hits from speed
  if (extraHits > 0 && target.hp > 0) {
    state.log.push({
      id: uid(),
      text: frenzyPassive
        ? `🌪️ ${attacker.name} Cuồng Đao — thêm ${extraHits} đòn vô hạn! (SPD: ${Math.round(effectiveSpd(attacker))})`
        : `💨 ${attacker.name} tốc độ cao — đánh thêm ${extraHits} đòn! (Tốc độ: ${Math.round(spd)})`,
      kind: "info",
    })
    for (let i = 0; i < extraHits; i++) {
      if (target.hp <= 0) break
      const { dmg: extraDmg } = rollDamage(
        attacker, target,
        { scale: 0.70 * dmgScaleExtra, stat: usesMag ? "mag" : "atk", type: usesMag ? "magic" : "physical" },
        state.log, state,
      )
      applyOnHitProcs(attacker, target, state.log)
      // stormStrike also procs on extra hits
      if (stormStrike && Math.random() < stormStrike.chainChance) {
        const others = state.units.filter(u => u.side === target.side && u.hp > 0 && u.uid !== target.uid)
        if (others.length > 0) {
          const ct = others[Math.floor(Math.random() * others.length)]
          // FIX: dùng extraDmg (hit hiện tại) thay vì dmg (first hit) — tránh stale variable
          const cd = Math.round(extraDmg * stormStrike.dmgDecay)
          ct.hp = Math.max(0, ct.hp - cd)
          state.log.push({ id: uid(), text: `⚡ Sét nhảy sang ${ct.name} — ${cd}!`, kind: "damage" })
        }
      }
      // frenzySword: SPD on extra hits (half rate)
      if (frenzyPassive) attacker.stats.spd += Math.round(frenzyPassive.spdPerHit * 0.5)
    }
  }
}

/**
 * Đổi hàng cho tướng người chơi trong chiến đấu.
 * - Lên hàng trước: unit.row "back" → "front" (xóa isResting)
 * - Xuống hàng sau: unit.row "front" → "back"
 *   - Nếu hàng trước sẽ trống: phải có 1 unit hàng sau để thế chỗ lên hàng trước
 *   - Tướng melee khi xuống hàng sau: vào trạng thái nghỉ (isResting=true, hồi 4% HP/lượt, không đánh thường)
 *   - Tướng ranged: xuống hàng sau bình thường, không isResting
 * Trả về { ok, reason } để báo lỗi nếu không thể đổi.
 */
export function performRowChange(
  state: CombatState,
  unitUid: string,
): { ok: boolean; reason?: string } {
  const unit = state.units.find(u => u.uid === unitUid)
  if (!unit || unit.hp <= 0) return { ok: false, reason: "Tướng không tồn tại hoặc đã chết." }
  if (unit.side !== "player") return { ok: false, reason: "Chỉ có thể đổi hàng tướng của người chơi." }

  const playerAlive = state.units.filter(u => u.side === "player" && u.hp > 0)
  const frontAlive = playerAlive.filter(u => u.row === "front")
  const backAlive = playerAlive.filter(u => u.row === "back")

  if (unit.row === "back") {
    // Tiến lên hàng trước
    unit.row = "front"
    unit.isResting = false
    state.log.push({
      id: uid(),
      text: `⬆ ${unit.name} tiến lên hàng trước!`,
      kind: "info",
      casterUid: unit.uid,
    })
    return { ok: true }
  } else {
    // unit.row === "front" — xuống hàng sau
    const willFrontBeEmpty = frontAlive.filter(u => u.uid !== unit.uid).length === 0

    if (willFrontBeEmpty) {
      // Cần 1 tướng hàng sau lên thế chỗ
      const replacement = backAlive[0]
      if (!replacement) {
        return { ok: false, reason: "Hàng trước không thể trống — không có tướng hàng sau để thế chỗ!" }
      }
      // Thế chỗ: replacement lên hàng trước
      replacement.row = "front"
      replacement.isResting = false
      state.log.push({
        id: uid(),
        text: `⬆ ${replacement.name} tiến lên hàng trước thế chỗ ${unit.name}!`,
        kind: "info",
        casterUid: replacement.uid,
      })
    }

    // Tướng đổi xuống hàng sau
    unit.row = "back"
    const isMelee = unit.range === "melee"
    if (isMelee) {
      unit.isResting = true
      state.log.push({
        id: uid(),
        text: `⬇ ${unit.name} lui về hàng sau — vào trạng thái NGHỈ NGƠI (hồi 4% HP/lượt, không thể tấn công).`,
        kind: "info",
        casterUid: unit.uid,
      })
    } else {
      unit.isResting = false
      state.log.push({
        id: uid(),
        text: `⬇ ${unit.name} lui về hàng sau.`,
        kind: "info",
        casterUid: unit.uid,
      })
    }
    return { ok: true }
  }
}

export function canCastSkill(unit: BattleUnit, skillIndex: 0 | 1 | 2): { ok: boolean; reason?: string } {
  const skill = unit.skills[skillIndex]
  if (!skill) return { ok: false, reason: "Không có kỹ năng" }
  if (unit.cooldowns[skillIndex] > 0) return { ok: false, reason: `Còn ${unit.cooldowns[skillIndex]} lượt cooldown` }
  if (skill.ultimate && unit.energy < ULTIMATE_ENERGY_COST) {
    return { ok: false, reason: `Cần ${ULTIMATE_ENERGY_COST} năng lượng (${unit.energy})` }
  }
  // FIX: silence status was defined in types and applied by skills/items but never checked here.
  // Silenced units could still cast skills — silence had zero effect on gameplay.
  if (unit.statuses.some(s => s.kind === "silence")) {
    return { ok: false, reason: "Đang bị câm lặng — không thể dùng kỹ năng" }
  }
  return { ok: true }
}

export function performSkill(
  state: CombatState,
  caster: BattleUnit,
  skillIndex: 0 | 1 | 2,
  primaryTargetUid: string | null,
): void {
  const skill = caster.skills[skillIndex]
  if (!skill) return
  const can = canCastSkill(caster, skillIndex)
  if (!can.ok) return

  // Consume energy for ultimate
  if (skill.ultimate) {
    caster.energy = 0
    // Fire onUltimate blessing/pact hook
    fireHook("onUltimate", state, caster)
  }

  state.log.push({
    id: uid(),
    text: `★ ${caster.name} dùng [${skill.name}]`,
    kind: "info",
    skillId: skill.id,
    casterUid: caster.uid,
  })

  const enemies = alivesOf(state, caster.side === "player" ? "enemy" : "player")
  const allies = alivesOf(state, caster.side)
  let targets: BattleUnit[] = []
  switch (skill.targeting) {
    case "enemy":
      targets = primaryTargetUid
        ? state.units.filter((u) => u.uid === primaryTargetUid && u.hp > 0)
        : enemies.length ? [enemies[0]] : []
      break
    case "all-enemies":
      targets = enemies
      break
    case "self":
      targets = [caster]
      break
    case "ally":
      targets = primaryTargetUid
        ? state.units.filter((u) => u.uid === primaryTargetUid && u.hp > 0)
        : [caster]
      break
    case "all-allies":
      targets = allies
      break
  }

  // Skill level scales damage/heal by 1 + (lvl-1)*0.15
  // lv1=100%  lv2=115%  lv3=130%  lv4=145%  lv5=160%
  // FIX: multiply by RARITY_SKILL_MULT so high-rarity heroes feel
  // meaningfully stronger even when using shared low-scale skills.
  const sLvl = caster.skillLevels[skillIndex]
  const rarityMult = RARITY_SKILL_MULT[caster.rarity] ?? 1.0
  const scaleMult = (1 + (sLvl - 1) * 0.15) * rarityMult

  // ── KSAN Special Skill Overrides ──────────────────────────────────────
  const ksanPassiveCheck = PASSIVES[caster.passiveId]
  if (ksanPassiveCheck?.signatureId === "ksan-batkhuat") {

    // DẠNG KHIÊN — Thế Thủ (skill 0): buff self + same-row allies
    if (skill.id === "ksanThethy") {
      const sameRow = state.units.filter(u => u.side === caster.side && u.hp > 0 && u.row === caster.row)
      for (const ally of sameRow) {
        applyStatus(ally, { kind: "defUp", value: 120, turns: 3, name: "Thế Thủ — DEF" }, state.log, caster.uid)
        // +30% HP max buff — apply as a shield proxy (virtual HP)
        const hpBonus = Math.round(ally.hpMax * 0.3)
        ally.hpMax += hpBonus
        ally.hp += hpBonus
      }
      state.log.push({ id: uid(), text: `🛡 ${caster.name} Thế Thủ — buff ${sameRow.length} đồng đội cùng hàng +120% DEF +30% HP!`, kind: "status" })
      caster.cooldowns[skillIndex] = skill.cooldown
      return
    }

    // DẠNG KHIÊN — Anh Hùng Khiên (skill 1): stun 2 random enemies, unblockable
    if (skill.id === "ksanAnhHungKhien") {
      const shuffled = [...enemies].sort(() => Math.random() - 0.5)
      const stunTargets = shuffled.slice(0, 2)
      for (const t of stunTargets) {
        // Unblockable stun — temporarily set acc to 999
        const origAcc = caster.stats.acc
        caster.stats.acc = 999
        applyStatus(t, { kind: "stun", value: 0, turns: 3, name: "Anh Hùng Khiên — Choáng" }, state.log, caster.uid)
        caster.stats.acc = origAcc
        state.log.push({ id: uid(), text: `🛡⚡ ${caster.name} lao vào ${t.name} — CHOÁNG 3 lượt! (Không thể né)`, kind: "status" })
      }
      caster.cooldowns[skillIndex] = skill.cooldown
      return
    }

    // DẠNG KHIÊN — Bức Tường Phòng Hộ (bonus skill): buff self + 2 lowest HP allies
    if (skill.id === "ksanBucTuongPhongHo") {
      const sortedByHpPct = [...allies].sort((a, b) => (a.hp / a.hpMax) - (b.hp / b.hpMax))
      const buffTargets = [caster, ...sortedByHpPct.filter(u => u.uid !== caster.uid).slice(0, 2)]
      for (const t of buffTargets) {
        applyStatus(t, { kind: "defUp", value: 60, turns: 3, name: "Bức Tường Phòng Hộ — DEF" }, state.log, caster.uid)
        t.stats.eva = (t.stats.eva || 0) + 30 // +30% EVA
      }
      state.log.push({ id: uid(), text: `🛡 ${caster.name} Bức Tường Phòng Hộ — buff ${buffTargets.length} đồng đội yếu nhất +60% DEF +30% EVA!`, kind: "status" })
      caster.cooldowns[skillIndex] = skill.cooldown
      return
    }

    // DẠNG KHIÊN — Khiên Thánh (ultimate): team-wide damage redirection shield on Ksan
    if (skill.id === "ksanKhienThanh") {
      const shieldVal = Math.round(caster.hpMax * 0.6)
      // Apply to all allies as a redirect marker — Ksan absorbs via __ksan_khienthanh status
      caster.statuses.push({ id: uid(), kind: "shield", value: 0.6, turns: 3, name: "Khiên Thánh" })
      // Mark all allies to redirect damage to Ksan
      for (const ally of allies) {
        if (ally.uid !== caster.uid) {
          ally.statuses.push({ id: uid(), kind: "__tracker", value: 1, turns: 3, name: "__ksan_redirect" })
        }
      }
      state.log.push({ id: uid(), text: `✨🛡 ${caster.name} KHIÊN THÁNH! Bức Tường Thánh xuất hiện — ${shieldVal} giáp ảo! Mọi sát thương team chuyển về Ksan!`, kind: "system" })
      caster.cooldowns[skillIndex] = skill.cooldown
      return
    }

    // DẠNG KIẾM — Inovar: hit 2 random enemies, def-based damage, can crit + lifesteal
    if (skill.id === "ksanInovar") {
      const shuffledEn = [...enemies].sort(() => Math.random() - 0.5).slice(0, 2)
      for (const t of shuffledEn) {
        // FIX: capture actual dmg from rollDamage (previously used a separately-computed estimate
        // that ignored defense, shields and dodge — lifesteal was wildly inaccurate)
        const { dmg: actualDmg } = rollDamage(caster, t, { scale: 1.6 * scaleMult, stat: "def", type: "true" }, state.log, state)
        if (caster.stats.lifesteal > 0 && actualDmg > 0) {
          const heal = Math.round(actualDmg * caster.stats.lifesteal / 100)
          caster.hp = Math.min(caster.hpMax, caster.hp + heal)
          state.log.push({ id: uid(), text: `🩸 ${caster.name} hút ${heal} HP (Inovar)!`, kind: "heal" })
        }
        applyOnHitProcs(caster, t, state.log)
      }
      caster.cooldowns[skillIndex] = skill.cooldown
      return
    }

    // DẠNG KIẾM — Chan Bố Đê: 3 highest HP enemies, debuff not cleansable
    if (skill.id === "ksanChanBoDe") {
      const sortedByHp = [...enemies].sort((a, b) => b.hp - a.hp).slice(0, 3)
      for (const t of sortedByHp) {
        rollDamage(caster, t, { scale: 1.3 * scaleMult, stat: "def", type: "true" }, state.log, state)
        // Apply debuffs — marked with __nocleanse so cleanses skip them
        t.statuses.push({ id: uid(), kind: "defDown", value: 20, turns: 3, name: "Chan Bố Đê — Yếu Thủ" })
        t.statuses.push({ id: uid(), kind: "atkDown", value: 20, turns: 3, name: "Chan Bố Đê — Yếu Công" })
        t.statuses.push({ id: uid(), kind: "spdDown", value: 20, turns: 3, name: "Chan Bố Đê — Yếu Tốc" })
        state.log.push({ id: uid(), text: `💥 ${caster.name} Chan Bố Đê — ${t.name} mất 20% tất cả chỉ số 3 lượt! (Không thanh tẩy được)`, kind: "status" })
      }
      caster.cooldowns[skillIndex] = skill.cooldown
      return
    }

    // DẠNG KIẾM — Đập Vỡ Nitro: AoE all enemies, x2 on crit
    if (skill.id === "ksanDapVoNitro") {
      for (const t of enemies) {
        // BALANCE FIX: Ksan def-based true 3.0→2.4 — vẫn mạnh nhưng không one-shot tank địch
        const { dmg, isCrit } = rollDamage(caster, t, { scale: 2.4 * scaleMult, stat: "def", type: "true" }, state.log, state)
        if (isCrit && dmg > 0) {
          // Apply bonus crit damage (x2 = extra 100%)
          const bonusCrit = dmg  // already critted, add equal dmg on top
          t.hp = Math.max(0, t.hp - bonusCrit)
          state.log.push({ id: uid(), text: `💥💥 ${caster.name} NITRO CHÍ MẠNG x2! Thêm ${bonusCrit} sát thương vào ${t.name}!`, kind: "damage" })
        }
      }
      caster.cooldowns[skillIndex] = skill.cooldown
      return
    }
  }
  // ── Special Skill Bonus Effects ───────────────────────────────────────────
  // FIX G: executioner +50% bonus vs low HP
  if (skill.id === "executioner" || skill.id === "executioner_evo") {
    for (const t of targets) {
      if (t.hp <= 0) continue
      const isLowHp = t.hp / t.hpMax < 0.4
      const bonusScale = isLowHp ? 0.5 : 0
      const scale = skill.id === "executioner" ? 2.2 : 3.0
      rollDamage(caster, t, { scale: (scale + bonusScale) * scaleMult, stat: "atk", type: "physical" }, state.log, state)
      applyOnHitProcs(caster, t, state.log)
      if (isLowHp) state.log.push({ id: uid(), text: `⚔️ ${caster.name} Đoạn Hồn Trảm — địch HP thấp, +50% sát thương!`, kind: "damage" })
    }
    // executioner_evo: instant kill if target HP < 30%
    if (skill.id === "executioner_evo") {
      for (const t of targets) {
        if (t.hp > 0 && t.hp / t.hpMax < 0.3) {
          state.log.push({ id: uid(), text: `⚔️💀 ${caster.name} Lưỡi Kiếm Phán Xét — INSTANT KILL! ${t.name} HP < 30%!`, kind: "damage" })
          t.hp = 0
        }
      }
    }
    caster.cooldowns[skillIndex] = skill.cooldown
    return
  }

  // FIX H: cyberRailgun +50% vs full HP
  if (skill.id === "cyberRailgun") {
    for (const t of targets) {
      if (t.hp <= 0) continue
      const isFullHp = t.hp >= t.hpMax
      const scale = isFullHp ? 2.7 * 1.5 : 2.7
      rollDamage(caster, t, { scale: scale * scaleMult, stat: "atk", type: "true" }, state.log, state)
      applyOnHitProcs(caster, t, state.log)
      if (isFullHp) state.log.push({ id: uid(), text: `🎯 ${caster.name} Pháo Ray — địch full HP, +50% sát thương!`, kind: "damage" })
    }
    caster.cooldowns[skillIndex] = skill.cooldown
    return
  }

  // FIX I: outlawAmbush — targets weakest enemy, extra turn if kill
  if (skill.id === "outlawAmbush") {
    const weakest = enemies.slice().sort((a, b) => a.hp - b.hp)[0]
    if (weakest) {
      const hpBefore = weakest.hp
      rollDamage(caster, weakest, { scale: 2.0 * scaleMult, stat: "atk", type: "physical" }, state.log, state)
      applyOnHitProcs(caster, weakest, state.log)
      if (weakest.hp <= 0 && hpBefore > 0) {
        // Grant extra turn by setting cooldown to 0 immediately (turn not consumed)
        caster.cooldowns[skillIndex] = 0
        state.log.push({ id: uid(), text: `🗡️ ${caster.name} Phục Kích Băng Đảng — HẠ GỤC! Không tốn lượt!`, kind: "damage" })
      } else {
        caster.cooldowns[skillIndex] = skill.cooldown
      }
    }
    return
  }

  // ── End Special Skill Bonus Effects ──────────────────────────────────────

  for (const ef of skill.effects) {
    if (ef.damage) {
      const hits = ef.damage.hits || 1
      for (let i = 0; i < hits; i++) {
        for (const t of targets) {
          if (t.hp <= 0) continue
          rollDamage(
            caster,
            t,
            { ...ef.damage, scale: ef.damage.scale * scaleMult },
            state.log,
            state,
          )
          // Item passive procs apply on skill hits too
          applyOnHitProcs(caster, t, state.log)
        }
      }
    }
    if (ef.heal) {
      // 🔧 FIX: Skills that target enemies (e.g. life-drain ultimates) should
      // always heal the CASTER, not the enemy targets.
      const healTargets =
        skill.targeting === "enemy" || skill.targeting === "all-enemies"
          ? [caster]
          : targets
      for (const t of healTargets) {
        healUnit(caster, t, { ...ef.heal, scale: ef.heal.scale * scaleMult }, state.log)
      }
    }
    if (ef.status) {
      const apply = ef.status.target || skill.targeting
      const statusTargets =
        apply === "self"
          ? [caster]
          : apply === "all-allies"
          ? allies
          : apply === "all-enemies"
          ? enemies
          : apply === "ally"
          ? targets
          : targets
      for (const t of statusTargets) {
        applyStatus(t, ef.status, state.log, caster.uid)
      }
    }
    if (ef.cooldownReductionAll) {
      for (const u of allies) {
        u.cooldowns = u.cooldowns.map((cd) => Math.max(0, cd - (ef.cooldownReductionAll || 0))) as [number, number, number]
      }
    }
    // FIX D: ef.cleanse existed in SkillEffect type but was never read in this loop.
    // Cleanse skill described "xóa hiệu ứng xấu" but debuffs were never removed.
    if (ef.cleanse) {
      const DEBUFF_KINDS = ["burn", "poison", "bleed", "stun", "silence", "atkDown", "defDown", "spdDown", "resDown"]
      for (const t of targets) {
        const before = t.statuses.length
        t.statuses = t.statuses.filter(s => !DEBUFF_KINDS.includes(s.kind))
        const removed = before - t.statuses.length
        if (removed > 0) {
          state.log.push({ id: uid(), text: `✨ ${caster.name} thanh tẩy ${removed} hiệu ứng xấu khỏi ${t.name}!`, kind: "status" })
        }
      }
    }
  }

  caster.cooldowns[skillIndex] = skill.cooldown

  // florenWalker: hồi 5% HP tối đa khi dùng Chiêu 1 (skillIndex 0)
  const passiveAfterSkill = PASSIVES[caster.passiveId]
  if (passiveAfterSkill?.signatureId === "floren-regen-on-attack" && skillIndex === 0) {
    const healAmt = Math.round(caster.hpMax * 0.05)
    caster.hp = Math.min(caster.hpMax, caster.hp + healAmt)
    state.log.push({ id: uid(), text: `🌿 ${caster.name} Lãng Khách Bất Diệt — hồi ${healAmt} HP!`, kind: "heal" })
  }

  // Speed passive: reduce ALL own cooldowns after casting based on speed
  const cdReduction = spdCooldownReduction(effectiveSpd(caster))
  if (cdReduction > 0) {
    caster.cooldowns = caster.cooldowns.map((cd, i) =>
      i === skillIndex ? cd : Math.max(0, cd - cdReduction)
    ) as [number, number, number]
    state.log.push({
      id: uid(),
      text: `⚡ ${caster.name} tốc độ cao — giảm ${cdReduction} lượt cooldown kỹ năng!`,
      kind: "info",
    })
  }

  // timeWarp: reduce all teammates' cooldowns after any skill cast
  const timeWarp = caster.itemPassives.find(ip => ip.kind === "timeWarp")
  if (timeWarp) {
    const allies = state.units.filter(u => u.side === caster.side && u.hp > 0 && u.uid !== caster.uid)
    for (const ally of allies) {
      ally.cooldowns = ally.cooldowns.map(cd => Math.max(0, cd - timeWarp.cdFlatReduction)) as [number, number, number]
    }
    if (allies.length > 0) {
      state.log.push({ id: uid(), text: `⏳ ${caster.name} Bẻ Cong Thời Gian! Giảm ${timeWarp.cdFlatReduction} lượt CD cho đồng đội!`, kind: "info" })
    }
  }
}

export function consumePotionInCombat(
  state: CombatState,
  inventoryItemId: string,
  targetUid: string,
  inventory: GameState["inventory"],
): { ok: boolean; nextInventory: GameState["inventory"]; reason?: string } {
  const inv = inventory.find((i) => i.uid === inventoryItemId)
  if (!inv) return { ok: false, nextInventory: inventory, reason: "Không tìm thấy bình thuốc." }
  const item = ITEMS_BY_ID[inv.itemId]
  if (!item || item.kind !== "potion") return { ok: false, nextInventory: inventory, reason: "Vật phẩm không phải thuốc." }
  const target = state.units.find((u) => u.uid === targetUid)
  if (!target || target.hp <= 0) return { ok: false, nextInventory: inventory, reason: "Mục tiêu không hợp lệ." }
  const p = item.potion
  if (!p) return { ok: false, nextInventory: inventory, reason: "Thuốc không có hiệu ứng." }

  // FIX: 1 use per 2 rounds cooldown — does NOT consume the player turn
  const roundsSinceLast = state.round - (state.potionLastUsedRound ?? -99)
  if (roundsSinceLast < 2) {
    const waitRounds = 2 - roundsSinceLast
    return { ok: false, nextInventory: inventory, reason: `Thuốc đang hồi chiêu — còn ${waitRounds} vòng nữa.` }
  }

  // Apply effects
  if (p.healPct) {
    const heal = Math.round(target.hpMax * p.healPct)
    target.hp = Math.min(target.hpMax, target.hp + heal)
    state.log.push({ id: uid(), text: `💊 ${target.name} dùng ${item.name} — hồi ${heal} HP`, kind: "heal" })
  }
  if (p.heal) {
    target.hp = Math.min(target.hpMax, target.hp + p.heal)
    state.log.push({ id: uid(), text: `💊 ${target.name} dùng ${item.name} — hồi ${p.heal} HP`, kind: "heal" })
  }
  if (p.energy) {
    target.energy = Math.min(target.energyMax, target.energy + p.energy)
    state.log.push({ id: uid(), text: `💊 ${target.name} hồi ${p.energy} năng lượng`, kind: "heal" })
  }
  if (p.cleanse) {
    target.statuses = target.statuses.filter(
      (s) => !["burn", "poison", "bleed", "stun", "atkDown", "defDown", "spdDown"].includes(s.kind),
    )
    state.log.push({ id: uid(), text: `✨ ${target.name} được thanh tẩy hiệu ứng xấu`, kind: "status" })
  }
  if (p.buff) {
    // FIX: was "attacker.uid" — no attacker context here; buff applied directly with no caster
    applyStatus(target, p.buff, state.log)
  }

  // FIX: record last used round (cooldown); does NOT advance turn
  state.potionLastUsedRound = state.round

  const nextInv = inventory
    .map((i) => (i.uid === inv.uid ? { ...i, quantity: i.quantity - 1 } : i))
    .filter((i) => i.quantity > 0)
  return { ok: true, nextInventory: nextInv }
}

// ============================================================
// Status processing per turn
// ============================================================


// ============================================================
// ⚡ ORDER INNATE — Nội Tại Thứ Tự
// Kích hoạt khi tướng đi ngay SAU (afterTrait) hoặc ngay TRƯỚC (beforeTrait)
// một tướng có chất phù hợp trong thứ tự lượt chiến đấu.
// ============================================================

/**
 * Gọi sau onUnitTurnStart. Kiểm tra và kích hoạt order innate của `unit`.
 * @param unit       tướng hiện đang hành động
 * @param adjUnit    tướng kề trong turn order (prev hoặc next)
 * @param when       "afterTrait" | "beforeTrait"
 * @param state      combat state (mutated in place)
 */
// ============================================================
// ⚡ ORDER INNATE ENGINE v3 — Cơ Chế Độc Đáo
// ============================================================

function _oiHasTrait(u: BattleUnit, trait: string): boolean {
  return u.role === trait || (u.origins as string[]).includes(trait)
}
function _oiAllies(unit: BattleUnit, state: CombatState): BattleUnit[] {
  return state.units.filter(u => u.side === unit.side && u.hp > 0 && u.uid !== unit.uid)
}
function _oiEnemies(unit: BattleUnit, state: CombatState): BattleUnit[] {
  return state.units.filter(u => u.side !== unit.side && u.hp > 0)
}
function _oiLeft(unit: BattleUnit, state: CombatState): BattleUnit | undefined {
  return state.units.find(u => u.side === unit.side && u.slotIndex === unit.slotIndex - 1 && u.hp > 0)
}
function _oiRight(unit: BattleUnit, state: CombatState): BattleUnit | undefined {
  return state.units.find(u => u.side === unit.side && u.slotIndex === unit.slotIndex + 1 && u.hp > 0)
}
function _oiTeamSize(side: BattleSide, state: CombatState): number {
  return state.units.filter(u => u.side === side).length
}
function _oiCountRow(side: BattleSide, row: BattleRow, state: CombatState): number {
  return state.units.filter(u => u.side === side && u.row === row && u.hp > 0).length
}

function _checkOI(
  cond: import("./types").OICondition,
  unit: BattleUnit, adj: BattleUnit | undefined, state: CombatState,
): boolean {
  const allies = _oiAllies(unit, state)
  const enemies = _oiEnemies(unit, state)
  const sz = _oiTeamSize(unit.side, state)
  const eSide: BattleSide = unit.side === "player" ? "enemy" : "player"
  switch (cond.type) {
    case "afterTrait": case "beforeTrait":
      if (!adj || adj.hp <= 0) return false
      if (cond.side === "ally" && adj.side !== unit.side) return false
      if (cond.side === "enemy" && adj.side === unit.side) return false
      return _oiHasTrait(adj, cond.trait)
    case "afterRole": case "beforeRole":
      if (!adj || adj.hp <= 0) return false
      if (cond.side === "ally" && adj.side !== unit.side) return false
      if (cond.side === "enemy" && adj.side === unit.side) return false
      return adj.role === cond.role
    case "fromLeft":  return unit.slotIndex === cond.n - 1
    case "fromRight": return unit.slotIndex === sz - cond.n
    case "slotLte":   return unit.slotIndex <= cond.slot
    case "slotGte":   return unit.slotIndex >= cond.slot
    case "inRow":     return unit.row === cond.row
    case "withinDistance": {
      const pool = cond.side === "ally" ? allies : cond.side === "enemy" ? enemies : [...allies, ...enemies]
      return pool.some(u => _oiHasTrait(u, cond.trait) && Math.abs(u.slotIndex - unit.slotIndex) <= cond.distance)
    }
    case "exactDistance": {
      const pool = cond.side === "ally" ? allies : cond.side === "enemy" ? enemies : [...allies, ...enemies]
      return pool.some(u => _oiHasTrait(u, cond.trait) && Math.abs(u.slotIndex - unit.slotIndex) === cond.distance)
    }
    case "leftIs": { const l = _oiLeft(unit, state); return !!l && _oiHasTrait(l, cond.trait) }
    case "rightIs": { const r = _oiRight(unit, state); return !!r && _oiHasTrait(r, cond.trait) }
    case "flankedBy": {
      const l = _oiLeft(unit, state); const r = _oiRight(unit, state)
      return !!l && !!r && _oiHasTrait(l, cond.trait) && _oiHasTrait(r, cond.trait)
    }
    case "allyCountInRow": {
      const cnt = _oiCountRow(unit.side, cond.row, state)
      return cond.op === ">=" ? cnt >= cond.count : cond.op === "<=" ? cnt <= cond.count : cnt === cond.count
    }
    case "enemyCountInRow": {
      const cnt = _oiCountRow(eSide, cond.row, state)
      return cond.op === ">=" ? cnt >= cond.count : cond.op === "<=" ? cnt <= cond.count : cnt === cond.count
    }
    case "and": return cond.conditions.every(c => _checkOI(c, unit, adj, state))
    case "or":  return cond.conditions.some(c => _checkOI(c, unit, adj, state))
    default: return false
  }
}

function _oiTargets(
  target: import("./types").OITarget,
  unit: BattleUnit, adj: BattleUnit | undefined, state: CombatState,
): BattleUnit[] {
  switch (target) {
    case "self":          return [unit]
    case "triggerUnit":   return adj && adj.hp > 0 ? [adj] : []
    case "allAllies":     return _oiAllies(unit, state)
    case "allEnemies":    return _oiEnemies(unit, state)
    case "leftNeighbor":  { const u = _oiLeft(unit, state);  return u ? [u] : [] }
    case "rightNeighbor": { const u = _oiRight(unit, state); return u ? [u] : [] }
    case "sameRow":       return state.units.filter(u => u.side === unit.side && u.row === unit.row && u.hp > 0 && u.uid !== unit.uid)
    case "frontRow":      return state.units.filter(u => u.side === unit.side && u.row === "front" && u.hp > 0)
    case "backRow":       return state.units.filter(u => u.side === unit.side && u.row === "back"  && u.hp > 0)
    default:              return [unit]
  }
}

function _reduceCooldowns(tgt: BattleUnit, amount: number, casterName: string, innateName: string, state: CombatState): void {
  let reduced = false
  tgt.cooldowns = tgt.cooldowns.map(cd => { if (cd > 0) { reduced = true; return Math.max(0, cd - amount) } return cd }) as [number, number, number]
  if (reduced) state.log.push({ id: uid(), text: `⚡ [${innateName}] ${casterName}→${tgt.name}: cooldown -${amount}`, kind: "system" })
}

function _applyOIEff(
  eff: import("./types").OIEffectKind,
  targets: BattleUnit[], caster: BattleUnit,
  innate: import("./types").OrderInnate, state: CombatState,
): void {
  const tag = `⚡ [${innate.name}]`
  for (const tgt of targets) {
    if (tgt.hp <= 0) continue
    switch (eff.kind) {
      case "atkUp":
        applyStatus(tgt, { name: innate.name, kind: "atkUp", value: eff.pct, turns: eff.turns }, state.log, caster.uid)
        state.log.push({ id: uid(), text: `${tag} ${caster.name}→${tgt.name} +${eff.pct}%ATK`, kind: "system" }); break
      case "defUp":
        applyStatus(tgt, { name: innate.name, kind: "defUp", value: eff.pct, turns: eff.turns }, state.log, caster.uid)
        state.log.push({ id: uid(), text: `${tag} ${caster.name}→${tgt.name} +${eff.pct}%DEF`, kind: "system" }); break
      case "spdUp":
        applyStatus(tgt, { name: innate.name, kind: "spdUp", value: eff.pct, turns: eff.turns }, state.log, caster.uid)
        state.log.push({ id: uid(), text: `${tag} ${caster.name}→${tgt.name} +${eff.pct}%SPD`, kind: "system" }); break
      case "critUp":
        tgt.stats = { ...tgt.stats, crit: (tgt.stats.crit || 0) + eff.pct }
        state.log.push({ id: uid(), text: `${tag} ${caster.name}→${tgt.name} +${eff.pct}%Crit`, kind: "system" }); break
      case "atkDown":
        applyStatus(tgt, { name: innate.name, kind: "atkDown", value: eff.pct, turns: eff.turns }, state.log, caster.uid)
        state.log.push({ id: uid(), text: `${tag} ${caster.name}→${tgt.name} -${eff.pct}%ATK`, kind: "system" }); break
      case "defDown":
        applyStatus(tgt, { name: innate.name, kind: "defDown", value: eff.pct, turns: eff.turns }, state.log, caster.uid)
        state.log.push({ id: uid(), text: `${tag} ${caster.name}→${tgt.name} -${eff.pct}%DEF`, kind: "system" }); break
      case "spdDown":
        applyStatus(tgt, { name: innate.name, kind: "spdDown", value: eff.pct, turns: eff.turns }, state.log, caster.uid)
        state.log.push({ id: uid(), text: `${tag} ${caster.name}→${tgt.name} -${eff.pct}%SPD`, kind: "system" }); break
      case "shield": {
        const val = Math.round(tgt.hpMax * eff.pct)
        applyStatus(tgt, { name: innate.name, kind: "shield", value: val, turns: eff.turns }, state.log, caster.uid)
        state.log.push({ id: uid(), text: `${tag} ${caster.name}→${tgt.name} khiên ${val}HP`, kind: "system" }); break
      }
      case "healPct": {
        const val = Math.round(tgt.hpMax * eff.pct)
        tgt.hp = Math.min(tgt.hpMax, tgt.hp + val)
        state.log.push({ id: uid(), text: `${tag} ${caster.name}→${tgt.name} hồi ${val}HP`, kind: "heal", casterUid: caster.uid, targetUid: tgt.uid }); break
      }
      case "energyGain":
        tgt.energy = Math.min(tgt.energyMax ?? 100, tgt.energy + eff.amount)
        state.log.push({ id: uid(), text: `${tag} ${caster.name}→${tgt.name} +${eff.amount}NL`, kind: "system" }); break
      case "applyStatus": {
        applyStatus(tgt, { name: innate.name, kind: eff.status, value: eff.value, turns: eff.turns }, state.log, caster.uid)
        const L: Record<string,string> = { burn:"🔥Bỏng",poison:"☠️Độc",bleed:"🩸Chảy máu",stun:"💫Choáng",silence:"🔇Câm",regen:"💚Tái sinh",taunt:"📣Khiêu chiến" }
        state.log.push({ id: uid(), text: `${tag} ${caster.name}→${tgt.name}: ${L[eff.status]??eff.status}`, kind: "status", casterUid: caster.uid, targetUid: tgt.uid }); break
      }
      // ── CƠ CHẾ ĐỘC ĐÁO ────────────────────────────────────
      case "reduceCooldown":
        _reduceCooldowns(tgt, eff.amount, caster.name, innate.name, state); break
      case "shareEnergy": {
        const actual = Math.min(eff.amount, caster.energy)
        if (actual > 0) {
          caster.energy -= actual
          tgt.energy = Math.min(tgt.energyMax ?? 100, tgt.energy + actual)
          state.log.push({ id: uid(), text: `${tag} ${caster.name}→${tgt.name}: truyền ${actual}NL`, kind: "system" })
        }
        break
      }
      case "hpToEnergy": {
        const cost = Math.round(tgt.hpMax * eff.hpPct)
        if (tgt.hp > cost + 1) {
          tgt.hp -= cost
          tgt.energy = Math.min(tgt.energyMax ?? 100, tgt.energy + eff.energyAmt)
          state.log.push({ id: uid(), text: `${tag} ${tgt.name}: -${cost}HP → +${eff.energyAmt}NL`, kind: "system" })
        }
        break
      }
      case "regenOnRow": {
        const rowMates = state.units.filter(u => u.side === caster.side && u.row === caster.row && u.hp > 0)
        for (const rm of rowMates)
          applyStatus(rm, { name: innate.name, kind: "regen", value: eff.pct, turns: eff.turns }, state.log, caster.uid)
        state.log.push({ id: uid(), text: `${tag} ${caster.name}: hàng ${caster.row} tái sinh ${eff.pct}%HP/${eff.turns}t`, kind: "system" }); break
      }
      case "tauntSelf":
        applyStatus(tgt, { name: innate.name, kind: "taunt", value: 1, turns: eff.turns }, state.log, caster.uid)
        state.log.push({ id: uid(), text: `${tag} ${tgt.name} khiêu chiến (${eff.turns}t)`, kind: "system" }); break
      case "resetSkill": {
        const slot = eff.slot ?? 0
        if (tgt.cooldowns[slot] > 0) {
          tgt.cooldowns[slot] = 0
          state.log.push({ id: uid(), text: `${tag} ${caster.name}→${tgt.name}: kỹ năng ${slot+1} hết CD!`, kind: "system" })
        }
        break
      }
      case "stackRegen": {
        const count = state.units.filter(u => u.side === tgt.side && u.hp > 0 && u.uid !== tgt.uid).length
        if (count > 0) {
          const totalPct = eff.pctPerAlly * count
          applyStatus(tgt, { name: innate.name, kind: "regen", value: totalPct, turns: eff.turns }, state.log, caster.uid)
          state.log.push({ id: uid(), text: `${tag} ${tgt.name}: tái sinh ${totalPct.toFixed(1)}%HP/t (${count}ĐT×${eff.pctPerAlly}%)`, kind: "system" })
        }
        break
      }
      case "echoEnergy":
        tgt.energy = Math.min(tgt.energyMax ?? 100, tgt.energy + eff.amount)
        state.log.push({ id: uid(), text: `${tag} ${tgt.name} tích NL +${eff.amount} (${tgt.energy}/${tgt.energyMax ?? 100})`, kind: "system" }); break
      case "transferShield": {
        const myShield = caster.statuses.find(s => s.kind === "shield")
        if (myShield && myShield.value > 0 && tgt.uid !== caster.uid) {
          const val = Math.round(myShield.value * eff.pct)
          myShield.value -= val
          if (myShield.value <= 0) caster.statuses = caster.statuses.filter(s => s !== myShield)
          applyStatus(tgt, { name: innate.name, kind: "shield", value: val, turns: myShield.turns }, state.log, caster.uid)
          state.log.push({ id: uid(), text: `${tag} ${caster.name}→${tgt.name}: chuyển khiên ${val}HP`, kind: "system" })
        }
        break
      }
      case "multi":
        for (const sub of eff.effects) _applyOIEff(sub, [tgt], caster, innate, state); break
    }
  }
}

export function processOrderInnate(
  unit: BattleUnit,
  adjPrev: BattleUnit | undefined,
  adjNext: BattleUnit | undefined,
  state: CombatState,
): void {
  if (!unit.orderInnateId) return
  const innate = ORDER_INNATES[unit.orderInnateId]
  if (!innate) return
  const ct = (innate.condition as any).type as string
  const isAfter  = ct === "afterTrait" || ct === "afterRole"
  const isBefore = ct === "beforeTrait" || ct === "beforeRole"
  const adj = isAfter ? adjPrev : isBefore ? adjNext : (adjPrev ?? adjNext)
  if (!_checkOI(innate.condition, unit, adj, state)) return
  const targets = _oiTargets(innate.effect.target, unit, adj, state)
  _applyOIEff(innate.effect, targets, unit, innate, state)
}

export function processEndOfTurn(state: CombatState, unit: BattleUnit) {
  // ══ DoT — 3 cơ chế khác nhau ══
  const poisonStacks = unit.statuses.filter(s => s.kind === "poison").length
  for (const st of unit.statuses) {

    // 🔥 BỎNG — pháp thuật, giảm bởi RES 50%, mạnh hơn khi HP cao
    //   Không stack · Tối đa 2 lượt · Giảm heal nhận -40% (xử lý ở healUnit)
    if (st.kind === "burn") {
      // Burn cũng bị giảm bởi RES theo flat subtraction (25% hệ số — DoT nhỏ hơn skill)
      const res = Math.max(0, unit.stats.res)
      const hpBonus = 1 + Math.min(0.20, (unit.hp / unit.hpMax) * 0.20)
      const dmg = Math.max(1, Math.round(Math.max(1, st.value - res * 0.25) * hpBonus))
      unit.hp = Math.max(0, unit.hp - dmg)
      const casterUid = st.appliedBy ?? ""
      state.log.push({ id: uid(), text: `🔥 ${unit.name} mất ${dmg} (Bỏng — pháp${hpBonus > 1.05 ? ", HP cao→mạnh hơn" : ""}) [src:${casterUid}]`, kind: "damage" })
    }

    // 🩸 CHẢY MÁU — vật lý thuần, xuyên giáp, leo thang +25%/lượt
    //   Không stack · Đánh lại → refresh turns (duy trì vết thương)
    else if (st.kind === "bleed") {
      const ticks = (st as any).__ticks ?? 0
      ;(st as any).__ticks = ticks + 1
      const escalation = 1 + ticks * 0.25
      const dmg = Math.max(1, Math.round(st.value * escalation))
      unit.hp = Math.max(0, unit.hp - dmg)
      const casterUid = st.appliedBy ?? ""
      state.log.push({ id: uid(), text: `🩸 ${unit.name} mất ${dmg} (Chảy máu +${Math.round(ticks * 25)}% — xuyên giáp) [src:${casterUid}]`, kind: "damage" })
    }

    // ☠️ ĐỘC — true dmg, cộng dồn stack (×10 tối đa), value mỗi stack = ½ gốc
    else if (st.kind === "poison") {
      const stackMult = Math.min(10, 1 + (poisonStacks - 1) * 0.30)
      const dmg = Math.max(1, Math.round(st.value * stackMult))
      unit.hp = Math.max(0, unit.hp - dmg)
      const casterUid = st.appliedBy ?? ""
      state.log.push({ id: uid(), text: `☠️ ${unit.name} mất ${dmg} (Độc×${poisonStacks}${poisonStacks > 1 ? ` ×${stackMult.toFixed(1)}` : ""} — thật) [src:${casterUid}]`, kind: "damage" })
    }

    if (st.kind === "regen") {
      const warFire = unit.statuses.find(s => s.kind === "warFire")
      const warFirePenalty = warFire ? (1 - warFire.value) : 1
      const heal = Math.round(unit.hpMax * st.value * warFirePenalty)
      unit.hp = Math.min(unit.hpMax, unit.hp + heal)
      state.log.push({ id: uid(), text: `💚 ${unit.name} hồi ${heal} HP (${st.name}${warFire ? ` −${Math.round(warFire.value*100)}% Chiến Hỏa` : ""})`, kind: "heal" })
    }
  }

  // Storm / Wind-Rider passive: per-turn SPD growth
  if (unit.hp > 0) {
    const passive = PASSIVES[unit.passiveId]
    if (passive?.signatureId === "wind-rider" || passive?.signatureId === "storm-chaser") {
      const stackKey = "__storm_spd"
      const existingStack = unit.statuses.find((s) => s.name === stackKey)
      const maxStacks = passive.signatureId === "storm-chaser" ? 15 : 10
      const growthPct = passive.signatureId === "storm-chaser" ? 0.05 : 0.03
      const currentStacks = existingStack ? existingStack.value : 0
      if (currentStacks < maxStacks) {
        const gain = Math.round(unit.stats.spd * growthPct)
        unit.stats.spd += gain
        if (existingStack) {
          existingStack.value = currentStacks + 1
        } else {
          unit.statuses.push({ id: uid(), kind: "spdUp" as const, value: 1, turns: 9999, name: stackKey })
        }
      }
    }

    // Mirror-Soul passive: track EVA stacks for energy on dodge (handled in rollDamage via eva check)
    // Plague synergy: spread poison/burn to random enemy each turn
    const plagueUnits = state.units.filter((u) => u.side === unit.side && u.hp > 0 && (u.origins as string[]).includes("plague"))
    if (plagueUnits.length >= 2) {
      const enemies = state.units.filter((u) => u.side !== unit.side && u.hp > 0)
      if (enemies.length > 0 && plagueUnits[0]?.uid === unit.uid) {
        const dotsToSpread = ["poison" as const, "burn" as const]
        for (const dotKind of dotsToSpread) {
          const sourceStatus = plagueUnits.flatMap(u => u.statuses).find(s => s.kind === dotKind)
          if (sourceStatus) {
            const randomEnemy = enemies[Math.floor(Math.random() * enemies.length)]
            if (!randomEnemy.statuses.some(s => s.kind === dotKind)) {
              randomEnemy.statuses.push({ ...sourceStatus, id: uid(), turns: Math.max(1, sourceStatus.turns) })
              state.log.push({ id: uid(), text: `🦠 Dịch lan! ${randomEnemy.name} bị nhiễm ${sourceStatus.name}`, kind: "status" })
            }
          }
        }
      }
    }
  }

  // Item passive regen + scalingPerTurn
  if (unit.hp > 0) {
    for (const ip of unit.itemPassives) {
      if (ip.kind === "regen") {
        const warFire = unit.statuses.find(s => s.kind === "warFire")
        const warFirePenalty = warFire ? (1 - warFire.value) : 1
        const heal = Math.round(unit.hpMax * ip.pct * warFirePenalty)
        unit.hp = Math.min(unit.hpMax, unit.hp + heal)
      }
      if (ip.kind === "scalingPerTurn") {
        // Apply per-turn stat growth (tracked via a pseudo-status with value as stacks)
        const existingStack = unit.statuses.find((s) => s.kind === "__tracker" && s.name === "__scaling_" + ip.stat)
        const currentStacks = existingStack ? existingStack.value : 0
        if (currentStacks < ip.maxStacks) {
          unit.stats[ip.stat] = (unit.stats[ip.stat] || 0) + ip.amountPerTurn
          // Track stacks via a hidden status
          if (existingStack) {
            existingStack.value = currentStacks + 1
          } else {
            unit.statuses.push({ id: uid(), kind: "__tracker" as const, value: 1, turns: 9999, name: "__scaling_" + ip.stat })
          }
        }
      }
    }
  }
  // ── New unique passive: bloodPact HP drain + stack accumulation ──────
  if (unit.hp > 0) {
    const bloodPact = unit.itemPassives.find(ip => ip.kind === "bloodPact")
    if (bloodPact) {
      const drain = Math.max(1, Math.round(unit.hpMax * bloodPact.hpCostPct))
      unit.hp = Math.max(1, unit.hp - drain)
      const stackSt = unit.statuses.find(s => s.name === "__bloodpact_stacks")
      if (stackSt) {
        if (stackSt.value < 3) {
          stackSt.value += 1
          state.log.push({ id: uid(), text: `🩸 ${unit.name} Giao Ước Máu! -${drain} HP, ×${(1 + stackSt.value * bloodPact.dmgBonus).toFixed(2)} sát thương (${stackSt.value}/3)`, kind: "status" })
        } else {
          state.log.push({ id: uid(), text: `🩸 ${unit.name} Giao Ước Máu! -${drain} HP (tối đa ×${(1 + 3 * bloodPact.dmgBonus).toFixed(2)})`, kind: "status" })
        }
      } else {
        unit.statuses.push({ id: uid(), kind: "__tracker" as const, value: 1, turns: 9999, name: "__bloodpact_stacks" })
        state.log.push({ id: uid(), text: `🩸 ${unit.name} Giao Ước Máu! -${drain} HP, ×${(1 + bloodPact.dmgBonus).toFixed(2)} sát thương (1/3)`, kind: "status" })
      }
    }

    // ── autoUlt: fire ult automatically when energy is full ──────────
    const autoUltPassive = unit.itemPassives.find(ip => ip.kind === "autoUlt")
    if (autoUltPassive && unit.energy >= ULTIMATE_ENERGY_COST) {
      const ultSkill = unit.skills[2]
      if (ultSkill?.ultimate && unit.cooldowns[2] === 0) {
        const enemies = state.units.filter(u => u.side !== unit.side && u.hp > 0)
        const allies = state.units.filter(u => u.side === unit.side && u.hp > 0)
        if (enemies.length > 0) {
          state.log.push({ id: uid(), text: `✨ ${unit.name} Tự Động Ulti! (${ultSkill.name})`, kind: "system" })
          unit.energy = 0
          // FIX: set cooldown AFTER the status-tick section would subtract 1 immediately.
          // We set it here and compensate by adding +1 so the end-of-turn tick lands on the correct value.
          unit.cooldowns[2] = ultSkill.cooldown + 1
          const sLvl = unit.skillLevels?.[2] ?? 1
          const rarityMult = RARITY_SKILL_MULT[unit.rarity] ?? 1.0
          const scaleMult = (1 + (sLvl - 1) * 0.15) * rarityMult
          const randEnemy = enemies[Math.floor(Math.random() * enemies.length)]
          for (const ef of ultSkill.effects) {
            // FIX: use skill.targeting for proper AoE support (ef.apply doesn't exist on SkillEffect)
            const targets =
              ultSkill.targeting === "all-enemies" ? enemies
              : ultSkill.targeting === "all-allies" ? allies
              : ultSkill.targeting === "self" ? [unit]
              : [randEnemy]
            for (const t of targets) {
              if (t.hp <= 0) continue
              if (ef.damage) rollDamage(unit, t, { ...ef.damage, scale: ef.damage.scale * scaleMult }, state.log, state)
              if (ef.heal) healUnit(unit, t, { ...ef.heal, scale: ef.heal.scale * scaleMult }, state.log)
              if (ef.status?.kind) applyStatus(t, ef.status, state.log, unit.uid)
            }
          }
          // FIX: fire onUltimate blessing/pact hook for autoUlt too
          fireHook("onUltimate", state, unit)
          // FIX: process __echo_ultimate (b_echo_strike blessing — echo ult at 50% power)
          const echoMark = unit.statuses.find(s => s.name === "__echo_ultimate")
          if (echoMark) {
            unit.statuses = unit.statuses.filter(s => s.name !== "__echo_ultimate")
            const echoScaleMult = scaleMult * 0.5
            const echoRandEnemy = enemies[Math.floor(Math.random() * enemies.length)]
            state.log.push({ id: uid(), text: `✨ [Vang Vọng Thiên Khải] ${unit.name} vang vọng chiêu tối thượng!`, kind: "system" })
            for (const ef of ultSkill.effects) {
              const targets =
                ultSkill.targeting === "all-enemies" ? enemies
                : ultSkill.targeting === "all-allies" ? allies
                : ultSkill.targeting === "self" ? [unit]
                : [echoRandEnemy]
              for (const t of targets) {
                if (t.hp <= 0) continue
                if (ef.damage) rollDamage(unit, t, { ...ef.damage, scale: ef.damage.scale * echoScaleMult }, state.log, state)
                if (ef.heal) healUnit(unit, t, { ...ef.heal, scale: ef.heal.scale * echoScaleMult }, state.log)
              }
            }
          }
        }
      }
    }

    // ── Process __echo_ultimate (b_echo_strike) when ult was cast manually ──
    {
      const echoMark = unit.statuses.find(s => s.name === "__echo_ultimate")
      if (echoMark) {
        const ultSkill = unit.skills[2]
        if (ultSkill?.ultimate) {
          unit.statuses = unit.statuses.filter(s => s.name !== "__echo_ultimate")
          const enemies = state.units.filter(u => u.side !== unit.side && u.hp > 0)
          const allies = state.units.filter(u => u.side === unit.side && u.hp > 0)
          if (enemies.length > 0) {
            const sLvl = unit.skillLevels?.[2] ?? 1
            const rarityMult = RARITY_SKILL_MULT[unit.rarity] ?? 1.0
            const echoScaleMult = (1 + (sLvl - 1) * 0.15) * rarityMult * 0.5
            const echoRandEnemy = enemies[Math.floor(Math.random() * enemies.length)]
            state.log.push({ id: uid(), text: `✨ [Vang Vọng Thiên Khải] ${unit.name} vang vọng chiêu tối thượng!`, kind: "system" })
            for (const ef of ultSkill.effects) {
              const targets =
                ultSkill.targeting === "all-enemies" ? enemies
                : ultSkill.targeting === "all-allies" ? allies
                : ultSkill.targeting === "self" ? [unit]
                : [echoRandEnemy]
              for (const t of targets) {
                if (t.hp <= 0) continue
                if (ef.damage) rollDamage(unit, t, { ...ef.damage, scale: ef.damage.scale * echoScaleMult }, state.log, state)
                if (ef.heal) healUnit(unit, t, { ...ef.heal, scale: ef.heal.scale * echoScaleMult }, state.log)
              }
            }
          }
        }
      }
    }
  }

  // Tick down statuses (skip already-zero turns set by exhausted shields).
  // FIX: Skip "stun" here — stun is already ticked (turns-1) in advanceTurn when the
  // unit's turn is skipped. Ticking it again here would cause a 2-turn stun to only
  // last 1 turn (skip tick → 2→1, then EOT tick → 1→0, removed before next round).
  unit.statuses = unit.statuses
    .map((s) => s.kind === "stun" ? s : { ...s, turns: s.turns - 1 })
    .filter((s) => s.turns > 0 && (s.kind !== "shield" || s.value > 0))
  // Cooldowns — skip if already ticked this turn (stun-skip path pre-ticks cooldowns)
  if (!(unit as any).__cooldownsAlreadyTicked) {
    unit.cooldowns = unit.cooldowns.map((cd) => Math.max(0, cd - 1)) as [number, number, number]
  }
  // Fire onTurnEnd blessing/pact hook
  fireHook("onTurnEnd", state, unit)

  // ── Nghỉ Ngơi: tướng melee ở hàng sau hồi 4% HP/lượt ──
  if (unit.isResting && unit.hp > 0 && unit.row === "back") {
    const restHeal = Math.round(unit.hpMax * 0.04)
    unit.hp = Math.min(unit.hpMax, unit.hp + restHeal)
    state.log.push({ id: uid(), text: `💤 ${unit.name} nghỉ ngơi — hồi ${restHeal} HP`, kind: "heal", casterUid: unit.uid })
  }
  // Keep log bounded
  trimLog(state.log)

  // ── KSAN: Tích Lực (Sword form trigger after 6 turns) ──
  ksanCheckSwordTransform(state, unit)
}

// Called at the start of a unit's own turn — gives them energy
export function onUnitTurnStart(unit: BattleUnit, state?: CombatState) {
  let gain = ENERGY_TURN_GAIN
  for (const ip of unit.itemPassives) {
    if (ip.kind === "manaRegen") gain += ip.amount
    if (ip.kind === "autoUlt") gain += ip.energyPerTurn
  }
  unit.energy = Math.min(unit.energyMax, unit.energy + gain)
  // Fire blessing/pact onTurnStart hook
  if (state) fireHook("onTurnStart", state, unit)
}

// ============================================================
// Win check
// ============================================================

// ============================================================
// ⚔️  CHIẾN HỎA — Battlefield Pressure System
// ============================================================
//
//  Vấn đề: 2 team có healer/tank trâu khiến trận kéo dài vô tận.
//
//  Giải pháp — "Chiến Hỏa" (War Fire):
//    • Bắt đầu từ vòng WAR_FIRE_START_ROUND (10), lửa chiến trường bùng phát.
//    • Mỗi vòng tiếp theo, ngọn lửa leo thang thêm 1 cấp độ.
//    • Mỗi cấp độ:
//        – Gây sát thương thật (true dmg) cho mọi unit theo % HP tối đa
//        – Giảm hiệu quả hồi máu của unit đó (bao gồm regen, heal skill)
//        – Stack tối đa WAR_FIRE_MAX_STAGE, sau đó giữ nguyên mức tối đa.
//    • Hiển thị cảnh báo vào đúng vòng kích hoạt và mỗi lần leo thang.
//
//  Kết quả: Mọi trận đấu đều HỮU HẠN. Healer trâu bò không thể bù kịp
//  sát thương khi Chiến Hỏa đã leo thang đủ cao.

export const WAR_FIRE_START_ROUND = 10  // vòng đầu tiên Chiến Hỏa xuất hiện
export const WAR_FIRE_MAX_STAGE   = 8   // cấp tối đa (giữ nguyên sau đó)

/** Tính cấp độ Chiến Hỏa hiện tại (0 = chưa kích hoạt) */
export function warFireStage(round: number): number {
  if (round < WAR_FIRE_START_ROUND) return 0
  return Math.min(WAR_FIRE_MAX_STAGE, round - WAR_FIRE_START_ROUND + 1)
}

/** % HP tối đa bị đốt mỗi vòng tại cấp stage (true dmg, xuyên giáp, bỏ qua res) */
export function warFireDmgPct(stage: number): number {
  // Stage 1 = 2%, stage 2 = 4%, ..., stage 8 = 16%
  return stage * 0.02
}

/** Hệ số giảm hiệu quả heal tại cấp stage (0 = không giảm, 1 = giảm 100%) */
export function warFireHealReduction(stage: number): number {
  // Stage 1 = 10%, stage 4 = 40%, stage 8 = 80%
  return Math.min(0.80, stage * 0.10)
}

/**
 * Áp dụng Chiến Hỏa cuối mỗi vòng.
 * Gọi sau processEndOfTurn, trước khi recompute turn order.
 */
export function applyWarFire(state: CombatState): void {
  // FIX J: state.round was already incremented by next.round++ BEFORE applyWarFire is called.
  // warFireStage uses the current round value, but announcement check compared against
  // WAR_FIRE_START_ROUND which is now 1 behind the incremented value.
  // Use (state.round - 1) as the "just-completed round" for announcement purposes.
  const completedRound = state.round - 1
  const stage = warFireStage(completedRound)
  if (stage <= 0) return

  const dmgPct  = warFireDmgPct(stage)
  const healRed = warFireHealReduction(stage)

  if (completedRound === WAR_FIRE_START_ROUND) {
    state.log.push({
      id: uid(),
      text: `🔥⚔️ CHIẾN HỎA bùng phát! Chiến trường nóng lên — mọi đơn vị chịu thêm ${Math.round(dmgPct * 100)}% HP thật/vòng, hồi máu giảm ${Math.round(healRed * 100)}%!`,
      kind: "system",
    })
  } else {
    state.log.push({
      id: uid(),
      text: `🔥⚔️ Chiến Hỏa leo thang [Cấp ${stage}/${WAR_FIRE_MAX_STAGE}] — ${Math.round(dmgPct * 100)}% HP/vòng · hồi máu -${Math.round(healRed * 100)}%`,
      kind: "system",
    })
  }

  for (const unit of state.units) {
    if (unit.hp <= 0) continue

    // Apply true damage (bypasses all armor/res)
    const dmg = Math.max(1, Math.round(unit.hpMax * dmgPct))
    unit.hp = Math.max(0, unit.hp - dmg)
    state.log.push({
      id: uid(),
      text: `🔥 ${unit.name} bị Chiến Hỏa thiêu đốt −${dmg} HP thật`,
      kind: "damage",
    })

    // Tag the unit with warFire status so healUnit can read reduction factor
    const existing = unit.statuses.find(s => s.kind === "warFire")
    if (existing) {
      existing.value  = healRed
      existing.turns  = 9999 // permanent while combat lasts
      existing.name   = `Chiến Hỏa Cấp ${stage}`
    } else {
      unit.statuses.push({
        id:    uid(),
        kind:  "warFire",
        name:  `Chiến Hỏa Cấp ${stage}`,
        value: healRed,   // heal reduction factor (0..0.80)
        turns: 9999,
      })
    }
  }
}

// ============================================================
// KSAN — Dual-Form Engine Logic
// ============================================================

/**
 * Checks if Ksan should transform from Shield → Sword form.
 * Conditions:
 *   1. Cận Tử: HP < 20% max HP
 *   2. Tích Lực: 6 turns accumulated (tracked via __ksan_turns __tracker status)
 */
function ksanCheckSwordTransform(state: CombatState, unit: BattleUnit) {
  const passive = PASSIVES[unit.passiveId]
  if (passive?.signatureId !== "ksan-batkhuat") return
  // Already in sword form?
  if (unit.statuses.some(s => s.name === "__ksan_sword")) return

  // Increment turn counter
  let turnTracker = unit.statuses.find(s => s.name === "__ksan_turns")
  if (!turnTracker) {
    turnTracker = { id: uid(), kind: "__tracker", value: 1, turns: 9999, name: "__ksan_turns" }
    unit.statuses.push(turnTracker)
  } else {
    turnTracker.value += 1
  }

  const hpPct = unit.hp / unit.hpMax
  const shouldTransform = hpPct < 0.20 || turnTracker.value >= 6

  if (shouldTransform) {
    ksanActivateSwordForm(state, unit)
  }
}

/**
 * Activates Ksan's Sword Form (Phá Khiên Hóa Kiếm).
 * - Keeps current HP + all HP buffs from Shield form
 * - Swaps skill set to Sword Form skills
 * - Grants: +30% Lifesteal, +30% Heal, AoE basic attack, ignore 50% armor
 * - Takes an immediate turn
 * - Enters immunity frame (CC-immune for 1 turn)
 */
function ksanActivateSwordForm(state: CombatState, unit: BattleUnit) {
  // Mark as sword form
  unit.statuses.push({ id: uid(), kind: "__tracker", value: 1, turns: 9999, name: "__ksan_sword" })

  // Swap skills to sword form
  const swordSkills = [SKILLS["ksanInovar"], SKILLS["ksanChanBoDe"], SKILLS["ksanDapVoNitro"]]
  if (swordSkills.every(Boolean)) {
    unit.skills = swordSkills as typeof unit.skills
    unit.cooldowns = [0, 0, 0]
  }

  // +30% Lifesteal (permanent buff via stat)
  unit.stats.lifesteal = (unit.stats.lifesteal || 0) + 30

  // CC immunity for 1 turn (Miễn khống chế khoảnh khắc Hóa Kiếm)
  unit.statuses.push({ id: uid(), kind: "__tracker", value: 1, turns: 1, name: "__ksan_ccimmune" })

  // Remove stun/cc effects
  unit.statuses = unit.statuses.filter(s => !["stun"].includes(s.kind))

  state.log.push({
    id: uid(),
    text: `⚡🗡 ${unit.name} — PHÁT KHIÊN HÓA KIẾM! Ksan chuyển sang Dạng Kiếm! Máu giữ nguyên: ${unit.hp}/${unit.hpMax}`,
    kind: "system",
  })

  // Chiếm turn ngay lập tức — prepend to order so Ksan acts next
  const idx = state.order.indexOf(unit.uid)
  if (idx !== -1) state.order.splice(idx, 1)
  state.order.unshift(unit.uid)
}

/**
 * Ksan's Cấp Cứu passive — fires when:
 *   - HP drops below 50% for the first time, OR
 *   - A single hit deals > 30% max HP
 * Grants: immunity to CC for 2 rounds, +20% HP heal, Undying.
 */
function ksanCapCuuCheck(
  state: CombatState,
  unit: BattleUnit,
  dmgReceived: number,
  wasBelowHalfBefore: boolean,
) {
  const passive = PASSIVES[unit.passiveId]
  if (passive?.signatureId !== "ksan-batkhuat") return
  if (unit.statuses.some(s => s.name === "__ksan_sword")) return // sword form — no shield passive
  if (unit.statuses.some(s => s.name === "__ksan_capcuu_used")) return // one-shot

  const hpPct = unit.hp / unit.hpMax
  const hitPct = dmgReceived / unit.hpMax
  const nowBelow50 = hpPct < 0.5

  if ((!wasBelowHalfBefore && nowBelow50) || hitPct > 0.30) {
    // Mark used
    unit.statuses.push({ id: uid(), kind: "__tracker", value: 1, turns: 9999, name: "__ksan_capcuu_used" })
    // CC immunity 2 rounds
    unit.statuses.push({ id: uid(), kind: "__tracker", value: 2, turns: 2, name: "__ksan_ccimmune" })
    // Heal 20% HP
    const heal = Math.round(unit.hpMax * 0.2)
    unit.hp = Math.min(unit.hpMax, unit.hp + heal)
    // Mark undying for this unit (handled in rollDamage check)
    unit.statuses.push({ id: uid(), kind: "__tracker", value: 1, turns: 2, name: "__ksan_undying" })

    state.log.push({
      id: uid(),
      text: `🛡✨ ${unit.name} CẤP CỨU! Bất Khuất kích hoạt — Miễn CC 2 lượt, hồi ${heal} HP, Bất Tử nhất kích!`,
      kind: "system",
    })
  }
}

export function checkEnded(state: CombatState): "victory" | "defeat" | null {
  // Single pass — avoid two separate filter calls
  let hasEnemy = false; let hasPlayer = false
  for (const u of state.units) {
    if (u.hp <= 0) continue
    if (u.side === "enemy") hasEnemy = true
    else hasPlayer = true
    if (hasEnemy && hasPlayer) return null // both sides alive, early exit
  }
  // FIX: Must check both conditions before returning null
  if (!hasEnemy && !hasPlayer) return "defeat" // edge case
  if (!hasEnemy) return "victory"
  if (!hasPlayer) return "defeat"
  return null
}

// ============================================================
// Rewards
// ============================================================

export function computeRewards(stage: number) {
  const gold = 80 + stage * 35 + Math.floor(Math.random() * (stage * 12 + 30))
  const gems = stage % 3 === 0 ? 5 + Math.floor(stage / 3) : Math.random() < 0.4 ? 2 : 0
  const xp = 80 + stage * 35
  // Item drop chance 35%
  const items: { itemId: string; quantity: number }[] = []
  if (Math.random() < 0.35) {
    // Pick a random rarity-weighted potion or material item
    const pool = ["p_minor", "p_minor", "p_medium", "p_haste", "p_rage"]
    if (stage > 5) pool.push("p_major")
    if (stage > 10) pool.push("p_elixir")
    items.push({ itemId: pickRandom(pool), quantity: 1 })
  }
  return { gold, gems, xp, items }
}

// ============================================================
// AI controller — picks an action for an enemy/AI unit
// ============================================================

export type AIAction =
  | { kind: "skill"; skillIndex: 0 | 1 | 2; targetUid: string | null }
  | { kind: "basic"; targetUid: string }
  | { kind: "rowChange" }

// ============================================================
// STRATEGIC AI v4 — Situational Intelligence System
//
// Nâng cấp hoàn toàn so với v3:
//  • Momentum tracking — AI nhận biết phe nào đang thắng thế
//  • Kill-threat detection — phát hiện đồng đội sắp bị hạ gục
//  • Burst window — tập trung hỏa lực khi địch đang yếu
//  • Cooldown conservation — giữ skill cho tình huống quan trọng
//  • WarFire awareness — tránh heal khi debuff warFire còn mạnh
//  • Energy state — tính toán thời điểm xài ultimate
//  • Enemy momentum — debuff địch đang bốc lửa
//  • Unit value weighting — ưu tiên bảo vệ unit cao giá trị nhất
// ============================================================

interface BattleContext {
  aliveAllies:        BattleUnit[]
  aliveEnemies:       BattleUnit[]
  lowestAlly:         BattleUnit | null
  lowestAllyPct:      number
  totalAllyHp:        number
  totalAllyMaxHp:     number
  totalEnemyHp:       number
  totalEnemyMaxHp:    number
  teamCarry:          BattleUnit | null
  enemyCarry:         BattleUnit | null
  phase:              "early" | "mid" | "late"
  allyAdvantage:      number
  momentum:           "winning" | "losing" | "even"
  panicMode:          boolean
  burstWindow:        boolean
  killThreat:         BattleUnit | null
  enemyHealerAlive:   boolean
  allyHealerAlive:    boolean
  enemyHasDot:        boolean
  allyHasWarFire:     boolean
  enemyBuffCount:     number
  allyDebuffCount:    number
  nextToActEnemy:     BattleUnit | null
  stunedEnemyCount:   number
}

// ── Build full battlefield snapshot ─────────────────────────────────────

function buildBattleContext(state: CombatState, unit: BattleUnit): BattleContext {
  const allySide = unit.side
  const oppSide: BattleSide = allySide === "player" ? "enemy" : "player"
  const aliveAllies: BattleUnit[] = []
  const aliveEnemies: BattleUnit[] = []
  let lowestAlly: BattleUnit | null = null
  let lowestAllyPct = 1
  let totalAllyHp = 0, totalAllyMaxHp = 0
  let totalEnemyHp = 0, totalEnemyMaxHp = 0
  let enemyBuffCount = 0, allyDebuffCount = 0
  let stunedEnemyCount = 0

  for (const u of state.units) {
    if (u.hp <= 0) continue
    if (u.side === allySide) {
      aliveAllies.push(u)
      const pct = u.hp / u.hpMax
      totalAllyHp += u.hp; totalAllyMaxHp += u.hpMax
      if (pct < lowestAllyPct) { lowestAlly = u; lowestAllyPct = pct }
      for (const s of u.statuses) {
        if (["atkDown","defDown","spdDown","burn","poison","bleed","stun","warFire"].includes(s.kind)) allyDebuffCount++
      }
    } else {
      aliveEnemies.push(u)
      totalEnemyHp += u.hp; totalEnemyMaxHp += u.hpMax
      for (const s of u.statuses) {
        if (["atkUp","defUp","spdUp","shield","regen"].includes(s.kind)) enemyBuffCount++
        if (s.kind === "stun") stunedEnemyCount++
      }
    }
  }

  const totalAlive = aliveAllies.length + aliveEnemies.length
  const phase: BattleContext["phase"] =
    totalAlive >= 8 ? "early" : totalAlive >= 4 ? "mid" : "late"

  const allyHpPct   = totalAllyMaxHp  > 0 ? totalAllyHp  / totalAllyMaxHp  : 1
  const enemyHpPct  = totalEnemyMaxHp > 0 ? totalEnemyHp / totalEnemyMaxHp : 1
  const allyAdvantage = aliveAllies.length - aliveEnemies.length

  // Momentum: so sánh HP% tổng thể + số lượng
  const hpDelta = allyHpPct - enemyHpPct
  const cntDelta = allyAdvantage
  const momentumScore = hpDelta * 60 + cntDelta * 20
  const momentum: BattleContext["momentum"] =
    momentumScore > 15 ? "winning" : momentumScore < -15 ? "losing" : "even"

  const panicMode = allyHpPct < 0.35 || aliveEnemies.length >= aliveAllies.length * 2

  // Burst window: địch tổng thể yếu, nên dồn hỏa lực
  const burstWindow = enemyHpPct < 0.45 && aliveEnemies.length <= aliveAllies.length

  // Kill threat: đồng đội sắp chết (HP < 20%)
  const killThreat = aliveAllies.find(a => a.hp / a.hpMax < 0.20) ?? null

  // WarFire on ally side
  const allyHasWarFire = aliveAllies.some(a => a.statuses.some(s => s.kind === "warFire"))

  // Enemy DoT bleeding onto ally
  const enemyHasDot = aliveAllies.some(a =>
    a.statuses.some(s => s.kind === "burn" || s.kind === "poison" || s.kind === "bleed")
  )

  // Next enemy to act in turn order (after current unit)
  const currentIdx = state.order.indexOf(unit.uid)
  let nextToActEnemy: BattleUnit | null = null
  for (let i = currentIdx + 1; i < state.order.length; i++) {
    const u = state.units.find(u => u.uid === state.order[i] && u.hp > 0 && u.side === oppSide)
    if (u) { nextToActEnemy = u; break }
  }

  return {
    aliveAllies,
    aliveEnemies,
    lowestAlly,
    lowestAllyPct,
    totalAllyHp,
    totalAllyMaxHp,
    totalEnemyHp,
    totalEnemyMaxHp,
    teamCarry:        findTeamCarry(aliveAllies),
    enemyCarry:       findTeamCarry(aliveEnemies),
    phase,
    allyAdvantage,
    momentum,
    panicMode,
    burstWindow,
    killThreat,
    enemyHealerAlive: aliveEnemies.some(u => u.role === "support"),
    allyHealerAlive:  aliveAllies.some(u => u.role === "support" && u.uid !== unit.uid),
    enemyHasDot,
    allyHasWarFire,
    enemyBuffCount,
    allyDebuffCount,
    nextToActEnemy,
    stunedEnemyCount,
  }
}

// ── Carry detection ──────────────────────────────────────────────────────

function scoreCarryPotential(unit: BattleUnit): number {
  let score = 0
  switch (unit.role) {
    case "assassin": score += 60; break
    case "mage":     score += 55; break
    case "marksman": score += 50; break
    case "warrior":  score += 35; break
    case "support":  score += 20; break
    case "tank":     score += 10; break
    default:         score += 25
  }
  const hpPct = unit.hp / unit.hpMax
  score += hpPct * 40
  score += Math.min(Math.max(unit.stats.atk ?? 0, unit.stats.mag ?? 0) / 20, 40)
  score += Math.min((unit.stats.spd ?? 0) / 10, 20)
  for (const s of unit.statuses) {
    if (s.kind === "atkUp" || s.kind === "spdUp") score += 10
    if (s.kind === "stun")   score -= 30  // stunned carry = useless this turn
    if (s.kind === "atkDown") score -= 15
  }
  if (hpPct < 0.15) score -= 80
  return score
}

function findTeamCarry(allies: BattleUnit[]): BattleUnit | null {
  if (allies.length < 2) return null
  const scored = allies.map(u => ({ unit: u, score: scoreCarryPotential(u) }))
  scored.sort((a, b) => b.score - a.score)
  const [best, second] = scored
  if (best.score >= 65 && best.score - second.score >= 20) return best.unit
  return null
}

function isProtectorRole(role: BattleUnit["role"]): boolean {
  return role === "support" || role === "tank"
}

// ── Row helpers ──────────────────────────────────────────────────────────

function aliveByRow(units: BattleUnit[], side: BattleSide, row: BattleRow): BattleUnit[] {
  return units.filter(u => u.hp > 0 && u.side === side && u.row === row)
}

// ── Threat scoring ───────────────────────────────────────────────────────
// Tính điểm "mức nguy hiểm" của 1 địch → càng cao càng nên đánh trước

function scoreThreatTarget(unit: BattleUnit, attacker: BattleUnit, ctx: BattleContext): number {
  let score = 0
  const hpPct = unit.hp / unit.hpMax

  // Ưu tiên kill-shot — đánh dứt điểm unit sắp chết
  if (hpPct < 0.15)      score += 100
  else if (hpPct < 0.25) score += 70
  else if (hpPct < 0.40) score += 40
  else if (hpPct < 0.60) score += 20
  else if (hpPct < 0.80) score += 8

  // Role threat — vai trò nguy hiểm hơn → ưu tiên hơn
  switch (unit.role) {
    case "support":  score += 60; break  // healer → phải chết đầu
    case "mage":     score += 50; break
    case "assassin": score += 45; break
    case "marksman": score += 38; break
    case "warrior":  score += 20; break
    case "tank":     score += 5;  break  // tank cuối cùng
    default:         score += 15
  }

  // Enemy carry = focus target tuyệt đối
  if (ctx.enemyCarry && unit.uid === ctx.enemyCarry.uid) score += 50

  // Buff stacking: địch đang bốc lửa thì nguy hiểm hơn
  for (const s of unit.statuses) {
    if (s.kind === "atkUp")   score += 18
    if (s.kind === "spdUp")   score += 15
    if (s.kind === "regen")   score += 12  // sẽ tự hồi nếu không kill
    if (s.kind === "shield")  score -= 12  // khó kill hơn → tạm thời giảm ưu tiên
    if (s.kind === "stun")    score -= 25  // đang stun → không nguy hiểm ngay
    if (s.kind === "defDown") score += 10  // dễ kill hơn → tăng ưu tiên
  }

  // Enemy healer alive → tất cả DPS ưu tiên kill healer trước
  if (ctx.enemyHealerAlive && unit.role === "support") score += 35

  // Burst window: mọi đòn tập trung vào unit yếu nhất để dứt điểm
  if (ctx.burstWindow && hpPct < 0.5) score += 25

  // Attacker-specific bonuses
  if (attacker.role === "assassin" && unit.row === "back")     score += 30
  if (attacker.role === "mage"     && unit.role === "support") score += 25
  if (attacker.role === "support"  && unit.role === "tank")    score -= 25
  if (attacker.role === "marksman" && unit.role === "support") score += 20

  // Late game: không còn phân biệt nhiều, tập trung dứt điểm
  if (ctx.phase === "late") {
    score += unit.role === "tank" ? -15 : 20
  }

  // Panic: đánh bất kỳ ai yếu nhất để tạo lợi thế số lượng
  if (ctx.panicMode && hpPct < 0.50) score += 35

  return score
}

function pickBestTarget(
  pool: BattleUnit[],
  attacker?: BattleUnit,
  ctx?: BattleContext,
): BattleUnit | null {
  if (pool.length === 0) return null
  if (!attacker || !ctx) {
    return pool.reduce((best, u) => (u.hp / u.hpMax < best.hp / best.hpMax ? u : best))
  }
  return pool.reduce((best, u) =>
    scoreThreatTarget(u, attacker, ctx) > scoreThreatTarget(best, attacker, ctx) ? u : best
  )
}

// ── Row-based target selection ───────────────────────────────────────────

export function pickRowTarget(
  units: BattleUnit[],
  attacker: BattleUnit,
  oppSide: BattleSide,
  ctx?: BattleContext,
): BattleUnit | null {
  const front = aliveByRow(units, oppSide, "front")
  const back  = aliveByRow(units, oppSide, "back")
  const all   = [...front, ...back]
  if (all.length === 0) return null

  // Taunt: hard redirect (cao hơn v3: 80%)
  const tauntingUnits = all.filter(u => u.statuses.some(s => s.kind === "taunt" && s.turns > 0))
  if (tauntingUnits.length > 0 && Math.random() < 0.80) {
    return tauntingUnits[Math.floor(Math.random() * tauntingUnits.length)]
  }

  // Tank aura (giảm xuống 40% so với 45% để logic thông minh hơn thể hiện)
  const tankPool = all.filter(u => u.role === "tank")
  if (tankPool.length > 0 && Math.random() < 0.40) {
    return tankPool[Math.floor(Math.random() * tankPool.length)]
  }

  // Burst window: TẤT CẢ tập trung vào unit yếu nhất để dứt điểm
  if (ctx?.burstWindow) {
    return pickBestTarget(all, attacker, ctx)
  }

  // Panic: cũng tập trung vào unit có thể kill nhanh nhất
  if (ctx?.panicMode) return pickBestTarget(all, attacker, ctx)

  // Healer hunt: DPS ưu tiên cao tiêu diệt healer địch
  if (ctx?.enemyHealerAlive) {
    const healer = all.find(u => u.role === "support")
    if (healer) {
      const isHunter = ["assassin","mage","marksman"].includes(attacker.role)
      const hunterBias = ctx.phase === "late" ? 0.75 : 0.55
      if (isHunter && Math.random() < hunterBias) return healer
    }
  }

  // Next-to-act enemy: nếu địch sắp đến lượt và nguy hiểm → ưu tiên stun/tấn công
  if (ctx?.nextToActEnemy && ctx.nextToActEnemy.role !== "tank") {
    const nextIsInPool = all.find(u => u.uid === ctx.nextToActEnemy?.uid)
    if (nextIsInPool && Math.random() < 0.30) return nextIsInPool
  }

  const role = attacker.role

  if (role === "tank") {
    // Tank: bám hàng trước, nhưng late game đôi khi đẩy vào backline
    const pool = (ctx?.phase === "late" && back.length > 0 && Math.random() < 0.35)
      ? back : (front.length > 0 ? front : back)
    return pickBestTarget(pool, attacker, ctx)
  }

  if (role === "support") {
    // Support bị ép đánh: nhắm mục tiêu ít nguy hiểm nhất, tránh tank
    const safePool = all.filter(u => u.role !== "tank")
    return pickBestTarget(safePool.length > 0 ? safePool : all, attacker, ctx)
  }

  if (role === "assassin") {
    // Assassin: chuyên săn backline, mid/late gần như luôn xuyên hàng
    const bias = ctx?.phase === "early" ? 0.65 : ctx?.phase === "mid" ? 0.80 : 0.90
    if (back.length > 0 && Math.random() < bias) return pickBestTarget(back, attacker, ctx)
    return pickBestTarget(front.length > 0 ? front : back, attacker, ctx)
  }

  if (role === "mage") {
    // Mage: snipe backline (support/mage), AoE thì chọn target tốt nhất toàn bộ
    const bias = ctx?.phase === "late" ? 0.88 : 0.68
    if (back.length > 0 && Math.random() < bias) return pickBestTarget(back, attacker, ctx)
    return pickBestTarget(front.length > 0 ? front : back, attacker, ctx)
  }

  if (role === "marksman") {
    // Marksman: early đánh frontline, mid/late linh hoạt hơn
    const frontBias = ctx?.phase === "early" ? 0.75 : 0.48
    if (front.length > 0 && Math.random() < frontBias) return pickBestTarget(front, attacker, ctx)
    return pickBestTarget(back.length > 0 ? back : front, attacker, ctx)
  }

  if (role === "warrior") {
    // Warrior: bám frontline, nhưng winning thì push backline
    const pushBack = ctx?.momentum === "winning" && back.length > 0 && Math.random() < 0.35
    if (pushBack) return pickBestTarget(back, attacker, ctx)
    return pickBestTarget(front.length > 0 ? front : back, attacker, ctx)
  }

  // Default
  const goFront = Math.random() < 0.60
  if (goFront && front.length > 0) return pickBestTarget(front, attacker, ctx)
  return pickBestTarget(back.length > 0 ? back : front, attacker, ctx)
}

// ── Skill scoring ────────────────────────────────────────────────────────
// Chấm điểm từng skill theo toàn bộ ngữ cảnh chiến trường

function scoreSkillUsage(
  skill: BattleUnit["skills"][number],
  skillIndex: number,
  unit: BattleUnit,
  ctx: BattleContext,
): number {
  let score = 0

  // Skill mạnh hơn (index cao hơn) được ưu tiên nhẹ
  score += skillIndex * 12

  // Ultimate: bonus nếu đã đủ energy, nhưng không bù lấp sai timing
  if (skill.ultimate) score += 40

  // Parse tất cả effect của skill
  let hasHeal = false, hasDmg = false, hasDebuff = false, hasAtkBuff = false
  let hasDefBuff = false, hasShield = false, hasDot = false, hasStun = false
  let hasRegen = false, hasSpdBuff = false, hasSpdDebuff = false, hasEnergyHeal = false

  for (const e of skill.effects) {
    if (e.heal) hasHeal = true
    if (e.damage) hasDmg = true
    if (e.status) {
      const k = e.status.kind
      if (k === "atkUp")   hasAtkBuff = true
      if (k === "spdUp")   { hasAtkBuff = true; hasSpdBuff = true }
      if (k === "defUp")   hasDefBuff = true
      if (k === "shield")  hasShield = true
      if (k === "atkDown" || k === "defDown") hasDebuff = true
      if (k === "spdDown") { hasDebuff = true; hasSpdDebuff = true }
      if (k === "burn" || k === "poison" || k === "bleed") hasDot = true
      if (k === "stun")    hasStun = true
      if (k === "regen")   hasRegen = true
    }
    if ((e as any).energy && ((e as any).energy > 0)) hasEnergyHeal = true
  }

  const {
    aliveAllies, aliveEnemies, lowestAllyPct, lowestAlly, killThreat,
    teamCarry, phase, panicMode, burstWindow, momentum,
    enemyCarry, enemyHealerAlive, allyHasWarFire, enemyBuffCount,
    allyDebuffCount, stunedEnemyCount, nextToActEnemy,
  } = ctx

  // ════════════════════════════════════════════════════════
  // HEAL LOGIC — Thông minh hơn, tránh lãng phí
  // ════════════════════════════════════════════════════════
  if (hasHeal && !hasDmg) {
    // WarFire nặng: heal giảm nhiều → tiết kiệm heal, đánh địch thay
    const warFireUnit = aliveAllies.find(a => a.statuses.some(s => s.kind === "warFire" && s.value > 0.4))
    if (warFireUnit && !panicMode) {
      score -= 30  // heal không hiệu quả, làm gì khác tốt hơn
    }

    if (skill.targeting === "all-allies") {
      const hurtCount = aliveAllies.filter(a => a.hp / a.hpMax < 0.72).length
      const critCount = aliveAllies.filter(a => a.hp / a.hpMax < 0.38).length
      if (hurtCount === 0) return -Infinity
      score += hurtCount * 20 + critCount * 30
      if (panicMode)    score += 45
      if (killThreat)   score += 25  // bạn sắp chết → AoE heal hữu ích
    } else {
      // Single target heal — đừng xài khi không cần
      if (!lowestAlly || lowestAllyPct >= 0.80) return -Infinity
      if (lowestAllyPct < 0.20)      score += 95  // sắp chết → khẩn cấp
      else if (lowestAllyPct < 0.35) score += 70
      else if (lowestAllyPct < 0.55) score += 40
      else if (lowestAllyPct < 0.70) score += 15
      else return -Infinity

      // Ưu tiên heal carry
      if (teamCarry && lowestAlly.uid === teamCarry.uid) score += 35
      // Ưu tiên heal unit sắp bị kill
      if (killThreat && lowestAlly.uid === killThreat.uid) score += 40
    }

    // Không có ai cần heal nghiêm trọng → giữ cooldown
    if (lowestAllyPct > 0.75 && !panicMode && !killThreat) return -Infinity
  }

  // ════════════════════════════════════════════════════════
  // REGEN — Kém ưu tiên hơn instant heal
  // ════════════════════════════════════════════════════════
  if (hasRegen && !hasDmg && !hasHeal) {
    const needsRegen = aliveAllies.some(a => a.hp / a.hpMax < 0.70)
    score += needsRegen ? 15 : -20
    if (panicMode) score += 20
  }

  // ════════════════════════════════════════════════════════
  // DAMAGE SKILLS — Tính theo ngữ cảnh chiến trường
  // ════════════════════════════════════════════════════════
  if (hasDmg) {
    if (aliveEnemies.length === 0) return -Infinity

    // AoE: value tuyến tính với số địch còn sống
    if (skill.targeting === "all-enemies") {
      if (aliveEnemies.length === 1) score -= 35  // lãng phí AoE 1 mục tiêu
      else score += (aliveEnemies.length - 1) * 14

      // Late game ít địch: ưu tiên single target
      if (phase === "late" && aliveEnemies.length <= 2) score -= 25

      // Nhiều địch đang bị stun: AoE là lý tưởng
      if (stunedEnemyCount >= 2) score += 20
    }

    // DoT: hiệu quả vs tank và địch HP đầy; vô dụng vs sắp chết
    if (hasDot) {
      const tankyCount = aliveEnemies.filter(e => e.role === "tank" || e.hp / e.hpMax > 0.75).length
      const nearDeadCount = aliveEnemies.filter(e => e.hp / e.hpMax < 0.22).length
      score += tankyCount * 12
      score -= nearDeadCount * 10  // DoT lên unit sắp chết = lãng phí
      // Nếu địch có healer: DoT rất có giá trị (healer phải xài resource để cure)
      if (enemyHealerAlive) score += 15
    }

    // Stun: cực kỳ quý giá trong nhiều tình huống
    if (hasStun) {
      const dangerCount = aliveEnemies.filter(e =>
        ["assassin","mage","support"].includes(e.role)
      ).length
      score += dangerCount * 20

      // Stun địch sắp đến lượt → cực kỳ có giá trị
      if (nextToActEnemy && nextToActEnemy.role !== "tank") {
        const isPowerful = ["assassin","mage","support","marksman"].includes(nextToActEnemy.role)
        score += isPowerful ? 40 : 20
      }

      if (ctx.allyAdvantage < 0) score += 30  // outnumbered → stun = survive
      if (panicMode)              score += 25
      if (phase === "late")       score += 20  // late game: stun = win condition
    }

    // Debuff: giảm sức mạnh địch, ưu tiên khi địch mạnh
    if (hasDebuff) {
      score += 18
      // Debuff địch mạnh hơn ta nhiều
      const bruiser = aliveEnemies.find(e =>
        (e.stats.atk ?? 0) > (unit.stats.def ?? 0) * 1.5 ||
        (e.stats.mag ?? 0) > (unit.stats.def ?? 0) * 1.5
      )
      if (bruiser) score += 28
      // Địch đang có nhiều buff → debuff để counter
      if (enemyBuffCount >= 3) score += 20
      // Debuff carry địch → rất hiệu quả
      if (enemyCarry) score += 18
      // Speed debuff khi địch nhanh hơn ta nhiều
      if (hasSpdDebuff) {
        const fastEnemy = aliveEnemies.some(e => (e.stats.spd ?? 0) > (unit.stats.spd ?? 0) * 1.3)
        if (fastEnemy) score += 15
      }
    }

    // Burst window: dồn hỏa lực tối đa khi địch đang yếu
    if (burstWindow) score += 25

    // Winning momentum: tấn công hung hãn hơn
    if (momentum === "winning") score += 10

    // Cooldown conservation: không xài skill mạnh vào mục tiêu sắp chết tự nhiên
    if (aliveEnemies.length === 1 && aliveEnemies[0].hp / aliveEnemies[0].hpMax < 0.18) {
      if (skill.targeting === "all-enemies") score -= 45
      if (skill.ultimate) score -= 25  // giữ ult cho trận tiếp
    }
  }

  // ════════════════════════════════════════════════════════
  // SHIELD SKILLS — Dựa vào áp lực chiến trường
  // ════════════════════════════════════════════════════════
  if (hasShield && !hasDmg) {
    const teamHurtCount = aliveAllies.filter(a => a.hp / a.hpMax < 0.60).length
    if (teamHurtCount === 0 && !panicMode && !killThreat) {
      score -= 30  // đừng lãng phí shield khi team đang ngon
    } else {
      score += teamHurtCount * 15
      if (panicMode)  score += 40
      if (killThreat) score += 35  // bạn sắp chết → shield = sống sót
      // Shield carry khi đang bị đe dọa
      if (teamCarry && teamCarry.hp / teamCarry.hpMax < 0.65) score += 30
    }

    // Sắp có địch nguy hiểm đến lượt → shield phòng thủ
    if (nextToActEnemy && ["assassin","mage","marksman"].includes(nextToActEnemy.role)) {
      score += 20
    }
  }

  // ════════════════════════════════════════════════════════
  // ATK / SPD BUFF — Timing là tất cả
  // ════════════════════════════════════════════════════════
  if (hasAtkBuff && !hasHeal && !hasDmg) {
    // Buff sớm → nhiều lượt còn lại để tận dụng
    score += phase === "early" ? 35 : phase === "mid" ? 22 : 8

    // Buff carry trước → nhân bội hiệu quả
    if (teamCarry) {
      const carryAlreadyBuffed = teamCarry.statuses.some(s => s.kind === "atkUp" || s.kind === "spdUp")
      score += carryAlreadyBuffed ? 3 : 35
    }

    // Đừng buff khi địch gần chết (buff lãng phí)
    const enemiesStillDangerous = aliveEnemies.some(e => e.hp / e.hpMax > 0.45)
    if (!enemiesStillDangerous) score -= 25

    // Speed buff khi ta chậm hơn địch
    if (hasSpdBuff) {
      const slowTeam = aliveAllies.some(a => aliveEnemies.some(e => (e.stats.spd ?? 0) > (a.stats.spd ?? 0) * 1.25))
      if (slowTeam) score += 20
    }

    // Losing → buff urgency tăng lên
    if (momentum === "losing") score += 15
  }

  // ════════════════════════════════════════════════════════
  // DEF BUFF — Phòng thủ theo tình huống
  // ════════════════════════════════════════════════════════
  if (hasDefBuff && !hasHeal && !hasDmg) {
    const pressured = aliveAllies.some(a => a.hp / a.hpMax < 0.60)
    const manyDebuffs = allyDebuffCount >= 3
    if (pressured || panicMode || manyDebuffs) score += 28
    else score += 5

    // Địch có carry đang bốc lửa → def buff khẩn cấp
    if (enemyCarry) {
      const carryDangerous = enemyCarry.statuses.some(s => s.kind === "atkUp" || s.kind === "spdUp")
      if (carryDangerous) score += 20
    }
  }

  // ════════════════════════════════════════════════════════
  // ENERGY HEAL (cooldown reduction / energy restore)
  // ════════════════════════════════════════════════════════
  if (hasEnergyHeal && !hasDmg) {
    // Hữu ích nhất khi carry cần ultimate gấp
    if (teamCarry) {
      const carryEnergyPct = teamCarry.energy / teamCarry.energyMax
      if (carryEnergyPct < 0.60) score += 25
      else if (carryEnergyPct < 0.85) score += 10
    }
  }

  // ════════════════════════════════════════════════════════
  // CARRY PROTECTION — Tập trung bảo vệ carry
  // ════════════════════════════════════════════════════════
  if (teamCarry && teamCarry.uid !== unit.uid) {
    const carryHpPct = teamCarry.hp / teamCarry.hpMax
    const isAllySkill = skill.targeting === "ally" || skill.targeting === "all-allies"

    if (isAllySkill || (!hasDmg && (hasHeal || hasShield || hasAtkBuff || hasDefBuff))) {
      let bonus = 0

      if (hasHeal) {
        if (carryHpPct < 0.30)      bonus += 85
        else if (carryHpPct < 0.55) bonus += 55
        else if (carryHpPct < 0.78) bonus += 22
      }
      if (hasShield)   bonus += carryHpPct < 0.55 ? 60 : carryHpPct < 0.80 ? 28 : 8
      if (hasAtkBuff) {
        const alreadyBuffed = teamCarry.statuses.some(s => s.kind === "atkUp")
        bonus += alreadyBuffed ? 5 : 42
      }
      if (hasDefBuff) bonus += carryHpPct < 0.60 ? 25 : 10

      // Protectors (tank/support) dành toàn bộ cho carry
      if (isProtectorRole(unit.role)) bonus = Math.round(bonus * 1.6)

      // Carry sắp bị kill → emergency priority
      if (killThreat && teamCarry.uid === killThreat.uid) bonus += 50

      score += bonus
    }
  }

  // ════════════════════════════════════════════════════════
  // PHASE-BASED & SITUATIONAL MODIFIERS
  // ════════════════════════════════════════════════════════
  if (phase === "early") {
    if (hasAtkBuff || hasDefBuff || hasDebuff) score += 12  // setup phase
  }
  if (phase === "late") {
    if (hasStun)                              score += 18  // stun = win
    if (hasDmg && !hasAtkBuff)               score += 12  // dứt điểm
    if (hasHeal && !hasDmg && killThreat)     score += 20  // bạn sắp chết
  }
  if (panicMode) {
    if (hasHeal || hasShield || hasDefBuff)   score += 35
    if (hasStun)                              score += 30  // mua thời gian
  }
  if (momentum === "winning" && hasDmg) {
    score += 10  // khi thắng thế → đánh hung hãn kết thúc nhanh
  }
  if (momentum === "losing") {
    if (hasStun || hasDebuff) score += 15  // khi thua thế → cần CC để lật ngược
    if (hasHeal)              score += 10
  }

  return score
}

// ── Resolve best ally target ─────────────────────────────────────────────

function resolveAllyTarget(
  skill: BattleUnit["skills"][number],
  unit: BattleUnit,
  ctx: BattleContext,
): string | null {
  const { teamCarry, lowestAlly, aliveAllies, killThreat } = ctx
  let hasHeal = false, hasShield = false, hasAtkBuff = false, hasRegen = false

  for (const e of skill.effects) {
    if (e.heal) hasHeal = true
    if (e.status?.kind === "shield") hasShield = true
    if (e.status?.kind === "atkUp" || e.status?.kind === "spdUp") hasAtkBuff = true
    if (e.status?.kind === "regen") hasRegen = true
  }

  // Emergency: unit sắp chết → heal / shield gấp
  if (killThreat && (hasHeal || hasShield)) return killThreat.uid

  // Carry protection: protector ưu tiên carry
  if (teamCarry && teamCarry.uid !== unit.uid && isProtectorRole(unit.role)) {
    const carryHpPct = teamCarry.hp / teamCarry.hpMax
    if (hasHeal   && carryHpPct < 0.85) return teamCarry.uid
    if (hasShield && carryHpPct < 0.78) return teamCarry.uid
    if (hasAtkBuff && !teamCarry.statuses.some(s => s.kind === "atkUp")) return teamCarry.uid
  }

  // ATK buff: ưu tiên unit có damage cao nhất chưa được buff
  if (hasAtkBuff && !hasHeal) {
    if (teamCarry && !teamCarry.statuses.some(s => s.kind === "atkUp")) return teamCarry.uid
    const unbuffedDps = aliveAllies
      .filter(a => a.uid !== unit.uid && !a.statuses.some(s => s.kind === "atkUp"))
      .sort((a, b) =>
        Math.max(b.stats.atk ?? 0, b.stats.mag ?? 0) -
        Math.max(a.stats.atk ?? 0, a.stats.mag ?? 0)
      )
    if (unbuffedDps.length > 0) return unbuffedDps[0].uid
  }

  // Regen: unit có HP thấp nhất
  if (hasRegen) return lowestAlly?.uid ?? null

  // Default: most injured
  return lowestAlly?.uid ?? null
}

/**
 * Kiểm tra intercept khi người chơi tấn công hàng sau kẻ địch.
 */
export function resolvePlayerTarget(
  targetUid: string,
  attackerRole: BattleUnit["role"],
  units: BattleUnit[],
): string {
  if (attackerRole === "assassin" || attackerRole === "support") return targetUid

  const target = units.find(u => u.uid === targetUid)
  if (!target) return targetUid

  const tauntingUnits = units.filter(
    u => u.hp > 0 && u.side === target.side && u.uid !== targetUid &&
    u.statuses.some(s => s.kind === "taunt" && s.turns > 0)
  )
  if (tauntingUnits.length > 0 && Math.random() < 0.80) {
    return tauntingUnits[Math.floor(Math.random() * tauntingUnits.length)].uid
  }

  if (target.row === "front") return targetUid

  if (Math.random() < 0.28) {
    const frontUnits = units.filter(u => u.hp > 0 && u.side === target.side && u.row === "front")
    if (frontUnits.length > 0) {
      return frontUnits[Math.floor(Math.random() * frontUnits.length)].uid
    }
  }
  return targetUid
}

// ── AI Row-change Logic ─────────────────────────────────────────────────
/**
 * Quyết định AI có nên đổi hàng trong lượt này không.
 * Trả về "advance" (tiến lên hàng trước), "retreat" (lùi về hàng sau), hoặc null (giữ nguyên).
 *
 * Nguyên tắc:
 *  LÙIÌ (front → back):
 *   - Tank/Warrior HP < 25% VÀ có đồng đội hàng sau sẵn sàng thế chỗ → lùi để hồi sinh
 *   - Mage/Support đang đứng hàng trước VÀ địch có assassin sống → lùi về sau ngay
 *   - Unit bị burn/poison/bleed nặng (> 3 stack) ở hàng trước VÀ có healer đồng đội → lùi để healer cứu
 *   - Momentum thua nặng (panicMode) + unit là carry → lùi để bảo toàn
 *
 *  TIẾN (back → front):
 *   - Hàng trước chỉ còn 1 unit sống VÀ unit hiện tại là tank/warrior (HP > 50%) → tiến lên đỡ đòn
 *   - Momentum đang thắng lớn (burstWindow) + unit là assassin/warrior → tiến lên áp đảo
 *   - Healer hàng sau còn đủ HP nhưng carry hàng trước đang nguy hiểm → giữ nguyên (healer không tiến)
 *   - Unit đã nghỉ ngơi (isResting) và HP > 70% → kết thúc nghỉ, tiến lên trận
 */
function aiDecideRowChange(
  state: CombatState,
  unit: BattleUnit,
  ctx: BattleContext,
): "advance" | "retreat" | null {
  const { aliveAllies, aliveEnemies, panicMode, burstWindow, momentum, killThreat } = ctx
  const hpPct = unit.hp / unit.hpMax

  const frontAllies = aliveAllies.filter(u => u.row === "front")
  const backAllies  = aliveAllies.filter(u => u.row === "back")

  const enemyHasAssassin = aliveEnemies.some(u => u.role === "assassin")
  const enemyFront = aliveEnemies.filter(u => u.row === "front")

  // Cooldown on row changes to prevent flip-flopping (tracked via isResting flag as proxy)
  // We use a simple rule: don't change row if unit changed row recently
  // (isResting is set when melee retreats — use it as a gate)

  // ── RETREAT LOGIC ──────────────────────────────────────────────────────
  if (unit.row === "front") {
    // 1. Squishies (mage/support/marksman) at front when assassin exists → retreat immediately
    if (
      (unit.role === "mage" || unit.role === "support" || unit.role === "marksman") &&
      enemyHasAssassin &&
      backAllies.length > 0
    ) {
      return "retreat"
    }

    // 2. Tank/warrior critically low HP, someone in back can take over → retreat to recover
    if (
      (unit.role === "tank" || unit.role === "warrior") &&
      hpPct < 0.22 &&
      frontAllies.filter(u => u.uid !== unit.uid).length >= 1 // at least 1 other frontliner stays
    ) {
      return "retreat"
    }

    // 3. Any unit with multiple DoTs and very low HP, back has support → retreat for healing
    const dotCount = unit.statuses.filter(s =>
      s.kind === "burn" || s.kind === "poison" || s.kind === "bleed"
    ).length
    const allyHasHealer = aliveAllies.some(u => u.uid !== unit.uid && u.role === "support")
    if (dotCount >= 2 && hpPct < 0.30 && allyHasHealer && backAllies.length > 0) {
      return "retreat"
    }

    // 4. Panic mode: protect the team carry — if this IS the carry and front is a slaughterhouse
    const isCarry = ctx.teamCarry?.uid === unit.uid
    if (
      panicMode &&
      isCarry &&
      (unit.role === "mage" || unit.role === "assassin" || unit.role === "marksman") &&
      frontAllies.filter(u => u.uid !== unit.uid).length >= 1
    ) {
      return "retreat"
    }

    // 5. Healer at front when enemy front is dangerous → retreat to heal from safety
    if (
      unit.role === "support" &&
      enemyFront.length >= 2 &&
      hpPct < 0.50
    ) {
      return "retreat"
    }
  }

  // ── ADVANCE LOGIC ──────────────────────────────────────────────────────
  if (unit.row === "back") {
    // 1. Resting unit has recovered (HP > 70%) → rejoin the front
    if (unit.isResting && hpPct > 0.70) {
      return "advance"
    }

    // 2. Front line is thin (only 1 alive) and unit is a frontliner → advance to reinforce
    if (
      frontAllies.length <= 1 &&
      (unit.role === "tank" || unit.role === "warrior") &&
      hpPct > 0.45 &&
      !unit.isResting
    ) {
      return "advance"
    }

    // 3. Burst window — assassin in back joins to overwhelm weakened enemy front
    if (
      burstWindow &&
      unit.role === "assassin" &&
      hpPct > 0.55 &&
      !unit.isResting
    ) {
      return "advance"
    }

    // 4. Winning momentum + warrior has high HP → push pressure
    if (
      momentum === "winning" &&
      unit.role === "warrior" &&
      hpPct > 0.65 &&
      frontAllies.length >= 1 && // don't leave back empty
      !unit.isResting
    ) {
      return "advance"
    }
  }

  return null
}

/**
 * Performs a row change for an AI-controlled unit (enemy or watch-mode player).
 * Similar to performRowChange but works for any side.
 */
export function performAIRowChange(state: CombatState, unit: BattleUnit): void {
  const aliveAllies = state.units.filter(u => u.hp > 0 && u.side === unit.side)
  const frontAllies = aliveAllies.filter(u => u.row === "front")
  const backAllies  = aliveAllies.filter(u => u.row === "back")

  if (unit.row === "back") {
    // Advance
    unit.row = "front"
    unit.isResting = false
    state.log.push({
      id: uid(),
      text: `⬆ ${unit.name} tiến lên hàng trước!`,
      kind: "info",
      casterUid: unit.uid,
    })
  } else {
    // Retreat
    const willFrontBeEmpty = frontAllies.filter(u => u.uid !== unit.uid).length === 0
    if (willFrontBeEmpty) {
      const replacement = backAllies[0]
      if (!replacement) return // can't retreat, no one to take over
      replacement.row = "front"
      replacement.isResting = false
      state.log.push({
        id: uid(),
        text: `⬆ ${replacement.name} tiến lên hàng trước thế chỗ ${unit.name}!`,
        kind: "info",
        casterUid: replacement.uid,
      })
    }
    unit.row = "back"
    const isMelee = unit.range === "melee"
    if (isMelee) {
      unit.isResting = true
      state.log.push({
        id: uid(),
        text: `⬇ ${unit.name} lui về hàng sau — nghỉ ngơi hồi HP.`,
        kind: "info",
        casterUid: unit.uid,
      })
    } else {
      unit.isResting = false
      state.log.push({
        id: uid(),
        text: `⬇ ${unit.name} lui về hàng sau.`,
        kind: "info",
        casterUid: unit.uid,
      })
    }
  }
}

/**
 * STRATEGIC AI v4 — Situational Intelligence
 * Mỗi lượt AI xây dựng BattleContext đầy đủ → chọn skill/target tối ưu.
 */
export function aiChooseAction(state: CombatState, unit: BattleUnit): AIAction {
  const oppSide: BattleSide = unit.side === "player" ? "enemy" : "player"
  const ctx = buildBattleContext(state, unit)
  const { aliveEnemies, enemyCarry } = ctx

  if (aliveEnemies.length === 0) return { kind: "basic", targetUid: "" }

  // ── Row-change decision (AI v5: tactical positioning) ───────────────────
  // Only consider row change if unit is not stunned/frozen
  const isIncapacitated = unit.statuses.some(s => s.kind === "stun" || s.kind === "freeze")
  if (!isIncapacitated) {
    const rowDecision = aiDecideRowChange(state, unit, ctx)
    if (rowDecision !== null) {
      // Add some randomness so AI doesn't robotically change row every turn
      // Retreat is urgent → 85% chance to execute; Advance is optional → 65%
      const threshold = rowDecision === "retreat" ? 0.85 : 0.65
      if (Math.random() < threshold) {
        return { kind: "rowChange" }
      }
    }
  }

  const targetEnemy = pickRowTarget(state.units, unit, oppSide, ctx)
  if (!targetEnemy) return { kind: "basic", targetUid: "" }

  // ── Chọn skill tốt nhất theo ngữ cảnh ──────────────────────────────────
  let bestSkillIndex: 0 | 1 | 2 | null = null
  let bestSkillScore = -Infinity

  for (let i = 0; i < unit.skills.length; i++) {
    const skill = unit.skills[i]
    if (!skill || unit.cooldowns[i] > 0) continue
    if (skill.ultimate && unit.energy < ULTIMATE_ENERGY_COST) continue

    const score = scoreSkillUsage(skill, i, unit, ctx)
    if (score > bestSkillScore) { bestSkillScore = score; bestSkillIndex = i as 0 | 1 | 2 }
  }

  if (bestSkillIndex !== null && bestSkillScore > 0) {
    const skill = unit.skills[bestSkillIndex]!
    let targetUid: string | null = null

    if (skill.targeting === "ally") {
      targetUid = resolveAllyTarget(skill, unit, ctx)

    } else if (skill.targeting === "all-allies") {
      targetUid = null

    } else if (skill.targeting === "enemy") {
      // Control/debuff skill → ưu tiên target carry địch hoặc target nguy hiểm nhất
      const hasControl = skill.effects.some(e =>
        e.status && ["atkDown","defDown","spdDown","stun","poison","burn","bleed"].includes(e.status.kind)
      )
      const hasHeavyStun = skill.effects.some(e => e.status?.kind === "stun")

      if (hasHeavyStun && ctx.nextToActEnemy) {
        // Stun địch sắp đến lượt → timing hoàn hảo
        const nextInPool = aliveEnemies.find(e => e.uid === ctx.nextToActEnemy?.uid)
        targetUid = nextInPool?.uid ?? pickBestTarget(aliveEnemies, unit, ctx)?.uid ?? targetEnemy.uid
      } else if (hasControl && enemyCarry) {
        // Debuff carry địch
        targetUid = enemyCarry.uid
      } else {
        targetUid = pickBestTarget(aliveEnemies, unit, ctx)?.uid ?? targetEnemy.uid
      }

    } else if (skill.targeting === "all-enemies") {
      targetUid = null

    } else if (skill.targeting === "self") {
      targetUid = unit.uid

    } else {
      targetUid = targetEnemy.uid
    }

    return { kind: "skill", skillIndex: bestSkillIndex, targetUid }
  }

  // ── Fallback: basic attack vào target nguy hiểm nhất ────────────────────
  return {
    kind: "basic",
    targetUid: pickBestTarget(aliveEnemies, unit, ctx)?.uid ?? targetEnemy.uid,
  }
}


// ============================================================
// Combo check (skill tree)
// ============================================================

export function canCombineSkills(
  skillId: string,
  knownSkills: Set<string>,
): boolean {
  const skill = SKILLS[skillId]
  if (!skill) return false
  if (!skill.comboRequires?.length) return true
  return skill.comboRequires.every((r) => knownSkills.has(r))
}

export { uid as _uid }

// ============================================================
// PvP Combat — build a combat state where enemy = opponent's team
// ============================================================
export function buildPvpCombatState(
  myState: GameState,
  opponentHeroes: OwnedHero[],
  opponentStats: GameState["playerStats"]
): CombatState {
  // Player side: current user's team
  const playerSlots = myState.team
    .map((id, idx) => ({ id, idx }))
    .filter((s): s is { id: string; idx: number } => !!s.id)

  const playerOwned: OwnedHero[] = playerSlots
    .map(s => myState.heroes.find(h => h.uid === s.id))
    .filter((h): h is OwnedHero => !!h)

  const playerRows = playerSlots.map((s, i) => {
    const rows = myState.teamRows ?? []
    return (rows[s.idx] ?? (playerOwned[i] && HEROES_BY_ID[playerOwned[i].templateId]?.range === "melee" ? "front" : "back")) as BattleRow
  })

  const playerTpls = playerOwned.map(h => HEROES_BY_ID[h.templateId])
  const playerSyn = computeSynergies(playerTpls)

  const playerBonuses: Partial<Stats> = {
    atk: myState.playerStats.attackBonus,
    mag: myState.playerStats.magicBonus,
    def: myState.playerStats.defenseBonus,
    hp: myState.playerStats.hpBonus,
    spd: myState.playerStats.speedBonus,
    crit: myState.playerStats.critBonus,
  }

  const playerUnits = playerOwned
    .map((o, i) => ({ ...ownedToUnit(o, "player", playerBonuses), row: playerRows[i] }))
    .map(u => applySynergyToUnit(u, playerSyn))

  // Enemy side: opponent's team with their playerStats bonuses
  const opTeam = opponentHeroes.filter((_, i) => i < 6)
  const opTpls = opTeam.map(h => HEROES_BY_ID[h.templateId])
  const opSyn = computeSynergies(opTpls)

  const opBonuses: Partial<Stats> = {
    atk: opponentStats.attackBonus,
    mag: opponentStats.magicBonus,
    def: opponentStats.defenseBonus,
    hp: opponentStats.hpBonus,
    spd: opponentStats.speedBonus,
    crit: opponentStats.critBonus,
  }

  const enemyUnits = opTeam
    .map(o => {
      const tpl = HEROES_BY_ID[o.templateId]
      const autoRow: BattleRow = tpl?.range === "melee" ? "front" : "back"
      return { ...ownedToUnit(o, "enemy", opBonuses), row: autoRow }
    })
    .map(u => applySynergyToUnit(u, opSyn))

  // Start-of-battle effects
  for (const u of [...playerUnits, ...enemyUnits]) {
    applyStartOfBattleEffects(u)
  }
  applyCrossTeamStartEffects(playerUnits, enemyUnits, playerSyn, opSyn)

  const all = [...playerUnits, ...enemyUnits]
  const order = computeTurnOrder(all)

  const initialLog: CombatLogEntry[] = [
    { id: uid(), text: "⚔️ PvP bắt đầu! Đây là trận chiến danh dự!", kind: "system" },
  ]

  applyAncientCdr(playerUnits, playerSyn, initialLog)
  applyAncientCdr(enemyUnits, opSyn, initialLog)

  const firstInOrder = all.find(u => u.uid === order[0])
  const cs: CombatState = {
    stage: 0, // PvP has no stage
    turn: 0,
    units: all,
    order,
    activeUnitIndex: 0,
    round: 1,
    log: initialLog,
    ended: null,
    awaitingPlayerInput: firstInOrder?.side === "player",
    watchMode: false,
    watchSpeed: 1,
    potionLastUsedRound: -99,
    isPvp: true,
    // FIX: was hardcoded to "player1" with a comment "will be overridden" — the setTimeout override
    // was a race condition. Now the store passes role explicitly via START_PVP_COMBAT action.
    pvpMyRole: "player1",
    reserveUnits: [], // PvP has no reserve
    enemyReserveUnits: [],
  }

  for (const u of playerUnits) {
    fireHook("onBattleStart", cs, u)
  }

  return cs
}
