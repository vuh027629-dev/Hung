/**
 * ORDER INNATES v3 — Cơ Chế Độc Đáo
 *
 * Không chỉ cộng chỉ số — mỗi tướng có một cơ chế thực sự khác biệt:
 * • Giảm cooldown đồng đội
 * • Chia sẻ / chuyển đổi năng lượng
 * • Đổi HP lấy năng lượng
 * • Tái sinh theo formation
 * • Khiêu chiến chiến thuật
 * • Reset kỹ năng
 * • Chuyển khiên
 * • Tích lũy theo vị trí
 */
import type { OrderInnate } from "./types"

export const ORDER_INNATES: Record<string, OrderInnate> = {

  // ══ COMMON ══════════════════════════════════════════════════════════════════

  // Borin — đứng đầu hàng trước, làm "điểm neo" để hàng sau tái sinh
  "oi_h_borin": {
    id: "oi_h_borin", name: "Neo Trận Tiên Phong",
    description: "Khi Borin đứng ở slot đầu từ trái và hàng trước, toàn bộ đồng đội hàng sau được tái sinh 4% HP mỗi lượt trong 3 lượt — Borin đang chịu đòn thay để đồng đội phục hồi.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromLeft", n: 1 },
      { type: "inRow", row: "front" },
    ]},
    effect: { kind: "regenOnRow", pct: 4, turns: 3, target: "backRow" },
  },

  // Lyrra — đứng hàng sau, giảm cooldown cho warrior kề trái
  "oi_h_lyrra": {
    id: "oi_h_lyrra", name: "Nhịp Bắn Đồng Điệu",
    description: "Nếu Lyrra đứng hàng sau và đồng đội [warrior] đứng ngay bên trái, warrior đó được giảm toàn bộ cooldown 1 lượt — nhịp bắn yểm trợ của Lyrra rút ngắn thời gian chuẩn bị.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "inRow", row: "back" },
      { type: "leftIs", trait: "warrior", side: "ally" },
    ]},
    effect: { kind: "reduceCooldown", amount: 1, target: "leftNeighbor" },
  },

  // Grom — beastkin trong vòng 2 slot, tự chuyển HP → NL (bản năng chiến đấu)
  "oi_h_grom": {
    id: "oi_h_grom", name: "Bản Năng Dã Chiến",
    description: "Nếu có đồng đội [beastkin] trong vòng 2 slot, Grom hi sinh 8% HP để nạp thêm 30 năng lượng — cơn cuồng nộ bộ lạc biến đau thương thành sức mạnh.",
    when: "turnStart",
    condition: { type: "withinDistance", distance: 2, trait: "beastkin", side: "ally" },
    effect: { kind: "hpToEnergy", hpPct: 0.08, energyAmt: 30, target: "self" },
  },

  // Mirelle — vị trí 2 từ trái, chia sẻ NL cho đồng đội bên phải
  "oi_h_mirelle": {
    id: "oi_h_mirelle", name: "Kênh Dẫn Phép",
    description: "Nếu Mirelle đứng ở vị trí thứ 2 từ trái, cô truyền 20 năng lượng sang đồng đội bên phải — Mirelle là cầu nối, không phải nguồn gốc sức mạnh.",
    when: "turnStart",
    condition: { type: "fromLeft", n: 2 },
    effect: { kind: "shareEnergy", amount: 20, target: "rightNeighbor" },
  },

  // Otto — đứng đầu hàng trước, khiêu chiến để bảo vệ đồng đội
  "oi_h_otto": {
    id: "oi_h_otto", name: "Thân Đỡ Thay",
    description: "Khi Otto đứng ở slot đầu từ trái và hàng trước, ông tự khiêu chiến thu hút địch tấn công vào mình trong 2 lượt — vị thế tiên phong đồng nghĩa với việc nhận đòn thay.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromLeft", n: 1 },
      { type: "inRow", row: "front" },
    ]},
    effect: { kind: "tauntSelf", turns: 2, target: "self" },
  },

  // ══ RARE ════════════════════════════════════════════════════════════════════

  // Zara — assassin kề, chuyển khiên của mình sang assassin đó
  "oi_h_zara": {
    id: "oi_h_zara", name: "Lá Chắn Bóng Tối",
    description: "Nếu có đồng đội [assassin] cách đúng 1 slot và Zara đang có khiên, Zara chuyển 80% khiên còn lại của mình sang assassin đó — hy sinh phòng thủ để đồng đội tấn công an toàn.",
    when: "turnStart",
    condition: { type: "exactDistance", distance: 1, trait: "assassin", side: "ally" },
    effect: { kind: "transferShield", pct: 0.8, target: "triggerUnit" },
  },

  // Thalas — trước elemental địch, reset kỹ năng đầu tiên của bản thân
  "oi_h_thalas": {
    id: "oi_h_thalas", name: "Đọc Trước Nguyên Tố",
    description: "Khi Thalas hành động ngay trước một địch [elemental] trong lượt, kỹ năng đầu tiên của Thalas hết cooldown ngay lập tức — đọc trước cơ thể địch để phản ứng kịp thời.",
    when: "turnStart",
    condition: { type: "beforeTrait", trait: "elemental", side: "enemy" },
    effect: { kind: "resetSkill", slot: 0, target: "self" },
  },

  // Ravi — warrior kề phải, trao 25 NL cho warrior đó
  "oi_h_ravi": {
    id: "oi_h_ravi", name: "Tiếp Sức Đồng Loại",
    description: "Nếu đồng đội [warrior] đứng ngay bên phải Ravi, Ravi truyền 25 năng lượng sang đồng đội đó — chiến binh gầm thét truyền lửa cho người kề vai.",
    when: "turnStart",
    condition: { type: "rightIs", trait: "warrior", side: "ally" },
    effect: { kind: "shareEnergy", amount: 25, target: "rightNeighbor" },
  },

  // Ember — sau outlaw đồng đội, tự đổi HP → NL (liều lĩnh)
  "oi_h_ember": {
    id: "oi_h_ember", name: "Máu Liều Lĩnh",
    description: "Sau khi một đồng đội [outlaw] hành động ngay trước trong lượt, Ember hi sinh 10% HP để nạp thêm 35 năng lượng — đồng bọn vừa đi, anh ta đốt máu mình để ra đòn ngay.",
    when: "turnStart",
    condition: { type: "afterTrait", trait: "outlaw", side: "ally" },
    effect: { kind: "hpToEnergy", hpPct: 0.10, energyAmt: 35, target: "self" },
  },

  // Priestess — cuối phải, tái sinh mỗi đồng đội tỉ lệ với số đồng đội cùng hàng
  "oi_h_priestess": {
    id: "oi_h_priestess", name: "Phúc Lành Tập Thể",
    description: "Nếu Priestess đứng cuối bên phải, mỗi đồng đội nhận tái sinh 2% HP mỗi lượt nhân với số lượng đồng đội cùng hàng — đội càng đông, phép chữa càng mạnh.",
    when: "turnStart",
    condition: { type: "fromRight", n: 1 },
    effect: { kind: "stackRegen", pctPerAlly: 2, turns: 2, target: "allAllies" },
  },

  // Vesper — hàng sau + phantom ≤2 slot, tích NL thụ động (phantom truyền khí)
  "oi_h_vesper": {
    id: "oi_h_vesper", name: "Hơi Thở Bóng Ma",
    description: "Nếu Vesper đứng hàng sau và có đồng đội [phantom] trong vòng 2 slot, Vesper tích lũy 20 năng lượng mỗi đầu lượt mà không cần tấn công — phantom truyền linh khí.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "inRow", row: "back" },
      { type: "withinDistance", distance: 2, trait: "phantom", side: "ally" },
    ]},
    effect: { kind: "echoEnergy", amount: 20, target: "self" },
  },

  // Morbus — trước tank địch, giảm CD toàn bộ kỹ năng của bản thân
  "oi_h_morbus": {
    id: "oi_h_morbus", name: "Bào Tử Thâm Nhập",
    description: "Khi Morbus hành động ngay trước một địch [tank] trong lượt, toàn bộ kỹ năng của Morbus được giảm 1 lượt cooldown — bào tử bệnh đã cài sẵn, chỉ chờ kẽ hở của giáp.",
    when: "turnStart",
    condition: { type: "beforeRole", role: "tank", side: "enemy" },
    effect: { kind: "reduceCooldown", amount: 1, target: "self" },
  },

  // Florenwalker — thứ 2 từ phải + hàng trước, tái sinh toàn hàng trước theo số lượng
  "oi_h_florenwalker": {
    id: "oi_h_florenwalker", name: "Dấu Chân Hộ Vệ",
    description: "Nếu Floren đứng thứ 2 từ phải ở hàng trước, hàng trước nhận tái sinh 3% HP mỗi lượt nhân với số đồng đội hàng trước — mỗi bước chân của lãng khách để lại dấu phép chữa lành.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromRight", n: 2 },
      { type: "inRow", row: "front" },
    ]},
    effect: { kind: "stackRegen", pctPerAlly: 3, turns: 2, target: "frontRow" },
  },

  // Deckhand Rax — sau pirate, giảm CD đồng đội ngay sau mình trong order
  "oi_h_deckhand_rax": {
    id: "oi_h_deckhand_rax", name: "Hiệu Lệnh Boong Tàu",
    description: "Sau khi một đồng đội [pirate] hành động ngay trước trong lượt, Rax giảm 1 CD toàn kỹ năng của mình — thấy đồng đội xuất chiêu, Rax lập tức sẵn sàng.",
    when: "turnStart",
    condition: { type: "afterTrait", trait: "pirate", side: "ally" },
    effect: { kind: "reduceCooldown", amount: 1, target: "self" },
  },

  // Ironside Belle — hàng sau + pirate cách đúng 1 slot, chuyển NL sang pirate đó
  "oi_h_ironside_belle": {
    id: "oi_h_ironside_belle", name: "Tiếp Đạn Hải Tặc",
    description: "Nếu Belle đứng hàng sau và có đồng đội [pirate] cách đúng 1 slot, Belle truyền 25 năng lượng sang pirate đó — người hậu cần tiếp sức cho người xung trận.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "inRow", row: "back" },
      { type: "exactDistance", distance: 1, trait: "pirate", side: "ally" },
    ]},
    effect: { kind: "shareEnergy", amount: 25, target: "triggerUnit" },
  },

  // Coralwarden — cuối phải + hàng sau, tái sinh toàn đội theo số đồng đội sống
  "oi_h_coralwarden": {
    id: "oi_h_coralwarden", name: "Vòng San Hô Sinh Lực",
    description: "Nếu Coral Warden đứng cuối bên phải hàng sau, toàn đội nhận tái sinh 2% HP mỗi lượt nhân với số đồng đội còn sống — vòng san hô càng nguyên vẹn, phép càng mạnh.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromRight", n: 1 },
      { type: "inRow", row: "back" },
    ]},
    effect: { kind: "stackRegen", pctPerAlly: 2, turns: 2, target: "allAllies" },
  },

  // Tideblade — trước merfolk địch, reset kỹ năng đầu của bản thân
  "oi_h_tideblade": {
    id: "oi_h_tideblade", name: "Đọc Thủy Triều",
    description: "Khi Tideblade hành động ngay trước một địch [merfolk] trong lượt, kỹ năng đầu tiên của Tideblade hết cooldown — đọc được dòng chảy của địch, ra đòn không cần chuẩn bị.",
    when: "turnStart",
    condition: { type: "beforeTrait", trait: "merfolk", side: "enemy" },
    effect: { kind: "resetSkill", slot: 0, target: "self" },
  },

  // Deckguard Ferro — slot 1 trái + hàng trước, khiêu chiến bảo vệ toàn hàng trước
  "oi_h_deckguard_ferro": {
    id: "oi_h_deckguard_ferro", name: "Chắn Tàu Tiên Phong",
    description: "Nếu Ferro đứng đầu hàng trước (slot 1 từ trái), Ferro tự khiêu chiến thu hút địch trong 2 lượt — lá chắn sống bảo vệ cả hàng trước.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromLeft", n: 1 },
      { type: "inRow", row: "front" },
    ]},
    effect: { kind: "tauntSelf", turns: 2, target: "self" },
  },

  // Rifleman Cross — trước marksman địch, giảm CD kỹ năng đầu bản thân
  "oi_h_rifleman_cross": {
    id: "oi_h_rifleman_cross", name: "Nạp Đạn Phản Xạ",
    description: "Khi Cross hành động ngay trước một địch [marksman] trong lượt, kỹ năng đầu tiên của Cross hết cooldown ngay — đối thủ cùng nghề khiến tay súng phản xạ nạp đạn nhanh hơn.",
    when: "turnStart",
    condition: { type: "beforeRole", role: "marksman", side: "enemy" },
    effect: { kind: "resetSkill", slot: 0, target: "self" },
  },

  // Rotweaver — trước plague địch, đổi HP → NL (nghi lễ hiến tế)
  "oi_h_rotweaver": {
    id: "oi_h_rotweaver", name: "Nghi Lễ Hiến Tế",
    description: "Khi Rotweaver hành động ngay trước một địch [plague] trong lượt, hi sinh 12% HP để nạp ngay 45 năng lượng — máu dệt lưới, xương làm thoi.",
    when: "turnStart",
    condition: { type: "beforeTrait", trait: "plague", side: "enemy" },
    effect: { kind: "hpToEnergy", hpPct: 0.12, energyAmt: 45, target: "self" },
  },

  // ══ EPIC ════════════════════════════════════════════════════════════════════

  // Kael — bị kẹp bởi elemental, giảm CD toàn bộ kỹ năng của bản thân 2 lượt
  "oi_h_kael": {
    id: "oi_h_kael", name: "Vòng Xuyến Nguyên Tố",
    description: "Nếu Kael bị kẹp giữa hai đồng đội [elemental], toàn bộ cooldown của Kael giảm 2 lượt — năng lượng nguyên tố từ hai bên hội tụ, làm sạch mọi kháng cự trong cơ thể.",
    when: "turnStart",
    condition: { type: "flankedBy", trait: "elemental", side: "ally" },
    effect: { kind: "reduceCooldown", amount: 2, target: "self" },
  },

  // Nyx — cuối phải + trước mage địch, chuyển toàn bộ NL của bản thân sang đồng đội khác để dùng ult
  "oi_h_nyx": {
    id: "oi_h_nyx", name: "Bóng Tối Tiếp Lửa",
    description: "Nếu Nyx đứng cuối bên phải và hành động ngay trước một địch [mage], Nyx truyền 40 năng lượng sang đồng đội hàng sau gần nhất — hi sinh cơ hội của mình để đồng đội tung ult.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromRight", n: 1 },
      { type: "beforeRole", role: "mage", side: "enemy" },
    ]},
    effect: { kind: "shareEnergy", amount: 40, target: "sameRow" },
  },

  // Ozric — slot giữa (2–3), tái sinh toàn hàng sau theo số đồng đội hàng sau
  "oi_h_ozric": {
    id: "oi_h_ozric", name: "Trục Phép Trung Tâm",
    description: "Nếu Ozric đứng ở slot 2–3, hàng sau nhận tái sinh 3% HP mỗi lượt nhân với số đồng đội hàng sau — đứng giữa đội, Ozric dẫn luồng phép đến hậu tuyến.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "slotGte", slot: 2 },
      { type: "slotLte", slot: 3 },
    ]},
    effect: { kind: "stackRegen", pctPerAlly: 3, turns: 2, target: "backRow" },
  },

  // Vex — hàng sau + thứ 2 từ phải, giảm CD toàn kỹ năng cho đồng đội hàng sau
  "oi_h_vex": {
    id: "oi_h_vex", name: "Giao Thức Ưu Tiên",
    description: "Nếu Vex đứng hàng sau ở vị trí thứ 2 từ phải, hệ thống của Vex giảm 1 lượt cooldown cho toàn bộ đồng đội hàng sau — dữ liệu chiến trường được xử lý, mọi người hành động nhanh hơn.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "inRow", row: "back" },
      { type: "fromRight", n: 2 },
    ]},
    effect: { kind: "reduceCooldown", amount: 1, target: "backRow" },
  },

  // Morgath — slot 1 trái + hàng trước ≥3, khiêu chiến + chuyển khiên của mình cho đồng đội hàng sau
  "oi_h_morgath": {
    id: "oi_h_morgath", name: "Vua Đứng Trước",
    description: "Nếu Morgath đứng đầu hàng trước và hàng trước có ≥3 đồng đội, Morgath khiêu chiến trong 2 lượt và chuyển 60% khiên của mình cho đồng đội hàng sau gần nhất — vua chịu đòn thay, quân được bảo vệ.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromLeft", n: 1 },
      { type: "allyCountInRow", row: "front", count: 3, op: ">=" },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "tauntSelf", turns: 2 },
      { kind: "transferShield", pct: 0.6 },
    ], target: "self" },
  },

  // Zephyr — sau storm đồng đội, đổi HP → NL (cuồng phong khai mở)
  "oi_h_zephyr": {
    id: "oi_h_zephyr", name: "Cuồng Phong Khai Mở",
    description: "Sau khi một đồng đội [storm] hành động ngay trước trong lượt, Zephyr hi sinh 10% HP để nạp 40 năng lượng — gió bão thổi vào, máu sôi lên thành sức mạnh.",
    when: "turnStart",
    condition: { type: "afterTrait", trait: "storm", side: "ally" },
    effect: { kind: "hpToEnergy", hpPct: 0.10, energyAmt: 40, target: "self" },
  },

  // Lynx — phantom kề trái, chuyển toàn bộ NL của phantom đó sang bản thân
  "oi_h_lynx": {
    id: "oi_h_lynx", name: "Hút Linh Bóng Ma",
    description: "Nếu đồng đội [phantom] đứng ngay bên trái Lynx, Lynx hút 30 năng lượng từ phantom đó về cho mình — bóng ma tự nguyện nhường khí để móng vuốt ra đòn.",
    when: "turnStart",
    condition: { type: "leftIs", trait: "phantom", side: "ally" },
    effect: { kind: "shareEnergy", amount: 30, target: "self" },
  },

  // Scalebreaker — trước tank địch, giảm 2 CD toàn bộ kỹ năng bản thân
  "oi_h_scalebreaker": {
    id: "oi_h_scalebreaker", name: "Phân Tích Điểm Yếu",
    description: "Khi Scalebreaker hành động ngay trước một địch [tank] trong lượt, toàn bộ kỹ năng của hắn giảm 2 lượt cooldown — mọi vảy giáp đều có kẽ hở, chỉ cần nhìn đúng lúc.",
    when: "turnStart",
    condition: { type: "beforeRole", role: "tank", side: "enemy" },
    effect: { kind: "reduceCooldown", amount: 2, target: "self" },
  },

  // Carrier — có undead cách đúng 2 slot, tái sinh cả hàng của bản thân
  "oi_h_carrier": {
    id: "oi_h_carrier", name: "Ký Sinh Sinh Tồn",
    description: "Nếu có đồng đội [undead] cách đúng 2 slot, Carrier kích hoạt tái sinh 4% HP mỗi lượt cho toàn bộ đồng đội cùng hàng trong 2 lượt — ký sinh trùng lan ra từ xác sống, nuôi dưỡng người sống.",
    when: "turnStart",
    condition: { type: "exactDistance", distance: 2, trait: "undead", side: "ally" },
    effect: { kind: "regenOnRow", pct: 4, turns: 2, target: "sameRow" },
  },

  // Thornmaw — hàng trước + địch ≥2 hàng trước, khiêu chiến thu địch về mình
  "oi_h_thornmaw": {
    id: "oi_h_thornmaw", name: "Bẫy Gai Hút Thù",
    description: "Nếu Thornmaw đứng hàng trước và địch có ≥2 tướng ở hàng trước, Thornmaw khiêu chiến trong 2 lượt — gai nhọn từ tứ phía, địch không nhịn được mà lao vào.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "inRow", row: "front" },
      { type: "enemyCountInRow", row: "front", count: 2, op: ">=" },
    ]},
    effect: { kind: "tauntSelf", turns: 2, target: "self" },
  },

  // Abyssalwitch — sau undead đồng đội, hút 25 NL từ đồng đội hàng sau gần nhất
  "oi_h_abyssalwitch": {
    id: "oi_h_abyssalwitch", name: "Vực Thẳm Hấp Thụ",
    description: "Sau khi một đồng đội [undead] hành động ngay trước trong lượt, Abyssal Witch hút 25 năng lượng từ đồng đội hàng sau gần nhất — phù thủy vực thẳm ăn năng lượng của người chết sống.",
    when: "turnStart",
    condition: { type: "afterTrait", trait: "undead", side: "ally" },
    effect: { kind: "shareEnergy", amount: 25, target: "self" },
  },

  // Tideguard — slot 1 trái + hàng trước ≥2, khiêu chiến + tái sinh hàng trước
  "oi_h_tideguard": {
    id: "oi_h_tideguard", name: "Triều Dâng Hộ Vệ",
    description: "Nếu Tideguard đứng đầu hàng trước và hàng trước có ≥2 đồng đội, Tideguard khiêu chiến 2 lượt và kích hoạt tái sinh 3% HP cho toàn hàng trước — triều dâng vừa thu địch, vừa hồi phục đồng đội.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromLeft", n: 1 },
      { type: "inRow", row: "front" },
      { type: "allyCountInRow", row: "front", count: 2, op: ">=" },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "tauntSelf", turns: 2 },
      { kind: "regenOnRow", pct: 3, turns: 2 },
    ], target: "self" },
  },

  // Navigator Voss — slot 3 từ trái, giảm CD toàn bộ đồng đội
  "oi_h_navigator_voss": {
    id: "oi_h_navigator_voss", name: "Sơ Đồ Tác Chiến",
    description: "Nếu Voss đứng ở vị trí thứ 3 từ trái, toàn bộ đồng đội được giảm 1 lượt cooldown — người điều phối đứng đúng vị trí, mọi người hành động theo kế hoạch.",
    when: "turnStart",
    condition: { type: "fromLeft", n: 3 },
    effect: { kind: "reduceCooldown", amount: 1, target: "allAllies" },
  },

  // Redrogue — kẹp bởi outlaw + hàng trước, đổi HP → NL cực mạnh
  "oi_h_redrogue": {
    id: "oi_h_redrogue", name: "Máu Cướp Biển",
    description: "Nếu Redrogue bị kẹp giữa hai đồng đội [outlaw] và đứng hàng trước, hi sinh 15% HP để nạp 55 năng lượng — ba tên cướp biển sát cạnh nhau, máu sôi lên không thể kìm.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "flankedBy", trait: "outlaw", side: "ally" },
      { type: "inRow", row: "front" },
    ]},
    effect: { kind: "hpToEnergy", hpPct: 0.15, energyAmt: 55, target: "self" },
  },

  // Shipsurgeon — cuối phải + hàng sau + trước support địch, reset kỹ năng 2 của bản thân
  "oi_h_shipsurgeon": {
    id: "oi_h_shipsurgeon", name: "Mổ Xẻ Kế Hoạch",
    description: "Nếu Shipsurgeon đứng cuối hàng sau và hành động ngay trước địch [support], kỹ năng thứ 2 của Shipsurgeon hết cooldown ngay — nhìn thấy kẻ chữa lành sắp ra tay, bác sĩ chiến trường phản ứng trước.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromRight", n: 1 },
      { type: "inRow", row: "back" },
      { type: "beforeRole", role: "support", side: "enemy" },
    ]},
    effect: { kind: "resetSkill", slot: 1, target: "self" },
  },

  // Commodore Steel — sau navy đồng đội, chuyển khiên của bản thân sang đồng đội đó
  "oi_h_commodore_steel": {
    id: "oi_h_commodore_steel", name: "Giáp Thưởng Công Trận",
    description: "Sau khi một đồng đội [navy] hành động ngay trước trong lượt, Steel chuyển 70% khiên còn lại của mình sang đồng đội đó — chỉ huy thưởng giáp cho người vừa xuất trận.",
    when: "turnStart",
    condition: { type: "afterTrait", trait: "navy", side: "ally" },
    effect: { kind: "transferShield", pct: 0.7, target: "triggerUnit" },
  },

  // Ghostcode — hàng sau + cyber ≤1 slot, giảm CD toàn bộ đồng đội hàng sau
  "oi_h_ghostcode": {
    id: "oi_h_ghostcode", name: "Patch Tốc Độ",
    description: "Nếu Ghostcode đứng hàng sau và có đồng đội [cyber] trong vòng 1 slot, toàn bộ đồng đội hàng sau được giảm 1 lượt cooldown — bản vá lỗi được push ngay, hệ thống phục hồi nhanh.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "inRow", row: "back" },
      { type: "withinDistance", distance: 1, trait: "cyber", side: "ally" },
    ]},
    effect: { kind: "reduceCooldown", amount: 1, target: "backRow" },
  },

  // ══ LEGENDARY ═══════════════════════════════════════════════════════════════

  // Seraphine — cuối phải + hàng sau, tái sinh toàn đội theo số đồng đội sống
  "oi_h_seraphine": {
    id: "oi_h_seraphine", name: "Hào Quang Bất Tử",
    description: "Nếu Seraphine đứng cuối bên phải hàng sau, toàn đội nhận tái sinh 3% HP mỗi lượt nhân với số đồng đội còn sống — ánh sáng mạnh nhất khi đoàn kết nguyên vẹn.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromRight", n: 1 },
      { type: "inRow", row: "back" },
    ]},
    effect: { kind: "stackRegen", pctPerAlly: 3, turns: 2, target: "allAllies" },
  },

  // Drakthar — sau dragon đồng đội, reset kỹ năng thứ 2 của bản thân
  "oi_h_drakthar": {
    id: "oi_h_drakthar", name: "Thừa Kế Lửa Rồng",
    description: "Sau khi một đồng đội [dragon] hành động ngay trước trong lượt, kỹ năng thứ 2 của Drakthar hết cooldown ngay — lửa rồng vừa cháy, Drakthar hấp thụ tàn lửa để xuất kỹ năng liền tay.",
    when: "turnStart",
    condition: { type: "afterTrait", trait: "dragon", side: "ally" },
    effect: { kind: "resetSkill", slot: 1, target: "self" },
  },

  // Velka — trước demon địch, đổi HP → NL (tế thần địa ngục)
  "oi_h_velka": {
    id: "oi_h_velka", name: "Tế Thần Địa Ngục",
    description: "Khi Velka hành động ngay trước một địch [demon] trong lượt, hi sinh 15% HP để nạp ngay 50 năng lượng — dâng máu để mời gọi ngọn lửa địa ngục thực sự.",
    when: "turnStart",
    condition: { type: "beforeTrait", trait: "demon", side: "enemy" },
    effect: { kind: "hpToEnergy", hpPct: 0.15, energyAmt: 50, target: "self" },
  },

  // Silvanir — cuối phải + hàng sau, giảm CD toàn bộ đồng đội hàng sau
  "oi_h_silvanir": {
    id: "oi_h_silvanir", name: "Ánh Sáng Dẫn Đường",
    description: "Nếu Silvanir đứng cuối bên phải hàng sau, toàn bộ đồng đội hàng sau được giảm 1 lượt cooldown — ánh sáng từ đỉnh cây chiếu xuống, soi đường cho mọi hành động.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromRight", n: 1 },
      { type: "inRow", row: "back" },
    ]},
    effect: { kind: "reduceCooldown", amount: 1, target: "backRow" },
  },

  // Kazumi — hàng trước + trước tank địch, chuyển 100% NL của bản thân → bản thân rồi đổi HP
  "oi_h_kazumi": {
    id: "oi_h_kazumi", name: "Đòn Trảm Quyết",
    description: "Khi Kazumi đứng hàng trước và hành động ngay trước một địch [tank] trong lượt, Kazumi hi sinh 12% HP để nạp 40 năng lượng và reset kỹ năng đầu — một cơ hội duy nhất để xuyên giáp.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "inRow", row: "front" },
      { type: "beforeRole", role: "tank", side: "enemy" },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "hpToEnergy", hpPct: 0.12, energyAmt: 40 },
      { kind: "resetSkill", slot: 0 },
    ], target: "self" },
  },

  // Pestis — slot 1 trái + hàng trước + địch ≥2 hàng trước, khiêu chiến + tái sinh hàng trước
  "oi_h_pestis": {
    id: "oi_h_pestis", name: "Lá Chắn Dịch Bệnh",
    description: "Nếu Pestis đứng đầu hàng trước và địch có ≥2 tướng hàng trước, Pestis khiêu chiến 2 lượt đồng thời kích hoạt tái sinh 3% HP cho toàn hàng trước — ai chạm vào ta thì bệnh, nhưng ta đứng đây không lay chuyển.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromLeft", n: 1 },
      { type: "inRow", row: "front" },
      { type: "enemyCountInRow", row: "front", count: 2, op: ">=" },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "tauntSelf", turns: 2 },
      { kind: "regenOnRow", pct: 3, turns: 2 },
    ], target: "self" },
  },

  // Raijin — storm ≤1 + elemental ≤2, đổi HP → NL rất mạnh
  "oi_h_raijin": {
    id: "oi_h_raijin", name: "Sét Huyết",
    description: "Nếu Raijin có đồng đội [storm] trong vòng 1 slot và đồng đội [elemental] trong vòng 2 slot, Raijin hi sinh 10% HP để nạp 50 năng lượng — điện sét chạy qua máu, đau đớn là giá của sức mạnh.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "withinDistance", distance: 1, trait: "storm", side: "ally" },
      { type: "withinDistance", distance: 2, trait: "elemental", side: "ally" },
    ]},
    effect: { kind: "hpToEnergy", hpPct: 0.10, energyAmt: 50, target: "self" },
  },

  // Wyrmcaller — sau dragon + hàng sau, giảm CD toàn kỹ năng của bản thân
  "oi_h_wyrmcaller": {
    id: "oi_h_wyrmcaller", name: "Lời Triệu Rồng",
    description: "Sau khi đồng đội [dragon] hành động ngay trước và Wyrmcaller đứng hàng sau, toàn bộ kỹ năng của Wyrmcaller giảm 2 lượt cooldown — rồng vừa cất tiếng, người gọi rồng lập tức cộng hưởng.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "afterTrait", trait: "dragon", side: "ally" },
      { type: "inRow", row: "back" },
    ]},
    effect: { kind: "reduceCooldown", amount: 2, target: "self" },
  },

  // Ghostcaptain — slot 3 trái + phantom ≤2, truyền NL cho phantom kề nhất
  "oi_h_ghostcaptain": {
    id: "oi_h_ghostcaptain", name: "Lệnh Thuyền Ma",
    description: "Nếu Ghost Captain đứng ở slot thứ 3 từ trái và có đồng đội [phantom] trong vòng 2 slot, truyền 35 năng lượng sang phantom đó — hạm trưởng ma ra lệnh, bóng ma thi hành.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromLeft", n: 3 },
      { type: "withinDistance", distance: 2, trait: "phantom", side: "ally" },
    ]},
    effect: { kind: "shareEnergy", amount: 35, target: "triggerUnit" },
  },

  // Wraithblade — phantom kề trái + undead kề phải, cả hai giảm 1 CD
  "oi_h_wraithblade": {
    id: "oi_h_wraithblade", name: "Lưỡi Nối Hai Cõi",
    description: "Nếu đồng đội [phantom] kề bên trái và đồng đội [undead] kề bên phải, cả hai đồng đội đó đều được giảm 1 lượt cooldown — Wraithblade đứng giữa ranh giới sống và chết, truyền năng lượng cho cả hai.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "leftIs", trait: "phantom", side: "ally" },
      { type: "rightIs", trait: "undead", side: "ally" },
    ]},
    effect: { kind: "reduceCooldown", amount: 1, target: "sameRow" },
  },

  // Tempestrix — sau storm + hàng sau + slot ≥3, đổi HP → NL mạnh
  "oi_h_tempestrix": {
    id: "oi_h_tempestrix", name: "Bão Huyết Tích Tụ",
    description: "Sau khi đồng đội [storm] hành động ngay trước và Tempestrix đứng hàng sau từ slot thứ 3 trở đi, hi sinh 12% HP để nạp 55 năng lượng — bão từ ngoài tràn vào, biến máu thành điện.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "afterTrait", trait: "storm", side: "ally" },
      { type: "inRow", row: "back" },
      { type: "slotGte", slot: 2 },
    ]},
    effect: { kind: "hpToEnergy", hpPct: 0.12, energyAmt: 55, target: "self" },
  },

  // Deepstrike — cuối phải + hàng trước, khiêu chiến + đổi HP → NL (lao vào từ vực sâu)
  "oi_h_deepstrike": {
    id: "oi_h_deepstrike", name: "Lao Từ Vực Sâu",
    description: "Nếu Deepstrike đứng cuối bên phải hàng trước, khiêu chiến trong 1 lượt và hi sinh 10% HP để nạp 35 năng lượng — đến từ vực thẳm, không sợ đau, chỉ cần đòn chí mạng.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromRight", n: 1 },
      { type: "inRow", row: "front" },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "tauntSelf", turns: 1 },
      { kind: "hpToEnergy", hpPct: 0.10, energyAmt: 35 },
    ], target: "self" },
  },

  // Dreadnought Kira — slot 1 trái + hàng trước + navy ≤2, khiêu chiến + tái sinh hàng trước
  "oi_h_dreadnought_kira": {
    id: "oi_h_dreadnought_kira", name: "Thiết Giáp Bất Phá",
    description: "Nếu Kira đứng đầu hàng trước và có đồng đội [navy] trong vòng 2 slot, Kira khiêu chiến 2 lượt và kích hoạt tái sinh 4% HP cho toàn hàng trước — thiết giáp hạm đứng đầu, hải quân hồi máu đằng sau.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromLeft", n: 1 },
      { type: "inRow", row: "front" },
      { type: "withinDistance", distance: 2, trait: "navy", side: "ally" },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "tauntSelf", turns: 2 },
      { kind: "regenOnRow", pct: 4, turns: 2 },
    ], target: "self" },
  },

  // ══ MYTHIC ══════════════════════════════════════════════════════════════════

  // Zerathus — kẹp bởi demon, giảm 2 CD toàn bộ kỹ năng + đổi HP → NL
  "oi_h_zerathus": {
    id: "oi_h_zerathus", name: "Khế Ước Máu Hủy Diệt",
    description: "Nếu Zerathus bị kẹp giữa hai đồng đội [demon], hi sinh 12% HP để nạp 45 năng lượng và giảm 2 lượt CD toàn bộ kỹ năng — hiệp ước với quỷ không phải không có giá.",
    when: "turnStart",
    condition: { type: "flankedBy", trait: "demon", side: "ally" },
    effect: { kind: "multi", effects: [
      { kind: "hpToEnergy", hpPct: 0.12, energyAmt: 45 },
      { kind: "reduceCooldown", amount: 2 },
    ], target: "self" },
  },

  // Orin — slot 1 trái + hàng trước + warrior kề phải, trao toàn bộ khiên cho warrior đó
  "oi_h_orin": {
    id: "oi_h_orin", name: "Khiên Thần Trao Tay",
    description: "Nếu Orin đứng đầu hàng trước và đồng đội [warrior] đứng ngay bên phải, Orin chuyển 100% khiên của mình sang warrior đó — người mang khiên thần không giữ cho mình, trao cho kẻ cần nhất.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromLeft", n: 1 },
      { type: "inRow", row: "front" },
      { type: "rightIs", trait: "warrior", side: "ally" },
    ]},
    effect: { kind: "transferShield", pct: 1.0, target: "rightNeighbor" },
  },

  // Xara — cuối phải + phantom cách đúng 2, hút 40 NL từ phantom đó
  "oi_h_xara": {
    id: "oi_h_xara", name: "Ký Ức Linh Hồn",
    description: "Nếu Xara đứng cuối bên phải và có đồng đội [phantom] cách đúng 2 slot, Xara hút 40 năng lượng từ phantom đó — linh hồn cách 2 bước chân vẫn có thể truyền ký ức và sức mạnh.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromRight", n: 1 },
      { type: "exactDistance", distance: 2, trait: "phantom", side: "ally" },
    ]},
    effect: { kind: "shareEnergy", amount: 40, target: "self" },
  },

  // Tianlong — slot 1 trái + dragon ≤2, giảm CD toàn đội + khiêu chiến
  "oi_h_tianlong": {
    id: "oi_h_tianlong", name: "Rồng Đứng Che Đầu",
    description: "Nếu Tianlong đứng đầu đội và có đồng đội [dragon] trong vòng 2 slot, Tianlong khiêu chiến 2 lượt và giảm 1 CD toàn bộ kỹ năng của toàn đội — rồng đứng trước, cả đoàn được chuẩn bị.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromLeft", n: 1 },
      { type: "withinDistance", distance: 2, trait: "dragon", side: "ally" },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "tauntSelf", turns: 2 },
      { kind: "reduceCooldown", amount: 1 },
    ], target: "self" },
  },

  // Riven — sau mage + hàng sau + slot ≥3, reset kỹ năng 2 + đổi HP → NL
  "oi_h_riven": {
    id: "oi_h_riven", name: "Cắt Đứt Giới Hạn",
    description: "Sau khi đồng đội [mage] hành động ngay trước và Riven đứng hàng sau từ slot thứ 3 trở đi, hi sinh 10% HP để nạp 40 năng lượng và reset kỹ năng thứ 2 — thấy đồng đội tung phép, Riven phá vỡ giới hạn của bản thân.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "afterRole", role: "mage", side: "ally" },
      { type: "inRow", row: "back" },
      { type: "slotGte", slot: 2 },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "hpToEnergy", hpPct: 0.10, energyAmt: 40 },
      { kind: "resetSkill", slot: 1 },
    ], target: "self" },
  },

  // Spectra — kẹp bởi phantom + hàng sau, truyền 30 NL cho cả hai phantom kề
  "oi_h_spectra": {
    id: "oi_h_spectra", name: "Khuếch Đại Ma Trận",
    description: "Nếu Spectra bị kẹp giữa hai đồng đội [phantom] và đứng hàng sau, Spectra truyền 30 năng lượng cho mỗi phantom kề bên — đứng giữa hai bóng ma, Spectra trở thành nguồn khuếch đại.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "flankedBy", trait: "phantom", side: "ally" },
      { type: "inRow", row: "back" },
    ]},
    effect: { kind: "shareEnergy", amount: 30, target: "sameRow" },
  },

  // Typhon — thứ 2 từ phải + hàng sau + storm ≤1, giảm CD toàn đội hàng sau + đổi HP → NL
  "oi_h_typhon": {
    id: "oi_h_typhon", name: "Tâm Bão Hy Sinh",
    description: "Nếu Typhon đứng ở vị trí thứ 2 từ phải hàng sau và có đồng đội [storm] cách 1 slot, hi sinh 10% HP để nạp 45 NL và giảm 1 CD toàn hàng sau — đứng trong tâm bão, hi sinh một phần để nuôi toàn đội.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromRight", n: 2 },
      { type: "inRow", row: "back" },
      { type: "withinDistance", distance: 1, trait: "storm", side: "ally" },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "hpToEnergy", hpPct: 0.10, energyAmt: 45 },
      { kind: "reduceCooldown", amount: 1 },
    ], target: "backRow" },
  },

  // Pirateking Darios — slot 3 trái + pirate ≤2, truyền NL cho mọi pirate xung quanh
  "oi_h_pirateking_darios": {
    id: "oi_h_pirateking_darios", name: "Phân Chia Chiến Lợi",
    description: "Nếu Darios đứng ở slot thứ 3 từ trái và có đồng đội [pirate] trong vòng 2 slot, Darios truyền 25 năng lượng cho tất cả đồng đội đó — hải vương phân chia sức mạnh, không giữ cho riêng mình.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromLeft", n: 3 },
      { type: "withinDistance", distance: 2, trait: "pirate", side: "ally" },
    ]},
    effect: { kind: "shareEnergy", amount: 25, target: "allAllies" },
  },

  // Ksan — slot 1 trái + hàng trước ≥3, khiêu chiến + tái sinh cả hàng trước + chuyển khiên
  "oi_h_ksan": {
    id: "oi_h_ksan", name: "Đứng Mũi Chịu Sào",
    description: "Nếu Ksan đứng đầu hàng trước và hàng trước có đủ 3 đồng đội, Ksan khiêu chiến 3 lượt, kích hoạt tái sinh 4% HP cho toàn hàng trước, và chuyển 70% khiên của mình sang đồng đội bên phải — đứng mũi nhọn, gánh tất cả.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromLeft", n: 1 },
      { type: "inRow", row: "front" },
      { type: "allyCountInRow", row: "front", count: 3, op: ">=" },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "tauntSelf", turns: 3 },
      { kind: "regenOnRow", pct: 4, turns: 3 },
      { kind: "transferShield", pct: 0.7 },
    ], target: "self" },
  },

  // ══ CELESTIAL ═══════════════════════════════════════════════════════════════

  // Aurion — cuối phải + hàng sau + celestial ≤2, tái sinh × đồng đội + giảm CD toàn đội
  "oi_h_aurion": {
    id: "oi_h_aurion", name: "Thánh Ân Toàn Diện",
    description: "Nếu Aurion đứng cuối hàng sau và có đồng đội [celestial] trong vòng 2 slot, toàn đội nhận tái sinh 3% HP nhân số đồng đội sống và giảm 1 lượt cooldown — thiên ân không phân biệt, trao đồng đều cho tất cả.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromRight", n: 1 },
      { type: "inRow", row: "back" },
      { type: "withinDistance", distance: 2, trait: "celestial", side: "ally" },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "stackRegen", pctPerAlly: 3, turns: 2 },
      { kind: "reduceCooldown", amount: 1 },
    ], target: "allAllies" },
  },

  // Morwen — undead kề trái + demon kề phải, hút NL từ cả hai và đổi HP → NL
  "oi_h_morwen": {
    id: "oi_h_morwen", name: "Giữa Hai Thế Giới",
    description: "Nếu đồng đội [undead] kề bên trái và đồng đội [demon] kề bên phải, Morwen hút 25 NL từ mỗi bên và hi sinh 10% HP để nạp thêm 35 NL — đứng giữa tử thần và quỷ dữ, hút kiệt sức mạnh của cả hai.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "leftIs", trait: "undead", side: "ally" },
      { type: "rightIs", trait: "demon", side: "ally" },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "hpToEnergy", hpPct: 0.10, energyAmt: 35 },
      { kind: "shareEnergy", amount: 25 },
    ], target: "self" },
  },

  // Aetherion — sau dragon + slot 1 trái + hàng trước, giảm 2 CD + khiêu chiến
  "oi_h_aetherion": {
    id: "oi_h_aetherion", name: "Cơn Thịnh Nộ Thiên Long",
    description: "Sau khi đồng đội [dragon] hành động ngay trước và Aetherion đứng đầu hàng trước, toàn bộ kỹ năng giảm 2 lượt CD và Aetherion khiêu chiến 2 lượt — rồng cất tiếng, người đứng đầu không thể đứng yên.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "afterTrait", trait: "dragon", side: "ally" },
      { type: "fromLeft", n: 1 },
      { type: "inRow", row: "front" },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "reduceCooldown", amount: 2 },
      { kind: "tauntSelf", turns: 2 },
    ], target: "self" },
  },

  // Calix — cuối phải + hàng sau + ancient ≤2, reset kỹ năng 2 + tích NL thụ động
  "oi_h_calix": {
    id: "oi_h_calix", name: "Mắt Ngắm Vĩnh Cửu",
    description: "Nếu Calix đứng cuối hàng sau và có đồng đội [ancient] trong vòng 2 slot, kỹ năng thứ 2 của Calix hết cooldown và Calix tích lũy thêm 30 năng lượng — đứng ở rìa thời gian, cổ đại trao cho ta cái nhìn vượt giới hạn.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromRight", n: 1 },
      { type: "inRow", row: "back" },
      { type: "withinDistance", distance: 2, trait: "ancient", side: "ally" },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "resetSkill", slot: 1 },
      { kind: "echoEnergy", amount: 30 },
    ], target: "self" },
  },

  // Yggdra — slot 1 trái + kẹp bởi elemental, khiêu chiến + tái sinh toàn đội theo số sống
  "oi_h_yggdra": {
    id: "oi_h_yggdra", name: "Cội Rễ Che Chở",
    description: "Nếu Yggdra đứng đầu đội và bị kẹp giữa hai đồng đội [elemental], Yggdra khiêu chiến 2 lượt và toàn đội nhận tái sinh 3% HP nhân số đồng đội sống — rễ cây thiêng che chở cả khu rừng.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromLeft", n: 1 },
      { type: "flankedBy", trait: "elemental", side: "ally" },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "tauntSelf", turns: 2 },
      { kind: "stackRegen", pctPerAlly: 3, turns: 2 },
    ], target: "allAllies" },
  },

  // Nemesis Plague — cuối phải + hàng sau + undead địch tồn tại, đổi HP → NL rất mạnh
  "oi_h_nemesis_plague": {
    id: "oi_h_nemesis_plague", name: "Thu Hoạch Xác Chết",
    description: "Nếu Nemesis đứng cuối hàng sau và có địch [undead] trên chiến trường, hi sinh 15% HP để nạp 60 năng lượng — thu hoạch sinh lực từ kẻ đã chết, không cần chờ đến lúc chúng ngã.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromRight", n: 1 },
      { type: "inRow", row: "back" },
      { type: "withinDistance", distance: 5, trait: "undead", side: "enemy" },
    ]},
    effect: { kind: "hpToEnergy", hpPct: 0.15, energyAmt: 60, target: "self" },
  },

  // Mirage — phantom kề trái + cuối phải, chuyển khiên phantom → bản thân + reset kỹ năng đầu
  "oi_h_mirage": {
    id: "oi_h_mirage", name: "Đánh Tráo Bóng Tối",
    description: "Nếu đồng đội [phantom] kề bên trái và Mirage đứng cuối bên phải, Mirage lấy 100% khiên của phantom đó về cho mình và reset kỹ năng đầu — bóng tối đánh tráo, người thật biến mất, bóng ma ở lại chịu đòn.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "leftIs", trait: "phantom", side: "ally" },
      { type: "fromRight", n: 1 },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "transferShield", pct: 1.0 },
      { kind: "resetSkill", slot: 0 },
    ], target: "self" },
  },

  // Leviathan Rex — kẹp bởi merfolk + hàng sau, toàn merfolk xung quanh được giảm 2 CD
  "oi_h_leviathan_rex": {
    id: "oi_h_leviathan_rex", name: "Quái Vật Trỗi Dậy",
    description: "Nếu Leviathan Rex bị kẹp bởi hai đồng đội [merfolk] và đứng hàng sau, toàn bộ đồng đội cùng hàng được giảm 2 lượt cooldown — quái vật biển sâu thức dậy, kéo theo cả đại dương.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "flankedBy", trait: "merfolk", side: "ally" },
      { type: "inRow", row: "back" },
    ]},
    effect: { kind: "reduceCooldown", amount: 2, target: "sameRow" },
  },

  // Admiral Vayne — cuối phải + hàng sau + navy ≤2, giảm CD toàn đội + tái sinh theo số đồng đội
  "oi_h_admiral_vayne": {
    id: "oi_h_admiral_vayne", name: "Uy Quyền Hạm Đội",
    description: "Nếu Vayne đứng cuối hàng sau và có đồng đội [navy] trong vòng 2 slot, toàn đội giảm 1 lượt CD toàn kỹ năng và nhận tái sinh 2% HP nhân số đồng đội sống — đô đốc phát lệnh, cả hạm đội hành động đồng bộ.",
    when: "turnStart",
    condition: { type: "and", conditions: [
      { type: "fromRight", n: 1 },
      { type: "inRow", row: "back" },
      { type: "withinDistance", distance: 2, trait: "navy", side: "ally" },
    ]},
    effect: { kind: "multi", effects: [
      { kind: "reduceCooldown", amount: 1 },
      { kind: "stackRegen", pctPerAlly: 2, turns: 2 },
    ], target: "allAllies" },
  },
}

export function getOrderInnateForHero(heroId: string): OrderInnate | undefined {
  return ORDER_INNATES["oi_" + heroId]
}
