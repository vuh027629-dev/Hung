// ============================================================
// PvP Invite Service — Supabase realtime invites
// ============================================================

import { supabase } from "./cloud-save"
import type { OwnedHero, GameState } from "./types"

export type PvpInviteStatus = "pending" | "accepted" | "declined" | "expired"

export interface PvpInvite {
  id: string
  from_user: string
  to_user: string
  from_team: OwnedHero[]
  from_stats: GameState["playerStats"]
  status: PvpInviteStatus
  session_id: string | null  // filled in when accepted
  created_at: string
}

// Send an invite to another player
export async function sendPvpInvite(
  fromUser: string,
  toUser: string,
  team: OwnedHero[],
  playerStats: GameState["playerStats"]
): Promise<{ ok: boolean; id?: string; error?: string }> {
  try {
    await supabase
      .from("pvp_invites")
      .update({ status: "expired" })
      .eq("from_user", fromUser)
      .eq("to_user", toUser)
      .eq("status", "pending")

    const { data, error } = await supabase
      .from("pvp_invites")
      .insert({
        from_user: fromUser,
        to_user: toUser,
        from_team: team,
        from_stats: playerStats,
        status: "pending",
        session_id: null,
      })
      .select("id")
      .single()

    if (error) return { ok: false, error: error.message }
    return { ok: true, id: data.id }
  } catch (err) {
    return { ok: false, error: String(err) }
  }
}

// Accept invite and attach session_id so challenger gets it via realtime
export async function respondPvpInvite(
  inviteId: string,
  status: "accepted" | "declined",
  sessionId?: string
): Promise<{ ok: boolean; error?: string }> {
  try {
    const patch: Record<string, unknown> = { status }
    if (sessionId) patch.session_id = sessionId

    const { error } = await supabase
      .from("pvp_invites")
      .update(patch)
      .eq("id", inviteId)

    if (error) return { ok: false, error: error.message }
    return { ok: true }
  } catch (err) {
    return { ok: false, error: String(err) }
  }
}

// Subscribe to incoming invites for a user (realtime)
export function subscribeToPvpInvites(
  username: string,
  onInvite: (invite: PvpInvite) => void
) {
  const channel = supabase
    .channel(`pvp_invites:${username}`)
    .on(
      "postgres_changes",
      {
        event: "INSERT",
        schema: "public",
        table: "pvp_invites",
        filter: `to_user=eq.${username}`,
      },
      (payload) => onInvite(payload.new as PvpInvite)
    )
    .on(
      "postgres_changes",
      {
        event: "UPDATE",
        schema: "public",
        table: "pvp_invites",
        filter: `from_user=eq.${username}`,
      },
      (payload) => onInvite(payload.new as PvpInvite)
    )
    .subscribe()

  return () => supabase.removeChannel(channel)
}

// Fetch pending invites for a user
export async function fetchPendingInvites(
  username: string
): Promise<PvpInvite[]> {
  const { data } = await supabase
    .from("pvp_invites")
    .select("*")
    .eq("to_user", username)
    .eq("status", "pending")
    .order("created_at", { ascending: false })
    .limit(10)

  return (data as PvpInvite[]) ?? []
}
