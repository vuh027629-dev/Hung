"use client"

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  useRef,
  startTransition,
} from "react"
import { toast } from "sonner"

import {
  buildCombatState,
  buildPvpCombatState,
  checkEnded,
  computeRewards,
  consumePotionInCombat,
  performBasicAttack,
  performSkill,
  processEndOfTurn,
  onUnitTurnStart,
  processOrderInnate,
  aiChooseAction,
  resolvePlayerTarget,
  xpToNextLevel,
  playerXpToNextLevel,
  _uid as uid,
  computeHeroStats,
  effectiveSpd,
  applyWarFire,
  warFireStage,
  WAR_FIRE_START_ROUND,
  generateEnemyTeam,
  performRowChange,
  performAIRowChange,
} from "./combat"
import { HEROES_BY_ID, HEROES_BY_RARITY } from "./heroes"
import { ITEMS_BY_ID, pickRandomShopItems, pickPremiumShopItems, getPremiumTier, SHOP_STOCK_COUNT, generateInnate } from "./items"
import { PASSIVES, SKILLS, SKILL_EVOLUTION_MAP, SKILL_LEVEL_REQUIREMENTS, checkSkillUnlockCondition } from "./skills"
import { DIG_RATES, HERO_GACHA_RATES, HERO_GACHA_RATES_GOLD, RARITY_ORDER, RARITY_LABEL, rarityRank, rollRarity, applyLuckToRates } from "./rarity"
import { SKILL_TREE_BY_ID, canLearnNode, computePlayerStatsFromTree } from "./skill-tree"
import { generateQuestBatch, generateQuestFill, checkObjectiveCompletion, MAX_ACTIVE_QUESTS } from "./quests"
import type { Quest, QuestState } from "./quests"
import {
  ALL_BY_ID as ALL_BLESSINGS_BY_ID,
  BLESSINGS, PACTS,
  rollShardsGems, rollShardsGold,
} from "./blessings"
// fireHook is defined in combat.ts but we need it in store for round hooks
import { _fireHook as fireHook } from "./combat"
import { createPvpSession, pushPvpTurn, subscribePvpSession, type PvpSession } from "./pvp-session"
import type {
  BattleRow,
  CombatState,
  EquipSlot,
  GameState,
  ItemTemplate,
  OwnedHero,
  PremiumShopStock,
  Rarity,
  GameEventId,
  ActiveEvent,
} from "./types"

// ============================================================
// Daily Event System
// ============================================================

export const GAME_EVENTS: Record<GameEventId, { name: string; description: string; icon: string; rarity: "uncommon" | "rare" | "epic" }> = {
  blood_moon: {
    name: "Đêm Trăng Máu",
    icon: "🩸🌕",
    rarity: "uncommon",
    description: "Toàn bộ kẻ địch hôm nay +25% ATK, DEF và HP.",
  },
  war_economy: {
    name: "VẬT GIÁ LEO THANG",
    icon: "💣📈",
    rarity: "uncommon",
    description: "Giá cửa hàng & triệu hồi +25%. Tiền phạt khi thua +25%.",
  },
  black_market: {
    name: "Chợ Đen Xuất Hiện",
    icon: "🕵️‍♂️🏪",
    rarity: "rare",
    description: "Hàng hóa cửa hàng giảm giá 15% hôm nay.",
  },
  golden_rain: {
    name: "Mưa Vàng",
    icon: "🌧️🪙",
    rarity: "uncommon",
    description: "Thưởng vàng từ mọi trận chiến +30% hôm nay.",
  },
  gem_surge: {
    name: "Bão Ngọc",
    icon: "💎⚡",
    rarity: "rare",
    description: "Thưởng đá quý từ mọi trận chiến +30% hôm nay.",
  },
  hero_blessing: {
    name: "Phúc Lành Anh Hùng",
    icon: "✨🦸",
    rarity: "uncommon",
    description: "XP anh hùng nhận được +30% hôm nay.",
  },
  ancient_curse: {
    name: "Lời Nguyền Cổ Đại",
    icon: "💀🔮",
    rarity: "epic",
    description: "Kẻ địch +20% ATK. Đội ta -10% DEF. Thưởng vàng khi thắng +15%.",
  },
  double_drop: {
    name: "Rơi Đôi",
    icon: "📦📦",
    rarity: "rare",
    description: "Vật phẩm drop từ chiến đấu x2 hôm nay.",
  },
  training_day: {
    name: "Ngày Huấn Luyện",
    icon: "🏋️⚔️",
    rarity: "uncommon",
    description: "Chi phí huấn luyện anh hùng giảm 50% hôm nay.",
  },
  celestial_gate: {
    name: "Cổng Thiên Giới Mở",
    icon: "🌌🚪",
    rarity: "epic",
    description: "Tỉ lệ ra Huyền Thoại và Thần Thoại khi triệu hồi +30% hôm nay.",
  },
  merchant_caravan: {
    name: "Đoàn Thương Nhân",
    icon: "🐪🛒",
    rarity: "rare",
    description: "Cửa hàng có thêm hàng hóa và giá giảm 10% hôm nay.",
  },
  cursed_moon: {
    name: "Trăng Nguyền",
    icon: "🌑😈",
    rarity: "uncommon",
    description: "Mỗi trận thua mất thêm 20% vàng. Cẩn thận!",
  },
  bounty_hunt: {
    name: "Săn Tiền Thưởng",
    icon: "🏹💰",
    rarity: "uncommon",
    description: "Mỗi trận thắng +25% vàng thưởng hôm nay.",
  },
  exp_festival: {
    name: "Lễ Hội Kinh Nghiệm",
    icon: "🎉📚",
    rarity: "rare",
    description: "Player XP nhận được +30% hôm nay.",
  },
  storm_of_chaos: {
    name: "Bão Hỗn Mang",
    icon: "🌀💥",
    rarity: "epic",
    description: "Kẻ địch mạnh hơn ngẫu nhiên 10–50%. Thưởng vàng & XP +50% nếu thắng.",
  },
}

// Weight: uncommon=40, rare=20, epic=8
const EVENT_WEIGHTS: Record<GameEventId, number> = {
  blood_moon: 40,
  war_economy: 40,
  golden_rain: 40,
  hero_blessing: 40,
  cursed_moon: 40,
  bounty_hunt: 40,
  training_day: 40,
  black_market: 20,
  gem_surge: 20,
  double_drop: 20,
  merchant_caravan: 20,
  exp_festival: 20,
  ancient_curse: 8,
  celestial_gate: 8,
  storm_of_chaos: 8,
}

// Roll events cho 1 ngày mới
// - 30% cơ bản để có ít nhất 1 event
// - Pity: nếu daysSinceLastEvent >= 4 thì đảm bảo có event, reset drought counter
// - Mỗi event sau có 30% tiếp tục (không trùng)
// - Khi có event: daysSinceLastEvent reset về 0; không có: +1
function rollDailyEvents(dayNumber: number, daysSinceLastEvent: number): ActiveEvent[] {
  const allEventIds = Object.keys(GAME_EVENTS) as GameEventId[]
  const available = [...allEventIds]
  const result: ActiveEvent[] = []

  // Pity: 4 ngày không có event → ngày thứ 5 guaranteed
  const guaranteed = daysSinceLastEvent >= 4
  if (!guaranteed && Math.random() > 0.30) return []

  while (available.length > 0) {
    if (result.length > 0 && Math.random() > 0.30) break

    const totalWeight = available.reduce((sum, id) => sum + EVENT_WEIGHTS[id], 0)
    let rand = Math.random() * totalWeight
    let chosen: GameEventId | null = null
    for (const id of available) {
      rand -= EVENT_WEIGHTS[id]
      if (rand <= 0) { chosen = id; break }
    }
    if (!chosen) chosen = available[available.length - 1]

    result.push({ eventId: chosen, dayRolled: dayNumber })
    available.splice(available.indexOf(chosen), 1)
  }

  return result
}

// Helper: kiểm tra event có active không
export function hasEvent(state: GameState, eventId: GameEventId): boolean {
  return (state.activeEvents ?? []).some(e => e.eventId === eventId)
}

// ── Win Streak & Perfect Streak Bonus ───────────────────────────────────
// Mỗi chuỗi thắng liên tiếp → nhân thưởng vàng tăng dần
// Perfect (thắng không mất quân) → thêm gem thưởng
//
// streak 1-2  → +0%   (chưa có bonus)
// streak 3-4  → +25%  gold  + toast
// streak 5-7  → +50%  gold  + 1 gem
// streak 8-11 → +80%  gold  + 2 gem
// streak 12+  → +120% gold  + 3 gem
// perfect x3+ → +1 gem thêm mỗi 3 streak
// ─────────────────────────────────────────────────────────────────────────
// Số lần được phép farm cùng tầng trước khi mất streak
export const STREAK_MAX_SAME_STAGE = 2

// Điều kiện tính streak: phải thắng tầng MỚI (chưa clear), thử thách thực sự
// Điều kiện phá streak:
//   1. THUA TRẬN → streak reset về 0
//   2. Tầng quá dễ (challengeRatio < 0.75) → reset về 0
//   3. Chơi lại tầng đã clear → reset về 0
//   4. Farm cùng tầng quá nhiều lần (> STREAK_MAX_SAME_STAGE) → reset về 0
//
// Mốc thưởng mới (khó hơn, phần thưởng cao hơn):
//   streak 1-4   → +0%   (đang khởi động)
//   streak 5-7   → +30%  gold
//   streak 8-11  → +60%  gold + 1 gem/trận
//   streak 12-17 → +100% gold + 2 gem/trận
//   streak 18+   → +160% gold + 3 gem/trận
//   perfect x5+ → +1 gem thêm mỗi 5 hoàn hảo

export function streakGoldMultiplier(streak: number): number {
  if (streak < 5)  return 1.00
  if (streak < 8)  return 1.30
  if (streak < 12) return 1.60
  if (streak < 18) return 2.00
  return 2.60
}

export function streakGemBonus(streak: number): number {
  if (streak < 8)  return 0
  if (streak < 12) return 1
  if (streak < 18) return 2
  return 3
}

export function streakLabel(streak: number): string {
  if (streak < 5)  return ""
  if (streak < 8)  return "🔥 Đang nóng"
  if (streak < 12) return "🔥🔥 Bùng cháy"
  if (streak < 18) return "🔥🔥🔥 Không thể cản"
  return "💀 Vô Đối"
}

export function perfectGemBonus(perfectStreak: number): number {
  if (perfectStreak < 5) return 0
  return Math.floor(perfectStreak / 5)
}

// Mô tả lý do streak bị phá — hiển thị trong toast/UI
export type StreakBreakReason =
  | "defeat"    // Thua trận
  | "too_easy"  // Tầng quá dễ so với đội hình
  | "replay"    // Chơi lại tầng đã clear
  | "farming"   // Farm cùng tầng quá nhiều lần

// Helper: price multiplier từ war_economy event
export function getEventPriceMultiplier(state: GameState): number {
  if (hasEvent(state, "black_market")) return 0.85   // -30% giá
  if (hasEvent(state, "merchant_caravan")) return 0.90 // -20% giá
  if (hasEvent(state, "war_economy")) return 1.25    // +25% giá
  return 1.0
}

// Helper: gold reward multiplier
export function getGoldRewardMultiplier(state: GameState): number {
  let mult = 1.0
  if (hasEvent(state, "golden_rain")) mult *= 1.3
  if (hasEvent(state, "bounty_hunt")) mult *= 1.25
  if (hasEvent(state, "storm_of_chaos")) mult *= 1.5
  if (hasEvent(state, "ancient_curse")) mult *= 1.15
  return mult
}

// Helper: gem reward multiplier
export function getGemRewardMultiplier(state: GameState): number {
  let mult = 1.0
  if (hasEvent(state, "gem_surge")) mult *= 1.3
  if (hasEvent(state, "storm_of_chaos")) mult *= 1.5
  return mult
}

// Helper: player XP multiplier
export function getPlayerXpMultiplier(state: GameState): number {
  let mult = 1.0
  if (hasEvent(state, "exp_festival")) mult *= 1.3
  if (hasEvent(state, "storm_of_chaos")) mult *= 1.5
  return mult
}

// Helper: hero XP multiplier
export function getHeroXpMultiplier(state: GameState): number {
  let mult = 1.0
  if (hasEvent(state, "hero_blessing")) mult *= 1.3
  return mult
}

// Helper: hero skill points earned for a given level (1 per 5 levels)
function heroSkillPointsForLevel(level: number): number {
  return Math.floor(level / 5)
}

// Helper: train cost multiplier
export function getTrainCostMultiplier(state: GameState): number {
  return hasEvent(state, "training_day") ? 0.5 : 1.0
}

// Helper: lose penalty multiplier (war_economy & cursed_moon)
export function getLosePenaltyMultiplier(state: GameState): number {
  let mult = 1.0
  if (hasEvent(state, "war_economy")) mult *= 1.25
  if (hasEvent(state, "cursed_moon")) mult *= 1.2
  return mult
}

// Helper: gacha luck multiplier (celestial_gate)
export function getGachaLuckMultiplier(state: GameState): number {
  return hasEvent(state, "celestial_gate") ? 1.3 : 1.0
}

// Helper: item drop multiplier (double_drop)
export function getItemDropMultiplier(state: GameState): number {
  return hasEvent(state, "double_drop") ? 2.0 : 1.0
}

// Helper: defeat penalty multiplier
export function getEventPenaltyMultiplier(state: GameState): number {
  return hasEvent(state, "war_economy") ? 1.25 : 1.0
}

// Helper: enemy stat multiplier từ blood_moon + ancient_curse (for UI display only)
// storm_of_chaos random roll is fixed at combat start in buildCombatState, not here
// FIX: previously had Math.random() here — called from multiple places each returning different values
export function getBloodMoonMultiplier(state: GameState): number {
  let mult = 1.0
  if (hasEvent(state, "blood_moon")) mult *= 1.25
  if (hasEvent(state, "ancient_curse")) mult *= 1.20
  if (hasEvent(state, "storm_of_chaos")) mult *= 1.3  // approximate display value (actual is 1.1–1.5 random)
  return mult
}



function createInitialState(): GameState {
  // Give player a starting hero (a Common warrior) + 5 minor potions + 200 gold + 30 gems
  const starter: OwnedHero = {
    uid: uid(),
    templateId: "h_borin",
    level: 1,
    xp: 0,
    heroSkillPoints: 0,
    skillLevels: [1, 1, 1],
    equipment: {},
  }
  const starterMage: OwnedHero = {
    uid: uid(),
    templateId: "h_mirelle",
    level: 1,
    xp: 0,
    heroSkillPoints: 0,
    skillLevels: [1, 1, 1],
    equipment: {}, equipmentInvUid: {},
  }
  const starterTank: OwnedHero = {
    uid: uid(),
    templateId: "h_otto",
    level: 1,
    xp: 0,
    heroSkillPoints: 0,
    skillLevels: [1, 1, 1],
    equipment: {}, equipmentInvUid: {},
  }
  return {
    gold: 500,
    gems: 50,
    blessingShards: 0,
    pactShards: 0,
    level: 1,
    xp: 0,
    statPoints: 0,
    skillPoints: 0,
    playerStats: {
      attackBonus: 0,
      defenseBonus: 0,
      hpBonus: 0,
      magicBonus: 0,
      speedBonus: 0,
      critBonus: 0,
    },
    skillTree: { nodes: {} },
    heroes: [starter, starterMage, starterTank],
    inventory: [
      { uid: uid(), itemId: "p_minor", quantity: 5 },
      { uid: uid(), itemId: "p_medium", quantity: 2 },
    ],
    team: [starter.uid, starterMage.uid, starterTank.uid, null, null, null],
    teamRows: ["front", "back", "front", "front", "back", "back"] as BattleRow[],
    teamReserve: [null, null, null, null],
    teamReserveRows: ["front", "front", "back", "back"] as BattleRow[],
    highestStage: 1,
    currentStage: 1,
    clearedStage: 0,
    notifications: [],
    combat: null,
    cachedEnemyTeam: null,
    totalRolls: 0,
    totalDigs: 0,
    battlesWon: 0,
    raidBattlesUsed: 0,
    raidResetAtBattle: 5,
    towerState: null,
    towerRecord: 0,
    towerClaimedMilestones: [],
    questState: {
      active: [],
      completed: [],
      lastRefreshed: 0,
      killStreak: 0,
      noDeathStreak: 0,
      consecutiveWins: 0,
    },
    shopStock: {
      weapon: { items: pickRandomShopItems("weapon", SHOP_STOCK_COUNT.weapon).map(it => ({ ...it, innate: generateInnate(ITEMS_BY_ID[it.itemId]) })), refreshedAt: Date.now(), dayNumber: 1 },
      armor: { items: pickRandomShopItems("armor", SHOP_STOCK_COUNT.armor).map(it => ({ ...it, innate: generateInnate(ITEMS_BY_ID[it.itemId]) })), refreshedAt: Date.now(), dayNumber: 1 },
      trinket: { items: pickRandomShopItems("trinket", SHOP_STOCK_COUNT.trinket).map(it => ({ ...it, innate: generateInnate(ITEMS_BY_ID[it.itemId]) })), refreshedAt: Date.now(), dayNumber: 1 },
      potion: { items: pickRandomShopItems("potion", SHOP_STOCK_COUNT.potion).map(it => it), refreshedAt: Date.now(), dayNumber: 1 },
    },
    premiumShopStock: undefined,
    activeEvents: [],
    daysSinceLastEvent: 0,
    currentDay: 1,
    luckBuff: null,
    autoSellRarities: [],
    winStreak: 0,
    perfectStreak: 0,
    streakLastStage: -1,    // tầng cuối cùng được tính streak
    streakSameStageCount: 0, // số lần farm cùng tầng liên tiếp
    gachaPity: { gemSinceLegendary: 0, gemSinceMythic: 0, goldSinceEpic: 0 },
    battleHistory: [],
  }
}

// ============================================================
// Actions
// ============================================================

type Action =
  | { type: "RESET" }
  | { type: "LOAD"; payload: GameState }
  // Currency / progress
  | { type: "ADD_GOLD"; amount: number }
  | { type: "ADD_GEMS"; amount: number }
  | { type: "ADD_PLAYER_XP"; amount: number }
  | { type: "SET_STAGE"; stage: number; fromVictory?: boolean; fromWatch?: boolean }
  // Team
  | { type: "SET_TEAM_SLOT"; slot: number; uid: string | null }
  | { type: "SET_TEAM_ROW"; slot: number; row: BattleRow }
  | { type: "SET_RESERVE_SLOT"; slot: number; uid: string | null }
  | { type: "SET_RESERVE_ROW"; slot: number; row: BattleRow }
  // Heroes
  | { type: "ADD_HERO"; templateId: string }
  | { type: "ADD_HEROES"; templateIds: string[] }
  | { type: "ADD_HERO_XP"; uid: string; amount: number }
  | { type: "TRAIN_HERO"; uid: string; mult: number }
  | { type: "SACRIFICE_HERO"; uid: string }
  | { type: "SACRIFICE_HERO_MULTI"; uids: string[] }
  | { type: "EQUIP_ITEM"; heroUid: string; slot: EquipSlot; itemId: string | null; invUid?: string | null }
  | { type: "ADD_SKILL_POINT_HERO"; uid: string; index: 0 | 1 | 2 }
  // Inventory
  | { type: "ADD_ITEM"; itemId: string; quantity?: number; innate?: import("./types").ItemInnate }
  | { type: "REMOVE_ITEM"; uid: string; quantity?: number }
  | { type: "SELL_ITEM"; uid: string }
  | { type: "RESTOCK_SHOP"; kind: import("./types").ShopKind }
  | { type: "BUY_SHOP_ITEM"; kind: import("./types").ShopKind; itemIndex: number }
  | { type: "BUY_SHOP_ITEM_NO_GOLD"; kind: import("./types").ShopKind; itemIndex: number }
  | { type: "BUY_PREMIUM_SHOP_ITEM"; itemIndex: number }
  | { type: "RESTOCK_PREMIUM_SHOP" }
  // Skill tree
  | { type: "LEARN_NODE"; nodeId: string }
  // Combat
  | { type: "START_COMBAT" }
  | { type: "START_WATCH_COMBAT" }
  | { type: "START_PVP_COMBAT"; opponentHeroes: OwnedHero[]; opponentStats: GameState["playerStats"] }
  | { type: "SCOUT_STAGE" }  // generate + cache enemy team for current stage
  | { type: "SET_WATCH_SPEED"; speed: 1 | 2 }
  | { type: "END_COMBAT" }
  | { type: "SET_COMBAT"; state: CombatState | null }
  // Stats
  | { type: "INC_STAT"; key: keyof GameState["playerStats"]; cost?: number }
  // Notifications
  | { type: "PUSH_NOTIFY"; text: string }
  | { type: "INC_DIG" }
  | { type: "INC_BATTLES_WON" }
  | { type: "INC_RAID_ATTEMPT" }
  // Quests
  | { type: "INIT_QUESTS" }
  | { type: "REFRESH_QUESTS" }
  | { type: "FILL_QUESTS" }
  | { type: "CLAIM_QUEST"; questId: string }
  | { type: "QUEST_ON_BATTLE_WIN"; killedRarities: import("./types").Rarity[]; hadDeaths: boolean; stage?: number }
  | { type: "QUEST_ON_RECRUIT"; count: number }
  | { type: "QUEST_ON_GOLD_EARNED"; amount: number }
  // Blessings & Pacts
  | { type: "ADD_BLESSING_SHARDS"; amount: number }
  | { type: "ADD_PACT_SHARDS"; amount: number }
  | { type: "ROLL_SHARDS_GEMS" }
  | { type: "ROLL_SHARDS_GOLD" }
  | { type: "EQUIP_BLESSING_PACT"; heroUid: string; blessingPactId: string }
  | { type: "UNEQUIP_BLESSING_PACT"; heroUid: string }
  | { type: "RESET_HERO_SKILLS"; uid: string }
  | { type: "EQUIP_HERO_SKILL"; uid: string; slot: 0 | 1 | 2; skillId: string }
  | { type: "RESET_PLAYER_STATS" }
  | { type: "UNLOCK_HERO_SKILL"; uid: string; skillId: string }
  // Tower
  | { type: "TOWER_START_RUN" }
  | { type: "TOWER_START_FLOOR_COMBAT" }
  | { type: "TOWER_HEAL_TEAM" }               // apply 30% heal to all living team members
  | { type: "TOWER_SWAP_HERO"; heroUid: string; slot: number }  // swap bench hero into team
  | { type: "TOWER_CONTINUE" }                // advance to next floor
  | { type: "TOWER_GIVE_UP" }                 // end run, save record
  | { type: "TOWER_SET_POST_VICTORY_STEP"; step: import("./types").TowerPostVictoryChoice }
  | { type: "TOWER_SET_PENDING_SWAP"; heroUid: string | null; slot: number | null }
  | { type: "QUEST_ON_TOWER_FLOOR_CLEAR"; floor: number }
  | { type: "QUEST_ON_RAID_PARTICIPATE" }
  // Batched reward action — applies all combat rewards in a single reducer call (no intermediate re-renders)
  | { type: "BATCH_COMBAT_REWARDS"; combat: CombatState; isTowerCombat: boolean; isWatchMode: boolean }
  // Defeat penalty — lose gold (can go negative), no cap
  | { type: "APPLY_DEFEAT_PENALTY"; goldLoss: number }
  // Battle history
  | { type: "SAVE_BATTLE_RECORD"; record: import("./types").BattleRecord }
  // Luck potions
  | { type: "USE_LUCK_POTION"; uid: string; tier: 1 | 2 | 3 }
  | { type: "SET_LUCK_BUFF_ROLLS"; rollsLeft: number }
  | { type: "SET_AUTO_SELL_RARITIES"; rarities: Rarity[] }
  | { type: "UPDATE_GACHA_PITY"; gem?: { gemSinceLegendary: number; gemSinceMythic: number }; gold?: { goldSinceEpic: number } }

function reducer(state: GameState, action: Action): GameState {
  switch (action.type) {
    case "RESET":
      return createInitialState()
    case "LOAD": {
      const loaded = action.payload
      // Migrate old 5-slot teams to 6 slots
      const migratedTeam = [...(loaded.team ?? [null,null,null,null,null])]
      while (migratedTeam.length < 6) migratedTeam.push(null)
      // Migrate / generate teamRows
      const migratedRows: BattleRow[] = (loaded as any).teamRows
        ? [...(loaded as any).teamRows]
        : migratedTeam.map((uid) => {
            if (!uid) return "back" as BattleRow
            const owned = (loaded.heroes ?? []).find((h: OwnedHero) => h.uid === uid)
            if (!owned) return "back" as BattleRow
            const tpl = HEROES_BY_ID[owned.templateId]
            return (tpl?.range === "melee" ? "front" : "back") as BattleRow
          })
      while (migratedRows.length < 6) migratedRows.push("back")
      return {
        ...loaded,
        team: migratedTeam,
        teamRows: migratedRows,
        clearedStage: loaded.clearedStage ?? (loaded.highestStage > 1 ? loaded.highestStage - 1 : 0),
        blessingShards: loaded.blessingShards ?? 0,
        pactShards: loaded.pactShards ?? 0,
        towerState: loaded.towerState ?? null,
        towerRecord: loaded.towerRecord ?? 0,
        towerClaimedMilestones: loaded.towerClaimedMilestones ?? [],
        questState: loaded.questState ?? {
          active: [], completed: [], lastRefreshed: 0,
          killStreak: 0, noDeathStreak: 0, consecutiveWins: 0,
        },
        activeEvents: (loaded as any).activeEvents ?? [],
        daysSinceLastEvent: (loaded as any).daysSinceLastEvent ?? 0,
        currentDay: (loaded as any).currentDay ?? Math.floor(((loaded as any).battlesWon ?? 0) / 5) + 1,
        luckBuff: (loaded as any).luckBuff ?? null,
        autoSellRarities: (loaded as any).autoSellRarities ?? [],
        winStreak: (loaded as any).winStreak ?? 0,
        perfectStreak: (loaded as any).perfectStreak ?? 0,
        streakLastStage: (loaded as any).streakLastStage ?? -1,
        streakSameStageCount: (loaded as any).streakSameStageCount ?? 0,
        premiumShopStock: (loaded as any).premiumShopStock ?? undefined,
        teamReserve: (loaded as any).teamReserve ?? [null, null, null, null],
        teamReserveRows: (loaded as any).teamReserveRows ?? ["front", "front", "back", "back"],
        gachaPity: (loaded as any).gachaPity ?? { gemSinceLegendary: 0, gemSinceMythic: 0, goldSinceEpic: 0 },
        battleHistory: (loaded as any).battleHistory ?? [],
        // Migrate: ensure all heroes have heroSkillPoints based on their level
        heroes: ((loaded as any).heroes ?? []).map((h: any) => ({
          ...h,
          heroSkillPoints: h.heroSkillPoints != null ? h.heroSkillPoints : Math.floor((h.level ?? 1) / 5),
        })),
        // Migrate: expand stacked equip items into unique uid instances
        inventory: (() => {
          const raw: any[] = (loaded as any).inventory ?? []
          const out: any[] = []
          for (const entry of raw) {
            const tpl = ITEMS_BY_ID[entry.itemId]
            if (tpl?.kind === "equip" && entry.quantity > 1) {
              // Explode stacked equips into individual uid instances
              for (let i = 0; i < entry.quantity; i++) {
                out.push({ uid: entry.uid + "_" + i, itemId: entry.itemId, quantity: 1, ...(entry.innate ? { innate: entry.innate } : {}) })
              }
            } else {
              out.push(entry)
            }
          }
          return out
        })(),
      }
    }
    case "ADD_GOLD":
      return { ...state, gold: Math.max(0, state.gold + action.amount) }
    case "ADD_GEMS":
      return { ...state, gems: Math.max(0, state.gems + action.amount) }
    case "ADD_PLAYER_XP": {
      let xp = state.xp + action.amount
      let level = state.level
      let statPoints = state.statPoints
      let skillPoints = state.skillPoints
      while (xp >= playerXpToNextLevel(level)) {
        xp -= playerXpToNextLevel(level)
        level++
        statPoints += 3
        skillPoints += 1
      }
      // Auto-init premium shop when first reaching level 50
      let premiumShopStock = state.premiumShopStock
      if (!premiumShopStock) {
        const tier = getPremiumTier(level, state.towerRecord ?? 0)
        if (tier) {
          const rawItems = pickPremiumShopItems(tier, 8)
          premiumShopStock = {
            items: rawItems.map(it => ({ ...it, innate: generateInnate(ITEMS_BY_ID[it.itemId]) })),
            refreshedAt: Date.now(), dayNumber: 1,
          }
        }
      }
      return { ...state, xp, level, statPoints, skillPoints, premiumShopStock }
    }
    case "SET_STAGE": {
      const maxAllowed = (state.clearedStage ?? 0) + 1
      return {
        ...state,
        cachedEnemyTeam: null, // clear cache whenever stage changes so scout re-generates
        currentStage: Math.max(1, Math.min(action.fromVictory ? action.stage : maxAllowed, action.stage)),
        // highestStage: always tracks furthest stage reached
        highestStage: action.fromVictory
          ? Math.max(state.highestStage, action.stage)
          : state.highestStage,
        // clearedStage: only advances when player manually wins (not watch mode)
        clearedStage: (action.fromVictory && !action.fromWatch)
          ? Math.max(state.clearedStage ?? 0, action.stage - 1)
          : (state.clearedStage ?? 0),
      }
    }
    case "SET_TEAM_SLOT": {
      const team = [...state.team]
      while (team.length < 6) team.push(null)
      if (action.uid) {
        for (let i = 0; i < team.length; i++) if (team[i] === action.uid) team[i] = null
      }

      // Level gap check: no hero in team can differ more than 20 levels from any other
      const MAX_LEVEL_GAP = 20
      if (action.uid) {
        const newHero = state.heroes.find(h => h.uid === action.uid)
        if (newHero) {
          const newLevel = newHero.level
          // Remove any existing hero whose level differs more than 20 from the new hero
          for (let i = 0; i < team.length; i++) {
            if (i === action.slot) continue
            if (!team[i]) continue
            const existingHero = state.heroes.find(h => h.uid === team[i])
            if (existingHero && Math.abs(existingHero.level - newLevel) > MAX_LEVEL_GAP) {
              team[i] = null
            }
          }
        }
      }

      team[action.slot] = action.uid
      // Auto-assign row when placing hero
      const teamRows = [...(state.teamRows ?? ["front","back","front","front","back","back"])]
      while (teamRows.length < 6) teamRows.push("back")
      if (action.uid) {
        const owned = state.heroes.find(h => h.uid === action.uid)
        const tpl = owned ? HEROES_BY_ID[owned.templateId] : null
        teamRows[action.slot] = tpl?.range === "melee" ? "front" : teamRows[action.slot]
      }
      return { ...state, team, teamRows }
    }
    case "SET_TEAM_ROW": {
      const teamRows = [...(state.teamRows ?? ["front","back","front","front","back","back"])]
      while (teamRows.length < 6) teamRows.push("back")
      // Melee bắt buộc ở hàng trước
      const heroUid = state.team[action.slot]
      if (heroUid) {
        const owned = state.heroes.find(h => h.uid === heroUid)
        const tpl = owned ? HEROES_BY_ID[owned.templateId] : null
        if (tpl?.range === "melee" && action.row === "back") return state
      }
      teamRows[action.slot] = action.row
      return { ...state, teamRows }
    }
    case "SET_RESERVE_SLOT": {
      const teamReserve = [...(state.teamReserve ?? [null, null, null, null])]
      while (teamReserve.length < 4) teamReserve.push(null)
      // Remove from team or other reserve slot if already placed there
      if (action.uid) {
        for (let i = 0; i < teamReserve.length; i++) if (teamReserve[i] === action.uid) teamReserve[i] = null
      }
      teamReserve[action.slot] = action.uid
      // Auto-assign row: front reserve (0-1) = "front", back reserve (2-3) = "back"
      const teamReserveRows = [...(state.teamReserveRows ?? ["front", "front", "back", "back"])]
      while (teamReserveRows.length < 4) teamReserveRows.push(action.slot < 2 ? "front" : "back")
      if (action.uid) {
        const owned = state.heroes.find(h => h.uid === action.uid)
        const tpl = owned ? HEROES_BY_ID[owned.templateId] : null
        // Melee: force front
        if (tpl?.range === "melee") teamReserveRows[action.slot] = "front"
      }
      return { ...state, teamReserve, teamReserveRows }
    }
    case "SET_RESERVE_ROW": {
      const teamReserveRows = [...(state.teamReserveRows ?? ["front", "front", "back", "back"])]
      while (teamReserveRows.length < 4) teamReserveRows.push("back")
      const heroUid = (state.teamReserve ?? [])[action.slot]
      if (heroUid) {
        const owned = state.heroes.find(h => h.uid === heroUid)
        const tpl = owned ? HEROES_BY_ID[owned.templateId] : null
        if (tpl?.range === "melee" && action.row === "back") return state
      }
      teamReserveRows[action.slot] = action.row
      return { ...state, teamReserveRows }
    }
    case "ADD_HERO": {
      const tpl = HEROES_BY_ID[action.templateId]
      if (!tpl) return state
      // If already owned: convert to upgrade material? simplest: add as new instance and grant 5 gems
      const existing = state.heroes.find((h) => h.templateId === action.templateId)
      const dupGems = existing ? rarityRank(tpl.rarity) * 2 + 1 : 0
      const newHero: OwnedHero = {
        uid: uid(),
        templateId: action.templateId,
        level: 1,
        xp: 0,
        heroSkillPoints: 0,
        skillLevels: [1, 1, 1],
        equipment: {}, equipmentInvUid: {},
      }
      return {
        ...state,
        heroes: [...state.heroes, newHero],
        gems: state.gems + dupGems,
      }
    }
    case "ADD_HEROES": {
      const autoSellSet = new Set(state.autoSellRarities as Rarity[])
      let goldGain = 0
      let gemGain = 0
      const keptHeroes: typeof state.heroes = []
      for (const tid of action.templateIds) {
        const tpl = HEROES_BY_ID[tid]
        if (tpl && autoSellSet.has(tpl.rarity)) {
          // Auto-sell: same payout as SACRIFICE_HERO at level 1
          goldGain += (rarityRank(tpl.rarity) + 1) * 80
          gemGain += rarityRank(tpl.rarity) >= 3 ? rarityRank(tpl.rarity) * 3 : 0
        } else {
          keptHeroes.push({
            uid: uid(),
            templateId: tid,
            level: 1,
            xp: 0,
            heroSkillPoints: 0,
            skillLevels: [1, 1, 1] as [number, number, number],
            equipment: {},
          })
        }
      }
      return {
        ...state,
        heroes: [...state.heroes, ...keptHeroes],
        totalRolls: state.totalRolls + action.templateIds.length,
        gold: state.gold + goldGain,
        gems: state.gems + gemGain,
      }
    }
    case "SET_AUTO_SELL_RARITIES": {
      return { ...state, autoSellRarities: action.rarities }
    }
    case "ADD_HERO_XP": {
      const heroes = state.heroes.map((h) => {
        if (h.uid !== action.uid) return h
        let xp = h.xp + action.amount
        let level = h.level
        while (xp >= xpToNextLevel(level)) {
          xp -= xpToNextLevel(level)
          level++
        }
        // Grant heroSkillPoints: 1 per 5 levels earned
        const newPoints = heroSkillPointsForLevel(level) - heroSkillPointsForLevel(h.level)
        const heroSkillPoints = (h.heroSkillPoints ?? 0) + Math.max(0, newPoints)
        return { ...h, xp, level, heroSkillPoints }
      })
      return { ...state, heroes }
    }
    case "TRAIN_HERO": {
      // FIX: atomic train — compute XP based on hero's CURRENT level inside reducer
      const hero = state.heroes.find((h) => h.uid === action.uid)
      if (!hero) return state
      const trainXp = hero.level > 80 ? 50 : hero.level > 60 ? 75 : hero.level > 30 ? 150 : 200
      const trainCostMult = getTrainCostMultiplier(state)
      const baseCosts: Record<number, number> = { 1: 100, 10: 1000, 100: 10000 }
      const baseCost = baseCosts[action.mult] ?? action.mult * 100
      const cost = Math.round(baseCost * trainCostMult)
      if (state.gold < cost) return state
      const totalXp = trainXp * action.mult
      const trainedHeroes = state.heroes.map((h) => {
        if (h.uid !== action.uid) return h
        let xp = h.xp + totalXp
        let level = h.level
        while (xp >= xpToNextLevel(level)) { xp -= xpToNextLevel(level); level++ }
        const newPts = heroSkillPointsForLevel(level) - heroSkillPointsForLevel(h.level)
        const heroSkillPoints = (h.heroSkillPoints ?? 0) + Math.max(0, newPts)
        return { ...h, xp, level, heroSkillPoints }
      })
      return { ...state, heroes: trainedHeroes, gold: Math.max(0, state.gold - cost) }
    }
    case "SACRIFICE_HERO": {
      const target = state.heroes.find((h) => h.uid === action.uid)
      if (!target) return state
      const tpl = HEROES_BY_ID[target.templateId]
      const goldGain = (rarityRank(tpl.rarity) + 1) * 80 + target.level * 20
      const gemGain = rarityRank(tpl.rarity) >= 3 ? rarityRank(tpl.rarity) * 3 : 0
      const team = state.team.map((u) => (u === action.uid ? null : u))
      const teamReserve = (state.teamReserve ?? []).map(u => u === action.uid ? null : u)
      return {
        ...state,
        heroes: state.heroes.filter((h) => h.uid !== action.uid),
        team,
        teamReserve,
        gold: state.gold + goldGain,
        gems: state.gems + gemGain,
      }
    }
    case "SACRIFICE_HERO_MULTI": {
      // FIX: bulk sell multiple heroes at once
      let totalGold = 0
      let totalGems = 0
      const uidSet = new Set(action.uids)
      for (const h of state.heroes) {
        if (!uidSet.has(h.uid)) continue
        const tpl = HEROES_BY_ID[h.templateId]
        if (!tpl) continue
        totalGold += (rarityRank(tpl.rarity) + 1) * 80 + h.level * 20
        totalGems += rarityRank(tpl.rarity) >= 3 ? rarityRank(tpl.rarity) * 3 : 0
      }
      const team = state.team.map((u) => (u && uidSet.has(u) ? null : u))
      const teamReserve = (state.teamReserve ?? []).map(u => (u && uidSet.has(u) ? null : u))
      return {
        ...state,
        heroes: state.heroes.filter((h) => !uidSet.has(h.uid)),
        team,
        teamReserve,
        gold: state.gold + totalGold,
        gems: state.gems + totalGems,
      }
    }
    case "EQUIP_ITEM": {
      const heroes = state.heroes.map((h) => {
        if (h.uid === action.heroUid) {
          // Equip/unequip on the target hero
          const newEquip = { ...h.equipment }
          const newEquipInvUid = { ...(h.equipmentInvUid ?? {}) }
          if (action.itemId) {
            newEquip[action.slot] = action.itemId
            newEquipInvUid[action.slot] = action.invUid ?? undefined
          } else {
            delete newEquip[action.slot]
            delete newEquipInvUid[action.slot]
          }
          return { ...h, equipment: newEquip, equipmentInvUid: newEquipInvUid }
        }
        // Safety: if another hero has the same invUid equipped, unequip it from them
        if (action.invUid && action.itemId) {
          const otherInvUid = h.equipmentInvUid?.[action.slot]
          if (otherInvUid === action.invUid) {
            const newEquip = { ...h.equipment }
            const newEquipInvUid = { ...(h.equipmentInvUid ?? {}) }
            delete newEquip[action.slot]
            delete newEquipInvUid[action.slot]
            return { ...h, equipment: newEquip, equipmentInvUid: newEquipInvUid }
          }
        }
        return h
      })
      return { ...state, heroes }
    }
    case "ADD_SKILL_POINT_HERO": {
      // Cost: 1 skill point for regular skills (index 0,1), 2 for ultimate (index 2)
      const skillPointCost = action.index === 2 ? 2 : 1
      const heroes = state.heroes.map((h) => {
        if (h.uid !== action.uid) return h
        const tpl = HEROES_BY_ID[h.templateId]
        if (!tpl) return h
        // Check hero has enough skill points
        const availablePoints = h.heroSkillPoints ?? 0
        if (availablePoints < skillPointCost) return h
        // Determine which skill is in this slot
        const loadout = h.equippedSkillIds ?? tpl.skills
        const skillId = loadout[action.index]
        const isBonus = !tpl.skills.includes(skillId as any)
        const reqs = SKILL_LEVEL_REQUIREMENTS[action.index] || [1, 5, 10, 20, 35]
        if (isBonus) {
          const bonusLvls = { ...(h.bonusSkillLevels ?? {}) }
          const currentLvl = bonusLvls[skillId] ?? 1
          if (currentLvl >= 5) return h
          const requiredHeroLevel = reqs[currentLvl]
          if (h.level < requiredHeroLevel) return h
          bonusLvls[skillId] = currentLvl + 1
          return { ...h, heroSkillPoints: availablePoints - skillPointCost, bonusSkillLevels: bonusLvls }
        }
        const lvls = [...h.skillLevels] as [number, number, number]
        const currentLvl = lvls[action.index]
        if (currentLvl >= 5) return h
        const requiredHeroLevel = reqs[currentLvl]
        if (h.level < requiredHeroLevel) return h
        lvls[action.index] = currentLvl + 1
        return { ...h, heroSkillPoints: availablePoints - skillPointCost, skillLevels: lvls }
      })
      return { ...state, heroes }
    }
    case "ADD_ITEM": {
      const qty = action.quantity || 1
      const itemTpl = ITEMS_BY_ID[action.itemId]
      // Equip items: always unique uid instance, one per copy (never stacked)
      if (itemTpl?.kind === "equip" || action.innate) {
        const newItems: typeof state.inventory = []
        for (let i = 0; i < qty; i++) {
          newItems.push({ uid: uid(), itemId: action.itemId, quantity: 1, ...(action.innate ? { innate: action.innate } : {}) })
        }
        return { ...state, inventory: [...state.inventory, ...newItems] }
      }
      // Potions/consumables: stack by itemId
      const existing = state.inventory.find((i) => i.itemId === action.itemId && !i.innate)
      if (existing) {
        return {
          ...state,
          inventory: state.inventory.map((i) =>
            i.itemId === action.itemId && !i.innate ? { ...i, quantity: i.quantity + qty } : i,
          ),
        }
      }
      return {
        ...state,
        inventory: [
          ...state.inventory,
          { uid: uid(), itemId: action.itemId, quantity: qty },
        ],
      }
    }
    case "RESTOCK_SHOP": {
      const { kind } = action
      const rawItems = pickRandomShopItems(kind, SHOP_STOCK_COUNT[kind])
      const itemsWithInnate = rawItems.map((it) => {
        const tpl = ITEMS_BY_ID[it.itemId]
        const innate = tpl ? generateInnate(tpl) : undefined
        return innate ? { ...it, innate } : it
      })
      const prevStock = state.shopStock?.[kind]
      return {
        ...state,
        shopStock: {
          ...state.shopStock,
          [kind]: {
            items: itemsWithInnate,
            refreshedAt: Date.now(),
            dayNumber: (prevStock?.dayNumber ?? 0) + 1,
          },
        },
      }
    }
    case "BUY_SHOP_ITEM":
    case "BUY_SHOP_ITEM_NO_GOLD": {
      const { kind, itemIndex } = action
      const stock = state.shopStock?.[kind]
      if (!stock) return state
      const stockItem = stock.items[itemIndex]
      if (!stockItem || stockItem.stock <= 0) return state
      const item = ITEMS_BY_ID[stockItem.itemId]
      if (!item) return state
      // For BUY_SHOP_ITEM: deduct gold normally. For BUY_SHOP_ITEM_NO_GOLD: gold already deducted
      if (action.type === "BUY_SHOP_ITEM" && state.gold < item.basePrice) return state
      const newItems = stock.items.map((it, idx) =>
        idx === itemIndex ? { ...it, stock: it.stock - 1 } : it
      )
      const newInv: typeof state.inventory[0][] = [...state.inventory]
      if (item.kind === "equip") {
        // Equip items: always unique instance (uid), never stacked
        newInv.push({ uid: uid(), itemId: item.id, quantity: 1, ...(stockItem.innate ? { innate: stockItem.innate } : {}) })
      } else if (stockItem.innate) {
        newInv.push({ uid: uid(), itemId: item.id, quantity: 1, innate: stockItem.innate })
      } else {
        // Potions/consumables: stack by itemId
        const existing = newInv.find((i) => i.itemId === item.id && !i.innate)
        if (existing) {
          const idx = newInv.indexOf(existing)
          newInv[idx] = { ...existing, quantity: existing.quantity + 1 }
        } else {
          newInv.push({ uid: uid(), itemId: item.id, quantity: 1 })
        }
      }
      return {
        ...state,
        gold: action.type === "BUY_SHOP_ITEM" ? state.gold - item.basePrice : state.gold,
        inventory: newInv,
        shopStock: {
          ...state.shopStock,
          [kind]: { ...stock, items: newItems },
        },
      }
    }
    case "REMOVE_ITEM": {
      const qty = action.quantity || 1
      const inv = state.inventory
        .map((i) => (i.uid === action.uid ? { ...i, quantity: i.quantity - qty } : i))
        .filter((i) => i.quantity > 0)
      return { ...state, inventory: inv }
    }
    case "BUY_PREMIUM_SHOP_ITEM": {
      const stock = state.premiumShopStock
      if (!stock) return state
      const si = stock.items[action.itemIndex]
      if (!si || si.stock <= 0) return state
      const tpl = ITEMS_BY_ID[si.itemId]
      if (!tpl || state.gold < tpl.basePrice) return state
      const newItems = stock.items.map((it, idx) =>
        idx === action.itemIndex ? { ...it, stock: it.stock - 1 } : it
      )
      const newInvItem: typeof state.inventory[0] = si.innate
        ? { uid: uid(), itemId: tpl.id, quantity: 1, innate: si.innate }
        : { uid: uid(), itemId: tpl.id, quantity: 1 }
      return {
        ...state,
        gold: state.gold - tpl.basePrice,
        inventory: [...state.inventory, newInvItem],
        premiumShopStock: { ...stock, items: newItems },
      }
    }
    case "RESTOCK_PREMIUM_SHOP": {
      const tier = getPremiumTier(state.level, state.towerRecord ?? 0)
      if (!tier) return state
      const rawItems = pickPremiumShopItems(tier, 8)
      const prev = state.premiumShopStock
      return {
        ...state,
        premiumShopStock: {
          items: rawItems.map(it => ({ ...it, innate: generateInnate(ITEMS_BY_ID[it.itemId]) })),
          refreshedAt: Date.now(),
          dayNumber: (prev?.dayNumber ?? 0) + 1,
        },
      }
    }
    case "SELL_ITEM": {
      const item = state.inventory.find((i) => i.uid === action.uid)
      if (!item) return state
      const tpl = ITEMS_BY_ID[item.itemId]
      if (!tpl) return state
      const price = Math.round(tpl.basePrice * 0.4)
      return {
        ...state,
        gold: state.gold + price,
        inventory: state.inventory
          .map((i) =>
            i.uid === action.uid ? { ...i, quantity: i.quantity - 1 } : i,
          )
          .filter((i) => i.quantity > 0),
      }
    }
    case "USE_LUCK_POTION": {
      // action: { uid: string, tier: 1|2|3 }
      const invItem = state.inventory.find((i) => i.uid === action.uid)
      if (!invItem || invItem.quantity <= 0) return state
      const newBuff = { tier: action.tier as 1 | 2 | 3, rollsLeft: 100 }
      return {
        ...state,
        luckBuff: newBuff,
        inventory: state.inventory
          .map((i) => i.uid === action.uid ? { ...i, quantity: i.quantity - 1 } : i)
          .filter((i) => i.quantity > 0),
      }
    }
    case "SET_LUCK_BUFF_ROLLS": {
      if (!state.luckBuff) return state
      const rollsLeft = action.rollsLeft as number
      if (rollsLeft <= 0) return { ...state, luckBuff: null }
      return { ...state, luckBuff: { ...state.luckBuff, rollsLeft } }
    }
    case "UPDATE_GACHA_PITY": {
      const prev = state.gachaPity ?? { gemSinceLegendary: 0, gemSinceMythic: 0, goldSinceEpic: 0 }
      return {
        ...state,
        gachaPity: {
          gemSinceLegendary: action.gem?.gemSinceLegendary ?? prev.gemSinceLegendary,
          gemSinceMythic: action.gem?.gemSinceMythic ?? prev.gemSinceMythic,
          goldSinceEpic: action.gold?.goldSinceEpic ?? prev.goldSinceEpic,
        },
      }
    }
    case "LEARN_NODE": {
      const node = SKILL_TREE_BY_ID[action.nodeId]
      if (!node) return state
      const cur = state.skillTree.nodes[node.id] || 0
      if (cur >= node.maxRank) return state
      if (state.skillPoints < node.cost) return state
      if (!canLearnNode(node, state.skillTree.nodes)) return state
      const nodes = { ...state.skillTree.nodes, [node.id]: cur + 1 }
      const playerStats = computePlayerStatsFromTree(nodes)
      return {
        ...state,
        skillTree: { nodes },
        skillPoints: state.skillPoints - node.cost,
        playerStats,
      }
    }
    case "INC_STAT": {
      const cost = action.cost ?? 1
      if (state.statPoints < cost) return state
      const playerStats = { ...state.playerStats }
      // Each stat point gives a fixed bump
      const stepByKey: Record<keyof GameState["playerStats"], number> = {
        attackBonus: 4,
        magicBonus: 5,
        defenseBonus: 4,
        hpBonus: 30,
        speedBonus: 2,
        critBonus: 1,
      }
      playerStats[action.key] = playerStats[action.key] + stepByKey[action.key]
      return {
        ...state,
        statPoints: state.statPoints - cost,
        playerStats,
      }
    }
    case "START_COMBAT": {
      // Need at least 1 hero in team
      const filled = state.team.filter((u) => !!u)
      if (filled.length === 0) return state
      const combat = buildCombatState(state)
      return { ...state, combat }
    }
    case "START_PVP_COMBAT": {
      const filled = state.team.filter((u) => !!u)
      if (filled.length === 0) return state
      const combat = buildPvpCombatState(state, action.opponentHeroes, action.opponentStats)
      return { ...state, combat }
    }
    case "SCOUT_STAGE": {
      // Generate and cache the enemy team for the current stage
      return { ...state, cachedEnemyTeam: generateEnemyTeam(state.currentStage) }
    }
    case "START_WATCH_COMBAT": {
      const filled = state.team.filter((u) => !!u)
      if (filled.length === 0) return state
      const combat = buildCombatState(state)
      // In watch mode AI also handles player turns — never await input
      combat.watchMode = true
      combat.awaitingPlayerInput = false
      return { ...state, combat }
    }
    case "SET_WATCH_SPEED": {
      if (!state.combat) return state
      return { ...state, combat: { ...state.combat, watchSpeed: action.speed } }
    }
    case "END_COMBAT":
      return { ...state, combat: null }
    case "SET_COMBAT":
      return { ...state, combat: action.state }
    case "PUSH_NOTIFY":
      return { ...state, notifications: [action.text, ...state.notifications].slice(0, 10) }
    case "INC_DIG":
      return { ...state, totalDigs: state.totalDigs + 1 }
    case "INC_BATTLES_WON": {
      const newBattlesWon = state.battlesWon + 1
      // Auto-restock every 5 battles (1 "day")
      const isNewDay = newBattlesWon % 5 === 0
      // Reset raid counter on new day
      const raidReset = isNewDay
        ? { raidBattlesUsed: 0, raidResetAtBattle: newBattlesWon + 5 }
        : {}
      if (isNewDay) {
        const kinds: import("./types").ShopKind[] = ["weapon", "armor", "trinket", "potion"]
        const newShopStock = { ...state.shopStock }
        for (const kind of kinds) {
          const rawItems = pickRandomShopItems(kind, SHOP_STOCK_COUNT[kind])
          const itemsWithInnate = rawItems.map((it) => {
            const tpl = ITEMS_BY_ID[it.itemId]
            const innate = tpl ? generateInnate(tpl) : undefined
            return innate ? { ...it, innate } : it
          })
          const prev = newShopStock[kind]
          newShopStock[kind] = { items: itemsWithInnate, refreshedAt: Date.now(), dayNumber: (prev?.dayNumber ?? 0) + 1 }
        }
        const newDay = (state.currentDay ?? 1) + 1
        const newEvents = rollDailyEvents(newDay, state.daysSinceLastEvent ?? 0)
        return { ...state, battlesWon: newBattlesWon, shopStock: newShopStock, activeEvents: newEvents, currentDay: newDay, daysSinceLastEvent: newEvents.length > 0 ? 0 : (state.daysSinceLastEvent ?? 0) + 1, ...raidReset }
      }
      return { ...state, battlesWon: newBattlesWon }
    }
    case "INC_RAID_ATTEMPT":
      return { ...state, raidBattlesUsed: (state.raidBattlesUsed ?? 0) + 1 }
    // ============================================================
    // Infinite Tower actions
    // ============================================================
    case "TOWER_START_RUN": {
      const filled = state.team.filter(u => !!u)
      if (filled.length === 0) return state
      const towerState: import("./types").TowerRunState = {
        floor: 1,
        pendingHeal: false,
        pendingSwapHeroUid: null,
        pendingSwapSlot: null,
        postVictoryStep: null,
      }
      return { ...state, towerState }
    }
    case "TOWER_START_FLOOR_COMBAT": {
      if (!state.towerState) return state
      const towerFloor = state.towerState.floor
      const virtualState = { ...state, currentStage: Math.max(1, towerFloor * 2) }
      const combat = buildCombatState(virtualState)
      // Infinite Tower: HP carries over from previous floor — no healing between floors
      combat.log = [{ id: uid(), text: `🗼 Tầng Vô Cực ${towerFloor} bắt đầu! ${combat.units.filter(u => u.side === "enemy").length} kẻ địch.`, kind: "system" as const }]
      combat.stage = towerFloor
      return { ...state, combat }
    }
    case "TOWER_HEAL_TEAM": {
      // FIX: 30% heal between tower floors was never implemented — TOWER_START_FLOOR_COMBAT
      // never read pendingHeal. Feature removed; action is now a no-op kept for compatibility.
      if (!state.towerState) return state
      return { ...state, towerState: { ...state.towerState, pendingHeal: false } }
    }
    case "TOWER_SWAP_HERO": {
      if (!state.towerState) return state
      const { heroUid, slot } = action
      // Validate
      const heroExists = state.heroes.find(h => h.uid === heroUid)
      if (!heroExists) return state
      const team = [...state.team]
      // Remove hero from any current slot
      for (let i = 0; i < team.length; i++) if (team[i] === heroUid) team[i] = null
      // Level gap check: remove existing heroes that differ more than 20 levels
      const MAX_LEVEL_GAP = 20
      const newLevel = heroExists.level
      for (let i = 0; i < team.length; i++) {
        if (i === slot || !team[i]) continue
        const existing = state.heroes.find(h => h.uid === team[i])
        if (existing && Math.abs(existing.level - newLevel) > MAX_LEVEL_GAP) {
          team[i] = null
        }
      }
      team[slot] = heroUid
      return { ...state, team, towerState: { ...state.towerState, pendingSwapHeroUid: null, pendingSwapSlot: null } }
    }
    case "TOWER_SET_POST_VICTORY_STEP": {
      if (!state.towerState) return state
      return { ...state, towerState: { ...state.towerState, postVictoryStep: action.step } }
    }
    case "TOWER_SET_PENDING_SWAP": {
      if (!state.towerState) return state
      return { ...state, towerState: { ...state.towerState, pendingSwapHeroUid: action.heroUid, pendingSwapSlot: action.slot } }
    }
    case "TOWER_CONTINUE": {
      if (!state.towerState) return state
      const nextFloor = state.towerState.floor + 1
      const newRecord = Math.max(state.towerRecord ?? 0, state.towerState.floor)
      const towerState: import("./types").TowerRunState = {
        floor: nextFloor,
        pendingHeal: false,
        pendingSwapHeroUid: null,
        pendingSwapSlot: null,
        postVictoryStep: null,
      }
      return { ...state, towerState, towerRecord: newRecord }
    }
    case "TOWER_GIVE_UP": {
      const newRecord = Math.max(state.towerRecord ?? 0, state.towerState?.floor ?? 0)
      return { ...state, towerState: null, towerRecord: newRecord, combat: null }
    }
    case "APPLY_DEFEAT_PENALTY": {
      // Gold can go negative — no floor
      // Reset all streaks on defeat
      const qs = state.questState
      return {
        ...state,
        gold: state.gold - action.goldLoss,
        winStreak: 0,
        perfectStreak: 0,
        streakLastStage: -1,
        streakSameStageCount: 0,
        questState: qs ? { ...qs, killStreak: 0, noDeathStreak: 0, consecutiveWins: 0 } : qs,
      }
    }
    case "SAVE_BATTLE_RECORD": {
      const history = [action.record, ...(state.battleHistory ?? [])].slice(0, 30)
      return { ...state, battleHistory: history }
    }
    case "QUEST_ON_TOWER_FLOOR_CLEAR": {
      const qs = state.questState
      if (!qs) return state
      const updated = qs.active.map(q => {
        if (q.completed) return q
        if (q.objective.type === "tower_clear_floors") {
          return { ...q, objective: { ...q.objective, current: q.objective.current + 1 } }
        }
        if (q.objective.type === "tower_reach_floor") {
          return { ...q, objective: { ...q.objective, current: Math.max(q.objective.current, action.floor) } }
        }
        return q
      })
      return { ...state, questState: { ...qs, active: updated } }
    }
    case "QUEST_ON_RAID_PARTICIPATE": {
      const qs = state.questState
      if (!qs) return state
      const updated = qs.active.map(q => {
        if (q.completed) return q
        if (q.objective.type === "raid_participate") {
          return { ...q, objective: { ...q.objective, current: q.objective.current + 1 } }
        }
        return q
      })
      return { ...state, questState: { ...qs, active: updated } }
    }
    // ============================================================
    // Quest actions
    // ============================================================
    case "INIT_QUESTS":
    case "REFRESH_QUESTS": {
      const existing = state.questState?.active ?? []
      if (action.type === "INIT_QUESTS" && existing.length > 0) return state
      const newQuests = generateQuestBatch(state)
      const qs: QuestState = {
        active: newQuests,
        completed: state.questState?.completed ?? [],
        lastRefreshed: Date.now(),
        killStreak: state.questState?.killStreak ?? 0,
        noDeathStreak: state.questState?.noDeathStreak ?? 0,
        consecutiveWins: state.questState?.consecutiveWins ?? 0,
      }
      return { ...state, questState: qs }
    }
    case "FILL_QUESTS": {
      const qs = state.questState
      if (!qs) return state
      if (qs.active.length >= MAX_ACTIVE_QUESTS) return state
      const filled = generateQuestFill(state, qs.active)
      return { ...state, questState: { ...qs, active: filled, lastRefreshed: Date.now() } }
    }
    case "CLAIM_QUEST": {
      const qs = state.questState
      if (!qs) return state
      const quest = qs.active.find(q => q.id === action.questId)
      if (!quest || !checkObjectiveCompletion(quest.objective, state, qs)) return state
      let ns = { ...state }
      const r = quest.reward
      if (r.gold) ns = { ...ns, gold: ns.gold + r.gold }
      if (r.gems) ns = { ...ns, gems: ns.gems + r.gems }
      if (r.items) {
        for (const it of r.items) {
          const existing2 = ns.inventory.find(i => i.itemId === it.itemId && !i.innate)
          if (existing2) {
            ns = { ...ns, inventory: ns.inventory.map(i => i.uid === existing2.uid ? { ...i, quantity: i.quantity + it.quantity } : i) }
          } else {
            ns = { ...ns, inventory: [...ns.inventory, { uid: uid(), itemId: it.itemId, quantity: it.quantity }] }
          }
        }
      }
      if (r.heroRarity) {
        const pool = HEROES_BY_RARITY[r.heroRarity] || []
        if (pool.length > 0) {
          const tplId = pool[Math.floor(Math.random() * pool.length)].id
          const newHero = { uid: uid(), templateId: tplId, level: 1, xp: 0, heroSkillPoints: 0, skillLevels: [1, 1, 1] as [1,1,1], equipment: {}, equipmentInvUid: {} }
          ns = { ...ns, heroes: [...ns.heroes, newHero] }
        }
      }
      const newActive = qs.active.filter(q => q.id !== action.questId)
      const claimedQuest = { ...quest, completed: true, claimedAt: Date.now() }
      const newCompleted = [claimedQuest, ...(qs.completed ?? [])].slice(0, 50)
      ns = { ...ns, questState: { ...qs, active: newActive, completed: newCompleted } }
      return ns
    }
    case "QUEST_ON_BATTLE_WIN": {
      const qs = state.questState
      if (!qs) return state
      const killedRarities = action.killedRarities
      const hadDeaths = action.hadDeaths
      // killStreak chỉ tăng nếu tầng là "thử thách thực sự" (địch >= 75% level ta)
      // Tầng quá dễ → reset killStreak về 0
      const teamHeroesKS = state.heroes.filter(h => state.team.includes(h.uid))
      const playerAvgLvKS = teamHeroesKS.length > 0
        ? teamHeroesKS.reduce((s, h) => s + h.level, 0) / teamHeroesKS.length : 1
      const enemyLvKS = Math.max(1, Math.floor((action.stage ?? 1) * 1.3))
      const isChallengeKS = (enemyLvKS / playerAvgLvKS) >= 0.75
      const newKillStreak = isChallengeKS ? (qs.killStreak ?? 0) + 1 : 0
      const newConsecutiveWins = (qs.consecutiveWins ?? 0) + 1
      const newNoDeathStreak = hadDeaths ? 0 : (qs.noDeathStreak ?? 0) + 1
      const totalKills = killedRarities.length
      const updatedActive = qs.active.map(q => {
        if (q.completed) return q
        let obj = { ...q.objective }
        switch (obj.type) {
          case "kill_total":
            obj = { ...obj, current: obj.current + totalKills }; break
          case "kill_streak":
            obj = { ...obj, current: newKillStreak }; break
          case "kill_monster_rarity": {
            const minRank = rarityRank(obj.rarity)
            const matching = killedRarities.filter(r2 => rarityRank(r2) >= minRank).length
            obj = { ...obj, current: obj.current + matching }; break
          }
          case "win_no_deaths":
            obj = hadDeaths ? { ...obj, current: 0 } : { ...obj, current: obj.current + 1 }; break
          case "win_consecutive":
            obj = { ...obj, current: newConsecutiveWins }; break
          default: break
        }
        return { ...q, objective: obj }
      })
      return { ...state, questState: { ...qs, active: updatedActive, killStreak: newKillStreak, noDeathStreak: newNoDeathStreak, consecutiveWins: newConsecutiveWins } }
    }
    case "QUEST_ON_RECRUIT": {
      const qs = state.questState
      if (!qs) return state
      const updatedActive = qs.active.map(q => {
        if (q.completed || q.objective.type !== "recruit_total") return q
        return { ...q, objective: { ...q.objective, current: q.objective.current + action.count } }
      })
      return { ...state, questState: { ...qs, active: updatedActive } }
    }
    case "QUEST_ON_GOLD_EARNED": {
      const qs = state.questState
      if (!qs) return state
      const updatedActive = qs.active.map(q => {
        if (q.completed || q.objective.type !== "collect_gold") return q
        return { ...q, objective: { ...q.objective, current: q.objective.current + action.amount } }
      })
      return { ...state, questState: { ...qs, active: updatedActive } }
    }
    // ============================================================
    // Blessing / Pact
    // ============================================================
    case "ADD_BLESSING_SHARDS":
      return { ...state, blessingShards: (state.blessingShards ?? 0) + action.amount }
    case "ADD_PACT_SHARDS":
      return { ...state, pactShards: (state.pactShards ?? 0) + action.amount }
    case "ROLL_SHARDS_GEMS": {
      const cost = 50
      if (state.gems < cost) return state
      const result = rollShardsGems()
      return {
        ...state,
        gems: state.gems - cost,
        blessingShards: (state.blessingShards ?? 0) + result.blessingShards,
        pactShards: (state.pactShards ?? 0) + result.pactShards,
      }
    }
    case "ROLL_SHARDS_GOLD": {
      const cost = 1000
      if (state.gold < cost) return state
      const result = rollShardsGold()
      return {
        ...state,
        gold: state.gold - cost,
        blessingShards: (state.blessingShards ?? 0) + result.blessingShards,
        pactShards: (state.pactShards ?? 0) + result.pactShards,
      }
    }
    case "EQUIP_BLESSING_PACT": {
      const bp = ALL_BLESSINGS_BY_ID[action.blessingPactId]
      if (!bp) return state
      // Check shard cost
      const shardKey = bp.kind === "blessing" ? "blessingShards" : "pactShards"
      const currentShards = (state[shardKey] ?? 0)
      if (currentShards < bp.shardCost) return state
      // Check uniqueness: no other hero in team can have this same id
      const teamUids = state.team.filter(Boolean) as string[]
      const conflict = state.heroes.find(h =>
        teamUids.includes(h.uid) && h.uid !== action.heroUid && h.blessingPactId === action.blessingPactId
      )
      if (conflict) return state
      // Check: hero can only hold one (blessing or pact)
      const heroes = state.heroes.map(h =>
        h.uid === action.heroUid ? { ...h, blessingPactId: action.blessingPactId } : h
      )
      return {
        ...state,
        heroes,
        [shardKey]: currentShards - bp.shardCost,
      }
    }
    case "UNEQUIP_BLESSING_PACT": {
      const heroes = state.heroes.map(h =>
        h.uid === action.heroUid ? { ...h, blessingPactId: undefined } : h
      )
      return { ...state, heroes }
    }
    case "RESET_HERO_SKILLS": {
      const hero = state.heroes.find((h) => h.uid === action.uid)
      if (!hero) return state
      // Regular skills: index 0,1 cost 1pt each; index 2 (ulti) costs 2pt each
      const basePoints = hero.skillLevels.reduce((sum, lv, idx) => sum + (lv - 1) * (idx === 2 ? 2 : 1), 0)
      const bonusPoints = Object.values(hero.bonusSkillLevels ?? {}).reduce((sum, lv) => sum + (lv - 1), 0)
      const totalSkillPoints = basePoints + bonusPoints
      const cost = 2000 + totalSkillPoints * 500
      if (state.gold < cost) return state
      // Refund all spent points back to hero
      const refundedPoints = heroSkillPointsForLevel(hero.level)
      const heroes = state.heroes.map((h) =>
        h.uid !== action.uid ? h : { ...h, heroSkillPoints: refundedPoints, skillLevels: [1, 1, 1] as [number, number, number], unlockedSkills: [], bonusSkillLevels: {} }
      )
      return { ...state, gold: state.gold - cost, heroes }
    }
    case "RESET_PLAYER_STATS": {
      const s = state.playerStats
      const totalSpent = Math.round(
        s.attackBonus / 4 + s.defenseBonus / 4 + s.hpBonus / 30 +
        s.magicBonus / 5 + s.speedBonus / 2 + s.critBonus
      )
      const RESET_GOLD_COST = 10000
      const RESET_GEM_COST = 1000
      if (state.gold < RESET_GOLD_COST || state.gems < RESET_GEM_COST) return state
      return {
        ...state,
        gold: state.gold - RESET_GOLD_COST,
        gems: state.gems - RESET_GEM_COST,
        statPoints: state.statPoints + totalSpent,
        playerStats: { attackBonus: 0, defenseBonus: 0, hpBonus: 0, magicBonus: 0, speedBonus: 0, critBonus: 0 },
      }
    }
    case "UNLOCK_HERO_SKILL": {
      const heroes = state.heroes.map((h) => {
        if (h.uid !== action.uid) return h
        const already = h.unlockedSkills || []
        if (already.includes(action.skillId)) return h
        return { ...h, unlockedSkills: [...already, action.skillId] }
      })
      return { ...state, heroes }
    }
    case "EQUIP_HERO_SKILL": {
      const heroes = state.heroes.map((h) => {
        if (h.uid !== action.uid) return h
        const tpl = HEROES_BY_ID[h.templateId]
        const current: [string, string, string] = h.equippedSkillIds
          ? [...h.equippedSkillIds]
          : [...tpl.skills]
        current[action.slot] = action.skillId
        return { ...h, equippedSkillIds: current as [string, string, string] }
      })
      return { ...state, heroes }
    }
    case "BATCH_COMBAT_REWARDS": {
      // Apply ALL combat rewards in a single state update — eliminates 6-8 intermediate re-renders
      const { combat, isTowerCombat, isWatchMode } = action
      if (combat.ended !== "victory" || !combat.rewards) return state

      let { gold, gems, xp, items } = combat.rewards
      let ns = state

      // Half rewards when replaying a stage already manually beaten
      // clearedStage = highest stage beaten by player manually (not watch mode)
      const isReplay = !isTowerCombat && combat.stage <= (ns.clearedStage ?? 0)
      if (isReplay || isWatchMode) {
        gold = Math.floor(gold / 2)
        gems = Math.floor(gems / 2)
        xp = Math.floor(xp / 2)
        items = [] // no item drops on replay/watch
      }

      // Tower: only grant resources at milestone floors (10, 20, 30...) — each only once
      if (isTowerCombat) {
        const floor = ns.towerState?.floor ?? 0
        const isMilestone = floor > 0 && floor % 10 === 0
        const alreadyClaimed = (ns.towerClaimedMilestones ?? []).includes(floor)
        if (!isMilestone || alreadyClaimed) {
          // Non-milestone floor: no gold/gems/items; small XP only
          gold = 0; gems = 0; items = []
          xp = Math.floor(xp / 3)
        } else {
          // Milestone: generous scaling reward, claimable only once
          const tier = Math.floor(floor / 10)
          gold = 500 * tier + 200
          gems = 10 * tier
          xp = xp * 2
          ns = { ...ns, towerClaimedMilestones: [...(ns.towerClaimedMilestones ?? []), floor] }
        }
      }

      // ── Win Streak & Perfect Streak bonuses ─────────────────────────────
      // Điều kiện TÍNH STREAK (phải đáp ứng TẤT CẢ):
      //   1. challengeRatio >= 0.75  → trận thực sự (địch lv >= 75% ta)
      //   2. Không farm cùng tầng quá nhiều lần (streakSameStageCount <= STREAK_MAX_SAME_STAGE)
      //   3. Chơi lại tầng cũ được phép nếu địch vẫn >= 75% level ta
      //
      // Điều kiện PHÁ STREAK:
      //   1. Thua trận (APPLY_DEFEAT_PENALTY → reset)
      //   2. Tầng quá dễ (ratio < 0.75) — kể cả khi replay
      //   3. Farm cùng tầng > STREAK_MAX_SAME_STAGE lần
      // ──────────────────────────────────────────────────────────────────────
      if (!isWatchMode && !isTowerCombat) {
        const hadDeaths = combat.units.some(u => u.side === "player" && u.hp <= 0)

        // Tính average level đội hình player hiện tại
        const teamHeroes = ns.heroes.filter(h => ns.team.includes(h.uid))
        const playerAvgLevel = teamHeroes.length > 0
          ? teamHeroes.reduce((sum, h) => sum + h.level, 0) / teamHeroes.length
          : 1

        // Địch level theo công thức generateEnemyTeam
        const enemyLevel = Math.max(1, Math.floor(combat.stage * 1.3))

        // Tỉ lệ sức mạnh địch / ta (theo level)
        const challengeRatio = enemyLevel / playerAvgLevel

        // Ngưỡng: địch phải đạt ít nhất 75% level trung bình của ta
        const isChallenge = challengeRatio >= 0.75

        // Kiểm tra farming: cùng tầng liên tiếp quá nhiều lần
        const lastStage   = ns.streakLastStage ?? -1
        const sameCount   = ns.streakSameStageCount ?? 0
        const isSameStage = combat.stage === lastStage
        const newSameCount = isSameStage ? sameCount + 1 : 1
        const isFarming    = newSameCount > STREAK_MAX_SAME_STAGE

        if (!isChallenge) {
          // Tầng quá dễ → reset streak (kể cả replay nếu địch quá yếu)
          if ((ns.winStreak ?? 0) > 0 || (ns.perfectStreak ?? 0) > 0) {
            ns = { ...ns, winStreak: 0, perfectStreak: 0, streakLastStage: combat.stage, streakSameStageCount: newSameCount }
          } else {
            ns = { ...ns, streakLastStage: combat.stage, streakSameStageCount: newSameCount }
          }
        } else if (isFarming) {
          // Farm cùng tầng quá nhiều → reset streak
          if ((ns.winStreak ?? 0) > 0 || (ns.perfectStreak ?? 0) > 0) {
            ns = { ...ns, winStreak: 0, perfectStreak: 0, streakLastStage: combat.stage, streakSameStageCount: newSameCount }
          } else {
            ns = { ...ns, streakLastStage: combat.stage, streakSameStageCount: newSameCount }
          }
        } else {
          // ✅ Trận hợp lệ — tính streak (kể cả replay nếu địch đủ mạnh)
          const newWinStreak  = (ns.winStreak  ?? 0) + 1
          const newPerfStreak = hadDeaths ? 0 : (ns.perfectStreak ?? 0) + 1

          // Gold multiplier from streak — add only to `gold` variable here.
          const mult = streakGoldMultiplier(newWinStreak)
          const streakGoldExtra = mult > 1 ? Math.round(gold * (mult - 1)) : 0
          if (streakGoldExtra > 0) {
            gold += streakGoldExtra
          }

          // Gem bonus từ streak + perfect
          const totalBonusGems = streakGemBonus(newWinStreak) + perfectGemBonus(newPerfStreak)
          if (totalBonusGems > 0) {
            ns = { ...ns, gems: ns.gems + totalBonusGems }
          }

          ns = { ...ns, winStreak: newWinStreak, perfectStreak: newPerfStreak, streakLastStage: combat.stage, streakSameStageCount: newSameCount }
        }
      }

      // ── Event multipliers ──────────────────────────────────────────
      const goldMult = getGoldRewardMultiplier(ns)
      const gemMult  = getGemRewardMultiplier(ns)
      const xpMult   = getPlayerXpMultiplier(ns)
      const heroXpMult = getHeroXpMultiplier(ns)
      const dropMult = getItemDropMultiplier(ns)

      if (!isReplay && !isTowerCombat) {
        gold  = Math.round(gold  * goldMult)
        gems  = Math.round(gems  * gemMult)
        xp    = Math.round(xp    * xpMult)
        if (dropMult > 1) items = [...items, ...items] // x2 items
      }

      // Gold & gems
      ns = { ...ns, gold: ns.gold + gold }
      if (gems) ns = { ...ns, gems: ns.gems + gems }
      // Player XP + level up
      let newXp = ns.xp + xp
      let newLevel = ns.level
      let newStatPoints = ns.statPoints
      let newSkillPoints = ns.skillPoints
      while (newXp >= playerXpToNextLevel(newLevel)) {
        newXp -= playerXpToNextLevel(newLevel)
        newLevel++
        newStatPoints += 3
        newSkillPoints += 1
      }
      ns = { ...ns, xp: newXp, level: newLevel, statPoints: newStatPoints, skillPoints: newSkillPoints }

      // Hero XP (với hero_blessing multiplier)
      const heroXpGain = Math.round(xp * heroXpMult)
      const updatedHeroes = ns.heroes.map(h => {
        if (!ns.team.includes(h.uid)) return h
        let hXp = h.xp + heroXpGain
        let hLv = h.level
        // FIX (updated): removed level cap — heroes can now grow beyond 60
        const prevHLv = h.level
        while (hXp >= xpToNextLevel(hLv)) { hXp -= xpToNextLevel(hLv); hLv++ }
        const combatPts = heroSkillPointsForLevel(hLv) - heroSkillPointsForLevel(prevHLv)
        const updatedSkillPts = (h.heroSkillPoints ?? 0) + Math.max(0, combatPts)
        return { ...h, xp: hXp, level: hLv, heroSkillPoints: updatedSkillPts }
      })
      ns = { ...ns, heroes: updatedHeroes }

      // Inventory items
      if (items.length > 0) {
        const newInventory = [...ns.inventory]
        for (const { itemId, quantity } of items) {
          const existing = newInventory.find(i => i.itemId === itemId && !ITEMS_BY_ID[itemId]?.unique)
          if (existing) {
            const idx = newInventory.indexOf(existing)
            newInventory[idx] = { ...existing, quantity: existing.quantity + quantity }
          } else {
            newInventory.push({ uid: uid(), itemId, quantity })
          }
        }
        ns = { ...ns, inventory: newInventory }
      }

      // Stage advancement or tower
      if (!isTowerCombat) {
        const nextStage = combat.stage + 1
        ns = {
          ...ns,
          // Watch mode: don't push currentStage past what player has manually cleared
          currentStage: isWatchMode ? ns.currentStage : nextStage,
          highestStage: Math.max(ns.highestStage, nextStage),
          // clearedStage: only update when player manually wins (not watch mode)
          clearedStage: isWatchMode ? ns.clearedStage : Math.max(ns.clearedStage, combat.stage),
          // Clear cached enemy team so the next stage generates fresh enemies
          cachedEnemyTeam: null,
        }
      } else {
        // Infinite Tower: skip post-victory UI — auto-advance to next floor immediately
        if (ns.towerState) {
          const nextFloor = ns.towerState.floor + 1
          const newRecord = Math.max(ns.towerRecord ?? 0, ns.towerState.floor)
          ns = {
            ...ns,
            towerRecord: newRecord,
            towerState: {
              ...ns.towerState,
              floor: nextFloor,
              pendingHeal: false,
              pendingSwapHeroUid: null,
              pendingSwapSlot: null,
              postVictoryStep: null,
            },
            combat: null,
          }
        }
      }

      // battlesWon + shop auto-restock
      const newBattlesWon = ns.battlesWon + 1
      const isNewDay = newBattlesWon % 5 === 0
      ns = { ...ns, battlesWon: newBattlesWon }
      if (isNewDay) {
        const kinds: import("./types").ShopKind[] = ["weapon", "armor", "trinket", "potion"]
        const newShopStock = { ...ns.shopStock }
        for (const kind of kinds) {
          const rawItems = pickRandomShopItems(kind, SHOP_STOCK_COUNT[kind])
          const itemsWithInnate = rawItems.map(it => {
            const tpl = ITEMS_BY_ID[it.itemId]
            const innate = tpl ? generateInnate(tpl) : undefined
            return innate ? { ...it, innate } : it
          })
          const prev = newShopStock[kind]
          newShopStock[kind] = { items: itemsWithInnate, refreshedAt: Date.now(), dayNumber: (prev?.dayNumber ?? 0) + 1 }
        }
        const newDay = (ns.currentDay ?? 1) + 1
        const newEvents = rollDailyEvents(newDay, state.daysSinceLastEvent ?? 0)
        ns = { ...ns, shopStock: newShopStock, raidBattlesUsed: 0, raidResetAtBattle: newBattlesWon + 5, activeEvents: newEvents, currentDay: newDay, daysSinceLastEvent: newEvents.length > 0 ? 0 : (state.daysSinceLastEvent ?? 0) + 1 }
        // Auto-add new daily quests when a new day starts
        if (ns.questState) {
          const newDailyQuests = generateQuestBatch(ns)
          const existingQs = ns.questState
          ns = { ...ns, questState: { ...existingQs, active: [...existingQs.active, ...newDailyQuests], lastRefreshed: Date.now() } }
        }
      }

      // Quest: battle win tracking
      const qs = ns.questState
      if (qs) {
        const killedRarities = combat.units.filter(u => u.side === "enemy" && u.hp <= 0).map(u => u.rarity)
        const hadDeaths = combat.units.some(u => u.side === "player" && u.hp <= 0)
        // killStreak chỉ tăng nếu tầng là thử thách thực sự (địch >= 75% level ta)
        // Tầng quá dễ hoặc chơi lại tầng đã clear → reset về 0
        const teamHeroesKS2 = ns.heroes.filter(h => ns.team.includes(h.uid))
        const playerAvgLvKS2 = teamHeroesKS2.length > 0
          ? teamHeroesKS2.reduce((s, h) => s + h.level, 0) / teamHeroesKS2.length : 1
        const enemyLvKS2 = Math.max(1, Math.floor(combat.stage * 1.3))
        const isChallengeKS2 = (enemyLvKS2 / playerAvgLvKS2) >= 0.75
        // Chơi lại tầng cũ được phép tính streak nếu địch vẫn tương đương (>= 75% level ta)
        const newKillStreak = isChallengeKS2 ? (qs.killStreak ?? 0) + 1 : 0
        const newConsecutiveWins = (qs.consecutiveWins ?? 0) + 1
        const newNoDeathStreak = hadDeaths ? 0 : (qs.noDeathStreak ?? 0) + 1
        const totalKills = killedRarities.length
        const questActive = qs.active.map(q => {
          if (q.completed) return q
          let obj = { ...q.objective }
          switch (obj.type) {
            case "kill_total": obj = { ...obj, current: obj.current + totalKills }; break
            case "kill_streak": obj = { ...obj, current: newKillStreak }; break
            case "kill_monster_rarity": {
              const minRank = rarityRank(obj.rarity)
              const matching = killedRarities.filter(r2 => rarityRank(r2) >= minRank).length
              obj = { ...obj, current: obj.current + matching }; break
            }
            case "win_no_deaths": obj = hadDeaths ? { ...obj, current: 0 } : { ...obj, current: obj.current + 1 }; break
            case "win_consecutive": obj = { ...obj, current: newConsecutiveWins }; break
            case "collect_gold": obj = { ...obj, current: obj.current + gold }; break
            default: break
          }
          return { ...q, objective: obj }
        })
        ns = { ...ns, questState: { ...qs, active: questActive, killStreak: newKillStreak, noDeathStreak: newNoDeathStreak, consecutiveWins: newConsecutiveWins } }
      }

      return ns
    }
  }
  return state
}

// ============================================================
// Provider
// ============================================================

type GameActions = {
  dispatch: React.Dispatch<Action>
  // Convenience operations (mutate state via dispatch + side-effects)
  rollHero: (count: 1 | 10 | 100) => void
  rollHeroGold: (count: 1 | 10 | 100) => void
  digArtifact: (count?: 1 | 10 | 100) => void
  buyItem: (itemId: string) => void
  buyShopItem: (kind: import("./types").ShopKind, itemIndex: number) => void
  restockShop: (kind: import("./types").ShopKind) => void
  buyPremiumShopItem: (itemIndex: number) => void
  restockPremiumShop: () => void
  sellItem: (uid: string) => void
  useLuckPotion: (uid: string, tier: 1 | 2 | 3) => void
  setAutoSellRarities: (rarities: Rarity[]) => void
  equipBest: (heroUid: string) => void
  startCombat: () => void
  startWatchCombat: () => void // AI controls both sides
  startPvpCombat: (opponentHeroes: OwnedHero[], opponentStats: GameState["playerStats"], sessionId?: string, opponentUsername?: string, myUsername?: string, isPlayer2?: boolean) => void
  setTeamRow: (slot: number, row: BattleRow) => void
  setReserveSlot: (slot: number, uid: string | null) => void
  setReserveRow: (slot: number, row: BattleRow) => void
  // Combat actions
  combatChooseSkill: (skillIndex: 0 | 1 | 2, targetUid: string | null) => void
  combatBasicAttack: (targetUid: string) => void
  combatUsePotion: (inventoryItemUid: string, targetUid: string) => void
  combatFlee: () => void
  combatSkipTurn: () => void
  combatChangeRow: (unitUid: string) => void
  // Misc
  resetGame: () => void
  resetHeroSkills: (uid: string) => void
  resetPlayerStats: () => void
  unlockHeroSkill: (uid: string, skillId: string) => void
  // Blessings & Pacts
  rollShardsWithGems: () => void
  rollShardsWithGold: () => void
  equipBlessingPact: (heroUid: string, blessingPactId: string) => void
  unequipBlessingPact: (heroUid: string) => void
  // Tower
  towerStartRun: () => void
  towerStartFloorCombat: () => void
  towerGiveUp: () => void
  towerContinue: () => void
}

// Legacy combined type for backward compatibility
type GameContextValue = { state: GameState } & GameActions

// ============================================================
// localStorage key management — per-user to prevent cross-account data bleed
// ============================================================
const BASE_STORAGE_KEY = "aetheria-save-v1"
let _currentStorageKey = BASE_STORAGE_KEY

export function setStorageUsername(username: string | null) {
  _currentStorageKey = username
    ? `${BASE_STORAGE_KEY}:${username.trim().toLowerCase()}`
    : BASE_STORAGE_KEY
}

export function getStorageKey() { return _currentStorageKey }

// Split into two contexts: state changes frequently, actions never change after mount
const GameStateContext = createContext<GameState | null>(null)
const GameActionsContext = createContext<GameActions | null>(null)

// Legacy combined context — kept for backward compat with useGame()
const GameContext = createContext<GameContextValue | null>(null)

export function GameProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined as unknown as GameState, createInitialState)
  const loadedRef = useRef(false)

  // Load from localStorage once on mount
  // Note: getStorageKey() returns the correct per-user key because
  // use-cloud-save calls setStorageUsername() synchronously before this effect fires
  // (child effects fire before parent effects in React)
  useEffect(() => {
    if (loadedRef.current) return
    loadedRef.current = true
    try {
      const raw = window.localStorage.getItem(getStorageKey())
      if (raw) {
        const parsed = JSON.parse(raw) as GameState
        if (parsed && parsed.heroes && parsed.team) {
          dispatch({ type: "LOAD", payload: parsed })
        }
      }
    } catch { /* ignore */ }
    setTimeout(() => dispatch({ type: "INIT_QUESTS" }), 50)
  }, [])

  // Persist on change — debounced 2s, skip when only transient combat state changed
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const persistFingerprintRef = useRef("")
  useEffect(() => {
    const fingerprint = `${state.gold}|${state.gems}|${state.battlesWon}|${state.heroes.length}|${state.level}|${state.currentStage}|${state.clearedStage}|${state.towerRecord}`
    if (fingerprint === persistFingerprintRef.current && !state.combat) return
    persistFingerprintRef.current = fingerprint

    if (saveTimerRef.current) clearTimeout(saveTimerRef.current)
    saveTimerRef.current = setTimeout(() => {
      try {
        // Don't persist active combat or cached enemy team — both are transient
        const { combat: _combat, cachedEnemyTeam: _cache, ...persistable } = state
        window.localStorage.setItem(getStorageKey(), JSON.stringify(persistable))
      } catch {
        // ignore quota errors
      }
    }, 2000)
    return () => { if (saveTimerRef.current) clearTimeout(saveTimerRef.current) }
  }, [state])

  // ============================================================
  // Operations
  // ============================================================

  const rollHero = useCallback(
    (count: 1 | 10 | 100) => {
      // Gem banner: x1=30, x10=280, x100=3000 (giá cố định, không tiết kiệm)
      const baseCost = count === 1 ? 30 : count === 10 ? 280 : 3000
      const priceMult = getEventPriceMultiplier(state)
      const cost = Math.round(baseCost * priceMult)
      if (state.gems < cost) {
        toast.error("Không đủ Đá Quý.")
        return
      }
      dispatch({ type: "ADD_GEMS", amount: -cost })
      const ids: string[] = []
      const baseLuckMult = state.luckBuff ? [1, 1.25, 1.50, 1.75][state.luckBuff.tier] : 1
      const celestialMult = getGachaLuckMultiplier(state)
      const luckMult = baseLuckMult * celestialMult
      const baseRates = luckMult > 1 ? applyLuckToRates(HERO_GACHA_RATES, luckMult) : HERO_GACHA_RATES

      // Pity — đúng tỉ lệ: legendary 0.5% → expected 200 → hard pity 200 (soft 150)
      //                      mythic 0.05% → expected 2000 → hard pity 2000 (soft 1500)
      // Soft pity legendary: pull 150→199, +1%/pull  → pull 150=1%, pull 200=guaranteed
      // Soft pity mythic:    pull 1500→1999, +0.1%/pull → pull 1500=0.1%, pull 2000=guaranteed
      let { gemSinceLegendary, gemSinceMythic } = (state.gachaPity ?? { gemSinceLegendary: 0, gemSinceMythic: 0, goldSinceEpic: 0 })

      for (let i = 0; i < count; i++) {
        gemSinceLegendary++
        gemSinceMythic++
        let rarity = rollRarity(baseRates) as Rarity

        // Hard pity
        if (gemSinceMythic >= 2000 && rarityRank(rarity) < rarityRank("mythic" as Rarity)) {
          rarity = "mythic"
        } else if (gemSinceLegendary >= 200 && rarityRank(rarity) < rarityRank("legendary" as Rarity)) {
          rarity = "legendary"
        }
        // Soft pity legendary: pull 150→199, +1%/pull
        else if (gemSinceLegendary >= 150 && rarityRank(rarity) < rarityRank("legendary" as Rarity)) {
          const softBoost = (gemSinceLegendary - 149) * 0.01
          if (Math.random() < Math.min(softBoost, 1)) rarity = "legendary"
        }
        // Soft pity mythic: pull 1500→1999, +0.1%/pull
        else if (gemSinceMythic >= 1500 && rarityRank(rarity) < rarityRank("mythic" as Rarity)) {
          const softBoost = (gemSinceMythic - 1499) * 0.001
          if (Math.random() < Math.min(softBoost, 1)) rarity = "mythic"
        }

        // Multi-pull safety: pull cuối đảm bảo epic+
        if ((count === 10 || count === 100) && i === count - 1 && rarityRank(rarity) < 2) rarity = "epic"

        // Reset pity khi đạt milestone
        if (rarityRank(rarity) >= rarityRank("mythic" as Rarity)) {
          gemSinceMythic = 0; gemSinceLegendary = 0
        } else if (rarityRank(rarity) >= rarityRank("legendary" as Rarity)) {
          gemSinceLegendary = 0
        }

        const pool = HEROES_BY_RARITY[rarity] || []
        const tpl = pool[Math.floor(Math.random() * pool.length)]
        if (tpl) ids.push(tpl.id)
      }

      dispatch({ type: "UPDATE_GACHA_PITY", gem: { gemSinceLegendary, gemSinceMythic } })
      if (state.luckBuff) {
        const newRollsLeft = state.luckBuff.rollsLeft - count
        dispatch({ type: "SET_LUCK_BUFF_ROLLS", rollsLeft: Math.max(0, newRollsLeft) })
      }
      dispatch({ type: "ADD_HEROES", templateIds: ids })
      dispatch({ type: "QUEST_ON_RECRUIT", count: ids.length })
      if (count <= 10) {
        const summary = ids.map((id) => HEROES_BY_ID[id]).map((h) => `${h.name} (${RARITY_LABEL[h.rarity]})`).join(", ")
        toast.success(`Triệu hồi: ${summary}`)
      } else {
        const byRarity = ids.reduce((acc, id) => {
          const r = HEROES_BY_ID[id]?.rarity ?? "common"
          acc[r] = (acc[r] ?? 0) + 1
          return acc
        }, {} as Record<string, number>)
        const summary = ["legendary","mythic","celestial","epic"].filter(r => byRarity[r]).map(r => `${byRarity[r]} ${RARITY_LABEL[r as Rarity]}`).join(", ")
        toast.success(`Triệu hồi x${count}: ${summary || "Hoàn thành!"}`)
      }
    },
    [state.gems, state.activeEvents, state.luckBuff, state.gachaPity],
  )

  const rollHeroGold = useCallback(
    (count: 1 | 10 | 100) => {
      // Gold banner: x1=500g, x10=4500g, x100=50000g (giá cố định)
      const baseCost = count === 1 ? 500 : count === 10 ? 4500 : 50000
      const priceMult = getEventPriceMultiplier(state)
      const cost = Math.round(baseCost * priceMult)
      if (state.gold < cost) {
        toast.error("Không đủ vàng.")
        return
      }
      dispatch({ type: "ADD_GOLD", amount: -cost })
      const ids: string[] = []
      const baseLuckMult = state.luckBuff ? [1, 1.25, 1.50, 1.75][state.luckBuff.tier] : 1
      const celestialMult = getGachaLuckMultiplier(state)
      const luckMult = baseLuckMult * celestialMult
      const rates = luckMult > 1 ? applyLuckToRates(HERO_GACHA_RATES_GOLD, luckMult) : HERO_GACHA_RATES_GOLD

      // Epic 7% → hard pity 50, soft pity 35→50 (+7%/pull)
      let { goldSinceEpic } = (state.gachaPity ?? { gemSinceLegendary: 0, gemSinceMythic: 0, goldSinceEpic: 0 })

      for (let i = 0; i < count; i++) {
        goldSinceEpic++
        let rarity = rollRarity(rates) as Rarity

        // Hard pity pull 50 → đảm bảo epic
        if (goldSinceEpic >= 50 && rarityRank(rarity) < 2) {
          rarity = "epic"
        }
        // Soft pity pull 35→49, +7% mỗi pull
        else if (goldSinceEpic >= 35 && rarityRank(rarity) < 2) {
          const softBoost = (goldSinceEpic - 34) * 0.07
          if (Math.random() < Math.min(softBoost, 1)) rarity = "epic"
        }

        // Multi-pull safety: pull cuối đảm bảo hiếm+
        if ((count === 10 || count === 100) && i === count - 1 && rarityRank(rarity) < 1) rarity = "rare"

        if (rarityRank(rarity) >= 2) goldSinceEpic = 0

        const pool = HEROES_BY_RARITY[rarity] || []
        const tpl = pool[Math.floor(Math.random() * pool.length)]
        if (tpl) ids.push(tpl.id)
      }

      dispatch({ type: "UPDATE_GACHA_PITY", gold: { goldSinceEpic } })
      if (state.luckBuff) {
        const newRollsLeft = state.luckBuff.rollsLeft - count
        dispatch({ type: "SET_LUCK_BUFF_ROLLS", rollsLeft: Math.max(0, newRollsLeft) })
      }
      dispatch({ type: "ADD_HEROES", templateIds: ids })
      dispatch({ type: "QUEST_ON_RECRUIT", count: ids.length })
      if (count <= 10) {
        const summary = ids.map((id) => HEROES_BY_ID[id]).map((h) => `${h.name} (${RARITY_LABEL[h.rarity]})`).join(", ")
        toast.success(`Triệu hồi: ${summary}`)
      } else {
        const byRarity = ids.reduce((acc, id) => {
          const r = HEROES_BY_ID[id]?.rarity ?? "common"
          acc[r] = (acc[r] ?? 0) + 1
          return acc
        }, {} as Record<string, number>)
        const summary = ["epic","rare"].filter(r => byRarity[r]).map(r => `${byRarity[r]} ${RARITY_LABEL[r as Rarity]}`).join(", ")
        toast.success(`Triệu hồi x${count}: ${summary || "Hoàn thành!"}`)
      }
    },
    [state.gold, state.activeEvents, state.luckBuff, state.gachaPity],
  )

  const digArtifact = useCallback(
    (count: 1 | 10 | 100 = 1) => {
    const cost = 60
    const totalCost = cost * count
    if (state.gold < totalCost) {
      toast.error(`Cần ${totalCost} vàng để đào x${count}.`)
      return
    }
    dispatch({ type: "ADD_GOLD", amount: -totalCost })

    if (count === 1) {
      dispatch({ type: "INC_DIG" })
      const result = rollRarity(DIG_RATES)
      if (result === "nothing") {
        dispatch({ type: "PUSH_NOTIFY", text: "Đào trúng đất đá. Không có gì." })
        toast("Không tìm thấy gì có giá trị...", { icon: "🪨" })
        return
      }
      const artifacts = Object.values(ITEMS_BY_ID).filter(
        (i) => i.kind === "artifact" && i.rarity === result,
      )
      const drop = artifacts[Math.floor(Math.random() * artifacts.length)]
      if (drop) {
        dispatch({ type: "ADD_ITEM", itemId: drop.id, quantity: 1 })
        toast.success(`Đào được ${drop.name}!`, {
          description: `${RARITY_LABEL[drop.rarity]} — ${drop.description}`,
        })
      }
    } else {
      // Batch dig: run count times, accumulate results
      const results: Record<string, number> = {}
      let nothingCount = 0
      for (let i = 0; i < count; i++) {
        dispatch({ type: "INC_DIG" })
        const result = rollRarity(DIG_RATES)
        if (result === "nothing") {
          nothingCount++
          continue
        }
        const artifacts = Object.values(ITEMS_BY_ID).filter(
          (i) => i.kind === "artifact" && i.rarity === result,
        )
        const drop = artifacts[Math.floor(Math.random() * artifacts.length)]
        if (drop) {
          results[drop.id] = (results[drop.id] || 0) + 1
        }
      }
      // Dispatch all items found
      for (const [itemId, qty] of Object.entries(results)) {
        dispatch({ type: "ADD_ITEM", itemId, quantity: qty })
      }
      const foundCount = Object.values(results).reduce((a, b) => a + b, 0)
      if (foundCount === 0) {
        toast(`Đào x${count}: Không tìm thấy gì!`, { icon: "🪨" })
      } else {
        const summary = Object.entries(results)
          .map(([id, q]) => `${ITEMS_BY_ID[id]?.name ?? id} ×${q}`)
          .join(", ")
        toast.success(`Đào x${count}: ${foundCount} cổ vật! (${nothingCount} lần trượt)`, {
          description: summary,
        })
      }
    }
  }, [state.gold])

  const buyItem = useCallback(
    (itemId: string) => {
      const item = ITEMS_BY_ID[itemId]
      if (!item) return
      const priceMult = getEventPriceMultiplier(state)
      const finalPrice = Math.round(item.basePrice * priceMult)
      if (state.gold < finalPrice) {
        toast.error("Không đủ vàng.")
        return
      }
      dispatch({ type: "ADD_GOLD", amount: -finalPrice })
      dispatch({ type: "ADD_ITEM", itemId, quantity: 1 })
      toast.success(`Mua thành công ${item.name}.`)
    },
    [state.gold, state.activeEvents],
  )

  const buyShopItem = useCallback(
    (kind: import("./types").ShopKind, itemIndex: number) => {
      const stock = state.shopStock?.[kind]
      if (!stock) return
      const si = stock.items[itemIndex]
      if (!si || si.stock <= 0) { toast.error("Hết hàng."); return }
      const item = ITEMS_BY_ID[si.itemId]
      if (!item) return
      const priceMult = getEventPriceMultiplier(state)
      const finalPrice = Math.round(item.basePrice * priceMult)
      if (state.gold < finalPrice) { toast.error("Không đủ vàng."); return }
      // Deduct the event-adjusted price directly (BUY_SHOP_ITEM uses basePrice internally, so we override via ADD_GOLD)
      dispatch({ type: "ADD_GOLD", amount: -finalPrice })
      dispatch({ type: "BUY_SHOP_ITEM_NO_GOLD", kind, itemIndex })
      toast.success(`Mua thành công ${item.name}.`)
    },
    [state.gold, state.shopStock, state.activeEvents],
  )

  const restockShop = useCallback(
    (kind: import("./types").ShopKind) => {
      dispatch({ type: "RESTOCK_SHOP", kind })
      toast.success("Cửa hàng đã được restocked!")
    },
    [],
  )

  const buyPremiumShopItem = useCallback((itemIndex: number) => {
    const stock = state.premiumShopStock
    if (!stock) return
    const si = stock.items[itemIndex]
    if (!si || si.stock <= 0) { toast.error("Hết hàng."); return }
    const tpl = ITEMS_BY_ID[si.itemId]
    if (!tpl) return
    if (state.gold < tpl.basePrice) { toast.error("Không đủ vàng!"); return }
    dispatch({ type: "BUY_PREMIUM_SHOP_ITEM", itemIndex })
    toast.success(`✨ Mua thành công: ${tpl.name}`)
  }, [state.premiumShopStock, state.gold])

  const restockPremiumShop = useCallback(() => {
    dispatch({ type: "RESTOCK_PREMIUM_SHOP" })
    toast.success("🌟 Cửa Hàng Huyền Bảo đã được làm mới!")
  }, [])

  const sellItem = useCallback((uid: string) => {
    const inv = state.inventory.find((i) => i.uid === uid)
    if (!inv) return
    const it = ITEMS_BY_ID[inv.itemId]
    dispatch({ type: "SELL_ITEM", uid })
    toast.success(`Đã bán ${it?.name} (+${Math.round((it?.basePrice || 0) * 0.4)}🪙)`)
  }, [state.inventory])

  const useLuckPotion = useCallback((uid: string, tier: 1 | 2 | 3) => {
    const inv = state.inventory.find((i) => i.uid === uid)
    if (!inv || inv.quantity <= 0) return
    const labelMap = { 1: "Nhỏ (+25%)", 2: "Vừa (+50%)", 3: "Lớn (+75%)" }
    dispatch({ type: "USE_LUCK_POTION", uid, tier })
    toast.success(`✨ Thuốc May Mắn ${labelMap[tier]} đã kích hoạt! 100 lần roll tiếp theo được buff.`)
  }, [state.inventory])

  const setAutoSellRarities = useCallback((rarities: Rarity[]) => {
    dispatch({ type: "SET_AUTO_SELL_RARITIES", rarities })
  }, [])

  const equipBest = useCallback((heroUid: string) => {
    const owned = state.heroes.find((h) => h.uid === heroUid)
    if (!owned) return
    // Collect inventory uids already used by other heroes
    const usedInvUids = new Set(
      state.heroes
        .filter((h) => h.uid !== heroUid)
        .flatMap((h) => Object.values(h.equipmentInvUid ?? {}))
        .filter(Boolean)
    )
    const usedItemIds = new Set(
      state.heroes
        .filter((h) => h.uid !== heroUid)
        .flatMap((h) => Object.values(h.equipment))
        .filter(Boolean)
    )
    const slots: EquipSlot[] = ["weapon", "armor", "trinket"]
    for (const slot of slots) {
      const candidateEntries = state.inventory
        .filter((i) => {
          const it = ITEMS_BY_ID[i.itemId]
          return it && it.kind === "equip" && it.slot === slot &&
            !usedInvUids.has(i.uid) &&
            !(usedItemIds.has(i.itemId) && !i.innate)
        })
      if (candidateEntries.length === 0) continue
      const best = candidateEntries.sort((a, b) => {
        const ia = ITEMS_BY_ID[a.itemId], ib = ITEMS_BY_ID[b.itemId]
        const sumA = Object.values(ia?.stats || {}).reduce((x, y) => x + (y as number), 0)
        const sumB = Object.values(ib?.stats || {}).reduce((x, y) => x + (y as number), 0)
        return sumB - sumA
      })[0]
      dispatch({ type: "EQUIP_ITEM", heroUid, slot, itemId: best.itemId, invUid: best.uid })
    }
    toast.success("Đã trang bị tự động.")
  }, [state.heroes, state.inventory])

  const startCombat = useCallback(() => {
    const filled = state.team.filter((u) => !!u)
    if (filled.length === 0) {
      toast.error("Hãy chọn ít nhất 1 anh hùng vào đội.")
      return
    }
    const teamRows = state.teamRows ?? []
    const hasFront = filled.some((_, i) => teamRows[i] === "front")
    if (!hasFront) {
      toast.error("Đội hình phải có ít nhất 1 tướng ở hàng trước!")
      return
    }
    dispatch({ type: "START_COMBAT" })
  }, [state.team, state.teamRows])

  const startWatchCombat = useCallback(() => {
    const filled = state.team.filter((u) => !!u)
    if (filled.length === 0) {
      toast.error("Hãy chọn ít nhất 1 anh hùng vào đội.")
      return
    }
    const teamRows = state.teamRows ?? []
    const hasFront = filled.some((_, i) => teamRows[i] === "front")
    if (!hasFront) {
      toast.error("Đội hình phải có ít nhất 1 tướng ở hàng trước!")
      return
    }
    dispatch({ type: "START_WATCH_COMBAT" })
  }, [state.team, state.teamRows])


  // Flip combat state perspective: swap "player" and "enemy" unit sides
  // Used so player2 always sees themselves as "player" side
  const flipCombatPerspective = useCallback((cs: import("./types").CombatState): import("./types").CombatState => {
    const flipped = JSON.parse(JSON.stringify(cs)) as import("./types").CombatState
    for (const u of flipped.units) {
      u.side = u.side === "player" ? "enemy" : "player"
    }
    // awaitingPlayerInput: true if currently active unit is now on player side
    const activeUid = flipped.order[flipped.activeUnitIndex]
    const activeUnit = flipped.units.find(u => u.uid === activeUid)
    flipped.awaitingPlayerInput = activeUnit?.side === "player"
    return flipped
  }, [])

  // PvP session refs — track active session without causing re-renders
  const pvpSessionIdRef = useRef<string | null>(null)
  const pvpOpponentRef = useRef<string | null>(null)
  const pvpMyUsernameRef = useRef<string | null>(null)
  const pvpUnsubRef = useRef<(() => void) | null>(null)

  const startPvpCombat = useCallback((
    opponentHeroes: OwnedHero[],
    opponentStats: GameState["playerStats"],
    sessionId?: string,
    opponentUsername?: string,
    myUsername?: string,
    isPlayer2?: boolean,
  ) => {
    const filled = state.team.filter((u) => !!u)
    if (filled.length === 0) {
      toast.error("Hãy chọn ít nhất 1 anh hùng vào đội trước khi PvP.")
      return
    }
    const teamRows = state.teamRows ?? []
    const hasFront = filled.some((_, i) => teamRows[i] === "front")
    if (!hasFront) {
      toast.error("Đội hình phải có ít nhất 1 tướng ở hàng trước!")
      return
    }

    // Store session info for turn sync
    pvpSessionIdRef.current = sessionId ?? null
    pvpOpponentRef.current = opponentUsername ?? null
    pvpMyUsernameRef.current = myUsername ?? null
    // Determine role: player1 = challenger (no flip), player2 = accepter (needs flip)
    // opponentUsername = the OTHER person. If I am player1, opponent is player2 and vice versa.
    // We pass myUsername explicitly so we can determine role accurately.

    // Unsubscribe from any previous session
    if (pvpUnsubRef.current) { pvpUnsubRef.current(); pvpUnsubRef.current = null }

    // Subscribe realtime if we have a session
    if (sessionId) {
      pvpUnsubRef.current = subscribePvpSession(sessionId, (session: PvpSession) => {
        // Session always stores state in player1 POV.
        // Only apply when it is NOW our turn (meaning opponent just pushed their move).
        if (session.turn_owner !== pvpMyUsernameRef.current) return

        const myRole = pvpMyUsernameRef.current === session.player1 ? "player1" : "player2"
        let nextState: import("./types").CombatState = {
          ...session.combat_state,
          isPvp: true,
          pvpMyRole: myRole,
        }
        // player2 sees the world flipped: their heroes are "enemy" in session storage
        if (myRole === "player2") {
          nextState = flipCombatPerspective(nextState) as typeof nextState
          nextState.isPvp = true
          nextState.pvpMyRole = "player2"
        }
        dispatch({ type: "SET_COMBAT", state: nextState })

        if (session.combat_state.ended) {
          pvpSessionIdRef.current = null
          if (pvpUnsubRef.current) { pvpUnsubRef.current(); pvpUnsubRef.current = null }
        }
      })
    }

    dispatch({ type: "START_PVP_COMBAT", opponentHeroes, opponentStats })

    // FIX: Apply pvpMyRole + perspective flip synchronously via a follow-up dispatch on next tick.
    // Previously used setTimeout(0) which is a race condition — if the component unmounts or
    // another dispatch fires between START_PVP_COMBAT and the timeout, combat state is wrong.
    // Using Promise.resolve().then() (microtask) guarantees it runs before any paint but after
    // the reducer has settled, which is safe and deterministic.
    Promise.resolve().then(() => {
      const cs = combatRef.current
      if (!cs) return
      let patched = { ...cs, isPvp: !!sessionId, pvpMyRole: (isPlayer2 ? "player2" : "player1") as "player1" | "player2" }
      if (isPlayer2) {
        patched = flipCombatPerspective(patched) as typeof patched
        patched.isPvp = !!sessionId
        patched.pvpMyRole = "player2"
      }
      dispatch({ type: "SET_COMBAT", state: patched })
    })
  }, [state.team, state.teamRows, flipCombatPerspective])

  // ============================================================
  // Combat actions — drives the player turn, then advances AI
  // ============================================================

  const combatRef = useRef(state.combat)
  useEffect(() => { combatRef.current = state.combat }, [state.combat])



  const advanceTurn = useCallback((next: CombatState) => {
    // ── RESERVE SUBSTITUTION ─────────────────────────────────────────────────
    // When a player unit dies, check if there's a matching reserve unit to bring in.
    // Priority: front-reserve replaces dead front hero, back-reserve replaces dead back hero.
    // Special case: if front hero died but only back-reserve exists →
    //   promote a living back hero to front, then substitute back-reserve into back.
    if (next.reserveUnits && next.reserveUnits.length > 0) {
      const deadPlayerUnits = next.units.filter(u => u.side === "player" && u.hp <= 0)
      for (const dead of deadPlayerUnits) {
        // Skip if already processed (tagged)
        if ((dead as any).__reserveProcessed) continue
        ;(dead as any).__reserveProcessed = true

        const deadRow = dead.row
        // Find matching reserve (same row preference)
        const matchIdx = next.reserveUnits.findIndex(r => r.row === deadRow)

        if (matchIdx >= 0) {
          // Direct substitution: reserve enters on the same row
          const [sub] = next.reserveUnits.splice(matchIdx, 1)
          next.units.push(sub)
          // Insert into turn order after current active unit so they act this round
          const insertPos = Math.min(next.activeUnitIndex + 1, next.order.length)
          next.order.splice(insertPos, 0, sub.uid)
          next.log.push({ id: uid(), text: `🔄 ${sub.name} (Dự Bị) vào sân thay thế ${dead.name}!`, kind: "system" as const })
        } else if (deadRow === "front") {
          // Front hero died, no front-reserve → check if there's a back-reserve
          const backReserveIdx = next.reserveUnits.findIndex(r => r.row === "back")
          if (backReserveIdx >= 0) {
            // Promote a living back hero to front
            const backHeroToPromote = next.units.find(u => u.side === "player" && u.row === "back" && u.hp > 0)
            if (backHeroToPromote) {
              backHeroToPromote.row = "front"
              next.log.push({ id: uid(), text: `⚔ ${backHeroToPromote.name} tiến lên hàng trước thay ${dead.name}!`, kind: "system" as const })
              // Now substitute back-reserve into back row
              const [sub] = next.reserveUnits.splice(backReserveIdx, 1)
              sub.row = "back"
              next.units.push(sub)
              const insertPos = Math.min(next.activeUnitIndex + 1, next.order.length)
              next.order.splice(insertPos, 0, sub.uid)
              next.log.push({ id: uid(), text: `🔄 ${sub.name} (Dự Bị Hàng Sau) vào sân ở hàng sau!`, kind: "system" as const })
            }
            // No living back hero to promote → back reserve still enters back row
            else {
              const [sub] = next.reserveUnits.splice(backReserveIdx, 1)
              sub.row = "back"
              next.units.push(sub)
              const insertPos = Math.min(next.activeUnitIndex + 1, next.order.length)
              next.order.splice(insertPos, 0, sub.uid)
              next.log.push({ id: uid(), text: `🔄 ${sub.name} (Dự Bị) vào sân ở hàng sau!`, kind: "system" as const })
            }
          }
        }
        // (Back hero died, no back-reserve, no special fallback needed)
      }
    }

    // ── ENEMY RESERVE SUBSTITUTION ───────────────────────────────────────────
    if (next.enemyReserveUnits && next.enemyReserveUnits.length > 0) {
      const deadEnemies = next.units.filter(u => u.side === "enemy" && u.hp <= 0)
      for (const dead of deadEnemies) {
        if ((dead as any).__reserveProcessed) continue
        ;(dead as any).__reserveProcessed = true
        const deadRow = dead.row
        const matchIdx = next.enemyReserveUnits.findIndex(r => r.row === deadRow)
        if (matchIdx >= 0) {
          const [sub] = next.enemyReserveUnits.splice(matchIdx, 1)
          next.units.push(sub)
          const insertPos = Math.min(next.activeUnitIndex + 1, next.order.length)
          next.order.splice(insertPos, 0, sub.uid)
          next.log.push({ id: uid(), text: `⚠️ ${sub.name} (Dự Bị Địch) xuất hiện thay ${dead.name}!`, kind: "system" as const })
        } else if (deadRow === "front") {
          const backReserveIdx = next.enemyReserveUnits.findIndex(r => r.row === "back")
          if (backReserveIdx >= 0) {
            const backToPromote = next.units.find(u => u.side === "enemy" && u.row === "back" && u.hp > 0)
            if (backToPromote) {
              backToPromote.row = "front"
              next.log.push({ id: uid(), text: `⚔ ${backToPromote.name} (địch) tiến lên hàng trước!`, kind: "system" as const })
            }
            const [sub] = next.enemyReserveUnits.splice(backReserveIdx, 1)
            sub.row = backToPromote ? "back" : "front"
            next.units.push(sub)
            const insertPos = Math.min(next.activeUnitIndex + 1, next.order.length)
            next.order.splice(insertPos, 0, sub.uid)
            next.log.push({ id: uid(), text: `⚠️ ${sub.name} (Dự Bị Địch) xuất hiện!`, kind: "system" as const })
          }
        }
      }
    }

    // Front-row promotion: if all player front-row units are dead, back-row units step up
    {
      const playerFrontAlive = next.units.filter(u => u.side === "player" && u.row === "front" && u.hp > 0)
      const playerBackAlive  = next.units.filter(u => u.side === "player" && u.row === "back"  && u.hp > 0)
      if (playerFrontAlive.length === 0 && playerBackAlive.length > 0) {
        for (const u of playerBackAlive) { u.row = "front" }
        next.log.push({ id: uid(), text: "⚔ Hàng trước đã ngã! Hàng sau tiến lên chiến đấu!", kind: "info" })
      }
      // Same for enemy side
      const enemyFrontAlive = next.units.filter(u => u.side === "enemy" && u.row === "front" && u.hp > 0)
      const enemyBackAlive  = next.units.filter(u => u.side === "enemy" && u.row === "back"  && u.hp > 0)
      if (enemyFrontAlive.length === 0 && enemyBackAlive.length > 0) {
        for (const u of enemyBackAlive) { u.row = "front" }
        next.log.push({ id: uid(), text: "⚔ Hàng trước kẻ địch bị tiêu diệt! Hàng sau của chúng tiến lên!", kind: "info" })
      }
    }
    // FIX: increment global turn counter
    next.turn = (next.turn || 0) + 1
    // FIX: Check end immediately after any action (catches kills from damage/DoT)
    {
      const immediateEnd = checkEnded(next)
      if (immediateEnd) {
        next.ended = immediateEnd
        if (immediateEnd === "victory") {
          const rewards = computeRewards(next.stage)
          next.rewards = rewards
          next.log.push({ id: uid(), text: `🏆 Chiến thắng! +${rewards.gold}🪙 +${rewards.gems}💎 +${rewards.xp} XP`, kind: "victory" })
        } else {
          next.log.push({ id: uid(), text: "💀 Thất bại! Hãy huấn luyện và quay lại.", kind: "defeat" })
        }
        next.awaitingPlayerInput = false
        return next
      }
    }
    // Skip dead units, recompute order each round when needed
    let safety = 50
    while (safety-- > 0) {
      // Check end
      const ended = checkEnded(next)
      if (ended) {
        next.ended = ended
        if (ended === "victory") {
          const rewards = computeRewards(next.stage)
          next.rewards = rewards
          next.log.push({ id: uid(), text: `🏆 Chiến thắng! +${rewards.gold}🪙 +${rewards.gems}💎 +${rewards.xp} XP`, kind: "victory" })
        } else {
          next.log.push({ id: uid(), text: "💀 Thất bại! Hãy huấn luyện và quay lại.", kind: "defeat" })
        }
        next.awaitingPlayerInput = false
        return next
      }

      next.activeUnitIndex++
      // ── Per-unit end-of-turn: DoT, regen, cooldowns, status ticks for the unit that JUST acted ──
      // (The unit that just acted is at index-1 after the increment above)
      {
        const prevUid = next.order[next.activeUnitIndex - 1]
        const prevUnit = prevUid ? next.units.find(u => u.uid === prevUid) : null
        if (prevUnit && prevUnit.hp > 0) processEndOfTurn(next, prevUnit)
      }
      // Recompute order if exhausted
      if (next.activeUnitIndex >= next.order.length) {
        // Snapshot alive units BEFORE end-of-round processing so we can detect new deaths
        const aliveBeforeEOT = new Set(next.units.filter(u => u.hp > 0).map(u => u.uid))

        next.round++
        // (processEndOfTurn is now called per-unit after each action/stun-skip, not batched here)

        // Fire onAllyDeath — only for units that NEWLY died this round (not from prior rounds)
        const newDeadPlayerUids = next.units
          .filter(u => u.side === "player" && u.hp <= 0 && aliveBeforeEOT.has(u.uid))
          .map(u => u.uid)
        if (newDeadPlayerUids.length > 0) {
          for (const u of next.units.filter(u2 => u2.side === "player" && u2.hp > 0)) {
            fireHook("onAllyDeath", next, u)
          }
        }
        const newDeadEnemyUids = next.units
          .filter(u => u.side === "enemy" && u.hp <= 0 && aliveBeforeEOT.has(u.uid))
          .map(u => u.uid)
        if (newDeadEnemyUids.length > 0) {
          for (const u of next.units.filter(u2 => u2.side === "enemy" && u2.hp > 0)) {
            fireHook("onAllyDeath", next, u)
          }
        }

        // Fire onRoundEnd for all alive units (both sides)
        for (const u of next.units.filter(u2 => u2.hp > 0)) {
          fireHook("onRoundEnd", next, u)
        }
        // ⚔️ Chiến Hỏa — apply battlefield pressure after all end-of-turn effects
        applyWarFire(next)
        // FIX: Check end AFTER processEndOfTurn + Chiến Hỏa — DoT/fire can kill last enemy
        const endedAfterDoT = checkEnded(next)
        if (endedAfterDoT) {
          next.ended = endedAfterDoT
          if (endedAfterDoT === "victory") {
            const rewards = computeRewards(next.stage)
            next.rewards = rewards
            next.log.push({ id: uid(), text: `🏆 Chiến thắng! +${rewards.gold}🪙 +${rewards.gems}💎 +${rewards.xp} XP`, kind: "victory" })
          } else {
            next.log.push({ id: uid(), text: "💀 Thất bại! Hãy huấn luyện và quay lại.", kind: "defeat" })
          }
          next.awaitingPlayerInput = false
          return next
        }
        // recompute order from alive units using effectiveSpd (accounts for spdUp/spdDown buffs)
        next.order = next.units
          .filter((u) => u.hp > 0)
          .slice()
          .sort((a, b) => effectiveSpd(b) - effectiveSpd(a))
          .map((u) => u.uid)
        next.activeUnitIndex = 0
      }
      const cur = next.units.find((u) => u.uid === next.order[next.activeUnitIndex])
      if (!cur || cur.hp <= 0) {
        // Dead unit still in order — skip it and move to next
        next.activeUnitIndex++
        continue
      }

      // FIX: Stunned — tick stun AND cooldowns, then skip
      if (cur.statuses.some((s) => s.kind === "stun")) {
        next.log.push({ id: uid(), text: `${cur.name} đang choáng — bỏ lượt.`, kind: "info" })
        cur.statuses = cur.statuses
          .map((s) => (s.kind === "stun" ? { ...s, turns: s.turns - 1 } : s))
          .filter((s) => s.turns > 0)
        // FIX: still tick cooldowns so unit isn't frozen in cooldown while stunned
        cur.cooldowns = cur.cooldowns.map((cd) => Math.max(0, cd - 1)) as [number, number, number]
        // FIX: run end-of-turn effects (DoT/regen) for stunned unit — they still take damage while stunned
        // Mark that cooldowns were already ticked so processEndOfTurn skips its own cooldown tick
        ;(cur as any).__cooldownsAlreadyTicked = true
        processEndOfTurn(next, cur)
        ;(cur as any).__cooldownsAlreadyTicked = false
        next.activeUnitIndex++
        continue
      }

      // FIX: Grant energy at start of own turn (was missing — onUnitTurnStart was declared but never called)
      onUnitTurnStart(cur, next)

      // ⚡ ORDER INNATE v3 — vị trí, cooldown, energy share, taunt, regen...
      {
        const idx = next.activeUnitIndex
        const prevUid = idx > 0 ? next.order[idx - 1] : undefined
        const nextUid = next.order[idx + 1]
        const adjPrev = prevUid ? next.units.find(u => u.uid === prevUid && u.hp > 0) : undefined
        const adjNext = nextUid ? next.units.find(u => u.uid === nextUid && u.hp > 0) : undefined
        processOrderInnate(cur, adjPrev, adjNext, next)
      }

      next.awaitingPlayerInput = cur.side === "player"
      return next
    }
    return next
  }, [])

  // After applying an action, advance turn & schedule AI step if needed
  // Shared clone helper — avoids repeating the same deep-clone inline everywhere.
  // Only clones units array + unit statuses/cooldowns; log is spread-cloned once.
  const cloneCombat = useCallback((cs: CombatState): CombatState => ({
    ...cs,
    units: cs.units.map((u) => ({
      ...u,
      statuses: u.statuses.slice(),
      cooldowns: u.cooldowns.slice() as [number, number, number],
      itemPassives: u.itemPassives, // immutable ref, no clone needed
    })),
    log: cs.log, // append-only — share the reference; combat.ts always pushes
    order: cs.order.slice(),
    reserveUnits: (cs.reserveUnits ?? []).map((u) => ({
      ...u,
      statuses: u.statuses.slice(),
      cooldowns: u.cooldowns.slice() as [number, number, number],
      itemPassives: u.itemPassives,
    })),
    enemyReserveUnits: (cs.enemyReserveUnits ?? []).map((u) => ({
      ...u,
      statuses: u.statuses.slice(),
      cooldowns: u.cooldowns.slice() as [number, number, number],
      itemPassives: u.itemPassives,
    })),
  }), [])

  const stepAI = useCallback(
    (combat: CombatState) => {
      let next = cloneCombat(combat)
      let safetyLimit = 30

      let cur = next.units.find((u) => u.uid === next.order[next.activeUnitIndex]) ?? null
      // Watch mode: AI drives BOTH sides. Normal mode: enemy side only.
      while (
        cur &&
        (cur.side === "enemy" || next.watchMode) &&
        next.ended === null &&
        safetyLimit-- > 0
      ) {
        const action = aiChooseAction(next, cur)
        if (action.kind === "skill") {
          performSkill(next, cur, action.skillIndex, action.targetUid)
        } else if (action.kind === "rowChange") {
          performAIRowChange(next, cur)
        } else {
          const target = action.targetUid
            ? next.units.find((u) => u.uid === action.targetUid)
            : undefined
          if (target) performBasicAttack(next, cur, target)
          else break
        }
        next = advanceTurn(next)
        // In watch mode never pause for player input
        if (next.watchMode) next.awaitingPlayerInput = false
        cur = next.units.find((u) => u.uid === next.order[next.activeUnitIndex]) ?? null
        // Watch mode: stop after ONE action so UI re-renders between each action
        if (next.watchMode) break
      }
      return next
    },
    [advanceTurn, cloneCombat],
  )
  const finishCombatRewards = useCallback(
    (combat: CombatState) => {
      const isTowerCombat = !!state.towerState

      // ── Build & save battle record ──────────────────────────────────────
      if (combat.ended && combat.ended !== "fled" || combat.ended === "fled") {
        const playerUnits = combat.units.filter(u => u.side === "player")
        const enemyUnits  = combat.units.filter(u => u.side === "enemy")

        const toSnap = (u: typeof playerUnits[0]): import("./types").BattleHeroSnapshot => ({
          templateId: u.templateId ?? u.id,
          name:       u.name,
          rarity:     u.rarity,
          role:       u.role,
          level:      u.level ?? 1,
          hpMax:      u.hpMax,
          hpFinal:    Math.max(0, u.hp),
          dead:       u.hp <= 0,
        })

        // Death order — units that died, sorted by order they appear in log
        const deadPlayers = playerUnits.filter(u => u.hp <= 0).map(u => u.templateId ?? u.id)
        const deadEnemies  = enemyUnits.filter(u => u.hp <= 0).map(u => u.name)

        // Killed-by analysis: scan log backwards for "X bị tiêu diệt" near last damage from enemy
        const killedBy: Record<string, string> = {}
        const logTexts = combat.log.map(l => l.text)
        for (const pu of playerUnits.filter(u => u.hp <= 0)) {
          const heroName = pu.name
          // Find last log entry mentioning this hero dying
          const idx = [...logTexts].reverse().findIndex(t => t.includes(heroName) && (t.includes("tiêu diệt") || t.includes("chết") || t.includes("tử vong") || t.includes("bị hạ")))
          if (idx >= 0) {
            const lineIdx = logTexts.length - 1 - idx
            // Look up to 5 lines before for attacker
            const context = logTexts.slice(Math.max(0, lineIdx - 5), lineIdx + 1).join(" ")
            const enemyMatch = enemyUnits.find(e => context.includes(e.name))
            if (enemyMatch) killedBy[pu.templateId ?? pu.id] = enemyMatch.name
          }
        }

        // Defeat reason analysis
        const defeatReasons: string[] = []
        if (combat.ended === "defeat") {
          const deadCount = playerUnits.filter(u => u.hp <= 0).length
          const totalCount = playerUnits.length
          if (deadCount === totalCount) defeatReasons.push("Toàn bộ đội hình bị tiêu diệt")

          // Speed difference
          const playerAvgSpd = playerUnits.reduce((s,u) => s + (u.stats?.spd ?? 0), 0) / Math.max(1, playerUnits.length)
          const enemyAvgSpd  = enemyUnits.reduce((s,u)  => s + (u.stats?.spd ?? 0), 0) / Math.max(1, enemyUnits.length)
          if (enemyAvgSpd > playerAvgSpd * 1.25) defeatReasons.push(`Địch nhanh hơn đáng kể (SPD ${Math.round(enemyAvgSpd)} vs ${Math.round(playerAvgSpd)})`)

          // HP difference
          const playerAvgHp = playerUnits.reduce((s,u) => s + u.hpMax, 0) / Math.max(1, playerUnits.length)
          const enemyAvgHp  = enemyUnits.reduce((s,u)  => s + u.hpMax, 0) / Math.max(1, enemyUnits.length)
          if (enemyAvgHp > playerAvgHp * 1.4) defeatReasons.push(`Địch có HP lớn hơn nhiều (${Math.round(enemyAvgHp)} vs ${Math.round(playerAvgHp)})`)

          // Rounds lasted
          if (combat.round <= 3) defeatReasons.push(`Thua nhanh chỉ sau ${combat.round} vòng — đội hình quá yếu so với địch`)
          else if (combat.round >= 12) defeatReasons.push(`Trận kéo dài ${combat.round} vòng — sát thương không đủ để hạ địch`)

          // Heroes that fell early
          const earlyDeaths = Object.entries(killedBy)
          if (earlyDeaths.length > 0) {
            defeatReasons.push(`Anh hùng bị hạ: ${earlyDeaths.map(([tid, by]) => {
              const pu = playerUnits.find(u => (u.templateId ?? u.id) === tid)
              return `${pu?.name ?? tid} (bởi ${by})`
            }).join(", ")}`)
          }

          if (defeatReasons.length === 0) defeatReasons.push("Sức mạnh tổng thể của địch vượt trội")
        }

        // Synergies active this battle
        const synergiesUsed: string[] = []
        for (const u of playerUnits) {
          if (u.synergyText) synergiesUsed.push(...u.synergyText)
        }
        const uniqueSynergies = [...new Set(synergiesUsed)]

        const goldDelta = combat.ended === "victory" && combat.rewards
          ? combat.rewards.gold
          : combat.ended === "defeat" && !isTowerCombat
            ? -(50 + combat.stage * 10)
            : 0

        const record: import("./types").BattleRecord = {
          id:       Math.random().toString(36).slice(2),
          timestamp: Date.now(),
          result:   combat.ended ?? "fled",
          stage:    combat.stage,
          isTower:  isTowerCombat,
          towerFloor: isTowerCombat ? (state.towerState?.floor ?? 0) : undefined,
          isPvp:    !!combat.isPvp,
          rounds:   combat.round,
          goldDelta,
          gemsEarned: combat.ended === "victory" && combat.rewards ? combat.rewards.gems : 0,
          playerTeam:    playerUnits.map(toSnap),
          enemyTeam:     enemyUnits.map(toSnap),
          log:           combat.log.slice(-80), // last 80 entries
          deathOrder:    deadPlayers,
          killedBy,
          synergiesUsed: uniqueSynergies,
          defeatReasons,
        }
        dispatch({ type: "SAVE_BATTLE_RECORD", record })
      }
      // ── End battle record ───────────────────────────────────────────────

      if (combat.ended === "victory" && combat.rewards) {
        // Single atomic dispatch — no intermediate re-renders between reward steps
        const isWatchMode = !!combat.watchMode
        dispatch({ type: "BATCH_COMBAT_REWARDS", combat, isTowerCombat, isWatchMode })

        // Win streak milestone toasts — chỉ hiện khi trận là "thử thách thực sự"
        if (!isWatchMode && !isTowerCombat) {
          const hadDeaths = combat.units.some(u => u.side === "player" && u.hp <= 0)

          // Tính challenge ratio giống reducer
          const teamHeroes = state.heroes.filter(h => state.team.includes(h.uid))
          const playerAvgLevel = teamHeroes.length > 0
            ? teamHeroes.reduce((sum, h) => sum + h.level, 0) / teamHeroes.length
            : 1
          const enemyLevel = Math.max(1, Math.floor(combat.stage * 1.3))
          const challengeRatio = enemyLevel / playerAvgLevel
          const isChallenge = challengeRatio >= 0.75
          const isReplayStage = combat.stage <= (state.clearedStage ?? 0)

          // Kiểm tra farming (giống reducer)
          const lastStage = state.streakLastStage ?? -1
          const sameCount = state.streakSameStageCount ?? 0
          const isSameStageCheck = combat.stage === lastStage
          const newSameCountCheck = isSameStageCheck ? sameCount + 1 : 1
          const isFarmingCheck = newSameCountCheck > STREAK_MAX_SAME_STAGE

          if (!isChallenge && (state.winStreak ?? 0) > 0) {
            // Streak bị reset do tầng quá dễ
            toast.error(`💔 Chuỗi thắng mất! Tầng ${combat.stage} quá dễ (địch lv${Math.round(enemyLevel)} / ta lv${Math.round(playerAvgLevel)} — ${Math.round(challengeRatio*100)}%)`, { duration: 4000 })
          } else if (isChallenge && isFarmingCheck && (state.winStreak ?? 0) > 0) {
            // Streak bị reset do farm cùng tầng quá nhiều
            toast.error(`💔 Chuỗi thắng mất! Đã farm tầng ${combat.stage} quá ${STREAK_MAX_SAME_STAGE} lần liên tiếp.`, { duration: 4000 })
          } else if (isChallenge && !isFarmingCheck) {
            const newStreak  = (state.winStreak ?? 0) + 1
            const newPerfect = hadDeaths ? 0 : (state.perfectStreak ?? 0) + 1

            if (newStreak === 5)  toast.success("🔥 Đang nóng ×5 — vàng tăng 30%!", { duration: 3000 })
            if (newStreak === 8)  toast.success("🔥🔥 Bùng cháy ×8 — vàng tăng 60% + 1💎/trận!", { duration: 3500 })
            if (newStreak === 12) toast.success("🔥🔥🔥 Không thể cản ×12 — vàng ×2.0 + 2💎/trận!", { duration: 4000 })
            if (newStreak === 18) toast.success("💀 VÔ ĐỐI ×18 — vàng ×2.6 + 3💎/trận!", { duration: 5000 })

            if (!hadDeaths && newPerfect === 5) toast.success("⭐ Hoàn Hảo ×5 — nhận +1💎 thêm mỗi trận!", { duration: 3500 })
            if (!hadDeaths && newPerfect % 5 === 0 && newPerfect > 5) toast.success(`⭐ Hoàn Hảo ×${newPerfect} — +${Math.floor(newPerfect/5)}💎 mỗi trận!`, { duration: 3000 })
            if (hadDeaths && (state.perfectStreak ?? 0) >= 5) toast.warning("💔 Chuỗi hoàn hảo kết thúc! (có quân tử trận)", { duration: 2500 })

            // Cảnh báo sắp mất streak do farming
            if (isSameStageCheck && newSameCountCheck === STREAK_MAX_SAME_STAGE && (state.winStreak ?? 0) >= 1) {
              toast.warning(`⚠️ Cảnh báo: Lần cuối được farm tầng ${combat.stage}! Farm thêm sẽ mất chuỗi.`, { duration: 4000 })
            }
          }
        }
        // Check if this victory triggers a new day (battlesWon+1 divisible by 5)
        const nextBattlesWon = state.battlesWon + 1
        if (!isTowerCombat && nextBattlesWon % 5 === 0) {
          const nextDay = (state.currentDay ?? 1) + 1
          // We roll events the same way as the reducer to predict what will happen
          // Just show a generic "new day" toast — actual events shown in the Event tab
          setTimeout(() => {
            const newDayEvents = (state as any)._pendingEvents // can't access yet, use generic toast
            toast.info(`🌅 Ngày ${nextDay} bắt đầu! Kiểm tra tab Sự Kiện.`, { duration: 4000 })
          }, 800)
        }
      } else if (combat.ended === "defeat" && isTowerCombat) {
        // Tower defeat: save record and end run
        dispatch({ type: "TOWER_GIVE_UP" })
        const floor = state.towerState?.floor ?? 0
        toast.error(`Đội hình bị tiêu diệt tại Tầng ${floor} 💀`)
      } else if (combat.ended === "defeat" && !isTowerCombat) {
        // Normal battle defeat: lose gold equal to the stage (can go negative, no cap)
        const basePenalty = 50 + combat.stage * 10
        const penaltyMult = getEventPenaltyMultiplier(state)
        const penalty = Math.round(basePenalty * penaltyMult)
        dispatch({ type: "APPLY_DEFEAT_PENALTY", goldLoss: penalty })
        const warNote = penaltyMult > 1 ? " (📈+25% do chiến tranh)" : ""
        toast.error(`Thất bại! Mất ${penalty.toLocaleString()}🪙 vàng!${warNote}`)
      } else if (combat.ended === "fled" && isTowerCombat) {
        dispatch({ type: "TOWER_GIVE_UP" })
      }
    },
    [state.towerState, state.battlesWon, state.currentDay, state.activeEvents, state.winStreak, state.perfectStreak, state.heroes, state.team, state.clearedStage],
  )

  // Run AI step when:
  // 1. Normal: enemy turn (awaitingPlayerInput = false)
  // 2. WatchMode: any turn (AI drives both sides)
  // PvP: never auto-step — opponent controls their own side via Supabase sync
  useEffect(() => {
    if (!state.combat || state.combat.ended) return
    if (state.combat.isPvp) return // PvP: no AI, opponent acts via realtime sync
    const shouldStep = state.combat.watchMode
      ? true
      : !state.combat.awaitingPlayerInput
    if (!shouldStep) return
    const delay = state.combat.watchMode
      ? (state.combat.watchSpeed === 2 ? 400 : 1200)
      : 1200
    const timer = setTimeout(() => {
      const current = combatRef.current
      if (!current || current.ended) return
      if (!current.watchMode && current.awaitingPlayerInput) return
      const next = stepAI(current)
      if (next.watchMode && !next.ended) next.awaitingPlayerInput = false
      // Use startTransition so combat re-renders are lower priority than user input
      // requestAnimationFrame ensures we don't dispatch mid-layout
      requestAnimationFrame(() => {
        startTransition(() => {
          dispatch({ type: "SET_COMBAT", state: next })
          if (next.ended) finishCombatRewards(next)
        })
      })
    }, delay)
    return () => clearTimeout(timer)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.combat?.awaitingPlayerInput, state.combat?.activeUnitIndex, state.combat?.round, state.combat?.watchMode])

  const combatChooseSkill = useCallback(
    (skillIndex: 0 | 1 | 2, targetUid: string | null) => {
      const combat = combatRef.current
      if (!combat || combat.ended || !combat.awaitingPlayerInput) return
      const cur = combat.units.find((u) => u.uid === combat.order[combat.activeUnitIndex])
      if (!cur || cur.side !== "player") return
      if (cur.cooldowns[skillIndex] > 0) {
        toast.warning(`${cur.skills[skillIndex].name} còn ${cur.cooldowns[skillIndex]} lượt cooldown.`)
        return
      }
      let next: CombatState = cloneCombat(combat)
      const liveCur = next.units.find((u) => u.uid === cur.uid)!
      // Resolve row intercept for player single-target skills
      const resolvedTarget = targetUid ? resolvePlayerTarget(targetUid, liveCur.role, next.units) : targetUid
      performSkill(next, liveCur, skillIndex, resolvedTarget)
      next = advanceTurn(next)
      next = stepAI(next)
      dispatch({ type: "SET_COMBAT", state: next })
      // PvP sync: push our move to opponent after player acts
      if (pvpSessionIdRef.current && pvpOpponentRef.current && !next.awaitingPlayerInput) {
        const _sid = pvpSessionIdRef.current
        const _opp = pvpOpponentRef.current
        // Always store in player1 POV — player2 must flip before pushing
        const stateToStore = next.pvpMyRole === "player2" ? flipCombatPerspective(next) : next
        pushPvpTurn(_sid, _opp, stateToStore).catch(() => {})
      }
      if (next.ended) finishCombatRewards(next)
    },
    [advanceTurn, stepAI, finishCombatRewards, flipCombatPerspective],
  )

  const combatBasicAttack = useCallback(
    (targetUid: string) => {
      const combat = combatRef.current
      if (!combat || combat.ended || !combat.awaitingPlayerInput) return
      const cur = combat.units.find((u) => u.uid === combat.order[combat.activeUnitIndex])
      if (!cur || cur.side !== "player") return
      let next: CombatState = cloneCombat(combat)
      const liveCur = next.units.find((u) => u.uid === cur.uid)!
      // Resolve row intercept for player basic attacks
      const resolvedTargetUid = resolvePlayerTarget(targetUid, liveCur.role, next.units)
      const target = next.units.find((u) => u.uid === resolvedTargetUid)
      if (!target) return
      performBasicAttack(next, liveCur, target)
      next = advanceTurn(next)
      next = stepAI(next)
      dispatch({ type: "SET_COMBAT", state: next })
      // PvP sync: push our move to opponent after player acts
      if (pvpSessionIdRef.current && pvpOpponentRef.current && !next.awaitingPlayerInput) {
        const _sid = pvpSessionIdRef.current
        const _opp = pvpOpponentRef.current
        const stateToStore = next.pvpMyRole === "player2" ? flipCombatPerspective(next) : next
        pushPvpTurn(_sid, _opp, stateToStore).catch(() => {})
      }
      if (next.ended) finishCombatRewards(next)
    },
    [advanceTurn, stepAI, finishCombatRewards, flipCombatPerspective],
  )

  const combatUsePotion = useCallback(
    (inventoryItemUid: string, targetUid: string) => {
      const combat = combatRef.current
      if (!combat || combat.ended || !combat.awaitingPlayerInput) return
      let next: CombatState = cloneCombat(combat)
      const result = consumePotionInCombat(next, inventoryItemUid, targetUid, state.inventory)
      if (!result.ok) {
        toast.error(result.reason ?? "Không thể dùng bình thuốc.")
        return
      }
      dispatch({ type: "REMOVE_ITEM", uid: inventoryItemUid, quantity: 1 })
      // FIX: Do NOT call advanceTurn — using a potion does NOT consume the player's turn.
      // The player can still act normally after using a potion.
      // potionLastUsedRound is already updated inside consumePotionInCombat.
      dispatch({ type: "SET_COMBAT", state: next })
      toast.success("Đã dùng thuốc!")
    },
    [state.inventory],
  )

  const combatFlee = useCallback(() => {
    const combat = combatRef.current
    if (!combat) return
    const next = { ...combat, ended: "fled" as const }
    next.log.push({ id: uid(), text: "🏃 Bạn đã bỏ chạy khỏi trận đấu.", kind: "info" })
    dispatch({ type: "SET_COMBAT", state: next })
    // FIX: Use APPLY_DEFEAT_PENALTY instead of ADD_GOLD so flee can make gold go negative
    // (consistent with defeat penalty behavior — both should penalize equally)
    const losePenalty = Math.round(50 * getLosePenaltyMultiplier(state))
    dispatch({ type: "APPLY_DEFEAT_PENALTY", goldLoss: losePenalty })
    const warNote = getLosePenaltyMultiplier(state) > 1 ? " (tăng do sự kiện)" : ""
    toast.warning(`Bạn đã bỏ chạy. -${losePenalty}🪙${warNote}`)
  }, [state.gold, state.questState, state.activeEvents])

  const combatSkipTurn = useCallback(() => {
    const combat = combatRef.current
    if (!combat || combat.ended || !combat.awaitingPlayerInput) return
    const cur = combat.units.find((u) => u.uid === combat.order[combat.activeUnitIndex])
    if (!cur || cur.side !== "player") return
    let next: CombatState = cloneCombat(combat)
    const liveCur = next.units.find((u) => u.uid === cur.uid)!
    next.log.push({ id: uid(), text: `${liveCur.name} bỏ qua lượt.`, kind: "info" })
    next = advanceTurn(next)
    next = stepAI(next)
    dispatch({ type: "SET_COMBAT", state: next })
    // PvP sync: push our move to opponent after player acts
    if (pvpSessionIdRef.current && pvpOpponentRef.current && !next.awaitingPlayerInput) {
      const _sid = pvpSessionIdRef.current
      const _opp = pvpOpponentRef.current
      const stateToStore = next.pvpMyRole === "player2" ? flipCombatPerspective(next) : next
      pushPvpTurn(_sid, _opp, stateToStore).catch(() => {})
    }
    if (next.ended) finishCombatRewards(next)
  }, [advanceTurn, stepAI, finishCombatRewards, cloneCombat, flipCombatPerspective])

  const combatChangeRow = useCallback((unitUid: string) => {
    const combat = combatRef.current
    if (!combat || combat.ended || !combat.awaitingPlayerInput) return
    const cur = combat.units.find((u) => u.uid === combat.order[combat.activeUnitIndex])
    if (!cur || cur.side !== "player") return
    // Only the active unit can change row
    if (cur.uid !== unitUid) {
      toast.warning("Chỉ có thể đổi hàng tướng đang đến lượt!")
      return
    }
    let next: CombatState = cloneCombat(combat)
    const liveCur = next.units.find((u) => u.uid === unitUid)!
    const result = performRowChange(next, unitUid)
    if (!result.ok) {
      toast.warning(result.reason ?? "Không thể đổi hàng!")
      return
    }
    next = advanceTurn(next)
    next = stepAI(next)
    dispatch({ type: "SET_COMBAT", state: next })
    if (pvpSessionIdRef.current && pvpOpponentRef.current && !next.awaitingPlayerInput) {
      const _sid = pvpSessionIdRef.current
      const _opp = pvpOpponentRef.current
      const stateToStore = next.pvpMyRole === "player2" ? flipCombatPerspective(next) : next
      pushPvpTurn(_sid, _opp, stateToStore).catch(() => {})
    }
    if (next.ended) finishCombatRewards(next)
  }, [advanceTurn, stepAI, finishCombatRewards, cloneCombat, flipCombatPerspective])

  const resetGame = useCallback(() => {
    if (typeof window !== "undefined") window.localStorage.removeItem(getStorageKey())
    dispatch({ type: "RESET" })
    toast.success("Đã reset game.")
  }, [])

  const resetHeroSkills = useCallback((uid: string) => {
    const hero = state.heroes.find((h) => h.uid === uid)
    if (!hero) return
    const basePoints = hero.skillLevels.reduce((sum, lv, idx) => sum + (lv - 1) * (idx === 2 ? 2 : 1), 0)
    const bonusPoints = Object.values(hero.bonusSkillLevels ?? {}).reduce((sum, lv) => sum + (lv - 1), 0)
    const totalSpent = basePoints + bonusPoints
    const cost = 2000 + totalSpent * 500
    if (state.gold < cost) { toast.error(`Không đủ vàng. Cần ${cost.toLocaleString()}🪙`); return }
    dispatch({ type: "RESET_HERO_SKILLS", uid })
    const refunded = Math.floor(hero.level / 5)
    toast.success(`Đã reset điểm kỹ năng (-${cost.toLocaleString()}🪙). Hoàn lại ${refunded} điểm kỹ năng.`)
  }, [state.heroes, state.gold])

  const resetPlayerStats = useCallback(() => {
    const s = state.playerStats
    const totalSpent = Math.round(
      s.attackBonus / 4 + s.defenseBonus / 4 + s.hpBonus / 30 +
      s.magicBonus / 5 + s.speedBonus / 2 + s.critBonus
    )
    const GOLD_COST = 10000
    const GEM_COST = 1000
    if (state.gold < GOLD_COST) { toast.error(`Không đủ vàng. Cần ${GOLD_COST.toLocaleString()}🪙`); return }
    if (state.gems < GEM_COST) { toast.error(`Không đủ đá quý. Cần ${GEM_COST.toLocaleString()}💎`); return }
    dispatch({ type: "RESET_PLAYER_STATS" })
    toast.success(`Đã reset chỉ số (-${GOLD_COST.toLocaleString()}🪙 -${GEM_COST.toLocaleString()}💎). Hoàn lại ${totalSpent} điểm chỉ số.`)
  }, [state.playerStats, state.gold, state.gems])

  const unlockHeroSkill = useCallback((uid: string, skillId: string) => {
    dispatch({ type: "UNLOCK_HERO_SKILL", uid, skillId })
  }, [])

  const setTeamRow = useCallback((slot: number, row: BattleRow) => {
    dispatch({ type: "SET_TEAM_ROW", slot, row })
  }, [])

  const setReserveSlot = useCallback((slot: number, uid: string | null) => {
    dispatch({ type: "SET_RESERVE_SLOT", slot, uid })
  }, [])

  const setReserveRow = useCallback((slot: number, row: BattleRow) => {
    dispatch({ type: "SET_RESERVE_ROW", slot, row })
  }, [])

  const rollShardsWithGems = useCallback(() => {
    if (state.gems < 50) { toast.error("Cần 50 💎 để tung cầu phúc!"); return }
    dispatch({ type: "ROLL_SHARDS_GEMS" })
    // Luck bonus: +1/+2/+3 bonus shards based on tier
    if (state.luckBuff && state.luckBuff.rollsLeft > 0) {
      const bonusShards = state.luckBuff.tier // tier 1→+1, tier 2→+2, tier 3→+3
      // Split bonus evenly between blessing and pact
      dispatch({ type: "ADD_BLESSING_SHARDS", amount: Math.ceil(bonusShards / 2) })
      dispatch({ type: "ADD_PACT_SHARDS", amount: Math.floor(bonusShards / 2) })
      const newRollsLeft = state.luckBuff.rollsLeft - 1
      dispatch({ type: "SET_LUCK_BUFF_ROLLS", rollsLeft: Math.max(0, newRollsLeft) })
    }
    toast.success("Tung cầu phúc thành công!")
  }, [state.gems, state.luckBuff])

  const rollShardsWithGold = useCallback(() => {
    if (state.gold < 1000) { toast.error("Cần 1000 🪙 để tung cầu phúc!"); return }
    dispatch({ type: "ROLL_SHARDS_GOLD" })
    // Luck bonus shards
    if (state.luckBuff && state.luckBuff.rollsLeft > 0) {
      const bonusShards = state.luckBuff.tier
      dispatch({ type: "ADD_BLESSING_SHARDS", amount: Math.ceil(bonusShards / 2) })
      dispatch({ type: "ADD_PACT_SHARDS", amount: Math.floor(bonusShards / 2) })
      const newRollsLeft = state.luckBuff.rollsLeft - 1
      dispatch({ type: "SET_LUCK_BUFF_ROLLS", rollsLeft: Math.max(0, newRollsLeft) })
    }
    toast.success("Tung cầu phúc thành công!")
  }, [state.gold, state.luckBuff])

  const equipBlessingPact = useCallback((heroUid: string, blessingPactId: string) => {
    const bp = ALL_BLESSINGS_BY_ID[blessingPactId]
    if (!bp) return
    const shardKey = bp.kind === "blessing" ? "blessingShards" : "pactShards"
    const currentShards = (state[shardKey] ?? 0)
    if (currentShards < bp.shardCost) {
      toast.error(`Cần ${bp.shardCost} ${bp.kind === "blessing" ? "Mảnh Thiên Thần" : "Mảnh Ác Quỷ"}!`)
      return
    }
    // Check team uniqueness
    const teamUids = state.team.filter(Boolean) as string[]
    const conflict = state.heroes.find(h =>
      teamUids.includes(h.uid) && h.uid !== heroUid && h.blessingPactId === blessingPactId
    )
    if (conflict) {
      toast.error(`Không thể trang bị ${bp.name} cho 2 tướng trong đội!`)
      return
    }
    dispatch({ type: "EQUIP_BLESSING_PACT", heroUid, blessingPactId })
    toast.success(`${bp.name} đã được trang bị!`)
  }, [state.heroes, state.team, state.blessingShards, state.pactShards])

  const unequipBlessingPact = useCallback((heroUid: string) => {
    dispatch({ type: "UNEQUIP_BLESSING_PACT", heroUid })
    toast.success("Đã gỡ nội tại!")
  }, [])

  const towerStartRun = useCallback(() => {
    const filled = state.team.filter(u => !!u)
    if (filled.length === 0) {
      toast.error("Hãy chọn ít nhất 1 anh hùng vào đội.")
      return
    }
    dispatch({ type: "TOWER_START_RUN" })
  }, [state.team])

  const towerStartFloorCombat = useCallback(() => {
    dispatch({ type: "TOWER_START_FLOOR_COMBAT" })
  }, [])

  const towerGiveUp = useCallback(() => {
    const floor = state.towerState?.floor ?? 0
    const record = Math.max(state.towerRecord ?? 0, floor)
    dispatch({ type: "TOWER_GIVE_UP" })
    if (floor > 0) {
      dispatch({ type: "QUEST_ON_TOWER_FLOOR_CLEAR", floor })
    }
    toast.info(`Đã bỏ cuộc tại tầng ${floor}. Kỷ lục: Tầng ${record} 🗼`)
  }, [state.towerState, state.towerRecord])

  const towerContinue = useCallback(() => {
    const floor = state.towerState?.floor ?? 0
    dispatch({ type: "QUEST_ON_TOWER_FLOOR_CLEAR", floor })
    dispatch({ type: "TOWER_CONTINUE" })
  }, [state.towerState])

  // Stable actions object — only recreates when the action callbacks themselves change
  // (which happens infrequently, not on every state tick)
  const actions = useMemo(() => ({
    dispatch,
    rollHero,
    rollHeroGold,
    digArtifact,
    buyItem,
    buyShopItem,
    restockShop,
    buyPremiumShopItem,
    restockPremiumShop,
    sellItem,
    useLuckPotion,
    setAutoSellRarities,
    equipBest,
    startCombat,
    startPvpCombat,
    startWatchCombat,
    setTeamRow,
    combatChooseSkill,
    combatBasicAttack,
    combatUsePotion,
    combatFlee,
    combatSkipTurn,
    combatChangeRow,
    resetGame,
    resetHeroSkills,
    resetPlayerStats,
    unlockHeroSkill,
    rollShardsWithGems,
    rollShardsWithGold,
    equipBlessingPact,
    unequipBlessingPact,
    towerStartRun,
    towerStartFloorCombat,
    towerGiveUp,
    towerContinue,
    setReserveSlot,
    setReserveRow,
  }), [
    rollHero, rollHeroGold, digArtifact, buyItem, buyShopItem, restockShop, buyPremiumShopItem, restockPremiumShop,
    sellItem, useLuckPotion, setAutoSellRarities, equipBest, startCombat, startPvpCombat, startWatchCombat, setTeamRow, setReserveSlot, setReserveRow, combatChooseSkill,
    combatBasicAttack, combatUsePotion, combatFlee, combatSkipTurn, combatChangeRow, resetGame, resetHeroSkills,
    resetPlayerStats, unlockHeroSkill, rollShardsWithGems, rollShardsWithGold,
    equipBlessingPact, unequipBlessingPact, towerStartRun, towerStartFloorCombat,
    towerGiveUp, towerContinue,
  ])

  // Combined value for legacy useGame() — recreates on every state change (unavoidable for compat)
  const value = useMemo<GameContextValue>(
    () => ({ state, ...actions }),
    [state, actions],
  )

  // Split providers: ActionsContext is STABLE (actions only recreate when callbacks change, rarely)
  // StateContext updates every state change but components using useGameSelector avoid wasted renders
  return (
    <GameActionsContext.Provider value={actions}>
      <GameStateContext.Provider value={state}>
        <GameContext.Provider value={value}>{children}</GameContext.Provider>
      </GameStateContext.Provider>
    </GameActionsContext.Provider>
  )
}

export function useGame(): GameContextValue {
  const ctx = useContext(GameContext)
  if (!ctx) throw new Error("useGame must be used within GameProvider")
  return ctx
}

/**
 * Actions-only hook — NEVER causes re-renders from state changes.
 * Use this in components that only dispatch actions and don't read state.
 */
export function useGameActions(): GameActions {
  const ctx = useContext(GameActionsContext)
  if (!ctx) throw new Error("useGameActions must be used within GameProvider")
  return ctx
}

/**
 * Selector hook — subscribes only to the slice of state returned by `selector`.
 * Components using this won't re-render when unrelated parts of state change.
 * e.g. useGameSelector(s => s.gold) — only re-renders when gold changes.
 *
 * Uses Object.is comparison by default. Pass a custom `isEqual` for deep comparison.
 */
export function useGameSelector<T>(selector: (state: GameState) => T, isEqual?: (a: T, b: T) => boolean): T {
  const stateCtx = useContext(GameStateContext)
  if (!stateCtx) throw new Error("useGameSelector must be used within GameProvider")

  const selectorRef = useRef(selector)
  const isEqualRef = useRef(isEqual)
  selectorRef.current = selector
  isEqualRef.current = isEqual

  const prevRef = useRef<T>(selector(stateCtx))
  const selected = selector(stateCtx)

  // Only update ref if value actually changed (avoids stale closure issues)
  const eq = isEqualRef.current ?? Object.is
  if (!eq(prevRef.current, selected)) {
    prevRef.current = selected
  }

  return prevRef.current
}

// Re-export utilities used by UI
export { computeHeroStats, xpToNextLevel, playerXpToNextLevel }
export { RARITY_ORDER, RARITY_LABEL }
export { BLESSINGS, PACTS, ALL_BLESSINGS_BY_ID }

/** Full state — dùng cho cloud save. Prefer useGameSelector cho từng field. */
export function useGameState(): GameState {
  const ctx = useContext(GameStateContext)
  if (!ctx) throw new Error("useGameState must be used within GameProvider")
  return ctx
}

/** Dispatch LOAD action để restore save từ cloud. */
export function useLoadSave() {
  const ctx = useContext(GameActionsContext)
  if (!ctx) throw new Error("useLoadSave must be used within GameProvider")
  return (saveData: GameState) => {
    ctx.dispatch({ type: "LOAD", payload: saveData })
    // Re-init quests after cloud load so quest objectives reflect restored state
    setTimeout(() => ctx.dispatch({ type: "INIT_QUESTS" }), 50)
  }
}
