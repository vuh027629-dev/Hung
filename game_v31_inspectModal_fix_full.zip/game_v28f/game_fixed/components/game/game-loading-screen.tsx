"use client"

import { useEffect, useState, useRef } from "react"

// ─── Danh sách tất cả tab cần preload thực sự ────────────────────
const TAB_IMPORTS: Array<{ label: string; load: () => Promise<unknown> }> = [
  { label: "Chiến trường...",        load: () => import("./tabs/battle-tab") },
  { label: "Anh hùng...",            load: () => import("./tabs/heroes-tab") },
  { label: "Triệu hồi...",           load: () => import("./tabs/recruit-tab") },
  { label: "Cửa hàng...",            load: () => import("./tabs/shop-tab") },
  { label: "Nhiệm vụ...",            load: () => import("./tabs/quest-tab") },
  { label: "Kho đồ...",              load: () => import("./tabs/inventory-tab") },
  { label: "Thống kê...",            load: () => import("./tabs/stats-tab") },
  { label: "Phe phái & phước lành...", load: () => import("./tabs/blessing-pact-tab") },
  { label: "Tháp vô tận...",         load: () => import("./tabs/tower-tab") },
  { label: "Raid...",                load: () => import("./tabs/raid-tab") },
  { label: "Sự kiện...",             load: () => import("./tabs/event-tab") },
  { label: "Cộng đồng...",           load: () => import("./tabs/community-tab") },
  { label: "Thư viện...",            load: () => import("./tabs/codex-tab") },
  { label: "Nhật ký chiến đấu...",   load: () => import("./tabs/battle-log-tab") },
]

// ─── Particle ───────────────────────────────────────────────────
interface Particle { id: number; x: number; size: number; speed: number; opacity: number; hue: number; delay: number }
function useParticles(count = 28): Particle[] {
  const [particles] = useState<Particle[]>(() =>
    Array.from({ length: count }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      size: 1.5 + Math.random() * 3,
      speed: 8 + Math.random() * 16,
      opacity: 0.2 + Math.random() * 0.6,
      hue: [78, 195, 22, 300][Math.floor(Math.random() * 4)],
      delay: Math.random() * 6,
    }))
  )
  return particles
}

// ─── Rune ring ──────────────────────────────────────────────────
function RuneRing({ size = 200, spin = 12, opacity = 0.18, color = "oklch(0.78 0.165 78)", reverse = false }: {
  size?: number; spin?: number; opacity?: number; color?: string; reverse?: boolean
}) {
  const r = size / 2 - 4
  const circ = 2 * Math.PI * r
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}
      style={{ opacity, position: "absolute", animation: `${reverse ? "spinR" : "spinF"} ${spin}s linear infinite` }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color}
        strokeWidth="1" strokeDasharray={`${circ*0.06} ${circ*0.04}`} />
      {Array.from({ length: 8 }).map((_, i) => {
        const a = (i / 8) * Math.PI * 2
        return <circle key={i} cx={size/2 + r*Math.cos(a)} cy={size/2 + r*Math.sin(a)} r="2" fill={color} opacity="0.7" />
      })}
    </svg>
  )
}

// ─── Main ────────────────────────────────────────────────────────
export function GameLoadingScreen({ onComplete }: { onComplete: () => void }) {
  const [currentLabel, setCurrentLabel] = useState("Khởi động Aetheria...")
  const [completedCount, setCompletedCount] = useState(0)
  const [fadeOut, setFadeOut] = useState(false)
  const [visible, setVisible] = useState(true)
  const [displayPct, setDisplayPct] = useState(0)
  const targetPctRef = useRef(0)
  const displayPctRef = useRef(0)
  const particles = useParticles(28)
  const total = TAB_IMPORTS.length

  // Smooth progress interpolation
  useEffect(() => {
    let raf: number
    const tick = () => {
      const diff = targetPctRef.current - displayPctRef.current
      if (Math.abs(diff) > 0.2) {
        displayPctRef.current += diff * 0.10
        setDisplayPct(displayPctRef.current)
      } else {
        displayPctRef.current = targetPctRef.current
        setDisplayPct(targetPctRef.current)
      }
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [])

  // Thực sự preload tất cả tab song song
  useEffect(() => {
    let done = 0

    TAB_IMPORTS.forEach(({ label, load }) => {
      load()
        .then(() => {
          done++
          setCurrentLabel(`Đã tải: ${label}`)
          setCompletedCount(done)
          // Để lại 5% cuối cho bước "sẵn sàng"
          targetPctRef.current = Math.round((done / total) * 95)

          if (done === total) {
            // Tất cả đã load — chạy nốt đến 100% rồi fade
            setCurrentLabel("Chào mừng trở lại, Lãnh Chúa!")
            targetPctRef.current = 100
            setTimeout(() => {
              setFadeOut(true)
              setTimeout(() => {
                setVisible(false)
                onComplete()
              }, 700)
            }, 600)
          }
        })
        .catch(() => {
          // Nếu 1 tab lỗi vẫn tiếp tục
          done++
          setCompletedCount(done)
          targetPctRef.current = Math.round((done / total) * 95)
          if (done === total) {
            setCurrentLabel("Sẵn sàng chiến đấu!")
            targetPctRef.current = 100
            setTimeout(() => {
              setFadeOut(true)
              setTimeout(() => { setVisible(false); onComplete() }, 700)
            }, 600)
          }
        })
    })
  }, [])

  if (!visible) return null
  const pct = Math.round(displayPct)

  return (
    <div
      className="fixed inset-0 z-[9999] flex flex-col items-center justify-center overflow-hidden select-none"
      style={{
        background: "oklch(0.08 0.015 265)",
        opacity: fadeOut ? 0 : 1,
        transition: "opacity 0.7s ease",
        pointerEvents: fadeOut ? "none" : "auto",
      }}
    >
      {/* Radial glow backdrop */}
      <div style={{ position:"absolute", inset:0, pointerEvents:"none",
        background: "radial-gradient(ellipse 60% 50% at 50% 50%, oklch(0.20 0.06 280 / 0.35) 0%, transparent 70%)" }} />
      <div style={{ position:"absolute", inset:0, pointerEvents:"none",
        background: "radial-gradient(ellipse 40% 30% at 50% 75%, oklch(0.55 0.22 25 / 0.07) 0%, transparent 60%)" }} />

      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {particles.map(p => (
          <div key={p.id} style={{
            position:"absolute", left:`${p.x}%`, bottom:`-${p.size*2}px`,
            width:`${p.size}px`, height:`${p.size}px`, borderRadius:"50%",
            background:`oklch(0.80 0.18 ${p.hue})`, opacity: p.opacity,
            animation:`floatUp ${p.speed}s ${p.delay}s infinite linear`,
            boxShadow:`0 0 ${p.size*3}px oklch(0.80 0.18 ${p.hue} / 0.5)`,
          }} />
        ))}
      </div>

      {/* Rune rings */}
      <div style={{ position:"absolute", left:"50%", top:"50%", transform:"translate(-50%,-50%)" }}>
        <RuneRing size={340} spin={22} opacity={0.10} color="oklch(0.78 0.165 78)" />
        <RuneRing size={290} spin={15} opacity={0.12} color="oklch(0.78 0.16 195)" reverse />
        <RuneRing size={240} spin={9}  opacity={0.08} color="oklch(0.62 0.24 22)" />
      </div>

      {/* Content */}
      <div className="relative flex flex-col items-center gap-7 px-6 w-full max-w-sm">

        {/* Emblem */}
        <div style={{ position:"relative", display:"flex", alignItems:"center", justifyContent:"center" }}>
          <div style={{ position:"absolute", width:110, height:110, borderRadius:"50%",
            background:"radial-gradient(circle, oklch(0.78 0.165 78 / 0.15) 0%, transparent 70%)",
            animation:"outerGlow 2.5s ease-in-out infinite" }} />
          <div style={{
            width:72, height:72, borderRadius:"50%",
            border:"2px solid oklch(0.78 0.165 78 / 0.60)",
            background:"linear-gradient(135deg, oklch(0.14 0.025 265) 0%, oklch(0.20 0.05 280) 100%)",
            display:"flex", alignItems:"center", justifyContent:"center",
            boxShadow:"0 0 24px oklch(0.78 0.165 78 / 0.30), inset 0 0 20px oklch(0.78 0.165 78 / 0.05)",
            animation:"iconPulse 3s ease-in-out infinite",
          }}>
            <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
              <path d="M18 3 L30 9 L30 21 L18 33 L6 21 L6 9 Z" stroke="oklch(0.78 0.165 78)" strokeWidth="1.2" fill="oklch(0.78 0.165 78 / 0.08)" />
              <path d="M18 10 L19.8 15.5 L25.5 15.5 L21 18.8 L22.8 24.3 L18 21 L13.2 24.3 L15 18.8 L10.5 15.5 L16.2 15.5 Z" fill="oklch(0.82 0.17 78)" opacity="0.9" />
              <circle cx="18" cy="18" r="2" fill="oklch(0.95 0.10 85)" />
            </svg>
          </div>
        </div>

        {/* Title */}
        <div className="text-center space-y-1">
          <h1 style={{
            fontFamily:"var(--font-cinzel-decorative), var(--font-cinzel), serif",
            fontSize:"clamp(1.6rem, 6vw, 2.2rem)", fontWeight:900, letterSpacing:"0.10em",
            background:"linear-gradient(135deg, oklch(0.70 0.12 78) 0%, oklch(0.92 0.18 85) 45%, oklch(0.78 0.165 78) 80%, oklch(0.65 0.10 78) 100%)",
            WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", backgroundClip:"text", lineHeight:1.1,
          }}>AETHERIA</h1>
          <p style={{ fontFamily:"var(--font-im-fell), Georgia, serif", fontSize:"0.72rem", letterSpacing:"0.30em",
            textTransform:"uppercase", color:"oklch(0.55 0.06 78)" }}>Fantasy Turn-Based Saga</p>
        </div>

        {/* Progress */}
        <div className="w-full space-y-3">
          {/* Counter */}
          <div className="flex justify-between items-center mb-1">
            <span style={{ fontFamily:"var(--font-cinzel), serif", fontSize:"0.65rem",
              color:"oklch(0.45 0.04 270)", letterSpacing:"0.05em" }}>
              {completedCount < total ? `${completedCount} / ${total} modules` : "Hoàn tất"}
            </span>
            <span style={{ fontFamily:"var(--font-cinzel), serif", fontSize:"0.72rem",
              fontWeight:700, color:"oklch(0.78 0.165 78)" }}>{pct}%</span>
          </div>

          {/* Bar */}
          <div style={{ position:"relative", height:6, borderRadius:9999,
            background:"oklch(0.20 0.025 270)", border:"1px solid oklch(0.32 0.04 265 / 0.60)", overflow:"hidden" }}>
            <div style={{
              position:"absolute", left:0, top:0, bottom:0, width:`${pct}%`, borderRadius:9999,
              background:"linear-gradient(90deg, oklch(0.60 0.12 78) 0%, oklch(0.88 0.18 85) 60%, oklch(0.78 0.165 78) 100%)",
              boxShadow:"0 0 10px oklch(0.78 0.165 78 / 0.60)",
              transition:"width 0.05s linear",
            }} />
            <div style={{ position:"absolute", inset:0,
              background:"linear-gradient(90deg, transparent 0%, oklch(0.95 0.10 85 / 0.25) 50%, transparent 100%)",
              animation:"shimmer 1.8s ease-in-out infinite" }} />
          </div>

          {/* Current step label */}
          <p style={{ fontFamily:"var(--font-im-fell), Georgia, serif", fontSize:"0.70rem",
            fontStyle:"italic", color:"oklch(0.55 0.04 78)", minHeight:"1.4em",
            transition:"opacity 0.2s" }}>
            {currentLabel}
          </p>
        </div>

        {/* Ornament */}
        <div style={{ display:"flex", alignItems:"center", gap:"0.6rem", width:"100%", opacity:0.30 }}>
          <div style={{ flex:1, height:1, background:"linear-gradient(90deg, transparent, oklch(0.78 0.165 78 / 0.60))" }} />
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M7 0 L8.5 5.5 L14 7 L8.5 8.5 L7 14 L5.5 8.5 L0 7 L5.5 5.5 Z" fill="oklch(0.78 0.165 78)" />
          </svg>
          <div style={{ flex:1, height:1, background:"linear-gradient(90deg, oklch(0.78 0.165 78 / 0.60), transparent)" }} />
        </div>
      </div>

      <style>{`
        @keyframes floatUp {
          0%   { transform: translateY(0) scale(1); }
          100% { transform: translateY(-100vh) scale(0.3); opacity: 0; }
        }
        @keyframes spinF  { to { transform: rotate(360deg);  } }
        @keyframes spinR  { to { transform: rotate(-360deg); } }
        @keyframes outerGlow {
          0%,100% { transform: scale(1);    opacity: 0.8; }
          50%      { transform: scale(1.15); opacity: 1;   }
        }
        @keyframes iconPulse {
          0%,100% { box-shadow: 0 0 24px oklch(0.78 0.165 78 / 0.30), inset 0 0 20px oklch(0.78 0.165 78 / 0.05); }
          50%      { box-shadow: 0 0 40px oklch(0.78 0.165 78 / 0.55), inset 0 0 28px oklch(0.78 0.165 78 / 0.12); }
        }
        @keyframes shimmer {
          0%   { transform: translateX(-100%); }
          100% { transform: translateX(200%);  }
        }
      `}</style>
    </div>
  )
}
