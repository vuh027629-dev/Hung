"use client"

import { useGameSelector, useGameActions, useGameState, useLoadSave } from "@/lib/game/store"
import { useCloudSave } from "@/lib/game/use-cloud-save"
import { playerXpToNextLevel } from "@/lib/game/combat"
import { Coins, Gem, Crown, RefreshCcw, Volume2, VolumeX, Maximize, Minimize } from "lucide-react"
import { useState, useCallback, useEffect } from "react"
import { toggleSoundMuted, getSoundMuted } from "@/hooks/use-sound"
import { CloudSaveWidget } from "./cloud-save-widget"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import type { GameState } from "@/lib/game/types"

function useFullscreen() {
  const [isFullscreen, setIsFullscreen] = useState(false)

  useEffect(() => {
    const onChange = () => setIsFullscreen(!!document.fullscreenElement)
    document.addEventListener("fullscreenchange", onChange)
    return () => document.removeEventListener("fullscreenchange", onChange)
  }, [])

  const toggle = useCallback(async () => {
    try {
      if (!document.fullscreenElement) {
        // Thử fullscreen element gốc trước, fallback document.documentElement
        const el = document.documentElement
        if (el.requestFullscreen) {
          await el.requestFullscreen()
        } else if ((el as any).webkitRequestFullscreen) {
          // Safari / iOS WKWebView
          await (el as any).webkitRequestFullscreen()
        }
      } else {
        if (document.exitFullscreen) {
          await document.exitFullscreen()
        } else if ((document as any).webkitExitFullscreen) {
          await (document as any).webkitExitFullscreen()
        }
      }
    } catch {
      // Một số trình duyệt mobile chặn fullscreen API — không làm gì
    }
  }, [])

  return { isFullscreen, toggle }
}

export function Header() {
  const gold = useGameSelector(s => s.gold)
  const gems = useGameSelector(s => s.gems)
  const level = useGameSelector(s => s.level)
  const xp = useGameSelector(s => s.xp)
  const { resetGame } = useGameActions()
  const state = useGameState()
  const loadSave = useLoadSave()

  const { username, status, errorMsg, login, register, logout, manualSave } = useCloudSave(
    state,
    (data: GameState) => loadSave(data),
  )

  const [isMuted, setIsMuted] = useState(() => getSoundMuted())
  const handleToggleMute = useCallback(() => {
    const next = toggleSoundMuted()
    setIsMuted(next)
  }, [])

  const { isFullscreen, toggle: toggleFullscreen } = useFullscreen()

  const xpNeed = playerXpToNextLevel(level)
  const xpPct = Math.min(100, (xp / xpNeed) * 100)

  const fmtCompact = (n: number) => {
    if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M"
    if (n >= 10_000)    return (n / 1_000).toFixed(1).replace(/\.0$/, "") + "k"
    return n.toLocaleString()
  }

  return (
    <header className="aetheria-header sticky top-0 z-30 backdrop-blur-md w-full">
      {/* ── Row 1: Logo + Actions ── */}
      <div className="w-full px-2 sm:px-4 py-2 flex items-center gap-1.5 sm:gap-3 min-w-0">

        {/* Logo */}
        <div className="flex items-center gap-1.5 shrink-0">
          <Crown className="size-5 sm:size-6 text-primary drop-shadow-[0_0_8px_oklch(0.78_0.16_80/0.7)]" />
          <h1 className="aetheria-logo text-base sm:text-lg leading-none">AETHERIA</h1>
        </div>

        {/* XP bar — desktop only */}
        <div className="hidden lg:flex items-center gap-2 flex-1 min-w-0 ml-1">
          <span className="level-badge text-lg font-bold shrink-0">{level}</span>
          <div className="flex-1 min-w-0">
            <div className="xp-bar-track">
              <div className="xp-bar-fill" style={{ width: `${xpPct}%` }} />
            </div>
            <p className="text-[9px] text-muted-foreground/60 mt-0.5 font-mono tabular-nums truncate">
              {xp.toLocaleString()} / {xpNeed.toLocaleString()} XP
            </p>
          </div>
        </div>

        {/* Spacer mobile */}
        <div className="flex-1 lg:hidden" />

        {/* Right actions */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">

          {/* Vàng */}
          <div className="header-chip">
            <Coins className="size-3.5 text-rarity-legendary shrink-0" />
            <span className="font-mono text-xs font-bold tabular-nums">{fmtCompact(gold)}</span>
          </div>

          {/* Đá quý */}
          <div className="header-chip">
            <Gem className="size-3.5 text-rarity-celestial shrink-0" />
            <span className="font-mono text-xs font-bold tabular-nums">{fmtCompact(gems)}</span>
          </div>

          {/* Âm thanh */}
          <button
            onClick={handleToggleMute}
            title={isMuted ? "Bật âm thanh" : "Tắt âm thanh"}
            className="header-icon-btn"
          >
            {isMuted ? <VolumeX className="size-3.5" /> : <Volume2 className="size-3.5" />}
          </button>

          {/* Fullscreen */}
          <button
            onClick={toggleFullscreen}
            title={isFullscreen ? "Thoát toàn màn hình" : "Toàn màn hình"}
            className="header-icon-btn"
          >
            {isFullscreen
              ? <Minimize className="size-3.5" />
              : <Maximize className="size-3.5" />
            }
          </button>

          {/* Cloud save */}
          <CloudSaveWidget
            username={username}
            status={status}
            errorMsg={errorMsg}
            onLogin={login}
            onRegister={register}
            onLogout={logout}
            onManualSave={manualSave}
          />

          {/* Reset */}
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <button className="header-icon-btn" aria-label="Reset game">
                <RefreshCcw className="size-3.5" />
              </button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle className="font-fantasy">Đặt lại tiến trình?</AlertDialogTitle>
                <AlertDialogDescription>
                  Mọi anh hùng, vật phẩm, vàng và đá quý sẽ bị xóa. Hành động không thể hoàn tác.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Hủy</AlertDialogCancel>
                <AlertDialogAction onClick={() => resetGame()}>Đặt lại</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      {/* ── Row 2: XP bar mobile ── */}
      <div className="lg:hidden w-full px-2 sm:px-4 pb-2">
        <div className="flex items-center gap-1.5">
          <span className="level-badge text-xs font-bold shrink-0">Lv{level}</span>
          <div className="xp-bar-track flex-1 min-w-0">
            <div className="xp-bar-fill" style={{ width: `${xpPct}%` }} />
          </div>
          <span className="text-[9px] text-muted-foreground/60 font-mono tabular-nums shrink-0">
            {fmtCompact(xp)}/{fmtCompact(xpNeed)}
          </span>
        </div>
      </div>
    </header>
  )
}
