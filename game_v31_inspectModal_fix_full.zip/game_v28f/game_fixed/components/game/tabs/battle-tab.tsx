"use client"

import { useMemo, useState } from "react"
import { useGameSelector, useGameActions, computeHeroStats } from "@/lib/game/store"
import { HEROES_BY_ID } from "@/lib/game/heroes"
import { SYNERGY_BY_TRAIT, TRAIT_LABEL, ROLE_LABEL, computeSynergies } from "@/lib/game/factions"
import { PASSIVES, SKILLS } from "@/lib/game/skills"
import { ORDER_INNATES } from "@/lib/game/order-innates"
import { getBlessingMeta } from "@/lib/game/blessings-meta"
import { RARITY_TEXT_CLASS, RARITY_BG_CLASS, RARITY_LABEL } from "@/lib/game/rarity"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { HeroCard } from "@/components/game/hero-card"
import {
  ChevronDown, ChevronUp, Swords, Trophy, Users, Eye, Info, Shield,
  Crosshair, RefreshCw, Search, Skull, Zap, FlaskConical, Star, Sparkles, Flame, AlertTriangle
} from "lucide-react"
import { cn } from "@/lib/utils"
import type { BattleRow, OwnedHero } from "@/lib/game/types"


// ── Enemy Preview Panel ──────────────────────────────────────────────────────
function EnemyPreviewPanel({ stage }: { stage: number }) {
  // Read cached team from store so scout and combat always show the same enemies
  const previewTeam = useGameSelector(s => s.cachedEnemyTeam)
  const { dispatch } = useGameActions()
  const [loading, setLoading] = useState(false)
  const [expanded, setExpanded] = useState<string | null>(null)

  const generate = () => {
    setLoading(true)
    setExpanded(null)
    // Dispatch generates a fresh team for currentStage and caches it in the store.
    // buildCombatState will then use this exact same cached team when combat starts.
    setTimeout(() => {
      dispatch({ type: "SCOUT_STAGE" })
      setLoading(false)
    }, 350)
  }

  const enemyTpls = (previewTeam ?? [])
    .map(h => HEROES_BY_ID[h.templateId])
    .filter(Boolean)

  const synergies = useMemo(() => computeSynergies(enemyTpls), [previewTeam])

  const ROLE_COLOR: Record<string, string> = {
    warrior:  "text-orange-400",
    mage:     "text-purple-400",
    assassin: "text-red-400",
    tank:     "text-blue-400",
    marksman: "text-emerald-400",
    support:  "text-yellow-400",
  }
  const ROLE_ICON: Record<string, string> = {
    warrior: "⚔", mage: "✦", assassin: "🗡", tank: "🛡", marksman: "🎯", support: "💚",
  }

  return (
    <Card className="ornate-border border-red-500/30 bg-red-950/10">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <CardTitle className="font-fantasy text-base flex items-center gap-2">
            <Search className="size-4 text-red-400" />
            Thám Thính Địch Thủ
          </CardTitle>
          <Button
            size="sm"
            variant="outline"
            className="h-7 gap-1.5 text-xs border-red-500/40 text-red-300 hover:bg-red-500/10 hover:text-red-200"
            onClick={generate}
            disabled={loading}
          >
            {loading
              ? <RefreshCw className="size-3 animate-spin" />
              : <Eye className="size-3" />}
            {previewTeam ? "Thám Thính Lại" : "Thám Thính"}
          </Button>
        </div>
        <p className="text-[11px] text-muted-foreground">
          Xem trước một đội địch ngẫu nhiên ở tầng này — bao gồm chỉ số, kỹ năng và hệ tộc.
          Đội thật khi vào trận được tạo riêng biệt.
        </p>
      </CardHeader>

      <CardContent>
        {!previewTeam && !loading && (
          <div className="rounded-lg border border-dashed border-red-500/25 bg-red-500/5 py-10 text-center">
            <Search className="size-9 mx-auto mb-2 text-red-400/30" />
            <p className="text-sm text-muted-foreground">Nhấn "Thám Thính" để xem trước đội hình địch</p>
            <p className="text-[11px] text-muted-foreground/60 mt-1">Hiển thị: chỉ số · kỹ năng · passive · hệ tộc · phúc &amp; kèo</p>
            {stage >= 5 && (
              <p className="text-[10px] text-sky-400/70 mt-2">✦ Tầng {stage} — địch có thể mang Phúc/Kèo!</p>
            )}
          </div>
        )}

        {loading && (
          <div className="py-10 text-center text-muted-foreground">
            <RefreshCw className="size-6 mx-auto mb-2 animate-spin text-red-400" />
            <p className="text-sm">Đang trinh sát...</p>
          </div>
        )}

        {previewTeam && !loading && (
          <div className="space-y-3">
            {/* ── Blessing/pact summary ── */}
            {(() => {
              const bpCount = previewTeam.filter(h => h.blessingPactId).length
              const blessingCount = previewTeam.filter(h => {
                const bp = getBlessingMeta(h.blessingPactId)
                return bp?.kind === "blessing"
              }).length
              const pactCount = bpCount - blessingCount
              if (bpCount === 0) return (
                <p className="text-[10px] text-muted-foreground/60 text-center py-1">
                  Không có Phúc/Kèo ở tầng này — địch vẫn nguy hiểm theo cách thường.
                </p>
              )
              return (
                <div className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-2">
                  <span className="text-[10px] text-muted-foreground flex-1">Phúc &amp; Kèo địch:</span>
                  {blessingCount > 0 && (
                    <span className="text-[10px] font-bold text-sky-300 flex items-center gap-1">
                      <Sparkles className="size-3" /> ×{blessingCount} Phúc
                    </span>
                  )}
                  {pactCount > 0 && (
                    <span className="text-[10px] font-bold text-red-300 flex items-center gap-1">
                      <Flame className="size-3" /> ×{pactCount} Kèo
                    </span>
                  )}
                </div>
              )
            })()}

            {/* ── Enemy cards ── */}
            <div className="grid gap-2">
              {previewTeam.map((owned) => {
                const tpl = HEROES_BY_ID[owned.templateId]
                if (!tpl) return null
                const stats   = computeHeroStats(owned, tpl)
                const passive = PASSIVES[tpl.passive]
                const isOpen  = expanded === owned.uid
                const rarityBg = RARITY_BG_CLASS[tpl.rarity] ?? ""

                return (
                  <div
                    key={owned.uid}
                    className={cn("rounded-xl border transition-all overflow-hidden", rarityBg)}
                  >
                    {/* ── Collapsed header ── */}
                    <button
                      type="button"
                      className="w-full flex items-center gap-3 px-3 py-2.5 text-left hover:bg-white/5 transition-colors"
                      onClick={() => setExpanded(isOpen ? null : owned.uid)}
                    >
                      {/* Rarity badge */}
                      <span className={cn(
                        "text-[9px] font-bold uppercase px-1.5 py-0.5 rounded border shrink-0",
                        RARITY_TEXT_CLASS[tpl.rarity],
                        "border-current/40 bg-current/10"
                      )}>
                        {RARITY_LABEL[tpl.rarity]}
                      </span>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={cn("font-fantasy font-bold text-sm leading-none", RARITY_TEXT_CLASS[tpl.rarity])}>
                            {tpl.name}
                          </span>
                          <span className={cn("text-[10px] font-medium", ROLE_COLOR[tpl.role] ?? "text-muted-foreground")}>
                            {ROLE_ICON[tpl.role]} {ROLE_LABEL[tpl.role as keyof typeof ROLE_LABEL] ?? tpl.role}
                          </span>
                          {owned.blessingPactId && (() => {
                            const bp = getBlessingMeta(owned.blessingPactId)
                            if (!bp) return null
                            const isBlessing = bp.kind === "blessing"
                            return (
                              <span className={cn(
                                "text-[9px] px-1.5 py-0.5 rounded border font-bold flex items-center gap-0.5",
                                isBlessing
                                  ? "border-sky-400/50 bg-sky-400/15 text-sky-300"
                                  : "border-red-500/50 bg-red-500/15 text-red-300"
                              )}>
                                {isBlessing ? "✦" : "🔥"} {isBlessing ? "Phúc" : "Kèo"} T{bp.tier}
                              </span>
                            )
                          })()}
                        </div>
                        <div className="flex flex-wrap gap-2 mt-1 text-[10px] text-muted-foreground">
                          <span>Lv.{owned.level}</span>
                          <span>❤ {stats.hp.toLocaleString()}</span>
                          {stats.atk > 0 && <span>⚔ {stats.atk}</span>}
                          {stats.mag > 0 && <span>✦ {stats.mag}</span>}
                          <span>🛡 {stats.def}</span>
                          <span>⚡ {stats.spd}</span>
                        </div>
                      </div>

                      <ChevronDown className={cn(
                        "size-4 text-muted-foreground transition-transform shrink-0",
                        isOpen && "rotate-180"
                      )} />
                    </button>

                    {/* ── Expanded detail ── */}
                    {isOpen && (
                      <div className="border-t border-white/10 px-3 pb-4 pt-3 space-y-4">
                        {/* Full stats */}
                        <div>
                          <p className="text-[10px] uppercase tracking-widest text-muted-foreground mb-2">Chỉ Số</p>
                          <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5 text-[10px]">
                            {([
                              ["HP", stats.hp.toLocaleString()],
                              ["ATK", stats.atk],
                              ["MAG", stats.mag],
                              ["DEF", stats.def],
                              ["RES", stats.res],
                              ["SPD", stats.spd],
                              ["CRIT", `${stats.crit}%`],
                              ["CR.DMG", `${stats.critDmg}%`],
                              ["LIFESTEAL", `${stats.lifesteal}%`],
                            ] as [string, string | number][]).map(([k, v]) => (
                              <div key={k} className="flex flex-col items-center rounded border border-white/10 bg-black/20 px-2 py-1.5">
                                <span className="text-muted-foreground text-[9px]">{k}</span>
                                <span className="font-mono font-bold text-[11px]">{v}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Skills */}
                        <div>
                          <p className="text-[10px] uppercase tracking-widest text-muted-foreground mb-2 flex items-center gap-1">
                            <Zap className="size-3" /> Kỹ Năng
                          </p>
                          <div className="space-y-1.5">
                            {tpl.skills.map((sid, i) => {
                              const skill = SKILLS[sid]
                              if (!skill) return null
                              const isUlt = i === 2
                              const maxScale = skill.effects
                                .flatMap(ef => [ef.damage?.scale ?? 0, ef.heal?.scale ?? 0])
                                .filter(Boolean)
                              const topScale = maxScale.length ? Math.max(...maxScale) : null

                              return (
                                <div key={sid} className={cn(
                                  "rounded-lg border px-3 py-2",
                                  isUlt
                                    ? "border-yellow-500/40 bg-yellow-500/10"
                                    : "border-white/10 bg-black/20"
                                )}>
                                  <div className="flex items-center gap-2 mb-0.5">
                                    <span className={cn(
                                      "text-[9px] font-bold uppercase px-1.5 py-0.5 rounded",
                                      isUlt
                                        ? "bg-yellow-500/30 text-yellow-300"
                                        : "bg-primary/20 text-primary"
                                    )}>
                                      {isUlt ? "ULT" : `S${i + 1}`}
                                    </span>
                                    <span className="font-fantasy text-[11px] font-bold">{skill.name}</span>
                                    <div className="ml-auto flex items-center gap-2 text-[9px] text-muted-foreground">
                                      {topScale && <span className="text-emerald-400">×{topScale.toFixed(1)}</span>}
                                      <span>CD:{skill.cooldown}</span>
                                    </div>
                                  </div>
                                  <p className="text-[10px] text-muted-foreground leading-relaxed">
                                    {skill.description}
                                  </p>
                                </div>
                              )
                            })}
                          </div>
                        </div>

                        {/* Passive */}
                        {passive && (
                          <div className="rounded-lg border border-amber-500/35 bg-amber-500/8 px-3 py-2">
                            <p className="text-[10px] font-bold text-amber-300 flex items-center gap-1.5 mb-0.5">
                              <Star className="size-3" /> Passive: {passive.name}
                            </p>
                            <p className="text-[10px] text-muted-foreground leading-relaxed">{passive.description}</p>
                          </div>
                        )}

                        {/* Order Innate */}
                        {tpl.orderInnate && (() => {
                          const oi = tpl.orderInnate!
                          const ek = (oi.effect as any).kind as string
                          const mechIcon =
                            ek === "reduceCooldown" ? "⏱️" :
                            ek === "shareEnergy"    ? "⚡→" :
                            ek === "hpToEnergy"     ? "🩸⚡" :
                            ek === "regenOnRow"     ? "💚" :
                            ek === "tauntSelf"      ? "📣" :
                            ek === "resetSkill"     ? "🔄" :
                            ek === "stackRegen"     ? "💚×" :
                            ek === "echoEnergy"     ? "🔋" :
                            ek === "transferShield" ? "🛡️→" :
                            ek === "multi"          ? "✨" : "⚡"
                          return (
                            <div className="rounded-lg border border-cyan-500/35 bg-cyan-500/8 px-3 py-2 space-y-0.5">
                              <p className="text-[10px] font-bold text-cyan-300 flex items-center gap-1.5">
                                {mechIcon} {oi.name}
                              </p>
                              <p className="text-[10px] text-muted-foreground leading-relaxed">{oi.description}</p>
                            </div>
                          )
                        })()}

                        {/* Blessing / Pact */}
                        {(() => {
                          const bp = owned.blessingPactId ? getBlessingMeta(owned.blessingPactId) : null
                          if (!bp) return null
                          const isBlessing = bp.kind === "blessing"
                          return (
                            <div className={cn(
                              "rounded-lg border px-3 py-2 space-y-1",
                              isBlessing
                                ? "border-sky-400/40 bg-sky-950/40"
                                : "border-red-500/40 bg-red-950/40"
                            )}>
                              <p className={cn(
                                "text-[10px] font-bold flex items-center gap-1.5",
                                isBlessing ? "text-sky-300" : "text-red-300"
                              )}>
                                {isBlessing
                                  ? <Sparkles className="size-3" />
                                  : <Flame className="size-3" />}
                                {isBlessing ? "Chúc Phúc" : "Giao Kèo"} — Tier {bp.tier}: {bp.name}
                              </p>
                              <p className="text-[10px] text-muted-foreground leading-relaxed">{bp.description}</p>
                              {(bp as any).curseSuffix && (
                                <p className="text-[10px] text-red-400/80 italic">{(bp as any).curseSuffix}</p>
                              )}
                            </div>
                          )
                        })()}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>

            {/* ── Enemy synergies ── */}
            {synergies.length > 0 && (
              <div className="rounded-lg border border-red-500/25 bg-red-500/8 p-3 space-y-2">
                <p className="text-[10px] uppercase tracking-widest text-red-400 flex items-center gap-1.5">
                  <Skull className="size-3" /> Hệ Tộc Kẻ Địch ({synergies.length})
                </p>
                <div className="grid gap-1.5">
                  {synergies.map(s => {
                    const def = SYNERGY_BY_TRAIT[s.trait]
                    const tierIdx = def.tiers.findIndex(t => t === s.tier) + 1
                    return (
                      <div key={s.trait} className="flex items-start gap-2 text-[10px]">
                        <span className="text-red-300 font-bold font-fantasy whitespace-nowrap shrink-0">
                          {def.name} ×{s.count}
                          <span className="ml-1 text-[9px] text-red-400/60">[T{tierIdx}]</span>
                        </span>
                        <span className="text-muted-foreground">{s.tier.description}</span>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            <p className="text-[10px] text-muted-foreground/50 italic text-center pt-1">
              ✅ Đây là đội địch thật — nhấn "Thám Thính Lại" để làm mới hoặc vào trận ngay
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// TACTICAL ANALYSIS PANEL
// Phân tích đội hình địch vs ta — gợi ý chiến thuật, điểm mạnh/yếu, counter
// ─────────────────────────────────────────────────────────────────────────────

function TacticalAnalysisPanel({ stage }: { stage: number }) {
  const cachedEnemyTeam = useGameSelector(s => s.cachedEnemyTeam)
  const team = useGameSelector(s => s.team)
  const heroes = useGameSelector(s => s.heroes)
  const teamRowsRaw = useGameSelector(s => s.teamRows)
  const [open, setOpen] = useState(false)

  const previewTeam = cachedEnemyTeam
  const teamHeroes  = team.map(id => id ? heroes.find(h => h.uid === id) ?? null : null).filter(Boolean) as NonNullable<ReturnType<typeof heroes.find>>[]
  const teamRows    = teamRowsRaw?.length === 6 ? teamRowsRaw : Array(6).fill("back") as BattleRow[]

  const analysis = useMemo(() => {
    if (!previewTeam || teamHeroes.length === 0) return null

    // ── Build enemy profile ────────────────────────────────────────────────
    const enemyTpls = previewTeam.map(h => HEROES_BY_ID[h.templateId]).filter(Boolean)
    const enemyRoles = enemyTpls.map(t => t.role)
    const enemyHasHealer  = enemyRoles.includes("support")
    const enemyHasAssassin= enemyRoles.includes("assassin")
    const enemyHasTank    = enemyRoles.includes("tank")
    const enemyHasMage    = enemyRoles.includes("mage")
    const enemyHasMarksman= enemyRoles.includes("marksman")
    const enemyAvgLevel   = previewTeam.reduce((s, h) => s + h.level, 0) / previewTeam.length
    const enemySynergies  = computeSynergies(enemyTpls)
    const enemyHasBurst   = enemyTpls.some(t => t.build === "burst")
    const enemyHasAtkSpeed = enemyTpls.some(t => t.build === "attack-speed")
    const enemyDotCount   = previewTeam.filter(h => {
      const tpl = HEROES_BY_ID[h.templateId]
      return tpl?.role === "mage" || tpl?.role === "support"
    }).length

    // ── Build our profile ─────────────────────────────────────────────────
    const myTpls   = teamHeroes.map(h => HEROES_BY_ID[h.templateId]).filter(Boolean)
    const myRoles  = myTpls.map(t => t.role)
    const myHasHealer   = myRoles.includes("support")
    const myHasTank     = myRoles.includes("tank")
    const myHasAssassin = myRoles.includes("assassin")
    const myHasMage     = myRoles.includes("mage")
    const myFrontCount  = teamHeroes.filter((_, i) => {
      const slot = team.findIndex(id => id === teamHeroes[i]?.uid)
      return slot >= 0 && teamRows[slot] === "front"
    }).length
    const myAvgLevel    = teamHeroes.reduce((s, h) => s + h.level, 0) / teamHeroes.length
    const mySynergies   = computeSynergies(myTpls)
    const myHasBurst    = myTpls.some(t => t.build === "burst")

    // ── Level comparison ──────────────────────────────────────────────────
    const levelDelta = myAvgLevel - enemyAvgLevel
    const levelAdvantage: "strong" | "even" | "weak" =
      levelDelta > 5 ? "strong" : levelDelta < -5 ? "weak" : "even"

    // ── Threats ─────────────────────────────────────────────────────────────
    const threats: { icon: string; text: string; severity: "high" | "medium" | "low" }[] = []

    if (enemyHasAssassin && myFrontCount < 2)
      threats.push({ icon: "🗡", text: "Sát Thủ địch sẽ xuyên thẳng hàng sau — cần thêm Tank phía trước!", severity: "high" })
    if (enemyHasAssassin && !myHasTank)
      threats.push({ icon: "🛡", text: "Không có Tank — Sát Thủ địch sẽ một đòn xoá xạ thủ/pháp sư của bạn.", severity: "high" })
    if (enemyHasHealer && !myHasMage && !myHasAssassin)
      threats.push({ icon: "💚", text: "Địch có Hỗ Trợ hồi máu — không có Pháp Sư/Sát Thủ để tiêu diệt nhanh!", severity: "high" })
    if (enemyHasBurst && !myHasTank)
      threats.push({ icon: "💥", text: "Địch đội Burst mạnh — thiếu Tank sẽ mất đội hình trong vài lượt đầu.", severity: "high" })
    if (enemyHasMage && myFrontCount === 0)
      threats.push({ icon: "✦", text: "Không có hàng trước — Pháp Sư địch dùng AoE sẽ xoá toàn bộ đội.", severity: "high" })
    if (enemyHasMarksman && !myHasTank)
      threats.push({ icon: "🎯", text: "Xạ Thủ địch gây sát thương liên tục — cần Tank hút đạn.", severity: "medium" })
    if (enemyHasAtkSpeed)
      threats.push({ icon: "⚡", text: "Địch tốc độ cao — sẽ hành động trước. Ưu tiên đặt Tank hàng đầu.", severity: "medium" })
    if (levelAdvantage === "weak")
      threats.push({ icon: "📉", text: `Ta yếu hơn địch ~${Math.abs(Math.round(levelDelta))} cấp — địch có chỉ số vượt trội.`, severity: "medium" })
    if (enemySynergies.length >= 3)
      threats.push({ icon: "🔗", text: `Địch có ${enemySynergies.length} hệ tộc hoạt động — synergy mạnh, khó phá vỡ.`, severity: "medium" })
    if (enemyDotCount >= 2)
      threats.push({ icon: "☠", text: "Nhiều đơn vị gây DoT — đội không có Hỗ Trợ sẽ mòn dần qua các lượt.", severity: "medium" })

    // ── Advantages ──────────────────────────────────────────────────────────
    const advantages: { icon: string; text: string }[] = []

    if (myHasHealer && enemyHasAssassin)
      advantages.push({ icon: "💊", text: "Có Hỗ Trợ — hồi máu giữ đội sống sót qua đợt burst của Sát Thủ." })
    if (myHasTank && enemyHasAssassin)
      advantages.push({ icon: "🛡", text: "Tank hàng trước chặn Sát Thủ địch — bảo vệ tốt hàng sau." })
    if (myHasAssassin && enemyHasHealer)
      advantages.push({ icon: "🗡", text: "Sát Thủ của ta sẽ xoá Hỗ Trợ địch trong lượt đầu — chặn hồi máu." })
    if (myHasMage && enemyHasTank)
      advantages.push({ icon: "✦", text: "Pháp Sư gây sát thương phép — xuyên qua giáp Tank địch hiệu quả." })
    if (myHasBurst && !enemyHasHealer)
      advantages.push({ icon: "💥", text: "Đội Burst mạnh + địch không có heal — có thể xoá từng mục tiêu nhanh." })
    if (levelAdvantage === "strong")
      advantages.push({ icon: "📈", text: `Cấp độ cao hơn địch ~${Math.round(levelDelta)} — chỉ số áp đảo.` })
    if (mySynergies.length >= 3)
      advantages.push({ icon: "🔗", text: `${mySynergies.length} hệ tộc hoạt động — synergy combo tăng sức mạnh đáng kể.` })
    if (myFrontCount >= 2 && enemyHasAssassin)
      advantages.push({ icon: "🏰", text: "Hàng trước dày — Sát Thủ địch khó xuyên để đánh hàng sau." })

    // ── Counter suggestions ──────────────────────────────────────────────────
    const counters: string[] = []

    if (enemyHasHealer)
      counters.push("Ưu tiên tiêu diệt Hỗ Trợ địch trước — không để chúng hồi máu liên tục")
    if (enemyHasAssassin && myFrontCount < 2)
      counters.push("Chuyển thêm 1 tướng lên hàng trước để bảo vệ hàng sau khỏi Sát Thủ")
    if (enemyHasTank && myHasMage)
      counters.push("Dùng Pháp Sư tấn công Tank địch — phép thuật xuyên giáp hiệu quả hơn vật lý")
    if (enemyHasBurst && myHasHealer)
      counters.push("Giữ chiêu hồi của Hỗ Trợ để cứu tướng quan trọng sau đợt burst đầu")
    if (enemySynergies.some(s => s.trait === "undead" || s.trait === "demon"))
      counters.push("Địch có hệ Undead/Demon: họ mạnh hơn khi HP thấp — tiêu diệt nhanh, tránh để dai")
    if (!myHasHealer && enemyDotCount > 1)
      counters.push("Không có heal — dùng thuốc hồi máu trong trận để chống DoT địch")

    // ── Formation score ────────────────────────────────────────────────────
    let score = 50
    if (myHasTank)           score += 10
    if (myHasHealer)         score += 10
    if (myFrontCount >= 2)   score += 8
    if (myFrontCount === 0)  score -= 20
    if (mySynergies.length >= 2) score += 8
    if (mySynergies.length >= 4) score += 7
    if (myHasAssassin && enemyHasHealer) score += 5
    if (myHasMage && enemyHasTank) score += 5
    if (threats.some(t => t.severity === "high")) score -= threats.filter(t => t.severity === "high").length * 8
    if (levelAdvantage === "strong") score += 10
    if (levelAdvantage === "weak")   score -= 10
    score = Math.max(5, Math.min(99, score))

    const scoreLabel =
      score >= 80 ? "Xuất Sắc" :
      score >= 65 ? "Tốt" :
      score >= 50 ? "Ổn" :
      score >= 35 ? "Yếu" : "Nguy Hiểm"
    const scoreColor =
      score >= 80 ? "text-emerald-400" :
      score >= 65 ? "text-green-400" :
      score >= 50 ? "text-yellow-400" :
      score >= 35 ? "text-orange-400" : "text-red-400"
    const scoreBg =
      score >= 80 ? "border-emerald-500/40 bg-emerald-950/20" :
      score >= 65 ? "border-green-500/40 bg-green-950/20" :
      score >= 50 ? "border-yellow-500/40 bg-yellow-950/20" :
      score >= 35 ? "border-orange-500/40 bg-orange-950/20" : "border-red-500/50 bg-red-950/30"

    return { threats, advantages, counters, score, scoreLabel, scoreColor, scoreBg, levelAdvantage, levelDelta: Math.round(levelDelta) }
  }, [previewTeam, teamHeroes, teamRows, team])

  if (!previewTeam || !analysis) return null

  return (
    <Card className="ornate-border border-violet-500/30 bg-violet-950/10">
      <button
        type="button"
        className="w-full"
        onClick={() => setOpen(o => !o)}
      >
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between gap-3">
            <CardTitle className="font-fantasy text-base flex items-center gap-2">
              <Star className="size-4 text-violet-400" />
              Phân Tích Chiến Thuật
            </CardTitle>
            <div className="flex items-center gap-2">
              {/* Formation score badge */}
              <div className={`rounded-lg border px-2.5 py-1 text-center min-w-[72px] ${analysis.scoreBg}`}>
                <div className={`font-bold text-base leading-none ${analysis.scoreColor}`}>{analysis.score}</div>
                <div className={`text-[9px] ${analysis.scoreColor} opacity-80`}>{analysis.scoreLabel}</div>
              </div>
              <ChevronDown className={cn("size-4 text-muted-foreground transition-transform", open && "rotate-180")} />
            </div>
          </div>
          {!open && (
            <p className="text-[10px] text-muted-foreground text-left">
              {analysis.threats.length > 0
                ? `⚠ ${analysis.threats.filter(t => t.severity === "high").length} nguy cơ cao · ${analysis.threats.filter(t => t.severity === "medium").length} trung bình`
                : "✅ Đội hình phù hợp — không có nguy cơ lớn"}
              {" · "}
              {analysis.advantages.length} lợi thế · Nhấn để xem chi tiết
            </p>
          )}
        </CardHeader>
      </button>

      {open && (
        <CardContent className="space-y-3 pt-0">

          {/* Level comparison */}
          <div className={`flex items-center justify-between rounded-lg border px-3 py-2 text-[11px] ${
            analysis.levelAdvantage === "strong" ? "border-green-500/40 bg-green-950/20 text-green-300"
            : analysis.levelAdvantage === "weak"  ? "border-red-500/40 bg-red-950/20 text-red-300"
            : "border-zinc-600/40 bg-zinc-900/30 text-zinc-300"
          }`}>
            <span className="font-bold">
              {analysis.levelAdvantage === "strong" ? "📈 Áp đảo cấp độ"
               : analysis.levelAdvantage === "weak" ? "📉 Yếu hơn về cấp độ"
               : "⚖ Cân bằng cấp độ"}
            </span>
            <span className="opacity-70">
              {analysis.levelDelta > 0 ? `+${analysis.levelDelta}` : analysis.levelDelta} cấp so với địch
            </span>
          </div>

          {/* Threats */}
          {analysis.threats.length > 0 && (
            <div className="space-y-1.5">
              <p className="text-[10px] uppercase tracking-widest text-red-400 flex items-center gap-1">
                <AlertTriangle className="size-3" /> Nguy Cơ
              </p>
              {analysis.threats.map((t, i) => (
                <div key={i} className={`flex items-start gap-2 rounded-lg border px-2.5 py-2 text-[11px] ${
                  t.severity === "high"
                    ? "border-red-500/50 bg-red-950/25 text-red-200"
                    : "border-orange-500/35 bg-orange-950/15 text-orange-200"
                }`}>
                  <span className="shrink-0 mt-0.5">{t.icon}</span>
                  <span>{t.text}</span>
                </div>
              ))}
            </div>
          )}

          {/* Advantages */}
          {analysis.advantages.length > 0 && (
            <div className="space-y-1.5">
              <p className="text-[10px] uppercase tracking-widest text-emerald-400 flex items-center gap-1">
                <Sparkles className="size-3" /> Lợi Thế
              </p>
              {analysis.advantages.map((a, i) => (
                <div key={i} className="flex items-start gap-2 rounded-lg border border-emerald-500/30 bg-emerald-950/15 px-2.5 py-2 text-[11px] text-emerald-200">
                  <span className="shrink-0 mt-0.5">{a.icon}</span>
                  <span>{a.text}</span>
                </div>
              ))}
            </div>
          )}

          {/* Counter tips */}
          {analysis.counters.length > 0 && (
            <div className="space-y-1.5">
              <p className="text-[10px] uppercase tracking-widest text-violet-400 flex items-center gap-1">
                <Info className="size-3" /> Gợi Ý Chiến Thuật
              </p>
              {analysis.counters.map((c, i) => (
                <div key={i} className="flex items-start gap-2 rounded-lg border border-violet-500/30 bg-violet-950/15 px-2.5 py-2 text-[11px] text-violet-200">
                  <span className="shrink-0 mt-0.5">💡</span>
                  <span>{c}</span>
                </div>
              ))}
            </div>
          )}

          {analysis.threats.length === 0 && analysis.counters.length === 0 && (
            <p className="text-center text-[11px] text-emerald-400/80 py-2">
              ✅ Đội hình phù hợp với trận này — không phát hiện nguy cơ lớn.
            </p>
          )}
        </CardContent>
      )}
    </Card>
  )
}

// ─────────────────────────────────────────────────────────────────────────────

export function BattleTab() {
  const team = useGameSelector(s => s.team)
  const heroes = useGameSelector(s => s.heroes)
  const teamRowsRaw = useGameSelector(s => s.teamRows)
  const teamReserveRaw = useGameSelector(s => s.teamReserve)
  const teamReserveRowsRaw = useGameSelector(s => s.teamReserveRows)
  const clearedStage = useGameSelector(s => s.clearedStage ?? 0)
  const currentStage = useGameSelector(s => s.currentStage)
  const highestStage = useGameSelector(s => s.highestStage)
  const cachedEnemyTeam = useGameSelector(s => s.cachedEnemyTeam)
  const activeEvents = useGameSelector(s => s.activeEvents ?? [])
  const battlesWon = useGameSelector(s => s.battlesWon)
  const totalRolls = useGameSelector(s => s.totalRolls)
  const totalDigs = useGameSelector(s => s.totalDigs)
  const winStreak = useGameSelector(s => s.winStreak ?? 0)
  const perfectStreak = useGameSelector(s => s.perfectStreak ?? 0)
  const streakLastStage = useGameSelector(s => (s as any).streakLastStage ?? -1)
  const streakSameStageCount = useGameSelector(s => (s as any).streakSameStageCount ?? 0)
  const clearedStage = useGameSelector(s => s.clearedStage ?? 0)
  const { dispatch, startCombat, startWatchCombat, setTeamRow, setReserveSlot, setReserveRow } = useGameActions()

  const [pickerSlot, setPickerSlot] = useState<number | null>(null)
  const [reservePickerSlot, setReservePickerSlot] = useState<number | null>(null)

  const slot6Locked = clearedStage < 15
  const teamHeroes = team.map((id) =>
    id ? heroes.find((h) => h.uid === id) : null,
  )
  const teamRows: BattleRow[] = teamRowsRaw?.length === 6
    ? teamRowsRaw
    : Array(6).fill("back")

  const teamTpls = teamHeroes
    .filter((h): h is NonNullable<typeof h> => !!h)
    .map((h) => HEROES_BY_ID[h.templateId])

  const synergies = useMemo(() => computeSynergies(teamTpls), [teamTpls])

  const counts: Record<string, number> = {}
  for (const t of teamTpls) {
    counts[t.role] = (counts[t.role] || 0) + 1
    for (const o of t.origins) counts[o] = (counts[o] || 0) + 1
  }
  const allCounts = Object.entries(counts).sort((a, b) => b[1] - a[1])

  const canWatch = clearedStage > 0 && currentStage <= clearedStage
  const hasTeam = !teamHeroes.every((h) => !h)
  const filledIndices = team.map((id, i) => id ? i : -1).filter(i => i >= 0)
  const hasFront = filledIndices.some(i => teamRows[i] === "front")

  function canGoBack(slotIdx: number): boolean {
    const uid = team[slotIdx]
    if (!uid) return true
    const owned = heroes.find(h => h.uid === uid)
    const tpl = owned ? HEROES_BY_ID[owned.templateId] : null
    return tpl?.range !== "melee"
  }

  function handleRowToggle(slotIdx: number) {
    const current = teamRows[slotIdx]
    const next: BattleRow = current === "front" ? "back" : "front"
    if (next === "back" && !canGoBack(slotIdx)) return
    setTeamRow(slotIdx, next)
  }

  const frontSlots = [0,1,2,3,4,5].filter(i => teamRows[i] === "front")
  const backSlots  = [0,1,2,3,4,5].filter(i => teamRows[i] === "back")

  // Reserve data
  const teamReserve = teamReserveRaw?.length === 4 ? teamReserveRaw : [null, null, null, null]
  const teamReserveRows: BattleRow[] = teamReserveRowsRaw?.length === 4
    ? teamReserveRowsRaw
    : ["front", "front", "back", "back"]
  const reserveHeroes = teamReserve.map(id => id ? heroes.find(h => h.uid === id) ?? null : null)

  // All uids currently in team or reserve (prevent duplicates)
  const allTeamUids = new Set([...team, ...teamReserve].filter(Boolean) as string[])

  function canReserveGoBack(slotIdx: number): boolean {
    const uid = teamReserve[slotIdx]
    if (!uid) return true
    const owned = heroes.find(h => h.uid === uid)
    const tpl = owned ? HEROES_BY_ID[owned.templateId] : null
    return tpl?.range !== "melee"
  }

  function handleReserveRowToggle(slotIdx: number) {
    const current = teamReserveRows[slotIdx]
    const next: BattleRow = current === "front" ? "back" : "front"
    if (next === "back" && !canReserveGoBack(slotIdx)) return
    setReserveRow(slotIdx, next)
  }

  // Reserve slot label: slots 0-1 are "front reserve", 2-3 are "back reserve"
  const reserveSlotLabel = (i: number) => i < 2 ? "Dự bị hàng trước" : "Dự bị hàng sau"

  function ReserveSlotCard({ i }: { i: number }) {
    const owned = reserveHeroes[i]
    const row = teamReserveRows[i]
    const tpl = owned ? HEROES_BY_ID[owned.templateId] : null
    const isMelee = tpl?.range === "melee"
    const isFrontReserve = i < 2

    return (
      <div className="flex flex-col gap-1">
        <button
          type="button"
          onClick={() => setReservePickerSlot(i)}
          className={cn(
            "min-h-[110px] rounded-lg border-2 border-dashed transition-colors p-1.5",
            owned && "border-primary/40 bg-card/40",
            !owned && "border-border hover:border-primary/50 bg-card/20",
            reservePickerSlot === i && "border-primary ring-2 ring-primary/50",
          )}
        >
          {owned ? (
            <HeroCard hero={owned} compact showStats={false} />
          ) : (
            <div className="h-full grid place-items-center text-muted-foreground/70">
              <div className="text-center">
                <Users className="size-5 mx-auto mb-1 opacity-60" />
                <p className="text-[10px]">{reserveSlotLabel(i)}</p>
              </div>
            </div>
          )}
        </button>
        {owned && (
          <button
            type="button"
            onClick={() => handleReserveRowToggle(i)}
            title={isMelee ? "Cận chiến: chỉ hàng trước" : `Thay thế cho hàng ${row === "front" ? "trước" : "sau"}`}
            className={cn(
              "text-[10px] rounded px-1.5 py-0.5 flex items-center justify-center gap-1 transition-colors w-full font-medium",
              isFrontReserve
                ? "bg-orange-500/20 border border-orange-500/50 text-orange-300"
                : "bg-blue-500/20 border border-blue-500/50 text-blue-300",
              isMelee && "opacity-60 cursor-not-allowed",
            )}
          >
            {isFrontReserve ? (
              <><Swords className="size-3" /> Thay hàng trước</>
            ) : (
              <><Crosshair className="size-3" /> Thay hàng sau</>
            )}
          </button>
        )}
      </div>
    )
  }

  function SlotCard({ i }: { i: number }) {
    const owned = teamHeroes[i]
    const row = teamRows[i]
    const tpl = owned ? HEROES_BY_ID[owned.templateId] : null
    const isMelee = tpl?.range === "melee"
    const isLocked6 = i === 5 && slot6Locked

    return (
      <div className="flex flex-col gap-1">
        <button
          type="button"
          onClick={() => { if (!isLocked6) setPickerSlot(i) }}
          className={cn(
            "min-h-[110px] rounded-lg border-2 border-dashed transition-colors p-1.5",
            isLocked6 && "opacity-40 cursor-not-allowed border-border/40",
            !isLocked6 && owned && "border-primary/40 bg-card/40",
            !isLocked6 && !owned && "border-border hover:border-primary/50 bg-card/20",
            pickerSlot === i && "border-primary ring-2 ring-primary/50",
          )}
        >
          {isLocked6 ? (
            <div className="h-full grid place-items-center text-muted-foreground/50">
              <div className="text-center">
                <Shield className="size-5 mx-auto mb-1 opacity-40" />
                <p className="text-[10px]">Mở ở tầng 15</p>
              </div>
            </div>
          ) : owned ? (
            <HeroCard hero={owned} compact showStats={false} />
          ) : (
            <div className="h-full grid place-items-center text-muted-foreground/70">
              <div className="text-center">
                <Users className="size-5 mx-auto mb-1 opacity-60" />
                <p className="text-xs">Slot {i + 1}</p>
              </div>
            </div>
          )}
        </button>

        {!isLocked6 && owned && (
          <button
            type="button"
            onClick={() => handleRowToggle(i)}
            title={isMelee ? "Cận chiến: chỉ hàng trước" : `Chuyển sang hàng ${row === "front" ? "sau" : "trước"}`}
            className={cn(
              "text-[10px] rounded px-1.5 py-0.5 flex items-center justify-center gap-1 transition-colors w-full font-medium",
              row === "front"
                ? "bg-orange-500/20 border border-orange-500/50 text-orange-300"
                : "bg-blue-500/20 border border-blue-500/50 text-blue-300",
              isMelee && "opacity-60 cursor-not-allowed",
            )}
          >
            {row === "front" ? (
              <><Swords className="size-3" /> Hàng trước</>
            ) : (
              <><Crosshair className="size-3" /> Hàng sau</>
            )}
          </button>
        )}
      </div>
    )
  }

  return (
    <div className="space-y-3">
    {/* Active Event Banner */}
    {activeEvents.length > 0 && (
      <div className="flex flex-wrap gap-2">
        {activeEvents.map(ae => {
          const banners: Record<string, { bg: string; text: string; msg: string }> = {
            blood_moon:  { bg: "bg-red-900/60 border-red-500/50",    text: "text-red-200",    msg: "🩸🌕 Đêm Trăng Máu — Kẻ địch +25% def/hp/dmg!" },
            war_economy: { bg: "bg-yellow-900/60 border-yellow-600/50", text: "text-yellow-200", msg: "💣📈 Chiến Tranh! Giá cả & tiền phạt +25%!" },
            black_market:{ bg: "bg-gray-800/60 border-gray-500/50",  text: "text-gray-300",   msg: "🕵️ Chợ Đen xuất hiện!" },
          }
          const b = banners[ae.eventId]
          return (
            <div key={ae.eventId} className={`flex-1 rounded-lg border px-3 py-2 text-xs font-semibold ${b.bg} ${b.text} animate-pulse`}>
              {b.msg}
            </div>
          )
        })}
      </div>
    )}
    <div className="grid lg:grid-cols-3 gap-4">
      <Card className="lg:col-span-2 ornate-border">
        <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
          <CardTitle className="font-fantasy flex items-center gap-2">
            <Swords className="size-5 text-primary" />
            Tháp Aetheria
          </CardTitle>
          <div className="flex items-center gap-2 text-xs">
            <Trophy className="size-4 text-rarity-legendary" />
            <span className="text-muted-foreground">Cao nhất:</span>
            <span className="font-bold text-rarity-legendary">Tầng {highestStage}</span>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-3">
            <Button variant="outline" size="icon"
              onClick={() => dispatch({ type: "SET_STAGE", stage: currentStage - 1 })}
              disabled={currentStage <= 1} aria-label="Giảm tầng">
              <ChevronDown className="size-4" />
            </Button>
            <div className="flex-1 grid place-items-center text-center bg-card/60 border-2 border-primary/40 rounded-lg py-6 ornate-border">
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Tầng hiện tại</p>
              <p className="font-fantasy font-bold text-4xl text-primary">{currentStage}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {currentStage <= 5 ? "Chỉ có quái Common"
                  : currentStage <= 15 ? "Quái Rare bắt đầu xuất hiện"
                  : currentStage <= 30 ? "Quái Epic — thử thách thật sự"
                  : currentStage <= 50 ? "Vùng nguy hiểm — Legendary xuất hiện"
                  : currentStage <= 70 ? "Mythical & Celestial cực hiếm"
                  : "Thiên Giới tràn ngập chiến trường!"}
              </p>
              {/* Stage status badge */}
              {currentStage <= clearedStage ? (
                <div className="mt-2 flex flex-col items-center gap-1">
                  <span className="text-[9px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-2 py-0.5">
                    ✓ Đã chinh phục thủ công
                  </span>
                  <span className="text-[9px] text-amber-400 bg-amber-500/10 border border-amber-500/20 rounded-full px-2 py-0.5">
                    ⚠ Chơi lại: phần thưởng giảm ½
                  </span>
                  <span className="text-[9px] text-sky-400 bg-sky-500/10 border border-sky-500/20 rounded-full px-2 py-0.5">
                    👁 Chế độ AI khả dụng
                  </span>
                </div>
              ) : currentStage === clearedStage + 1 ? (
                <span className="mt-2 text-[9px] text-yellow-300 bg-yellow-500/15 border border-yellow-500/30 rounded-full px-2 py-0.5">
                  ⚔ Tầng mới — chinh phục để mở tầng {currentStage + 1}!
                </span>
              ) : (
                <span className="mt-2 text-[9px] text-red-400/80 bg-red-500/10 border border-red-500/20 rounded-full px-2 py-0.5">
                  🔒 Hãy chinh phục tầng {clearedStage + 1} trước
                </span>
              )}
              <span className="mt-1 text-[9px] text-red-400/70 bg-red-500/10 border border-red-500/20 rounded-full px-2 py-0.5">
                💀 Thua: mất {(50 + currentStage * 10).toLocaleString()}🪙
              </span>
            </div>
            <Button variant="outline" size="icon"
              onClick={() => dispatch({ type: "SET_STAGE", stage: currentStage + 1 })}
              disabled={currentStage >= clearedStage + 1} aria-label="Tăng tầng">
              <ChevronUp className="size-4" />
            </Button>
          </div>

          <div className="grid grid-cols-1 gap-2">
            <Button size="lg" className="w-full font-fantasy text-lg tracking-wider"
              onClick={() => startCombat()} disabled={!hasTeam || !hasFront}>
              <Swords className="size-5 mr-2" />XUẤT TRẬN — TẦNG {currentStage}
            </Button>
            {hasTeam && !hasFront && (
              <p className="flex items-center gap-1.5 text-[10px] text-amber-400 bg-amber-500/10 border border-amber-500/30 rounded-md px-2 py-1.5">
                <Shield className="size-3 flex-shrink-0" />
                Phải có ít nhất 1 tướng ở <strong className="mx-0.5">hàng trước</strong> mới xuất trận được!
              </p>
            )}
            <Button size="lg" variant="outline"
              className={cn("w-full font-fantasy tracking-wider gap-2 transition-all",
                canWatch && hasFront ? "border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/10 hover:border-emerald-400"
                  : "opacity-40 cursor-not-allowed")}
              onClick={() => canWatch && hasFront && startWatchCombat()} disabled={!hasTeam || !canWatch || !hasFront}>
              <Eye className="size-4" />XEM AI ĐÁNH — TẦNG {currentStage}
            </Button>
            {!canWatch && (
              <p className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                <Info className="size-3 flex-shrink-0" />
                {clearedStage === 0
                  ? "Hãy tự tay chinh phục tầng 1 để mở khóa chế độ xem AI!"
                  : `Chế độ xem AI chỉ khả dụng ở tầng đã chinh phục thủ công (≤ Tầng ${clearedStage})`}
              </p>
            )}
          </div>

          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <Stat label="Trận thắng" value={battlesWon} />
            <Stat label="Tổng triệu hồi" value={totalRolls} />
            <Stat label="Tổng đào" value={totalDigs} />
          </div>

          {/* Win Streak & Perfect Streak display */}
          {(() => {
            const teamHeroes   = heroes.filter(h => team.includes(h.uid))
            const playerAvgLv  = teamHeroes.length > 0
              ? teamHeroes.reduce((s, h) => s + h.level, 0) / teamHeroes.length : 1
            const enemyLv      = Math.max(1, Math.floor(currentStage * 1.3))
            const ratio        = enemyLv / playerAvgLv
            const isChallenge  = ratio >= 0.75
            const pct          = Math.round(ratio * 100)
            const isReplay     = currentStage <= clearedStage

            // Farming detection
            const isSameStage  = currentStage === streakLastStage
            const newSameCount = isSameStage ? streakSameStageCount + 1 : 1
            const farmWarning  = isSameStage && newSameCount >= 2   // đang ở lần farm thứ 2 (lần cuối cho phép)
            const isFarming    = newSameCount > 2                   // đã vượt giới hạn farm

            // Lý do streak sẽ bị phá nếu đánh tầng này
            // Chơi lại tầng cũ được phép nếu địch vẫn tương đương (>= 75%)
            const breakReason: string | null =
              !isChallenge ? `Tầng quá dễ (địch lv${Math.round(enemyLv)} / ta lv${Math.round(playerAvgLv)} — ${pct}%)` :
              isFarming ? `Farm tầng ${currentStage} quá ${2} lần liên tiếp` :
              null

            const willBreak = breakReason !== null && winStreak > 0

            return (
              <div className="mt-2 space-y-1.5">
                {/* Challenge indicator — now shows break reason clearly */}
                <div className={`rounded-md px-2.5 py-1.5 text-[11px] border space-y-0.5 ${
                  willBreak
                    ? "border-red-500/50 bg-red-950/25 text-red-300"
                    : breakReason
                    ? "border-zinc-600/40 bg-zinc-900/30 text-zinc-400"
                    : farmWarning && winStreak > 0
                    ? "border-amber-500/50 bg-amber-950/25 text-amber-300"
                    : isChallenge
                    ? "border-green-500/40 bg-green-950/20 text-green-300"
                    : "border-zinc-600/40 bg-zinc-900/30 text-zinc-400"
                }`}>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">
                      {willBreak ? "💔 Đánh tầng này sẽ MẤT chuỗi!" :
                       breakReason && winStreak === 0 ? "⛔ Tầng này không tính streak" :
                       farmWarning && winStreak > 0 ? "⚠️ Cảnh báo: Lần farm cuối cùng!" :
                       "✅ Tầng này tính streak"}
                    </span>
                    <span className="opacity-70">
                      Địch lv{Math.round(enemyLv)} / Ta lv{Math.round(playerAvgLv)} ({pct}%)
                    </span>
                  </div>
                  {breakReason && (
                    <div className="text-[10px] opacity-80">Lý do: {breakReason}</div>
                  )}
                  {farmWarning && !isFarming && winStreak > 0 && (
                    <div className="text-[10px] opacity-80">
                      Đã farm tầng này {newSameCount - 1}/{2} lần — farm thêm 1 lần nữa sẽ mất chuỗi
                    </div>
                  )}
                </div>

                {/* Streak rules hint (collapsed, show only if no active streak) */}
                {winStreak === 0 && perfectStreak === 0 && (
                  <div className="text-[10px] text-zinc-500 px-1 space-y-0.5">
                    <div className="font-semibold text-zinc-400 mb-0.5">📋 Luật chuỗi diệt:</div>
                    <div>• Phải thắng tầng thử thách (địch ≥ 75% level ta)</div>
                    <div>• Chơi lại tầng cũ được phép nếu địch vẫn ≥ 75% level ta</div>
                    <div>• Không farm cùng tầng quá 2 lần liên tiếp</div>
                    <div>• Thua trận → mất toàn bộ chuỗi</div>
                    <div className="mt-1 text-zinc-400">🎯 Mốc thưởng: ×5 → +30%🪙 | ×8 → +60%🪙+💎 | ×12 → ×2🪙+2💎 | ×18 → ×2.6🪙+3💎</div>
                  </div>
                )}

                {/* Streak badges */}
                {(winStreak > 0 || perfectStreak > 0) && (
                  <div className="flex gap-2 flex-wrap">
                    {winStreak >= 1 && (() => {
                      const mult  = winStreak < 5  ? null
                                  : winStreak < 8  ? "×1.30🪙"
                                  : winStreak < 12 ? "×1.60🪙"
                                  : winStreak < 18 ? "×2.00🪙"
                                  : "×2.60🪙"
                      const label = winStreak < 5  ? "🔥 Chuỗi thắng"
                                  : winStreak < 8  ? "🔥 Đang nóng"
                                  : winStreak < 12 ? "🔥🔥 Bùng cháy"
                                  : winStreak < 18 ? "🔥🔥🔥 Không thể cản"
                                  : "💀 Vô Đối"
                      const color = winStreak < 5  ? "border-orange-500/40 text-orange-300 bg-orange-950/20"
                                  : winStreak < 8  ? "border-orange-400/60 text-orange-200 bg-orange-900/30"
                                  : winStreak < 12 ? "border-yellow-400/60 text-yellow-200 bg-yellow-900/30"
                                  : winStreak < 18 ? "border-red-400/60 text-red-200 bg-red-900/30"
                                  : "border-purple-400/70 text-purple-200 bg-purple-900/40"
                      // Next milestone info
                      const nextMilestone = winStreak < 5 ? `${5 - winStreak} trận nữa → +30%🪙`
                                          : winStreak < 8 ? `${8 - winStreak} trận nữa → +60%🪙+💎`
                                          : winStreak < 12 ? `${12 - winStreak} trận nữa → ×2🪙+2💎`
                                          : winStreak < 18 ? `${18 - winStreak} trận nữa → ×2.6🪙+3💎`
                                          : "Đỉnh cao tối thượng!"
                      return (
                        <div className={`flex-1 rounded-lg border px-2 py-1.5 text-center ${color} ${willBreak ? "opacity-50 line-through" : ""}`}>
                          <div className="font-bold text-sm">{label} ×{winStreak}</div>
                          {mult && <div className="text-[10px] opacity-80">Vàng {mult}/trận</div>}
                          <div className="text-[10px] opacity-60 mt-0.5">{nextMilestone}</div>
                        </div>
                      )
                    })()}
                    {perfectStreak >= 1 && (
                      <div className={`flex-1 rounded-lg border border-sky-400/50 text-sky-200 bg-sky-900/30 px-2 py-1.5 text-center ${willBreak ? "opacity-50" : ""}`}>
                        <div className="font-bold text-sm">⭐ Hoàn hảo ×{perfectStreak}</div>
                        <div className="text-[10px] opacity-80">
                          {perfectStreak >= 5
                            ? `+${Math.floor(perfectStreak / 5)}💎/trận`
                            : `Thêm ${5 - perfectStreak} trận không tử trận để nhận 💎`}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )
          })()}
        </CardContent>
      </Card>

      <Card className="ornate-border">
        <CardHeader>
          <CardTitle className="font-fantasy flex items-center gap-2 text-base">
            <Users className="size-5 text-primary" />Hệ Tộc Đang Hoạt Động
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {synergies.length === 0 && (
            <p className="text-xs text-muted-foreground italic">
              Chưa có hệ tộc nào kích hoạt. Ghép 2+ tướng cùng tộc/role để mở khoá buff.
            </p>
          )}
          {synergies.map((s) => {
            const def = SYNERGY_BY_TRAIT[s.trait]
            return (
              <div key={s.trait} className="rounded-md border border-primary/40 bg-primary/10 p-2">
                <div className="flex items-center justify-between">
                  <span className="font-fantasy font-bold text-sm text-primary">{def.name} ×{s.count}</span>
                  <span className="text-[10px] uppercase tracking-wider text-primary/80">
                    Tier {def.tiers.findIndex((t) => t === s.tier) + 1}
                  </span>
                </div>
                <p className="text-[11px] text-muted-foreground">{s.tier.description}</p>
              </div>
            )
          })}
          {allCounts.length > synergies.length && (
            <div className="border-t border-border/60 pt-2 mt-2">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Đang gần kích hoạt</p>
              <div className="flex flex-wrap gap-1">
                {allCounts
                  .filter(([t, c]) => c < 2 || !synergies.find((s) => s.trait === t))
                  .slice(0, 6)
                  .map(([t, c]) => (
                    <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-secondary/60 border border-border">
                      {TRAIT_LABEL[t as keyof typeof TRAIT_LABEL]} ×{c}
                    </span>
                  ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* === ENEMY PREVIEW === */}
      <div className="lg:col-span-3">
        <EnemyPreviewPanel stage={currentStage} />
      </div>

      {/* === TACTICAL ANALYSIS === */}
      {cachedEnemyTeam && (
        <div className="lg:col-span-3">
          <TacticalAnalysisPanel stage={currentStage} />
        </div>
      )}

      {/* === FORMATION EDITOR === */}
      <Card className="lg:col-span-3 ornate-border">
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-2">
            <CardTitle className="font-fantasy text-base flex items-center gap-2">
              <Shield className="size-4 text-primary" />
              Đội Hình ({teamHeroes.filter(Boolean).length}/{slot6Locked ? 5 : 6})
              {slot6Locked && (
                <span className="text-[10px] text-muted-foreground font-normal">· Slot 6 mở ở tầng 15</span>
              )}
            </CardTitle>
            <p className="text-[10px] text-muted-foreground">
              Click slot → chọn tướng · Click nhãn hàng → đổi vị trí
            </p>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* BACK ROW */}
          <div className="rounded-lg border border-blue-500/30 bg-blue-500/5 p-3">
            <p className="text-[10px] text-blue-400 font-bold uppercase tracking-widest mb-2 flex items-center gap-1">
              <Crosshair className="size-3" /> Hàng Sau — Xạ Thủ / Pháp Sư / Hỗ Trợ
              <span className="ml-auto font-normal normal-case text-blue-300/60">Quái đánh hàng sau 30%</span>
            </p>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 min-h-[80px]">
              {backSlots.map(i => <SlotCard key={i} i={i} />)}
              {backSlots.length === 0 && (
                <p className="col-span-6 text-center text-xs text-muted-foreground/60 py-6 italic">
                  Chưa có tướng ở hàng sau
                </p>
              )}
            </div>
          </div>

          {/* FRONT ROW */}
          <div className={cn("rounded-lg border p-3", hasTeam && !hasFront ? "border-amber-500/60 bg-amber-500/10" : "border-orange-500/30 bg-orange-500/5")}>
            <p className="text-[10px] text-orange-400 font-bold uppercase tracking-widest mb-2 flex items-center gap-1">
              <Swords className="size-3" /> Hàng Trước — Cận Chiến / Đấu Sĩ / Tank
              {hasTeam && !hasFront && (
                <span className="ml-2 text-amber-400 normal-case font-normal text-[10px]">⚠ Bắt buộc có ít nhất 1 tướng!</span>
              )}
              <span className="ml-auto font-normal normal-case text-orange-300/60">Quái đánh hàng trước 70%</span>
            </p>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 min-h-[80px]">
              {frontSlots.map(i => <SlotCard key={i} i={i} />)}
              {frontSlots.length === 0 && (
                <p className={cn("col-span-6 text-center text-xs py-6 italic", hasTeam ? "text-amber-400/80" : "text-muted-foreground/60")}>
                  {hasTeam ? "⚠ Hàng trước trống — không thể xuất trận!" : "Chưa có tướng ở hàng trước"}
                </p>
              )}
            </div>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-3 text-[10px] text-muted-foreground pt-1">
            <span className="flex items-center gap-1">
              <span className="inline-block size-2 rounded-full bg-orange-500/70" />
              Cận chiến: bắt buộc hàng trước
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block size-2 rounded-full bg-blue-500/70" />
              Tầm xa / Hỗ trợ: tự do chọn hàng
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block size-2 rounded-full bg-purple-500/70" />
              Assassin ưu tiên đánh hàng sau 70%
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block size-2 rounded-full bg-yellow-500/70" />
              15% hàng trước đỡ đòn cho hàng sau
            </span>
          </div>

          {/* Picker */}
          {pickerSlot !== null && (
            <div className="mt-2 p-3 rounded-lg bg-card/60 border border-border">
              <div className="flex items-center justify-between mb-2">
                <p className="font-fantasy text-sm">Chọn anh hùng cho slot {pickerSlot + 1}
                  <span className={cn("ml-2 text-[10px]",
                    teamRows[pickerSlot] === "front" ? "text-orange-400" : "text-blue-400")}>
                    ({teamRows[pickerSlot] === "front" ? "Hàng trước" : "Hàng sau"})
                  </span>
                </p>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline"
                    onClick={() => { dispatch({ type: "SET_TEAM_SLOT", slot: pickerSlot, uid: null }); setPickerSlot(null) }}>
                    Bỏ trống
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setPickerSlot(null)}>Đóng</Button>
                </div>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2 max-h-[360px] overflow-y-auto">
                {heroes.length === 0 && (
                  <p className="col-span-full text-center text-sm text-muted-foreground py-6">Chưa có anh hùng nào.</p>
                )}
                {heroes.map((h) => {
                  // Skip heroes already in reserve (unless it's the current slot's hero)
                  const inReserve = teamReserve.includes(h.uid) && team[pickerSlot!] !== h.uid
                  if (inReserve) return null
                  const tpl = HEROES_BY_ID[h.templateId]
                  const willAutoFront = tpl?.range === "melee" && teamRows[pickerSlot!] === "back"
                  // Level gap check: no hero in team can differ > 20 levels
                  const MAX_LEVEL_GAP = 20
                  const existingTeamHeroes = team
                    .map((id, i) => i === pickerSlot ? null : id ? heroes.find(x => x.uid === id) ?? null : null)
                    .filter(Boolean) as typeof heroes
                  const levelGapViolator = existingTeamHeroes.find(existing => Math.abs(existing.level - h.level) > MAX_LEVEL_GAP)
                  const hasLevelGap = !!levelGapViolator
                  return (
                    <div key={h.uid} className={cn("relative", hasLevelGap && "opacity-50")}>
                      <HeroCard hero={h} compact showStats={false}
                        onClick={() => {
                          if (!hasLevelGap) {
                            dispatch({ type: "SET_TEAM_SLOT", slot: pickerSlot, uid: h.uid })
                            setPickerSlot(null)
                          }
                        }}
                      />
                      {willAutoFront && !hasLevelGap && (
                        <div className="absolute bottom-0 left-0 right-0 bg-orange-900/80 rounded-b-lg px-1 py-0.5 text-center">
                          <p className="text-[9px] text-orange-300">→ Tự chuyển hàng trước</p>
                        </div>
                      )}
                      {hasLevelGap && (
                        <div className="absolute inset-0 flex items-end justify-center rounded-lg cursor-not-allowed">
                          <div className="w-full bg-red-950/90 rounded-b-lg px-1 py-0.5 text-center">
                            <p className="text-[9px] text-red-400">Chênh {Math.abs((levelGapViolator?.level ?? 0) - h.level)} cấp</p>
                          </div>
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* === RESERVE BENCH === */}
      <Card className="lg:col-span-3 ornate-border">
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-2">
            <CardTitle className="font-fantasy text-base flex items-center gap-2">
              <Shield className="size-4 text-purple-400" />
              Hàng Dự Bị
              <span className="text-[10px] font-normal text-muted-foreground">
                ({reserveHeroes.filter(Boolean).length}/4)
              </span>
            </CardTitle>
            <p className="text-[10px] text-muted-foreground">
              Tướng dự bị vào sân khi tướng chính thức cùng hàng bị hạ gục
            </p>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* FRONT RESERVE */}
          <div className="rounded-lg border border-orange-500/30 bg-orange-500/5 p-3">
            <p className="text-[10px] text-orange-400 font-bold uppercase tracking-widest mb-2 flex items-center gap-1">
              <Swords className="size-3" /> Dự Bị Hàng Trước (2 slot)
              <span className="ml-auto font-normal normal-case text-orange-300/60">Vào sân khi tướng hàng trước chết</span>
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 min-h-[80px]">
              {[0, 1].map(i => <ReserveSlotCard key={i} i={i} />)}
            </div>
          </div>

          {/* BACK RESERVE */}
          <div className="rounded-lg border border-blue-500/30 bg-blue-500/5 p-3">
            <p className="text-[10px] text-blue-400 font-bold uppercase tracking-widest mb-2 flex items-center gap-1">
              <Crosshair className="size-3" /> Dự Bị Hàng Sau (2 slot)
              <span className="ml-auto font-normal normal-case text-blue-300/60">Vào sân khi tướng hàng sau chết</span>
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 min-h-[80px]">
              {[2, 3].map(i => <ReserveSlotCard key={i} i={i} />)}
            </div>
          </div>

          {/* Reserve rules explanation */}
          <div className="rounded-md border border-purple-500/20 bg-purple-500/5 p-2.5 space-y-1">
            <p className="text-[10px] font-bold text-purple-300 uppercase tracking-wider">Luật thay thế</p>
            <ul className="text-[10px] text-muted-foreground space-y-0.5">
              <li>🟠 Tướng <strong>hàng trước</strong> chết → Dự bị hàng trước vào thay</li>
              <li>🔵 Tướng <strong>hàng sau</strong> chết → Dự bị hàng sau vào thay</li>
              <li>⚠ Hàng trước chết, <em>chỉ có dự bị hàng sau</em> → Tướng hàng sau hiện tại tiến lên trước, dự bị hàng sau chiếm hàng sau</li>
            </ul>
          </div>

          {/* Reserve Picker */}
          {reservePickerSlot !== null && (
            <div className="mt-2 p-3 rounded-lg bg-card/60 border border-border">
              <div className="flex items-center justify-between mb-2">
                <p className="font-fantasy text-sm">
                  Chọn tướng dự bị — {reserveSlotLabel(reservePickerSlot)}
                  <span className={cn("ml-2 text-[10px]",
                    reservePickerSlot < 2 ? "text-orange-400" : "text-blue-400")}>
                    ({reservePickerSlot < 2 ? "Hàng trước" : "Hàng sau"})
                  </span>
                </p>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline"
                    onClick={() => { setReserveSlot(reservePickerSlot, null); setReservePickerSlot(null) }}>
                    Bỏ trống
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setReservePickerSlot(null)}>Đóng</Button>
                </div>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2 max-h-[360px] overflow-y-auto">
                {heroes.length === 0 && (
                  <p className="col-span-full text-center text-sm text-muted-foreground py-6">Chưa có anh hùng nào.</p>
                )}
                {heroes
                  .filter(h => !allTeamUids.has(h.uid) || teamReserve[reservePickerSlot] === h.uid)
                  .map((h) => {
                    const tpl = HEROES_BY_ID[h.templateId]
                    const isMelee = tpl?.range === "melee"
                    const willAutoFront = isMelee && reservePickerSlot >= 2
                    return (
                      <div key={h.uid} className="relative">
                        <HeroCard hero={h} compact showStats={false}
                          onClick={() => { setReserveSlot(reservePickerSlot, h.uid); setReservePickerSlot(null) }}
                        />
                        {willAutoFront && (
                          <div className="absolute bottom-0 left-0 right-0 bg-orange-900/80 rounded-b-lg px-1 py-0.5 text-center">
                            <p className="text-[9px] text-orange-300">⚔ Cận chiến → hàng trước</p>
                          </div>
                        )}
                      </div>
                    )
                  })}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
    </div>
  )
}

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="rounded-md bg-card/60 border border-border py-2">
      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="font-fantasy font-bold text-base text-foreground">{value}</p>
    </div>
  )
}
