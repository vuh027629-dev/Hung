"use client"

import { useGameSelector } from "@/lib/game/store"
import { GAME_EVENTS } from "@/lib/game/store"
import type { GameEventId } from "@/lib/game/types"

// Event rarity color mappings
const RARITY_COLORS: Record<string, string> = {
  uncommon: "from-green-900/60 to-green-800/30 border-green-500/40",
  rare:     "from-blue-900/60 to-blue-800/30 border-blue-500/40",
  epic:     "from-purple-900/60 to-purple-800/30 border-purple-500/40",
}
const RARITY_BADGE: Record<string, string> = {
  uncommon: "bg-green-700/80 text-green-200",
  rare:     "bg-blue-700/80 text-blue-200",
  epic:     "bg-purple-700/80 text-purple-200",
}
const RARITY_LABEL_VI: Record<string, string> = {
  uncommon: "Hiếm",
  rare:     "Quý Hiếm",
  epic:     "Sử Thi",
}

// Detail descriptions for each event effect
const EVENT_EFFECTS: Partial<Record<GameEventId, { label: string; color: string }[]>> = {
  blood_moon: [
    { label: "👹 Kẻ địch +25% ATK & MAG", color: "text-red-300" },
    { label: "🛡️ Kẻ địch +25% DEF & RES", color: "text-orange-300" },
    { label: "❤️ Kẻ địch +25% HP tối đa", color: "text-rose-300" },
  ],
  war_economy: [
    { label: "🏪 Giá cửa hàng +25%", color: "text-yellow-300" },
    { label: "💫 Giá triệu hồi anh hùng +25%", color: "text-yellow-300" },
    { label: "💸 Tiền phạt khi thua +25%", color: "text-red-300" },
  ],
  black_market: [
    { label: "🏪 Giá cửa hàng giảm 15%", color: "text-green-300" },
    { label: "🛍️ Mua sắm hôm nay là cơ hội vàng!", color: "text-green-400" },
  ],
  golden_rain: [
    { label: "🪙 Vàng thưởng từ chiến đấu +30%", color: "text-yellow-300" },
    { label: "💰 Áp dụng cho mọi trận thắng hôm nay", color: "text-yellow-400" },
  ],
  gem_surge: [
    { label: "💎 Đá quý thưởng từ chiến đấu +30%", color: "text-cyan-300" },
    { label: "✨ Cơ hội tích lũy đá quý hiếm có!", color: "text-cyan-400" },
  ],
  hero_blessing: [
    { label: "⚔️ XP anh hùng nhận được +30%", color: "text-purple-300" },
    { label: "📈 Anh hùng cấp thấp sẽ lên nhanh hơn", color: "text-purple-400" },
  ],
  ancient_curse: [
    { label: "💀 Kẻ địch +20% ATK", color: "text-red-400" },
    { label: "🛡️ Đội ta -10% DEF", color: "text-orange-400" },
    { label: "🏆 Thắng được → vàng +15%", color: "text-yellow-300" },
  ],
  double_drop: [
    { label: "📦 Vật phẩm drop từ chiến đấu x2", color: "text-blue-300" },
    { label: "🎁 Cơ hội tốt nhất để farm vật phẩm!", color: "text-blue-400" },
  ],
  training_day: [
    { label: "🏋️ Chi phí huấn luyện anh hùng -50%", color: "text-green-300" },
    { label: "📚 Train x10, x100 giảm 50% chi phí hôm nay", color: "text-green-400" },
  ],
  celestial_gate: [
    { label: "🌌 Tỉ lệ Huyền Thoại +30% khi triệu hồi", color: "text-yellow-300" },
    { label: "✨ Tỉ lệ Thần Thoại +30% khi triệu hồi", color: "text-purple-300" },
    { label: "🚪 Cổng Thiên Giới chỉ mở 1 ngày!", color: "text-cyan-400" },
  ],
  merchant_caravan: [
    { label: "🛒 Cửa hàng có thêm nhiều hàng hơn", color: "text-amber-300" },
    { label: "🐪 Giá mua giảm 10% hôm nay", color: "text-amber-400" },
  ],
  cursed_moon: [
    { label: "🌑 Mỗi trận thua mất thêm 20% vàng", color: "text-red-400" },
    { label: "😈 Hãy cẩn thận — đừng để thua!", color: "text-red-300" },
  ],
  bounty_hunt: [
    { label: "🏹 Mỗi trận thắng +25% vàng thưởng", color: "text-green-300" },
    { label: "💰 Ngày lý tưởng để farm vàng!", color: "text-yellow-400" },
  ],
  exp_festival: [
    { label: "🎉 Player XP nhận được +30%", color: "text-purple-300" },
    { label: "📚 Lên cấp người chơi nhanh hơn 100%", color: "text-purple-400" },
  ],
  storm_of_chaos: [
    { label: "🌀 Kẻ địch mạnh hơn ngẫu nhiên 10–50%", color: "text-red-400" },
    { label: "💥 Nhưng thắng được → vàng & XP +50%!", color: "text-yellow-300" },
    { label: "⚠️ Thử thách cao nhất trong ngày!", color: "text-orange-300" },
  ],
}

const ALL_EVENT_CHANCES: { id: GameEventId; chance: string; rarity: string }[] = [
  { id: "blood_moon",       chance: "~8%",  rarity: "uncommon" },
  { id: "war_economy",      chance: "~8%",  rarity: "uncommon" },
  { id: "golden_rain",      chance: "~8%",  rarity: "uncommon" },
  { id: "hero_blessing",    chance: "~8%",  rarity: "uncommon" },
  { id: "cursed_moon",      chance: "~8%",  rarity: "uncommon" },
  { id: "bounty_hunt",      chance: "~8%",  rarity: "uncommon" },
  { id: "training_day",     chance: "~8%",  rarity: "uncommon" },
  { id: "black_market",     chance: "~4%",  rarity: "rare" },
  { id: "gem_surge",        chance: "~4%",  rarity: "rare" },
  { id: "double_drop",      chance: "~4%",  rarity: "rare" },
  { id: "merchant_caravan", chance: "~4%",  rarity: "rare" },
  { id: "exp_festival",     chance: "~4%",  rarity: "rare" },
  { id: "ancient_curse",    chance: "~1.5%",rarity: "epic" },
  { id: "celestial_gate",   chance: "~1.5%",rarity: "epic" },
  { id: "storm_of_chaos",   chance: "~1.5%",rarity: "epic" },
]

export function EventTab() {
  const activeEvents = useGameSelector(s => s.activeEvents ?? [])
  const currentDay   = useGameSelector(s => s.currentDay ?? 1)
  const battlesWon          = useGameSelector(s => s.battlesWon)
  const daysSinceLastEvent  = useGameSelector(s => s.daysSinceLastEvent ?? 0)

  const battlesUntilNextDay = 5 - (battlesWon % 5)
  const droughtDays = daysSinceLastEvent
  const daysUntilGuaranteed = Math.max(0, 4 - droughtDays)
  const hasEvents = activeEvents.length > 0

  return (
    <div className="space-y-5">
      {/* Drought Pity Bar */}
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="text-xl font-fantasy font-bold text-amber-300 flex items-center gap-2">
            📅 Sự Kiện Hàng Ngày
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Ngày {currentDay} · Còn {battlesUntilNextDay} trận đến ngày mới
          </p>
        </div>
        <div className="text-xs text-muted-foreground bg-card/60 border border-border/40 rounded-lg px-3 py-1.5">
          Mỗi ngày có <span className="text-amber-300 font-semibold">25%</span> xuất hiện sự kiện
        </div>
      </div>

      {/* Active events */}

      {/* Drought / Pity Bar */}
      <div className="rounded-xl border border-border bg-card/40 p-3">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-muted-foreground">🎲 Pity Sự Kiện</span>
          {daysUntilGuaranteed === 0
            ? <span className="text-xs font-bold text-yellow-400 animate-pulse">⚡ Hôm nay GUARANTEED có sự kiện!</span>
            : <span className="text-xs text-muted-foreground">Còn {daysUntilGuaranteed} ngày nữa guaranteed</span>
          }
        </div>
        <div className="h-2 rounded-full bg-muted/40 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${droughtDays >= 4 ? "bg-yellow-400 animate-pulse" : droughtDays >= 3 ? "bg-orange-400" : "bg-primary"}`}
            style={{ width: `${Math.min(100, (droughtDays / 4) * 100)}%` }}
          />
        </div>
        <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
          <span>0 ngày</span>
          <span>{droughtDays}/4 ngày không có sự kiện</span>
          <span>Ngày 5: guaranteed</span>
        </div>
      </div>

      {hasEvents ? (
        <div className="space-y-3">
          <p className="text-sm font-semibold text-amber-200 flex items-center gap-1.5">
            <span className="animate-pulse">🔥</span>
            Sự kiện đang diễn ra hôm nay ({activeEvents.length})
          </p>
          {activeEvents.map(ae => {
            const ev = GAME_EVENTS[ae.eventId]
            const effects = EVENT_EFFECTS[ae.eventId]
            const colors = RARITY_COLORS[ev.rarity]
            const badge  = RARITY_BADGE[ev.rarity]
            return (
              <div
                key={ae.eventId}
                className={`rounded-xl border bg-gradient-to-br ${colors} p-4 space-y-3 shadow-lg`}
              >
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{ev.icon}</span>
                    <div>
                      <div className="font-fantasy font-bold text-white leading-tight text-sm sm:text-base">
                        {ev.name}
                      </div>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-semibold ${badge}`}>
                        {RARITY_LABEL_VI[ev.rarity]}
                      </span>
                    </div>
                  </div>
                  <div className="text-[10px] text-muted-foreground bg-black/30 rounded px-2 py-1">
                    Ngày {ae.dayRolled}
                  </div>
                </div>

                <p className="text-xs text-white/80 leading-relaxed">{ev.description}</p>

                <div className="space-y-1 pt-1 border-t border-white/10">
                  <p className="text-[10px] text-white/50 uppercase tracking-wider font-semibold mb-1">Hiệu ứng</p>
                  {effects.map((eff, i) => (
                    <div key={i} className={`text-xs font-medium ${eff.color} flex items-center gap-1.5`}>
                      <span>{eff.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            )
          })}
        </div>
      ) : (
        <div className="rounded-xl border border-border/30 bg-card/40 p-6 text-center space-y-2">
          <div className="text-3xl">🌙</div>
          <p className="text-sm font-semibold text-muted-foreground">Hôm nay bình yên</p>
          <p className="text-xs text-muted-foreground/70">Không có sự kiện nào diễn ra trong ngày hôm nay.</p>
        </div>
      )}

      {/* Divider */}
      <div className="border-t border-border/30" />

      {/* Event Compendium */}
      <div className="space-y-3">
        <p className="text-sm font-semibold text-muted-foreground">📖 Danh Sách Sự Kiện Có Thể Xuất Hiện</p>
        <div className="grid gap-3">
          {ALL_EVENT_CHANCES.map(({ id, chance, rarity }) => {
            const ev = GAME_EVENTS[id]
            const effects = EVENT_EFFECTS[id]
            const isActive = activeEvents.some(ae => ae.eventId === id)
            const badge = RARITY_BADGE[ev.rarity]
            return (
              <div
                key={id}
                className={`rounded-lg border p-3 space-y-2 transition-all ${
                  isActive
                    ? "border-amber-500/50 bg-amber-900/20"
                    : "border-border/30 bg-card/30 opacity-70"
                }`}
              >
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{ev.icon}</span>
                    <span className="text-xs font-fantasy font-semibold text-white/90">{ev.name}</span>
                    {isActive && (
                      <span className="text-[9px] bg-amber-500 text-black px-1.5 py-0.5 rounded-full font-bold animate-pulse">
                        ĐANG DIỄN RA
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-semibold ${badge}`}>
                      {RARITY_LABEL_VI[ev.rarity]}
                    </span>
                    <span className="text-[10px] text-muted-foreground">Tỉ lệ: <span className="text-amber-300">{chance}</span></span>
                  </div>
                </div>
                <div className="space-y-0.5 pl-7">
                  {effects.map((eff, i) => (
                    <p key={i} className="text-[10px] text-muted-foreground/80">{eff.label}</p>
                  ))}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Probability info */}
      <div className="rounded-lg border border-border/20 bg-card/20 p-3 text-[10px] text-muted-foreground space-y-1">
        <p className="font-semibold text-white/60">ℹ️ Cơ chế xác suất</p>
        <p>• Mỗi ngày mới (sau 5 trận) có <span className="text-amber-300">25%</span> để xuất hiện ít nhất 1 sự kiện.</p>
        <p>• Nếu có sự kiện đầu tiên, tiếp tục có <span className="text-amber-300">25%</span> để xuất hiện thêm sự kiện thứ 2 (khác loại).</p>
        <p>• Trọng số: Trăng Máu 40% · Chiến Tranh 40% · Chợ Đen 20%.</p>
        <p>• Nhiều sự kiện có thể diễn ra cùng lúc, nhưng không thể trùng nhau.</p>
      </div>
    </div>
  )
}
