"use client"

import { useState } from "react"
import { useGameState, useGameSelector, useGameActions, computeHeroStats, RARITY_LABEL, getTrainCostMultiplier } from "@/lib/game/store"
import { xpToNextLevel } from "@/lib/game/combat"
import { HEROES_BY_ID } from "@/lib/game/heroes"
import { ITEMS_BY_ID } from "@/lib/game/items"
import { ORIGIN_LABEL, ROLE_LABEL } from "@/lib/game/factions"
import { PASSIVES, SKILLS, SKILL_EVOLUTION_MAP, SKILL_LEVEL_REQUIREMENTS, checkSkillUnlockCondition, getUnlockConditionText } from "@/lib/game/skills"
import { ORDER_INNATES } from "@/lib/game/order-innates"

// Mirror from combat.ts — skill scale formula
const RARITY_SKILL_MULT: Record<string, number> = {
  common:    1.00,
  rare:      1.10,
  uncommon:  1.10,
  epic:      1.22,
  legendary: 1.38,
  mythic:    1.58,
  celestial: 1.82,
}

/** Tính % scale thực tế của skill tại một cấp nhất định */
function getSkillScaleInfo(skill: { effects?: Array<{ damage?: { scale: number }; heal?: { scale: number } }> }, skillLvl: number, rarity: string) {
  if (!skill?.effects) return null
  const rarityMult = RARITY_SKILL_MULT[rarity] ?? 1.0
  const scaleMult = (1 + (skillLvl - 1) * 0.15) * rarityMult

  const dmgEffects = skill.effects.filter(e => e.damage).map(e => e.damage!.scale)
  const healEffects = skill.effects.filter(e => e.heal).map(e => e.heal!.scale)

  if (dmgEffects.length === 0 && healEffects.length === 0) return null

  const parts: string[] = []
  if (dmgEffects.length > 0) {
    parts.push(`⚔ ${dmgEffects.map(s => Math.round(s * scaleMult * 100) + "%").join(" + ")}`)
  }
  if (healEffects.length > 0) {
    parts.push(`💚 ${healEffects.map(s => Math.round(s * scaleMult * 100) + "%").join(" + ")}`)
  }
  return parts.join("  ")
}
import {
  RARITY_BG_CLASS,
  RARITY_GLOW,
  RARITY_TEXT_CLASS,
  RARITY_ORDER,
} from "@/lib/game/rarity"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { HeroCard } from "@/components/game/hero-card"
import { cn } from "@/lib/utils"
import {
  Sparkles,
  Trash2,
  Plus,
  ArrowUpCircle,
  Shield as ShieldIcon,
  Sword as SwordIcon,
  Gem as GemIcon,
  Zap,
} from "lucide-react"
import type { EquipSlot, Rarity } from "@/lib/game/types"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

// ── Auto-Sell Panel ─────────────────────────────────────────────────────────
function AutoSellPanel() {
  const autoSellRarities = useGameSelector(s => s.autoSellRarities)
  const { setAutoSellRarities } = useGameActions()
  const current = new Set(autoSellRarities as Rarity[])

  // Only allow auto-sell of common/rare (never epic+ to avoid accidents)
  const SELLABLE: Rarity[] = ["common", "rare", "epic"]

  const toggle = (rarity: Rarity) => {
    const next = new Set(current)
    next.has(rarity) ? next.delete(rarity) : next.add(rarity)
    setAutoSellRarities([...next] as Rarity[])
  }

  const RARITY_COLOR: Record<string, string> = {
    common:    "border-gray-400 text-gray-300",
    rare:      "border-blue-400 text-blue-300",
    epic:      "border-purple-400 text-purple-300",
  }
  const RARITY_ACTIVE: Record<string, string> = {
    common:    "bg-gray-500/30 border-gray-300",
    rare:      "bg-blue-500/30 border-blue-300",
    epic:      "bg-purple-500/30 border-purple-300",
  }
  const RARITY_LABEL_VI: Record<string, string> = {
    common: "Thường", rare: "Hiếm", epic: "Sử Thi",
  }

  return (
    <Card className="ornate-border border-orange-500/40">
      <CardHeader className="pb-2">
        <CardTitle className="font-fantasy text-base flex items-center gap-2">
          <Zap className="size-4 text-orange-400" />
          Bán Tướng Nhanh
          {current.size > 0 && (
            <span className="ml-auto text-xs font-normal text-orange-300 bg-orange-500/20 border border-orange-500/40 rounded px-2 py-0.5">
              Đang bật · {current.size} bậc
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-xs text-muted-foreground">
          Tướng có bậc hiếm được chọn sẽ <span className="text-orange-300 font-semibold">tự động bán ngay</span> khi roll — nhận vàng tương đương hi sinh. Không áp dụng cho Legendary trở lên.
        </p>
        <div className="flex flex-wrap gap-2">
          {SELLABLE.map((rarity) => {
            const active = current.has(rarity)
            return (
              <button
                key={rarity}
                onClick={() => toggle(rarity)}
                className={cn(
                  "px-3 py-1.5 rounded-lg border-2 text-sm font-fantasy font-bold transition-all",
                  active ? RARITY_ACTIVE[rarity] : "bg-card/50 opacity-60",
                  RARITY_COLOR[rarity],
                )}
              >
                {active ? "✓ " : ""}{RARITY_LABEL_VI[rarity]}
              </button>
            )
          })}
        </div>
        {current.size > 0 && (
          <p className="text-[11px] text-orange-300/80">
            ⚠ Đang tự bán: {[...current].map(r => RARITY_LABEL_VI[r]).join(", ")}. Nhấn lại để tắt.
          </p>
        )}
      </CardContent>
    </Card>
  )
}
// ────────────────────────────────────────────────────────────────────────────

export function HeroesTab() {
  const heroes = useGameSelector(s => s.heroes)
  const gold = useGameSelector(s => s.gold)
  const { dispatch } = useGameActions()
  const [selectedUid, setSelectedUid] = useState<string | null>(
    heroes[0]?.uid || null,
  )
  const [sellMode, setSellMode] = useState(false)
  const [sellSelected, setSellSelected] = useState<Set<string>>(new Set())

  const selected =
    heroes.find((h) => h.uid === selectedUid) ||
    heroes[0] ||
    null

  const toggleSellSelect = (uid: string) => {
    setSellSelected(prev => {
      const next = new Set(prev)
      next.has(uid) ? next.delete(uid) : next.add(uid)
      return next
    })
  }

  const confirmSell = () => {
    if (sellSelected.size === 0) return
    dispatch({ type: "SACRIFICE_HERO_MULTI", uids: [...sellSelected] })
    setSellSelected(new Set())
    setSellMode(false)
  }

  // Compute sell preview
  const { RARITY_LABEL_VI_SHORT } = {
    RARITY_LABEL_VI_SHORT: { common:"Thường",rare:"Hiếm",epic:"Sử Thi",legendary:"Huyền Thoại",mythic:"Thần Thoại",celestial:"Thiên Thể" } as Record<string, string>
  }
  const sellPreviewGold = [...sellSelected].reduce((acc, uid) => {
    const h = heroes.find(x => x.uid === uid)
    if (!h) return acc
    const tpl = HEROES_BY_ID[h.templateId]
    if (!tpl) return acc
    const rarityRankMap: Record<string, number> = {common:0,rare:1,epic:2,legendary:3,mythic:4,celestial:5}
    const rr = rarityRankMap[tpl.rarity] ?? 0
    return acc + (rr + 1) * 80 + h.level * 20
  }, 0)

  return (
    <div className="grid lg:grid-cols-3 gap-4">
      <div className="lg:col-span-1 space-y-3">
        <AutoSellPanel />

        <Card className="ornate-border">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="font-fantasy text-base">
                Anh hùng ({heroes.length})
              </CardTitle>
              <Button
                size="sm"
                variant={sellMode ? "destructive" : "outline"}
                className="h-7 px-2 text-xs"
                onClick={() => { setSellMode(v => !v); setSellSelected(new Set()) }}
              >
                <Trash2 className="size-3 mr-1" />
                {sellMode ? "Hủy" : "Bán Nhiều"}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {sellMode && (
              <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-2 space-y-2">
                <p className="text-xs text-red-300">
                  Nhấn chọn tướng muốn bán. Tướng đang trong đội sẽ bị rút khỏi đội.
                </p>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-yellow-300 flex-1">
                    {sellSelected.size > 0
                      ? `${sellSelected.size} tướng · +${sellPreviewGold}🪙`
                      : "Chưa chọn tướng nào"}
                  </span>
                  <Button
                    size="sm"
                    variant="destructive"
                    className="h-6 px-2 text-xs"
                    disabled={sellSelected.size === 0}
                    onClick={confirmSell}
                  >
                    Hi sinh ({sellSelected.size})
                  </Button>
                </div>
              </div>
            )}
            <div className="grid grid-cols-2 gap-2 max-h-[560px] overflow-y-auto pr-1">
              {heroes.map((h) => {
                const isSellSelected = sellSelected.has(h.uid)
                return (
                  <div key={h.uid} className="relative">
                    <HeroCard
                      hero={h}
                      compact
                      showStats={false}
                      selected={sellMode ? isSellSelected : h.uid === selected?.uid}
                      onClick={() => {
                        if (sellMode) toggleSellSelect(h.uid)
                        else setSelectedUid(h.uid)
                      }}
                    />
                    {sellMode && isSellSelected && (
                      <div className="absolute top-1 right-1 bg-red-500 rounded-full size-4 flex items-center justify-center pointer-events-none">
                        <span className="text-white text-[9px] font-bold">✓</span>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="lg:col-span-2 space-y-3">
        {!sellMode && selected ? (
          <HeroDetail uid={selected.uid} />
        ) : !sellMode ? (
          <Card className="ornate-border">
            <CardContent className="py-12 text-center text-muted-foreground">
              Chưa có anh hùng. Hãy đến Triệu hồi.
            </CardContent>
          </Card>
        ) : (
          <Card className="ornate-border">
            <CardContent className="py-12 text-center text-muted-foreground space-y-2">
              <Trash2 className="size-8 mx-auto text-red-400 opacity-50" />
              <p className="text-sm">Chọn tướng bên trái để bán.</p>
              <p className="text-xs opacity-60">Mỗi tướng đổi được vàng và đá quý theo bậc hiếm.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

function HeroDetail({ uid }: { uid: string }) {
  const heroes = useGameSelector(s => s.heroes)
  const gold = useGameSelector(s => s.gold)
  const state = useGameState()
  const { dispatch, equipBest } = useGameActions()
  const owned = heroes.find((h) => h.uid === uid)
  if (!owned) return null
  const tpl = HEROES_BY_ID[owned.templateId]
  const stats = computeHeroStats(owned, tpl)
  const passive = PASSIVES[tpl.passive]
  const xpNeed = xpToNextLevel(owned.level)
  const xpPct = Math.min(100, (owned.xp / xpNeed) * 100)

  return (
    <>
      <Card
        className={cn(
          "ornate-border",
          RARITY_GLOW[tpl.rarity],
        )}
      >
        <CardHeader>
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3
                className={cn(
                  "font-fantasy text-2xl font-bold",
                  RARITY_TEXT_CLASS[tpl.rarity],
                )}
              >
                {tpl.name}
              </h3>
              <p className="text-sm text-muted-foreground italic">
                {tpl.title}
              </p>
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground mt-1">
                {RARITY_LABEL[tpl.rarity]} · Lv.{owned.level}
              </p>
            </div>
            <div className="flex flex-col items-end gap-1">
              <span className="text-[10px] px-2 py-0.5 rounded bg-primary/15 text-primary border border-primary/30">
                {ROLE_LABEL[tpl.role]}
              </span>
              {tpl.origins.map((o) => (
                <span
                  key={o}
                  className="text-[10px] px-2 py-0.5 rounded bg-secondary/60 text-secondary-foreground border border-border"
                >
                  {ORIGIN_LABEL[o]}
                </span>
              ))}
              <span className="text-[10px] px-2 py-0.5 rounded bg-accent/30 text-accent-foreground border border-accent/40">
                {tpl.range === "melee" ? "Cận Chiến" : "Tầm Xa"}
              </span>
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-2 italic leading-relaxed">
            "{tpl.flavor}"
          </p>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <div className="flex justify-between text-[10px] mb-1">
              <span>Kinh nghiệm</span>
              <span className="font-mono">
                {owned.xp} / {xpNeed}
              </span>
            </div>
            <Progress value={xpPct} className="h-2" />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 text-xs">
            {(
              [
                ["HP", stats.hp],
                ["ATK", stats.atk],
                ["MAG", stats.mag],
                ["DEF", stats.def],
                ["RES", stats.res],
                ["SPD", stats.spd],
                ["CRIT", `${stats.crit}%`],
                ["CR.DMG", `${stats.critDmg}%`],
                ["LIFE", `${stats.lifesteal}%`],
              ] as const
            ).map(([k, v]) => (
              <div
                key={k}
                className="flex justify-between rounded border border-border bg-background/50 px-2 py-1"
              >
                <span className="text-muted-foreground">{k}</span>
                <span className="font-mono">{v}</span>
              </div>
            ))}
          </div>

          {/* Passive */}
          {passive && (
            <div className="rounded-lg border border-rarity-legendary/40 bg-rarity-legendary/10 p-3">
              <div className="flex items-center gap-2">
                <Sparkles className="size-4 text-rarity-legendary" />
                <span className="font-fantasy font-bold text-sm text-rarity-legendary">
                  Nội tại — {passive.name}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {passive.description}
              </p>
            </div>
          )}

          {/* Order Innate */}
          {tpl.orderInnate && (() => {
            const oi = tpl.orderInnate!
            const ek = (oi.effect as any).kind as string
            const mechIcon =
              ek === "reduceCooldown" ? "⏱️" :
              ek === "shareEnergy"    ? "⚡→" :
              ek === "hpToEnergy"     ? "🩸⚡" :
              ek === "regenOnRow"     ? "💚" :
              ek === "tauntSelf"      ? "📣" :
              ek === "resetSkill"     ? "🔄" :
              ek === "stackRegen"     ? "💚×" :
              ek === "echoEnergy"     ? "🔋" :
              ek === "transferShield" ? "🛡️→" :
              ek === "multi"          ? "✨" : "⚡"
            const mechLabel =
              ek === "reduceCooldown" ? "Giảm Cooldown" :
              ek === "shareEnergy"    ? "Truyền Năng Lượng" :
              ek === "hpToEnergy"     ? "Đổi HP → NL" :
              ek === "regenOnRow"     ? "Tái Sinh Hàng" :
              ek === "tauntSelf"      ? "Khiêu Chiến" :
              ek === "resetSkill"     ? "Reset Kỹ Năng" :
              ek === "stackRegen"     ? "Tái Sinh × ĐT" :
              ek === "echoEnergy"     ? "Tích Lũy NL" :
              ek === "transferShield" ? "Chuyển Khiên" :
              ek === "multi"          ? "Đa Hiệu Ứng" : "Đặc Biệt"
            return (
              <div className="rounded-lg border border-cyan-500/40 bg-cyan-500/10 p-3 space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-base">{mechIcon}</span>
                  <span className="font-fantasy font-bold text-sm text-cyan-400">
                    {oi.name}
                  </span>
                  <span className="ml-auto text-[10px] bg-cyan-500/20 text-cyan-300 px-1.5 py-0.5 rounded-full">
                    {mechLabel}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">{oi.description}</p>
              </div>
            )
          })()}

          <div className="flex items-center gap-2 flex-wrap">
            <Button size="sm" variant="outline" onClick={() => equipBest(uid)}>
              <ArrowUpCircle className="size-4 mr-1" />
              Trang bị tốt nhất
            </Button>
            {(() => {
              const trainXp = owned.level > 80 ? 50 : owned.level > 60 ? 75 : owned.level > 30 ? 150 : 200
              const trainCostMult = getTrainCostMultiplier(state)
              const trainOptions: { mult: number; label: string; baseCost: number }[] = [
                { mult: 1,   label: "x1",   baseCost: 100 },
                { mult: 10,  label: "x10",  baseCost: 1000 },
                { mult: 100, label: "x100", baseCost: 10000 },
              ]
              return (
                <div className="flex items-center gap-1 flex-wrap">
                  {trainOptions.map(({ mult, label, baseCost }) => {
                    const cost = Math.round(baseCost * trainCostMult)
                    const discounted = trainCostMult < 1
                    return (
                      <Button
                        key={mult}
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          // FIX: use atomic TRAIN_HERO action to avoid stale-level bug with x10/x100
                          dispatch({ type: "TRAIN_HERO", uid, mult })
                        }}
                        disabled={gold < cost}
                        title={`-${cost} vàng, +${(trainXp * mult).toLocaleString()} XP${discounted ? " (Ngày Huấn Luyện -50%!)" : ""}`}
                        className={discounted ? "border-green-500/60 text-green-400" : ""}
                      >
                        <Plus className="size-4 mr-1" />
                        {label}{" "}
                        <span className={`ml-1 text-[10px] ${discounted ? "text-green-400" : "text-muted-foreground"}`}>
                          -{cost >= 1000 ? cost/1000+"k" : cost}g{discounted ? " ✨" : ""}
                        </span>
                      </Button>
                    )
                  })}
                </div>
              )
            })()}
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button size="sm" variant="destructive">
                  <Trash2 className="size-4 mr-1" />
                  Hi sinh
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle className="font-fantasy">
                    Hi sinh {tpl.name}?
                  </AlertDialogTitle>
                  <AlertDialogDescription>
                    Anh hùng sẽ biến mất vĩnh viễn — đổi lại ngươi nhận được
                    vàng và đá quý theo độ hiếm.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Hủy</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() =>
                      dispatch({ type: "SACRIFICE_HERO", uid })
                    }
                  >
                    Hi sinh
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </CardContent>
      </Card>

      <Card className="ornate-border">
        <CardHeader>
          <CardTitle className="font-fantasy text-base">Kỹ năng & Trang Bị Loadout</CardTitle>
        </CardHeader>
        <CardContent>
          <SkillLoadoutEditor uid={uid} owned={owned} tpl={tpl} />
        </CardContent>
      </Card>

      {/* Equipment */}
      <Card className="ornate-border">
        <CardHeader>
          <CardTitle className="font-fantasy text-base">Trang bị</CardTitle>
        </CardHeader>
        <CardContent className="grid sm:grid-cols-3 gap-3">
          {(["weapon", "armor", "trinket"] as EquipSlot[]).map((slot) => (
            <EquipSlotPicker key={slot} heroUid={uid} slot={slot} />
          ))}
        </CardContent>
      </Card>
    </>
  )
}

// ============================================================
// Item Detail Card — rich stat + passive display
// ============================================================

const STAT_LABEL: Record<string, string> = {
  hp: "HP", atk: "ATK", mag: "MAG", def: "DEF", res: "RES",
  spd: "TỐC", crit: "CRIT%", critDmg: "CRIT DMG%", acc: "ACC%",
  eva: "TRÁNH%", lifesteal: "HÚT MÁU%",
}

const STAT_COLOR: Record<string, string> = {
  hp: "text-green-400", atk: "text-red-400", mag: "text-purple-400",
  def: "text-blue-400", res: "text-cyan-400", spd: "text-yellow-400",
  crit: "text-orange-400", critDmg: "text-orange-300", acc: "text-sky-400",
  eva: "text-teal-400", lifesteal: "text-pink-400",
}

function formatStatValue(key: string, val: number): string {
  if (["crit", "critDmg", "acc", "eva", "lifesteal"].includes(key)) return `+${val}%`
  return `+${val}`
}

function ItemDetailCard({
  item,
  innate,
  compact = false,
}: {
  item: import("@/lib/game/types").ItemTemplate
  innate?: import("@/lib/game/types").ItemInnate
  compact?: boolean
}) {
  const rarityLabel: Record<string, string> = {
    common: "Thường", rare: "Hiếm", epic: "Sử Thi",
    legendary: "Huyền Thoại", mythic: "Thần Thoại",
  }

  return (
    <div className="space-y-1.5">
      {/* Description */}
      {!compact && (
        <p className="text-[10px] text-muted-foreground italic leading-snug">{item.description}</p>
      )}

      {/* Base Stats */}
      {item.stats && Object.keys(item.stats).length > 0 && (
        <div className="rounded border border-border/60 bg-background/40 px-2 py-1.5">
          <p className="text-[9px] uppercase tracking-widest text-muted-foreground mb-1">Chỉ Số</p>
          <div className="grid grid-cols-2 gap-x-3 gap-y-0.5">
            {(Object.entries(item.stats) as [string, number][]).map(([k, v]) => (
              <div key={k} className="flex items-center justify-between gap-1">
                <span className="text-[10px] text-muted-foreground">{STAT_LABEL[k] ?? k.toUpperCase()}</span>
                <span className={`text-[10px] font-bold ${STAT_COLOR[k] ?? "text-primary"}`}>
                  {formatStatValue(k, v)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Innate bonus */}
      {innate && (
        <div className="rounded border border-amber-500/40 bg-amber-500/10 px-2 py-1.5">
          <p className="text-[9px] uppercase tracking-widest text-amber-400/80 mb-0.5">⚡ Nội Tại Ngẫu Nhiên</p>
          <span className="text-[10px] font-bold text-amber-300">
            +{innate.value} {innate.label}
          </span>
        </div>
      )}

      {/* Passive ability */}
      {item.passive && (
        <div className="rounded border border-violet-500/40 bg-violet-500/10 px-2 py-1.5">
          <p className="text-[9px] uppercase tracking-widest text-violet-400/80 mb-0.5">
            ✦ Nội Tại Trang Bị
            {"name" in item.passive ? ` — ${(item.passive as any).name}` : ""}
          </p>
          <p className="text-[10px] text-violet-200 leading-snug">{item.passive.description}</p>
        </div>
      )}

      {/* Price */}
      {!compact && (
        <p className="text-[9px] text-muted-foreground text-right">
          Giá gốc: {item.basePrice.toLocaleString()}🪙 · Bán lại: {Math.round(item.basePrice * 0.4).toLocaleString()}🪙
        </p>
      )}
    </div>
  )
}


function EquipSlotPicker({
  heroUid,
  slot,
}: {
  heroUid: string
  slot: EquipSlot
}) {
  const heroes = useGameSelector(s => s.heroes)
  const inventory = useGameSelector(s => s.inventory)
  const { dispatch } = useGameActions()
  const owned = heroes.find((h) => h.uid === heroUid)
  const equippedId = owned?.equipment[slot]
  const equipped = equippedId ? ITEMS_BY_ID[equippedId] : null
  const equippedInvUid = owned?.equipmentInvUid?.[slot]
  const equippedInvEntry = equippedInvUid
    ? inventory.find(i => i.uid === equippedInvUid)
    : equippedId ? inventory.find(i => i.itemId === equippedId && i.innate) : null

  // Collect inventory uids already equipped by OTHER heroes in this slot
  const usedInvUids = new Set(
    heroes
      .filter((h) => h.uid !== heroUid)
      .map((h) => h.equipmentInvUid?.[slot])
      .filter(Boolean)
  )
  // Also collect itemIds equipped by others (for items without invUid tracking)
  const usedItemIds = new Set(
    heroes
      .filter((h) => h.uid !== heroUid)
      .map((h) => h.equipment[slot])
      .filter(Boolean)
  )

  const candidates = inventory
    .map((i) => ({ inv: i, item: ITEMS_BY_ID[i.itemId] }))
    .filter(
      (x) =>
        x.item &&
        x.item.kind === "equip" &&
        x.item.slot === slot &&
        // Each equip item is a unique instance (uid); exclude those worn by other heroes
        !usedInvUids.has(x.inv.uid),
    )

  const SLOT_ICON =
    slot === "weapon"
      ? SwordIcon
      : slot === "armor"
      ? ShieldIcon
      : GemIcon
  const SLOT_LABEL =
    slot === "weapon"
      ? "Vũ Khí"
      : slot === "armor"
      ? "Giáp"
      : "Trang Sức"

  return (
    <div className="rounded-lg border border-border bg-card/60 p-2">
      <div className="flex items-center gap-2">
        <SLOT_ICON className="size-4 text-primary" />
        <span className="font-fantasy text-xs uppercase tracking-wider text-muted-foreground">
          {SLOT_LABEL}
        </span>
      </div>
      {equipped ? (
        <div
          className={cn(
            "mt-1 rounded border p-2 space-y-1",
            RARITY_BG_CLASS[equipped.rarity],
          )}
        >
          <div className="flex items-start justify-between gap-1">
            <div>
              <p className={cn("font-fantasy text-sm font-bold leading-tight", RARITY_TEXT_CLASS[equipped.rarity])}>
                {equipped.name}
              </p>
              <p className="text-[9px] uppercase tracking-widest text-muted-foreground">
                {equipped.rarity === "common" ? "Thường" : equipped.rarity === "rare" ? "Hiếm" : equipped.rarity === "epic" ? "Sử Thi" : equipped.rarity === "legendary" ? "Huyền Thoại" : "Thần Thoại"}
              </p>
            </div>
            <Button
              size="sm"
              variant="ghost"
              className="h-6 px-2 text-[10px] shrink-0"
              onClick={() => dispatch({ type: "EQUIP_ITEM", heroUid, slot, itemId: null })}
            >
              Tháo
            </Button>
          </div>
          <ItemDetailCard item={equipped} innate={equippedInvEntry?.innate} />
        </div>
      ) : (
        <p className="text-[11px] text-muted-foreground italic mt-1">
          Trống
        </p>
      )}
      {candidates.length > 0 && (
        <details className="mt-2">
          <summary className="cursor-pointer text-[11px] text-primary/80 hover:text-primary select-none">
            ▾ Chọn trang bị ({candidates.length} trong túi đồ)
          </summary>
          <div className="mt-2 space-y-2 max-h-72 overflow-y-auto pr-0.5">
            {candidates.map(({ inv, item }) => (
              <div
                key={inv.uid}
                className={cn(
                  "rounded border p-2 text-[11px] space-y-1.5",
                  RARITY_BG_CLASS[item.rarity],
                )}
              >
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <span className={cn("font-fantasy font-bold text-xs", RARITY_TEXT_CLASS[item.rarity])}>
                      {item.name}
                    </span>
                    <span className="ml-1.5 text-[9px] uppercase tracking-widest text-muted-foreground">
                      {item.rarity === "common" ? "Thường" : item.rarity === "rare" ? "Hiếm" : item.rarity === "epic" ? "Sử Thi" : item.rarity === "legendary" ? "Huyền Thoại" : "Thần Thoại"}
                    </span>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-6 px-2 text-[10px] shrink-0"
                    onClick={() =>
                      dispatch({
                        type: "EQUIP_ITEM",
                        heroUid,
                        slot,
                        itemId: item.id,
                        invUid: inv.uid,
                      })
                    }
                  >
                    Trang Bị
                  </Button>
                </div>
                <ItemDetailCard item={item} innate={inv.innate} compact />
              </div>
            ))}
          </div>
        </details>
      )}
    </div>
  )
}

// ============================================================
// Skill Loadout Editor
// ============================================================

function SkillLoadoutEditor({
  uid,
  owned,
  tpl,
}: {
  uid: string
  owned: import("@/lib/game/types").OwnedHero
  tpl: import("@/lib/game/types").HeroTemplate
}) {
  const battlesWon = useGameSelector(s => s.battlesWon)
  const { dispatch } = useGameActions()
  const [swapSlot, setSwapSlot] = useState<0 | 1 | 2 | null>(null)

  const loadout: [string, string, string] = owned.equippedSkillIds ?? [...tpl.skills] as [string, string, string]

  const allUnlocked = owned.unlockedSkills ?? []
  const bonusUnlocked = (tpl.bonusSkills ?? []).filter(bs =>
    allUnlocked.includes(bs.skillId) ||
    checkSkillUnlockCondition(bs.unlockCondition, owned, battlesWon)
  ).map(bs => bs.skillId)

  const ultimateSkillIds = [...tpl.skills, ...bonusUnlocked].filter(sid => SKILLS[sid]?.ultimate)
  const regularSkillIds = [...tpl.skills, ...bonusUnlocked].filter(sid => !SKILLS[sid]?.ultimate)
  const lockedBonusSkills = (tpl.bonusSkills ?? []).filter(bs => !bonusUnlocked.includes(bs.skillId))

  function getAvailableForSlot(slot: 0 | 1 | 2): string[] {
    if (slot === 2) return ultimateSkillIds
    const others = [loadout[0], loadout[1], loadout[2]].filter((_, i) => i !== slot)
    return regularSkillIds.filter(sid => !others.includes(sid))
  }

  return (
    <div className="space-y-4">
      <div>
        {/* Hero Skill Points Display */}
        <div className="flex items-center justify-between rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 mb-3">
          <div className="flex items-center gap-1.5">
            <span className="text-amber-400 text-sm">⚡</span>
            <span className="text-[11px] font-bold text-amber-300">Điểm Kỹ Năng</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[13px] font-bold text-amber-400">{owned.heroSkillPoints ?? 0}</span>
            <span className="text-[10px] text-muted-foreground">/ Tổng: {Math.floor(owned.level / 5)}</span>
          </div>
          <div className="text-[9px] text-muted-foreground">Skill 1,2: 1đ · Ulti: 2đ</div>
        </div>
        <p className="text-[11px] uppercase tracking-widest text-muted-foreground mb-2">
          Loadout Chiến Đấu (3 kỹ năng)
        </p>
        <div className="grid sm:grid-cols-3 gap-2">
          {([0, 1, 2] as const).map(i => {
            const sid = loadout[i]
            const isBonus = !tpl.skills.includes(sid as any)
            const lvl = isBonus ? ((owned.bonusSkillLevels ?? {})[sid] ?? 1) : owned.skillLevels[i]
            const evoId = SKILL_EVOLUTION_MAP[sid]
            const isEvolved = lvl >= 5 && !!evoId
            const displaySid = isEvolved ? evoId : sid
            const skill = SKILLS[displaySid]
            const reqs = SKILL_LEVEL_REQUIREMENTS[i] || [1, 5, 10, 20, 35]
            const nextReq = lvl < 5 ? reqs[lvl] : null
            const skillPointCost = i === 2 ? 2 : 1
            const availableSkillPts = owned.heroSkillPoints ?? 0
            const canUpgrade = lvl < 5 && owned.level >= (nextReq ?? 999) && availableSkillPts >= skillPointCost
            const isSwapping = swapSlot === i
            const available = getAvailableForSlot(i)

            return (
              <div
                key={i}
                className={cn(
                  "rounded-lg border-2 p-3 bg-card/70 transition-all",
                  isSwapping ? "border-primary ring-2 ring-primary/30" :
                  i === 2 ? "border-rarity-legendary/60 bg-rarity-legendary/10" :
                  isEvolved ? "border-rarity-mythic/60 bg-rarity-mythic/10" :
                  isBonus ? "border-rarity-epic/60 bg-rarity-epic/5" :
                  "border-border",
                )}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={cn(
                    "font-fantasy font-bold text-sm",
                    i === 2 ? "text-rarity-legendary" : isEvolved ? "text-rarity-mythic" : isBonus ? "text-rarity-epic" : "",
                  )}>
                    {skill?.name ?? sid}
                  </span>
                  <span className="text-[9px] uppercase tracking-widest text-muted-foreground">
                    {i === 2 ? "Ultimate" : `Slot ${i + 1}`}
                  </span>
                </div>
                {isBonus && (
                  <span className="text-[9px] text-rarity-epic uppercase tracking-wider block mb-1">⚡ Bonus</span>
                )}
                {isEvolved && (
                  <span className="text-[9px] text-rarity-mythic uppercase tracking-wider block mb-1">✦ Tiến Hóa</span>
                )}
                <p className="text-[10px] text-muted-foreground leading-snug mb-2">
                  {skill?.description}
                </p>
                {/* Scale info theo cấp kỹ năng */}
                {skill && (() => {
                  const curScale = getSkillScaleInfo(skill as any, lvl, owned.rarity)
                  const nxtScale = lvl < 5 ? getSkillScaleInfo(skill as any, lvl + 1, owned.rarity) : null
                  if (!curScale) return null
                  return (
                    <div className="rounded border border-primary/20 bg-primary/5 px-2 py-1 mb-2 space-y-0.5">
                      <div className="text-[10px] font-bold text-primary/80">
                        Lv{lvl}: {curScale}
                      </div>
                      {nxtScale && (
                        <div className="text-[10px] text-amber-400/80">
                          Lv{lvl + 1}: {nxtScale} <span className="text-muted-foreground">(+15% scale)</span>
                        </div>
                      )}
                    </div>
                  )
                })()}
                <div className="text-[10px] text-muted-foreground mb-2">
                  CD: {skill?.cooldown ?? "?"} lượt · Cấp {lvl}/5
                </div>
                <div className="flex items-center gap-1 flex-wrap">
                  {lvl < 5 && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 px-2 text-[10px]"
                      disabled={!canUpgrade}
                      title={
                        nextReq && owned.level < nextReq
                          ? `Cần Lv.${nextReq}`
                          : availableSkillPts < skillPointCost
                          ? `Không đủ điểm kỹ năng (cần ${skillPointCost}đ)`
                          : `Nâng cấp (tốn ${skillPointCost} điểm kỹ năng)`
                      }
                      onClick={() => dispatch({ type: "ADD_SKILL_POINT_HERO", uid, index: i })}
                    >
                      <Plus className="size-3" />
                      {nextReq && owned.level < nextReq ? `Lv.${nextReq}` : availableSkillPts < skillPointCost ? `${skillPointCost}đ❌` : `+1 (${skillPointCost}đ)`}
                    </Button>
                  )}
                  {available.length > 1 && (
                    <Button
                      size="sm"
                      variant={isSwapping ? "default" : "outline"}
                      className="h-6 px-2 text-[10px]"
                      onClick={() => setSwapSlot(isSwapping ? null : i)}
                    >
                      ⇄ Đổi
                    </Button>
                  )}
                  {lvl >= 5 && !isEvolved && evoId && (
                    <span className="text-[9px] text-rarity-epic">⚡→{SKILLS[evoId]?.name}</span>
                  )}
                  {lvl >= 5 && !evoId && (
                    <span className="text-[9px] text-yellow-400">✦ MAX</span>
                  )}
                </div>

                {isSwapping && (
                  <div className="mt-2 space-y-1 border-t border-border pt-2">
                    <p className="text-[9px] uppercase tracking-wider text-muted-foreground mb-1">Chọn kỹ năng thay thế:</p>
                    {available.map(altSid => {
                      const altSkill = SKILLS[altSid]
                      if (!altSkill) return null
                      const isCurrent = altSid === sid
                      return (
                        <button
                          key={altSid}
                          type="button"
                          className={cn(
                            "w-full text-left rounded border p-1.5 text-[10px] transition-colors",
                            isCurrent
                              ? "border-primary bg-primary/10 text-primary"
                              : "border-border hover:border-primary/60 bg-background/60",
                          )}
                          onClick={() => {
                            if (!isCurrent) {
                              dispatch({ type: "EQUIP_HERO_SKILL", uid, slot: i, skillId: altSid })
                            }
                            setSwapSlot(null)
                          }}
                        >
                          <span className="font-fantasy font-bold">{altSkill.name}</span>
                          {isCurrent && <span className="ml-1 text-[8px] opacity-70">(đang dùng)</span>}
                          <span className="block text-muted-foreground text-[9px]">{altSkill.description.slice(0, 55)}…</span>
                        </button>
                      )
                    })}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>

      {lockedBonusSkills.length > 0 && (
        <div>
          <p className="text-[11px] uppercase tracking-widest text-muted-foreground mb-2">
            🔒 Kỹ Năng Chưa Mở Khóa
          </p>
          <div className="grid sm:grid-cols-2 gap-2">
            {lockedBonusSkills.map(bs => {
              const skill = SKILLS[bs.skillId]
              if (!skill) return null
              return (
                <div key={bs.skillId} className="rounded-lg border border-dashed border-muted-foreground/40 p-2 bg-muted/10 opacity-70">
                  <div className="flex items-center gap-1 mb-1">
                    <span className="text-[10px]">🔒</span>
                    <span className="font-fantasy font-bold text-[11px] text-muted-foreground">{skill.name}</span>
                  </div>
                  <p className="text-[10px] text-muted-foreground/70 mb-1">{skill.description.slice(0, 70)}…</p>
                  <p className="text-[9px] text-primary/70 uppercase tracking-wider">
                    Điều kiện: {getUnlockConditionText(bs.unlockCondition)}
                  </p>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
