"use client"

import { useState, useCallback, useEffect, useRef } from "react"
import { supabase } from "@/lib/game/cloud-save"
import {
  sendPvpInvite, respondPvpInvite,
  subscribeToPvpInvites, fetchPendingInvites,
  type PvpInvite,
} from "@/lib/game/pvp"
import {
  createPvpSession,
} from "@/lib/game/pvp-session"
import { buildPvpCombatState } from "@/lib/game/combat"
import { HEROES_BY_ID } from "@/lib/game/heroes"
import { RARITY_TEXT_CLASS, RARITY_BG_CLASS, RARITY_LABEL } from "@/lib/game/rarity"
import { useGameState, useGameActions } from "@/lib/game/store"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Users, Search, Trophy, Swords, Star, ChevronLeft,
  Shield, Zap, Crown, TrendingUp, Ghost, Loader2,
  Globe, Clock, X, Check, Sword,
} from "lucide-react"
import type { GameState, OwnedHero, Rarity } from "@/lib/game/types"

// ── Types ────────────────────────────────────────────────────
interface PlayerEntry {
  username: string
  level: number
  highestStage: number
  battlesWon: number
  towerRecord: number
  heroCount: number
  topHeroes: OwnedHero[]
  saveData: GameState
}

// ── Helpers ──────────────────────────────────────────────────
function getRarityPower(r: Rarity): number {
  const order: Rarity[] = [
    "common","rare","epic","legendary",
    "mythic","celestial","transcendent","divine","primordial",
  ]
  return order.indexOf(r)
}

function getTopHeroes(heroes: OwnedHero[], count = 5): OwnedHero[] {
  return [...heroes]
    .sort((a, b) => {
      const rDiff = getRarityPower(b.rarity) - getRarityPower(a.rarity)
      return rDiff !== 0 ? rDiff : b.level - a.level
    })
    .slice(0, count)
}

function formatNumber(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M"
  if (n >= 1_000) return (n / 1_000).toFixed(1) + "K"
  return String(n)
}

function getTeamHeroes(gs: GameState): OwnedHero[] {
  return (gs.team ?? [])
    .filter((uid): uid is string => !!uid)
    .map(uid => gs.heroes.find(h => h.uid === uid))
    .filter((h): h is OwnedHero => !!h)
}

// ── Sub-components ────────────────────────────────────────────
function HeroChip({ hero }: { hero: OwnedHero }) {
  const tpl = HEROES_BY_ID[hero.templateId]
  return (
    <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-medium ${RARITY_BG_CLASS[hero.rarity]} ${RARITY_TEXT_CLASS[hero.rarity]}`}>
      <span className="font-fantasy">{tpl?.name ?? hero.templateId}</span>
      <span className="opacity-60">Lv{hero.level}</span>
    </span>
  )
}

function StatPill({ icon, label, value }: { icon: React.ReactNode; label: string; value: string | number }) {
  return (
    <div className="flex flex-col items-center rounded-lg border border-white/10 bg-black/20 px-3 py-2 min-w-[70px]">
      <span className="text-muted-foreground mb-0.5">{icon}</span>
      <span className="font-fantasy text-base font-bold text-foreground">{value}</span>
      <span className="text-[9px] text-muted-foreground uppercase tracking-wide">{label}</span>
    </div>
  )
}

// ── Incoming invite notification ──────────────────────────────
function InviteNotification({ invite, onAccept, onDecline }: {
  invite: PvpInvite
  onAccept: () => void
  onDecline: () => void
}) {
  return (
    <div className="rounded-xl border border-amber-500/60 bg-amber-500/10 p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <p className="font-fantasy text-sm font-bold text-amber-300 flex items-center gap-2">
            <Sword className="size-4 shrink-0" /> Lời Mời PvP!
          </p>
          <p className="text-xs text-muted-foreground mt-0.5">
            <span className="text-foreground font-semibold">{invite.from_user}</span> thách đấu bạn
          </p>
          <div className="flex flex-wrap gap-1 mt-2">
            {getTopHeroes(invite.from_team, 4).map(h => <HeroChip key={h.uid} hero={h} />)}
          </div>
        </div>
        <div className="flex flex-col gap-2 shrink-0">
          <Button size="sm" onClick={onAccept} className="bg-green-600 hover:bg-green-700 font-fantasy text-xs">
            <Check className="size-3 mr-1" /> Chấp nhận
          </Button>
          <Button size="sm" variant="outline" onClick={onDecline} className="font-fantasy text-xs border-red-500/50 text-red-400 hover:bg-red-500/10">
            <X className="size-3 mr-1" /> Từ chối
          </Button>
        </div>
      </div>
    </div>
  )
}

// ── Player Card (list) ────────────────────────────────────────
function PlayerCard({ player, rank, onView, onChallenge, currentUser, pendingTo }: {
  player: PlayerEntry; rank: number
  onView: () => void; onChallenge: () => void
  currentUser: string; pendingTo: string | null
}) {
  const rankColors = ["text-yellow-400","text-slate-300","text-amber-600"]
  const rankIcons = ["👑","🥈","🥉"]
  const isMe = player.username === currentUser
  const isSending = pendingTo === player.username

  return (
    <Card className="ornate-border hover:border-primary/40 transition-colors">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer" onClick={onView}>
            <span className={`font-fantasy text-xl font-bold shrink-0 ${rankColors[rank] ?? "text-muted-foreground"}`}>
              {rank < 3 ? rankIcons[rank] : `#${rank + 1}`}
            </span>
            <div className="min-w-0">
              <p className="font-fantasy text-base font-bold truncate flex items-center gap-2">
                {player.username}
                {isMe && <Badge variant="outline" className="text-[9px] border-primary/40 text-primary shrink-0">Bạn</Badge>}
              </p>
              <p className="text-[10px] text-muted-foreground">Lv.{player.level} · {player.heroCount} anh hùng</p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0 text-[11px] text-muted-foreground">
            <span className="flex items-center gap-1"><Swords className="size-3 text-red-400" /> Stage {player.highestStage}</span>
          </div>
        </div>

        {player.topHeroes.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1">
            {player.topHeroes.map(h => <HeroChip key={h.uid} hero={h} />)}
          </div>
        )}

        <div className="mt-3 flex items-center justify-between gap-2">
          <Button variant="ghost" size="sm" className="text-[11px] text-muted-foreground px-2" onClick={onView}>
            <Search className="size-3 mr-1" /> Xem chi tiết
          </Button>
          {!isMe && currentUser ? (
            <Button
              size="sm"
              onClick={onChallenge}
              disabled={isSending || !!pendingTo}
              className="font-fantasy text-xs bg-red-700/70 hover:bg-red-700 border border-red-500/40"
            >
              {isSending
                ? <><Clock className="size-3 mr-1 animate-spin" /> Chờ...</>
                : <><Sword className="size-3 mr-1" /> Thách Đấu</>}
            </Button>
          ) : !currentUser && !isMe ? (
            <p className="text-[10px] text-muted-foreground italic">Đăng nhập để PvP</p>
          ) : null}
        </div>
      </CardContent>
    </Card>
  )
}

// ── Player Detail ─────────────────────────────────────────────
function PlayerDetail({ player, onBack, onChallenge, currentUser, pendingTo }: {
  player: PlayerEntry; onBack: () => void
  onChallenge: () => void; currentUser: string; pendingTo: string | null
}) {
  const gs = player.saveData
  const isMe = player.username === currentUser
  const isSending = pendingTo === player.username

  const rarityOrder: Rarity[] = [
    "primordial","divine","transcendent","celestial",
    "mythic","legendary","epic","rare","common",
  ]
  const heroGroups = rarityOrder
    .map(r => ({ rarity: r, heroes: gs.heroes.filter(h => h.rarity === r) }))
    .filter(g => g.heroes.length > 0)

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="sm" onClick={onBack} className="text-muted-foreground">
          <ChevronLeft className="size-4 mr-1" /> Quay lại
        </Button>
        {!isMe && currentUser && (
          <Button
            size="sm" onClick={onChallenge}
            disabled={isSending || (!!pendingTo && !isSending)}
            className="font-fantasy bg-red-700/70 hover:bg-red-700 border border-red-500/40"
          >
            {isSending
              ? <><Clock className="size-3 mr-1 animate-spin" /> Chờ phản hồi...</>
              : <><Sword className="size-4 mr-1.5" /> Thách Đấu PvP</>}
          </Button>
        )}
      </div>

      <Card className="ornate-border">
        <CardContent className="p-5">
          <div className="flex items-center gap-4">
            <div className="size-14 rounded-full bg-primary/20 border-2 border-primary/40 flex items-center justify-center">
              <Ghost className="size-7 text-primary/70" />
            </div>
            <div>
              <h2 className="font-fantasy text-2xl font-bold flex items-center gap-2">
                {player.username}
                {isMe && <Badge variant="outline" className="text-xs border-primary/40 text-primary">Bạn</Badge>}
              </h2>
              <p className="text-sm text-muted-foreground">Level {player.level} · {player.heroCount} anh hùng</p>
            </div>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <StatPill icon={<TrendingUp className="size-3.5" />} label="Stage" value={gs.highestStage} />
            <StatPill icon={<Swords className="size-3.5" />} label="Trận thắng" value={formatNumber(gs.battlesWon)} />
            <StatPill icon={<Shield className="size-3.5" />} label="Tháp" value={`F${gs.towerRecord}`} />
            <StatPill icon={<Star className="size-3.5" />} label="Tướng" value={gs.heroes.length} />
            <StatPill icon={<Zap className="size-3.5" />} label="Gacha" value={formatNumber(gs.totalRolls ?? 0)} />
          </div>
        </CardContent>
      </Card>

      {gs.team?.some(Boolean) && (
        <Card className="ornate-border">
          <CardHeader className="pb-2">
            <CardTitle className="font-fantasy text-sm flex items-center gap-2">
              <Crown className="size-4 text-amber-400" /> Đội Hình Hiện Tại
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {getTeamHeroes(gs).map(hero => {
                const tpl = HEROES_BY_ID[hero.templateId]
                return (
                  <div key={hero.uid} className={`flex flex-col items-center rounded-xl border p-3 min-w-[80px] ${RARITY_BG_CLASS[hero.rarity]}`}>
                    <span className={`font-fantasy text-xs font-bold text-center ${RARITY_TEXT_CLASS[hero.rarity]}`}>{tpl?.name ?? hero.uid}</span>
                    <span className="text-[9px] text-muted-foreground mt-0.5">{RARITY_LABEL[hero.rarity]}</span>
                    <span className="text-[9px] text-muted-foreground">Lv {hero.level}</span>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="ornate-border">
        <CardHeader className="pb-2">
          <CardTitle className="font-fantasy text-sm flex items-center gap-2">
            <Users className="size-4 text-sky-400" /> Bộ Sưu Tập ({gs.heroes.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {heroGroups.map(({ rarity, heroes }) => (
            <div key={rarity}>
              <p className={`text-[10px] font-bold uppercase tracking-wider mb-2 ${RARITY_TEXT_CLASS[rarity]}`}>
                {RARITY_LABEL[rarity]} ({heroes.length})
              </p>
              <div className="flex flex-wrap gap-1.5">
                {heroes.sort((a, b) => b.level - a.level).map(h => <HeroChip key={h.uid} hero={h} />)}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}

// ── Main Tab ─────────────────────────────────────────────────
export function CommunityTab() {
  const state = useGameState()
  const { startPvpCombat } = useGameActions()

  // ── Auth ─────────────────────────────────────────────────
  const [currentUser, setCurrentUser] = useState("")
  const currentUserRef = useRef("")
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      const u = (data.user?.email ?? "").replace("@aetheria.game", "")
      setCurrentUser(u)
      currentUserRef.current = u
    })
  }, [])

  // ── Players list ─────────────────────────────────────────
  const [players, setPlayers] = useState<PlayerEntry[]>([])
  const playersRef = useRef<PlayerEntry[]>([])
  const [loading, setLoading] = useState(false)
  const [loaded, setLoaded] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [selectedPlayer, setSelectedPlayer] = useState<PlayerEntry | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [pendingTo, setPendingTo] = useState<string | null>(null)
  const [incomingInvites, setIncomingInvites] = useState<PvpInvite[]>([])

  // ── PvP invite refs (stable, no re-render) ───────────────
  const pendingInviteId = useRef<string | null>(null)
  const startPvpCombatRef = useRef(startPvpCombat)
  useEffect(() => { startPvpCombatRef.current = startPvpCombat }, [startPvpCombat])
  const stateRef = useRef(state)
  useEffect(() => { stateRef.current = state }, [state])

  // ── Realtime invite subscription ─────────────────────────
  useEffect(() => {
    if (!currentUser) return
    fetchPendingInvites(currentUser).then(setIncomingInvites)

    const unsub = subscribeToPvpInvites(currentUser, (invite) => {
      // Incoming new invite for me
      if (invite.to_user === currentUser && invite.status === "pending") {
        setIncomingInvites(prev => [invite, ...prev.filter(i => i.id !== invite.id)])
        return
      }

      // My invite was accepted — opponent wrote session_id into the invite row
      if (
        invite.from_user === currentUser &&
        invite.id === pendingInviteId.current &&
        invite.status === "accepted" &&
        invite.session_id
      ) {
        setPendingTo(null)
        pendingInviteId.current = null

        const target = playersRef.current.find(p => p.username === invite.to_user)
        if (!target) return

        // I am player1 (challenger) — no perspective flip, join session directly
        startPvpCombatRef.current(
          getTeamHeroes(target.saveData),
          target.saveData.playerStats,
          invite.session_id,
          invite.to_user,        // opponent = player2
          currentUserRef.current,// me = player1
          false                  // isPlayer2 = false → no flip
        )
        return
      }

      // My invite was declined
      if (
        invite.from_user === currentUser &&
        invite.id === pendingInviteId.current &&
        invite.status === "declined"
      ) {
        setPendingTo(null)
        pendingInviteId.current = null
      }
    })

    return unsub
  }, [currentUser])

  // ── Fetch players ────────────────────────────────────────
  const fetchPlayers = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const { data, error: dbErr } = await supabase
        .from("game_saves")
        .select("save_data, user_id")
        .order("updated_at", { ascending: false })
        .limit(100)

      if (dbErr) {
        setError(dbErr.code === "42501" || dbErr.code === "PGRST301"
          ? "Cần quyền đọc công khai. Chạy SUPABASE_PVP_SETUP.sql trong Supabase."
          : dbErr.message)
        return
      }

      const entries: PlayerEntry[] = (data ?? []).map(row => {
        const gs = row.save_data as GameState & { _username?: string }
        if (!gs || typeof gs !== "object") return null
        return {
          username: gs._username ?? `Player#${row.user_id.slice(0, 6)}`,
          level: gs.level ?? 1,
          highestStage: gs.highestStage ?? 0,
          battlesWon: gs.battlesWon ?? 0,
          towerRecord: gs.towerRecord ?? 0,
          heroCount: gs.heroes?.length ?? 0,
          topHeroes: getTopHeroes(gs.heroes ?? [], 5),
          saveData: gs,
        } as PlayerEntry
      }).filter((p): p is PlayerEntry => p !== null)

      entries.sort((a, b) =>
        b.highestStage !== a.highestStage ? b.highestStage - a.highestStage : b.battlesWon - a.battlesWon
      )
      setPlayers(entries)
      playersRef.current = entries
      setLoaded(true)
    } catch (err) {
      setError(String(err))
    } finally {
      setLoading(false)
    }
  }, [])

  // ── Challenge (send invite) ──────────────────────────────
  const handleChallenge = useCallback(async (player: PlayerEntry) => {
    if (!currentUser || pendingTo) return
    const teamHeroes = getTeamHeroes(player.saveData)
    if (teamHeroes.length === 0) { alert(`${player.username} chưa có đội hình!`); return }

    setPendingTo(player.username)
    const myTeam = stateRef.current.team
      .filter((uid): uid is string => !!uid)
      .map(uid => stateRef.current.heroes.find(h => h.uid === uid))
      .filter((h): h is OwnedHero => !!h)

    const result = await sendPvpInvite(currentUser, player.username, myTeam, stateRef.current.playerStats)
    if (!result.ok) { alert("Lỗi gửi lời mời: " + result.error); setPendingTo(null); return }

    pendingInviteId.current = result.id ?? null
    // Auto-cancel after 60s if no response
    setTimeout(() => {
      if (pendingInviteId.current === result.id) {
        setPendingTo(null)
        pendingInviteId.current = null
      }
    }, 60_000)
  }, [currentUser, pendingTo])

  // ── Accept invite ────────────────────────────────────────
  const handleAccept = useCallback(async (invite: PvpInvite) => {
    setIncomingInvites(prev => prev.filter(i => i.id !== invite.id))

    // Build combat state from CHALLENGER (player1) perspective
    // player1 = invite.from_user (challenger) → their team = "player" side
    // player2 = currentUser (me, accepter) → my team = "enemy" side in session
    // We need challenger's team as player side — that is invite.from_team
    // And my team as enemy side — stateRef.current
    const myState = stateRef.current

    // Build with MY state as base but challenger's team as opponent
    // Actually: session is always stored in player1 POV:
    //   player side = challenger's heroes (invite.from_team)
    //   enemy side  = my heroes (accepter)
    // So we call buildPvpCombatState with challenger as "self" and my team as "opponent"
    const challengerFakeState = {
      ...myState,
      // Override team/heroes to be challenger's
      team: invite.from_team.map(h => h.uid),
      heroes: invite.from_team,
      teamRows: invite.from_team.map(h => {
        const tpl = (HEROES_BY_ID as Record<string, {range?: string}>)[h.templateId]
        return tpl?.range === "melee" ? "front" : "back"
      }),
      playerStats: invite.from_stats,
    } as any

    const myTeamHeroes = getTeamHeroes(myState)
    const sharedCombat = buildPvpCombatState(challengerFakeState, myTeamHeroes, myState.playerStats)

    // Create session — stored in player1 (challenger) POV
    const result = await createPvpSession(invite.from_user, currentUser, sharedCombat)
    if (!result.ok || !result.id) {
      // Fallback: local only
      await respondPvpInvite(invite.id, "accepted")
      startPvpCombatRef.current(invite.from_team, invite.from_stats)
      return
    }

    // Write session_id back into invite row so challenger receives it via realtime
    await respondPvpInvite(invite.id, "accepted", result.id)

    // I am player2 (accepter) — my team is "enemy" in session, need perspective flip
    startPvpCombatRef.current(
      invite.from_team,
      invite.from_stats,
      result.id,
      invite.from_user,        // opponent = player1 (challenger)
      currentUser,             // me = player2
      true                     // isPlayer2 = true → flip perspective
    )
  }, [currentUser])

  // ── Decline invite ───────────────────────────────────────
  const handleDecline = useCallback(async (invite: PvpInvite) => {
    await respondPvpInvite(invite.id, "declined")
    setIncomingInvites(prev => prev.filter(i => i.id !== invite.id))
  }, [])

  const filtered = searchQuery.trim()
    ? players.filter(p => p.username.toLowerCase().includes(searchQuery.trim().toLowerCase()))
    : players

  if (selectedPlayer) {
    return (
      <div className="space-y-4">
        {incomingInvites.map(inv => (
          <InviteNotification key={inv.id} invite={inv} onAccept={() => handleAccept(inv)} onDecline={() => handleDecline(inv)} />
        ))}
        <PlayerDetail
          player={selectedPlayer} onBack={() => setSelectedPlayer(null)}
          onChallenge={() => handleChallenge(selectedPlayer)}
          currentUser={currentUser} pendingTo={pendingTo}
        />
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {incomingInvites.map(inv => (
        <InviteNotification key={inv.id} invite={inv} onAccept={() => handleAccept(inv)} onDecline={() => handleDecline(inv)} />
      ))}

      <Card className="ornate-border">
        <CardContent className="p-4">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              <h2 className="font-fantasy text-xl font-bold flex items-center gap-2">
                <Globe className="size-5 text-sky-400" /> Cộng Đồng
                {incomingInvites.length > 0 && (
                  <span className="size-5 rounded-full bg-red-500 text-white text-[10px] flex items-center justify-center animate-pulse">
                    {incomingInvites.length}
                  </span>
                )}
              </h2>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                {currentUser ? `Đăng nhập: ${currentUser}` : "Đăng nhập để thách đấu PvP"}
              </p>
            </div>
            <Button onClick={fetchPlayers} disabled={loading} size="sm" className="font-fantasy shrink-0">
              {loading
                ? <><Loader2 className="size-4 mr-1.5 animate-spin" /> Đang tải...</>
                : <><Search className="size-4 mr-1.5" />{loaded ? "Làm mới" : "Tải danh sách"}</>}
            </Button>
          </div>

          {loaded && players.length > 0 && (
            <div className="mt-3 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
              <input
                type="text" placeholder="Tìm kiếm theo tên..."
                value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
                className="w-full rounded-md border border-white/10 bg-black/30 pl-8 pr-3 py-1.5 text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
              />
            </div>
          )}
        </CardContent>
      </Card>

      {pendingTo && (
        <Card className="border-amber-500/40 bg-amber-500/10">
          <CardContent className="p-3 flex items-center gap-3">
            <Clock className="size-4 text-amber-400 animate-pulse shrink-0" />
            <div className="flex-1">
              <p className="text-sm text-amber-300 font-medium">Đang chờ <span className="font-bold">{pendingTo}</span> chấp nhận...</p>
              <p className="text-[10px] text-amber-400/70">Lời mời hết hạn sau 60 giây</p>
            </div>
            <Button size="sm" variant="ghost" className="text-red-400 text-xs shrink-0"
              onClick={() => { setPendingTo(null); pendingInviteId.current = null }}>
              <X className="size-3 mr-1" /> Hủy
            </Button>
          </CardContent>
        </Card>
      )}

      {error && (
        <Card className="border-red-500/40 bg-red-500/10">
          <CardContent className="p-4">
            <p className="text-sm text-red-400 font-medium mb-1">Lỗi tải dữ liệu</p>
            <pre className="text-[10px] text-red-300/80 whitespace-pre-wrap">{error}</pre>
          </CardContent>
        </Card>
      )}

      {!loading && !loaded && !error && (
        <Card className="ornate-border">
          <CardContent className="p-10 text-center">
            <Trophy className="size-12 mx-auto mb-4 text-amber-400/40" />
            <h3 className="font-fantasy text-lg text-muted-foreground mb-2">Bảng Xếp Hạng & PvP</h3>
            <p className="text-sm text-muted-foreground/60 mb-4">Xem thành tích và thách đấu người chơi khác</p>
            <Button onClick={fetchPlayers} className="font-fantasy">
              <Users className="size-4 mr-2" /> Xem cộng đồng
            </Button>
          </CardContent>
        </Card>
      )}

      {!loading && loaded && filtered.length === 0 && !error && (
        <Card className="ornate-border">
          <CardContent className="p-8 text-center">
            <Ghost className="size-10 mx-auto mb-3 text-muted-foreground/40" />
            <p className="font-fantasy text-muted-foreground">
              {searchQuery ? "Không tìm thấy người chơi nào" : "Chưa có người chơi nào khác"}
            </p>
          </CardContent>
        </Card>
      )}

      {!error && filtered.length > 0 && (
        <>
          <div className="flex items-center justify-between">
            <p className="text-[11px] text-muted-foreground">{filtered.length} người chơi · Sắp theo stage</p>
            <Badge variant="outline" className="text-[10px]">
              <Trophy className="size-3 mr-1 text-amber-400" /> Top {Math.min(filtered.length, 100)}
            </Badge>
          </div>
          <div className="space-y-2">
            {filtered.map((player, idx) => (
              <PlayerCard
                key={player.username} player={player} rank={idx}
                onView={() => setSelectedPlayer(player)}
                onChallenge={() => handleChallenge(player)}
                currentUser={currentUser} pendingTo={pendingTo}
              />
            ))}
          </div>
        </>
      )}

      {loaded && (
        <Card className="border-sky-500/20 bg-sky-500/5">
          <CardContent className="p-3">
            <p className="text-[10px] text-sky-400/70">
              💡 PvP dùng Supabase Realtime. Cần chạy <code className="font-mono">SUPABASE_PVP_SETUP.sql</code> trong Supabase Dashboard để kích hoạt.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
