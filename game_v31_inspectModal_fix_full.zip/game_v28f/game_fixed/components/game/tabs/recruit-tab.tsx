"use client"

import { useGameSelector, useGameActions } from "@/lib/game/store"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { HEROES_BY_RARITY } from "@/lib/game/heroes"
import {
  HERO_GACHA_RATES,
  HERO_GACHA_RATES_GOLD,
  RARITY_LABEL,
  RARITY_ORDER,
  RARITY_TEXT_CLASS,
} from "@/lib/game/rarity"
import type { Rarity } from "@/lib/game/types"
import { Gem, Sparkles, Coins, Star, ShieldAlert } from "lucide-react"
import { cn } from "@/lib/utils"

export function RecruitTab() {
  return (
    <Tabs defaultValue="gem" className="space-y-3">
      <TabsList className="bg-card/60 ornate-border p-1">
        <TabsTrigger value="gem" className="font-fantasy">
          <Gem className="size-4 mr-1 text-rarity-celestial" />
          Vực Tinh Tú
        </TabsTrigger>
        <TabsTrigger value="gold" className="font-fantasy">
          <Coins className="size-4 mr-1 text-rarity-legendary" />
          Quán Lữ Hành
        </TabsTrigger>
      </TabsList>

      <TabsContent value="gem">
        <GemBanner />
      </TabsContent>
      <TabsContent value="gold">
        <GoldBanner />
      </TabsContent>
    </Tabs>
  )
}

// ── Pity bar component ────────────────────────────────────────────────────────
function PityBar({ current, hard, label, color }: { current: number; hard: number; label: string; color: string }) {
  const pct = Math.min(100, Math.round((current / hard) * 100))
  const isSoftPity = current >= Math.round(hard * 0.75)
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-[11px]">
        <span className={cn("font-medium", isSoftPity ? "text-yellow-300" : "text-muted-foreground")}>
          {isSoftPity && "⚡ "}Pity {label}
        </span>
        <span className={cn("font-mono font-bold", isSoftPity ? "text-yellow-300" : "text-foreground")}>
          {current} / {hard}
        </span>
      </div>
      <div className="h-2 rounded-full bg-muted/40 overflow-hidden">
        <div
          className={cn("h-full rounded-full transition-all duration-500", color, isSoftPity && "animate-pulse")}
          style={{ width: `${pct}%` }}
        />
      </div>
      {isSoftPity && (
        <p className="text-[10px] text-yellow-400/80">Soft pity đang hoạt động — tỉ lệ tăng dần!</p>
      )}
    </div>
  )
}

function GemBanner() {
  const gems = useGameSelector(s => s.gems)
  const luckBuff = useGameSelector(s => s.luckBuff)
  const gachaPity = useGameSelector(s => s.gachaPity)
  const { rollHero } = useGameActions()
  const displayRarities = RARITY_ORDER.filter((r) => HERO_GACHA_RATES[r] > 0)
  const pity = gachaPity ?? { gemSinceLegendary: 0, gemSinceMythic: 0, goldSinceEpic: 0 }

  return (
    <div className="grid lg:grid-cols-3 gap-4">
      <Card className="lg:col-span-2 ornate-border">
        <CardHeader>
          <CardTitle className="font-fantasy flex items-center gap-2">
            <Sparkles className="size-5 text-primary" />
            Cổng Triệu Hồi Anh Hùng
            {luckBuff && (
              <span className="ml-auto text-xs font-normal text-yellow-300 flex items-center gap-1 bg-yellow-500/20 border border-yellow-500/40 rounded px-2 py-0.5">
                ✨ May Mắn +{[0,25,50,75][luckBuff.tier]}% · còn {luckBuff.rollsLeft} lần
              </span>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div
            className="relative rounded-xl border-2 border-primary/40 ornate-border h-44 grid place-items-center"
            aria-hidden
            style={{
              background:
                "radial-gradient(ellipse at center, oklch(0.4 0.15 80 / 0.3), transparent 70%), oklch(0.18 0.03 270)",
            }}
          >
            <div className="absolute inset-0 shimmer rounded-xl opacity-30" />
            <div className="text-center">
              <Sparkles className="size-12 text-primary mx-auto pulse-rarity" />
              <p className="font-fantasy text-2xl text-primary mt-2">Vực Tinh Tú</p>
              <p className="text-xs text-muted-foreground italic max-w-xs mx-auto px-4">
                Hơi thở của các vị thần đang chờ một anh hùng mới được khắc lên vũ trụ.
              </p>
            </div>
          </div>

          {/* Pity counters */}
          <div className="rounded-lg border border-border bg-card/40 p-3 space-y-3">
            <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground mb-1">
              <ShieldAlert className="size-3" /> Bộ đếm Pity
            </div>
            <PityBar
              current={pity.gemSinceLegendary}
              hard={200}
              label="Huyền Thoại (soft 150)"
              color="bg-rarity-legendary"
            />
            <PityBar
              current={pity.gemSinceMythic}
              hard={2000}
              label="Thần Thoại (soft 1500)"
              color="bg-rarity-mythic"
            />
          </div>

          <div className="grid grid-cols-3 gap-2">
            <Button
              size="lg"
              variant="secondary"
              className="font-fantasy"
              onClick={() => rollHero(1)}
              disabled={gems < 30}
            >
              <Gem className="size-4 mr-1 text-rarity-celestial" />
              x1 — 30 💎
            </Button>
            <Button
              size="lg"
              className="font-fantasy"
              onClick={() => rollHero(10)}
              disabled={gems < 280}
            >
              <Gem className="size-4 mr-1" />
              x10 — 280 💎
            </Button>
            <Button
              size="lg"
              className="font-fantasy bg-gradient-to-r from-yellow-600 to-amber-500 hover:from-yellow-500 hover:to-amber-400"
              onClick={() => rollHero(100)}
              disabled={gems < 3000}
            >
              <Sparkles className="size-4 mr-1" />
              x100 — 3000 💎
            </Button>
          </div>

          <p className="text-[11px] text-muted-foreground">
            Triệu hồi tướng trùng sẽ nhận được đá quý hoàn trả theo độ hiếm.
          </p>
        </CardContent>
      </Card>

      <Card className="ornate-border">
        <CardHeader>
          <CardTitle className="font-fantasy text-base">Tỉ lệ rơi</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {displayRarities.map((r) => (
            <div
              key={r}
              className="flex items-center justify-between p-2 rounded border border-border bg-card/50"
            >
              <span className={cn("font-fantasy font-bold text-sm", RARITY_TEXT_CLASS[r])}>
                {RARITY_LABEL[r]}
              </span>
              <span className="font-mono text-sm">
                {(HERO_GACHA_RATES[r] * 100).toFixed(2)}%
              </span>
            </div>
          ))}
          <div className="mt-3 rounded border border-border bg-card/30 p-2 space-y-1 text-[10px] text-muted-foreground">
            <p className="font-bold text-foreground/70">Pity System</p>
            <p>• Pull 150–199: soft pity Huyền Thoại (+1%/pull)</p>
            <p>• Pull 200: đảm bảo Huyền Thoại</p>
            <p>• Pull 1500–1999: soft pity Thần Thoại (+0.1%/pull)</p>
            <p>• Pull 2000: đảm bảo Thần Thoại</p>
            <p>• x10 / x100: pull cuối đảm bảo Sử Thi+</p>
            <p>• x100 = 3000 💎 (giá cố định)</p>
          </div>
          <p className="text-[10px] text-muted-foreground italic mt-2">
            Tổng cộng:{" "}
            {RARITY_ORDER.reduce((a, r) => a + (HEROES_BY_RARITY[r]?.length || 0), 0)} tướng.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}

function GoldBanner() {
  const gold = useGameSelector(s => s.gold)
  const luckBuff = useGameSelector(s => s.luckBuff)
  const gachaPity2 = useGameSelector(s => s.gachaPity)
  const { rollHeroGold } = useGameActions()
  const goldRarities: Rarity[] = ["common", "rare", "epic"]
  const pity = gachaPity2 ?? { gemSinceLegendary: 0, gemSinceMythic: 0, goldSinceEpic: 0 }

  return (
    <div className="grid lg:grid-cols-3 gap-4">
      <Card className="lg:col-span-2 ornate-border">
        <CardHeader>
          <CardTitle className="font-fantasy flex items-center gap-2">
            <Star className="size-5 text-rarity-legendary" />
            Quán Lữ Hành
            {luckBuff && (
              <span className="ml-auto text-xs font-normal text-yellow-300 flex items-center gap-1 bg-yellow-500/20 border border-yellow-500/40 rounded px-2 py-0.5">
                ✨ May Mắn +{[0,25,50,75][luckBuff.tier]}% · còn {luckBuff.rollsLeft} lần
              </span>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div
            className="relative rounded-xl border-2 border-rarity-legendary/40 ornate-border h-44 grid place-items-center"
            aria-hidden
            style={{
              background:
                "radial-gradient(ellipse at center, oklch(0.45 0.12 60 / 0.25), transparent 70%), oklch(0.18 0.04 50)",
            }}
          >
            <div className="text-center">
              <Coins className="size-12 text-rarity-legendary mx-auto" />
              <p className="font-fantasy text-2xl text-rarity-legendary mt-2">Quán Lữ Hành</p>
              <p className="text-xs text-muted-foreground italic max-w-xs mx-auto px-4">
                Những anh hùng lang thang ghé lại quán trọ — dùng vàng để chiêu mộ họ.
              </p>
            </div>
          </div>

          {/* Pity counter */}
          <div className="rounded-lg border border-border bg-card/40 p-3 space-y-3">
            <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground mb-1">
              <ShieldAlert className="size-3" /> Bộ đếm Pity
            </div>
            <PityBar
              current={pity.goldSinceEpic}
              hard={50}
              label="Sử Thi (soft 35)"
              color="bg-rarity-epic"
            />
          </div>

          <div className="grid grid-cols-3 gap-2">
            <Button
              size="lg"
              variant="secondary"
              className="font-fantasy border-rarity-legendary/40"
              onClick={() => rollHeroGold(1)}
              disabled={gold < 500}
            >
              <Coins className="size-4 mr-1 text-rarity-legendary" />
              x1 — 500 🪙
            </Button>
            <Button
              size="lg"
              className="font-fantasy"
              onClick={() => rollHeroGold(10)}
              disabled={gold < 4500}
            >
              <Coins className="size-4 mr-1 text-rarity-legendary" />
              x10 — 4500 🪙
            </Button>
            <Button
              size="lg"
              className="font-fantasy bg-gradient-to-r from-yellow-700 to-yellow-500 hover:from-yellow-600 hover:to-yellow-400"
              onClick={() => rollHeroGold(100)}
              disabled={gold < 50000}
            >
              <Coins className="size-4 mr-1" />
              x100 — 50k 🪙
            </Button>
          </div>

          <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-200">
            ⚠️ Giới hạn tối đa <span className="font-bold">Sử Thi</span> — không thể triệu hồi Huyền Thoại trở lên từ quán này.
          </div>
        </CardContent>
      </Card>

      <Card className="ornate-border">
        <CardHeader>
          <CardTitle className="font-fantasy text-base flex items-center gap-2">
            <Coins className="size-4 text-rarity-legendary" />
            Tỉ lệ rơi
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {goldRarities.map((r) => (
            <div
              key={r}
              className="flex items-center justify-between p-2 rounded border border-border bg-card/50"
            >
              <span className={cn("font-fantasy font-bold text-sm", RARITY_TEXT_CLASS[r])}>
                {RARITY_LABEL[r]}
              </span>
              <span className="font-mono text-sm">
                {(HERO_GACHA_RATES_GOLD[r] * 100).toFixed(0)}%
              </span>
            </div>
          ))}
          <div className="mt-3 text-[10px] text-muted-foreground space-y-1">
            <p>• Pull 35–49: soft pity Sử Thi (+7%/pull)</p>
            <p>• Pull 50: đảm bảo Sử Thi (tỉ lệ gốc 7%)</p>
            <p>• x10 / x100: pull cuối đảm bảo Hiếm+</p>
            <p>• Tướng trùng hoàn trả vàng theo độ hiếm</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

