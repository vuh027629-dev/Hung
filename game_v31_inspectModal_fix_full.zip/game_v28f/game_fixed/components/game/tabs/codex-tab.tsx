"use client"

import { useState, useMemo } from "react"
import { useGameSelector } from "@/lib/game/store"
import { HEROES, HEROES_BY_ID } from "@/lib/game/heroes"
import { SKILLS, PASSIVES } from "@/lib/game/skills"
import { SYNERGIES, SYNERGY_BY_TRAIT, ALL_ROLES, ALL_ORIGINS, ROLE_LABEL, ORIGIN_LABEL } from "@/lib/game/factions"
import { RARITY_ORDER, RARITY_LABEL, RARITY_TEXT_CLASS, RARITY_BG_CLASS } from "@/lib/game/rarity"
import type { Rarity, Role, Origin, Trait } from "@/lib/game/types"
import { cn } from "@/lib/utils"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  BookOpen, Users, Swords, Shield, Wand2, Target, Heart, Zap,
  Search, ChevronRight, X, Star, Lock, Globe
} from "lucide-react"

// ── Icons ─────────────────────────────────────────────────────────────────────
const ROLE_ICON: Record<Role, React.ReactNode> = {
  warrior:  <Swords className="size-3.5" />,
  assassin: <Zap className="size-3.5" />,
  mage:     <Wand2 className="size-3.5" />,
  marksman: <Target className="size-3.5" />,
  tank:     <Shield className="size-3.5" />,
  support:  <Heart className="size-3.5" />,
}

const ROLE_COLOR: Record<Role, string> = {
  warrior:  "text-orange-400 bg-orange-900/30 border-orange-700/40",
  assassin: "text-purple-400 bg-purple-900/30 border-purple-700/40",
  mage:     "text-blue-400 bg-blue-900/30 border-blue-700/40",
  marksman: "text-green-400 bg-green-900/30 border-green-700/40",
  tank:     "text-gray-300 bg-gray-800/40 border-gray-600/40",
  support:  "text-pink-400 bg-pink-900/30 border-pink-700/40",
}

const ORIGIN_EMOJI: Record<Origin, string> = {
  human:     "👤",
  beastkin:  "🐺",
  cyber:     "🤖",
  ancient:   "🏛️",
  elemental: "🌊",
  undead:    "💀",
  dragon:    "🐉",
  demon:     "😈",
  celestial: "✨",
  outlaw:    "⚔️",
  phantom:   "👻",
  plague:    "☣️",
  storm:     "⚡",
  pirate:    "🏴‍☠️",
  merfolk:   "🐠",
  navy:      "⚓",
}

// ── Hero Card in codex ────────────────────────────────────────────────────────
function CodexHeroCard({
  tpl,
  owned,
  onClick,
}: {
  tpl: ReturnType<typeof HEROES[0]> & {},
  owned: boolean,
  onClick: () => void
}) {
  const rarity = tpl.rarity as Rarity
  return (
    <button
      onClick={onClick}
      className={cn(
        "relative rounded-lg border p-2 flex flex-col items-center gap-1.5 transition-all duration-200 hover:scale-105 active:scale-95",
        "bg-card/60 hover:bg-card/90",
        owned
          ? `${RARITY_BG_CLASS[rarity]} shadow-sm`
          : "border-white/5 opacity-50 grayscale",
      )}
    >
      {/* Avatar */}
      <div className={cn(
        "w-12 h-12 rounded-full flex items-center justify-center text-2xl font-bold relative overflow-hidden",
        owned ? `${RARITY_BG_CLASS[rarity]} border` : "bg-muted/30",
      )}>
        {tpl.avatarUrl
          ? <img src={tpl.avatarUrl} alt={tpl.name} className="w-full h-full object-cover" />
          : <span className="text-lg">{owned ? tpl.name[0] : "?"}</span>
        }
        {!owned && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/60">
            <Lock className="size-4 text-white/60" />
          </div>
        )}
      </div>

      {/* Name */}
      <div className="text-center w-full">
        <p className={cn("text-[10px] font-bold leading-tight truncate w-full", owned ? RARITY_TEXT_CLASS[rarity] : "text-muted-foreground")}>
          {owned ? tpl.name : "???"}
        </p>
        <p className="text-[9px] text-muted-foreground/60 mt-0.5">{RARITY_LABEL[rarity]}</p>
      </div>

      {/* Role badge */}
      <div className={cn("flex items-center gap-1 px-1.5 py-0.5 rounded border text-[9px]", ROLE_COLOR[tpl.role as Role])}>
        {ROLE_ICON[tpl.role as Role]}
        <span>{ROLE_LABEL[tpl.role as Role]}</span>
      </div>
    </button>
  )
}

// ── Hero Detail Panel ─────────────────────────────────────────────────────────
function HeroDetailPanel({ heroId, onClose }: { heroId: string; onClose: () => void }) {
  const tpl = HEROES_BY_ID[heroId]
  const ownedHeroes = useGameSelector(s => s.heroes)
  const owned = ownedHeroes.some(h => h.templateId === heroId)
  const rarity = tpl?.rarity as Rarity

  if (!tpl) return null

  const skills = tpl.skills.map(id => SKILLS[id]).filter(Boolean)
  const passive = PASSIVES[tpl.passive]
  const synergies = [tpl.role, ...tpl.origins].map(t => SYNERGY_BY_TRAIT[t as Trait]).filter(Boolean)

  const statsDisplay = [
    { key: "hp", label: "HP", icon: "❤️" },
    { key: "atk", label: "ATK", icon: "⚔️" },
    { key: "mag", label: "MAG", icon: "🔮" },
    { key: "def", label: "DEF", icon: "🛡️" },
    { key: "res", label: "RES", icon: "✨" },
    { key: "spd", label: "SPD", icon: "💨" },
    { key: "crit", label: "CRIT", icon: "⚡" },
  ] as const

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/70 backdrop-blur-sm" onClick={onClose}>
      <div
        className={cn(
          "w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-xl border shadow-2xl bg-card",
          owned ? `${RARITY_BG_CLASS[rarity]}` : "border-white/10"
        )}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className={cn("p-4 flex items-start gap-3 border-b border-white/10", owned ? "" : "opacity-60")}>
          <div className={cn("w-16 h-16 rounded-xl flex items-center justify-center text-3xl shrink-0 border", RARITY_BG_CLASS[rarity])}>
            {tpl.avatarUrl
              ? <img src={tpl.avatarUrl} alt={tpl.name} className="w-full h-full object-cover rounded-xl" />
              : tpl.name[0]
            }
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className={cn("text-lg font-bold font-fantasy", owned ? RARITY_TEXT_CLASS[rarity] : "text-muted-foreground")}>
                {owned ? tpl.name : "Chưa Khám Phá"}
              </h2>
              <span className={cn("text-xs px-1.5 py-0.5 rounded border font-mono", RARITY_BG_CLASS[rarity], RARITY_TEXT_CLASS[rarity])}>
                {RARITY_LABEL[rarity]}
              </span>
            </div>
            {owned && <p className="text-xs text-muted-foreground mt-0.5">{tpl.title}</p>}
            <div className="flex flex-wrap gap-1 mt-1.5">
              <span className={cn("flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded border", ROLE_COLOR[tpl.role as Role])}>
                {ROLE_ICON[tpl.role as Role]} {ROLE_LABEL[tpl.role as Role]}
              </span>
              {tpl.origins.map(o => (
                <span key={o} className="text-[10px] px-1.5 py-0.5 rounded border border-white/10 text-muted-foreground bg-white/5">
                  {ORIGIN_EMOJI[o as Origin]} {ORIGIN_LABEL[o as Origin]}
                </span>
              ))}
            </div>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-white transition-colors shrink-0">
            <X className="size-5" />
          </button>
        </div>

        {!owned ? (
          <div className="p-8 text-center text-muted-foreground">
            <Lock className="size-12 mx-auto mb-3 opacity-30" />
            <p className="font-fantasy text-lg mb-1">Chưa Được Triệu Hồi</p>
            <p className="text-sm opacity-70">Triệu hồi anh hùng này để xem thông tin chi tiết.</p>
          </div>
        ) : (
          <div className="p-4 space-y-4">
            {/* Flavor */}
            <p className="text-xs text-muted-foreground/80 italic border-l-2 border-white/10 pl-3">
              {tpl.flavor}
            </p>

            {/* Base Stats */}
            <div>
              <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2">Chỉ Số Cơ Bản</h3>
              <div className="grid grid-cols-4 gap-1.5">
                {statsDisplay.map(({ key, label, icon }) => (
                  <div key={key} className="bg-black/20 rounded-lg p-2 text-center">
                    <div className="text-sm">{icon}</div>
                    <div className="text-xs font-bold text-foreground">{tpl.baseStats[key] || 0}</div>
                    <div className="text-[9px] text-muted-foreground">{label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Passive */}
            {passive && (
              <div>
                <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2">Kỹ Năng Thụ Động</h3>
                <div className="bg-amber-900/20 border border-amber-700/30 rounded-lg p-3">
                  <p className="text-xs font-bold text-amber-300 mb-1">⭐ {passive.name}</p>
                  <p className="text-xs text-muted-foreground">{passive.description}</p>
                </div>
              </div>
            )}

            {/* Skills */}
            <div>
              <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2">Kỹ Năng Chiến Đấu</h3>
              <div className="space-y-2">
                {skills.map((skill, i) => skill && (
                  <div key={skill.id} className={cn(
                    "rounded-lg p-3 border",
                    i === 2 ? "bg-purple-900/20 border-purple-700/30" : "bg-black/20 border-white/10"
                  )}>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-bold text-foreground">{skill.name}</span>
                      {i === 2 && <span className="text-[9px] px-1 py-0.5 bg-purple-700/50 text-purple-200 rounded">ULTIMATE</span>}
                      <span className="text-[9px] text-muted-foreground ml-auto">CD: {skill.cooldown}T</span>
                    </div>
                    <p className="text-[11px] text-muted-foreground">{skill.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Synergies this hero contributes to */}
            {synergies.length > 0 && (
              <div>
                <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2">Tộc Hệ Kích Hoạt</h3>
                <div className="space-y-1.5">
                  {synergies.map(syn => (
                    <div key={syn.trait} className="bg-blue-900/20 border border-blue-700/30 rounded-lg p-2.5">
                      <p className="text-xs font-bold text-blue-300 mb-0.5">🔷 {syn.name}</p>
                      <p className="text-[10px] text-muted-foreground">{syn.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

// ── Synergy Browser ───────────────────────────────────────────────────────────
function SynergyBrowser() {
  const ownedHeroes = useGameSelector(s => s.heroes)
  const ownedTemplateIds = new Set(ownedHeroes.map(h => h.templateId))

  const [selected, setSelected] = useState<string | null>(null)
  const selectedSyn = selected ? SYNERGY_BY_TRAIT[selected as Trait] : null

  // Count owned heroes per trait
  const traitCounts = useMemo(() => {
    const counts: Record<string, number> = {}
    for (const uid of ownedTemplateIds) {
      const tpl = HEROES_BY_ID[uid]
      if (!tpl) continue
      counts[tpl.role] = (counts[tpl.role] || 0) + 1
      for (const o of tpl.origins) counts[o] = (counts[o] || 0) + 1
    }
    return counts
  }, [ownedHeroes])

  // Heroes belonging to a trait
  const heroesForTrait = (trait: string) =>
    HEROES.filter(h => h.role === trait || h.origins.includes(trait as Origin))

  return (
    <div className="space-y-4">
      {/* Roles */}
      <div>
        <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2 flex items-center gap-1.5">
          <Swords className="size-3.5" /> Vai Trò
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {ALL_ROLES.map(role => {
            const syn = SYNERGY_BY_TRAIT[role]
            const count = traitCounts[role] || 0
            const tier = syn?.tiers.filter(t => count >= t.count).at(-1)
            return (
              <button
                key={role}
                onClick={() => setSelected(selected === role ? null : role)}
                className={cn(
                  "rounded-lg border p-3 text-left transition-all",
                  selected === role ? "border-blue-500/60 bg-blue-900/20" : "border-white/10 bg-card/40 hover:bg-card/70",
                )}
              >
                <div className="flex items-center gap-2 mb-1">
                  <span className={cn("flex items-center gap-1 text-xs font-bold", ROLE_COLOR[role].split(" ")[0])}>
                    {ROLE_ICON[role]} {ROLE_LABEL[role]}
                  </span>
                  <span className="ml-auto text-[10px] text-muted-foreground">{count} hero</span>
                </div>
                {tier ? (
                  <p className="text-[10px] text-green-400 font-medium">✓ Kích hoạt: {tier.count}+ hero</p>
                ) : (
                  <p className="text-[10px] text-muted-foreground/60">Cần {syn?.tiers[0]?.count}+ để kích hoạt</p>
                )}
              </button>
            )
          })}
        </div>
      </div>

      {/* Origins */}
      <div>
        <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2 flex items-center gap-1.5">
          <Globe className="size-3.5" /> Tộc Phái
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {ALL_ORIGINS.map(origin => {
            const syn = SYNERGY_BY_TRAIT[origin]
            if (!syn) return null
            const count = traitCounts[origin] || 0
            const tier = syn.tiers.filter(t => count >= t.count).at(-1)
            const maxHeroes = heroesForTrait(origin).length
            return (
              <button
                key={origin}
                onClick={() => setSelected(selected === origin ? null : origin)}
                className={cn(
                  "rounded-lg border p-2.5 text-left transition-all",
                  selected === origin ? "border-amber-500/60 bg-amber-900/20" : "border-white/10 bg-card/40 hover:bg-card/70",
                )}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm">{ORIGIN_EMOJI[origin]}</span>
                  <span className="text-[9px] text-muted-foreground">{count}/{maxHeroes}</span>
                </div>
                <p className="text-[11px] font-bold text-foreground/90">{ORIGIN_LABEL[origin]}</p>
                {tier ? (
                  <p className="text-[9px] text-green-400 mt-0.5">✓ Cấp {syn.tiers.indexOf(tier) + 1}</p>
                ) : (
                  <p className="text-[9px] text-muted-foreground/50 mt-0.5">Cần {syn.tiers[0]?.count}+</p>
                )}
              </button>
            )
          })}
        </div>
      </div>

      {/* Detail popup */}
      {selectedSyn && selected && (
        <div className="rounded-xl border border-blue-500/30 bg-blue-900/15 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-blue-300 font-fantasy">
                {selected in ORIGIN_EMOJI ? ORIGIN_EMOJI[selected as Origin] : ""} {selectedSyn.name}
              </h3>
              <p className="text-[11px] text-muted-foreground mt-0.5">{selectedSyn.description}</p>
            </div>
            <button onClick={() => setSelected(null)} className="text-muted-foreground hover:text-white">
              <X className="size-4" />
            </button>
          </div>

          {/* Tiers */}
          <div className="space-y-2">
            {selectedSyn.tiers.map((tier, i) => {
              const active = (traitCounts[selected] || 0) >= tier.count
              return (
                <div key={i} className={cn(
                  "rounded-lg border p-2.5",
                  active ? "border-green-500/40 bg-green-900/20" : "border-white/10 bg-black/20 opacity-60"
                )}>
                  <div className="flex items-center gap-2 mb-1">
                    <span className={cn("text-xs font-bold", active ? "text-green-400" : "text-muted-foreground")}>
                      {active ? "✓" : "○"} {tier.count}+ Anh Hùng
                    </span>
                  </div>
                  <p className="text-[11px] text-foreground/80">{tier.description}</p>
                </div>
              )
            })}
          </div>

          {/* Heroes in this trait */}
          <div>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1.5">Anh Hùng ({heroesForTrait(selected).length})</p>
            <div className="flex flex-wrap gap-1">
              {heroesForTrait(selected).map(h => {
                const isOwned = ownedTemplateIds.has(h.id)
                return (
                  <span key={h.id} className={cn(
                    "text-[10px] px-1.5 py-0.5 rounded border",
                    isOwned ? `${RARITY_TEXT_CLASS[h.rarity as Rarity]} ${RARITY_BG_CLASS[h.rarity as Rarity]}` : "text-muted-foreground/40 border-white/5 bg-white/5"
                  )}>
                    {isOwned ? h.name : "???"}
                  </span>
                )
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ── Hero Browser ──────────────────────────────────────────────────────────────
function HeroBrowser() {
  const ownedHeroes = useGameSelector(s => s.heroes)
  const ownedTemplateIds = new Set(ownedHeroes.map(h => h.templateId))

  const [search, setSearch] = useState("")
  const [filterRarity, setFilterRarity] = useState<Rarity | "all">("all")
  const [filterRole, setFilterRole] = useState<Role | "all">("all")
  const [filterOwned, setFilterOwned] = useState(false)
  const [selectedHeroId, setSelectedHeroId] = useState<string | null>(null)

  const filtered = useMemo(() => {
    return HEROES.filter(h => {
      if (filterRarity !== "all" && h.rarity !== filterRarity) return false
      if (filterRole !== "all" && h.role !== filterRole) return false
      if (filterOwned && !ownedTemplateIds.has(h.id)) return false
      if (search) {
        const q = search.toLowerCase()
        const owned = ownedTemplateIds.has(h.id)
        if (!owned) return false // can't search unknown heroes
        return h.name.toLowerCase().includes(q) || h.title.toLowerCase().includes(q)
      }
      return true
    }).sort((a, b) => {
      // Owned first, then by rarity desc
      const ao = ownedTemplateIds.has(a.id) ? 0 : 1
      const bo = ownedTemplateIds.has(b.id) ? 0 : 1
      if (ao !== bo) return ao - bo
      return RARITY_ORDER.indexOf(b.rarity as Rarity) - RARITY_ORDER.indexOf(a.rarity as Rarity)
    })
  }, [search, filterRarity, filterRole, filterOwned, ownedHeroes])

  const ownedCount = ownedTemplateIds.size
  const totalCount = HEROES.length

  return (
    <div className="space-y-3">
      {/* Progress bar */}
      <div className="rounded-lg bg-card/40 border border-white/10 p-3">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-xs text-muted-foreground">Bộ Sưu Tập</span>
          <span className="text-xs font-bold text-foreground">{ownedCount} / {totalCount}</span>
        </div>
        <div className="h-1.5 rounded-full bg-muted/30 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-500"
            style={{ width: `${Math.round((ownedCount / totalCount) * 100)}%` }}
          />
        </div>
        <p className="text-[10px] text-muted-foreground mt-1">{Math.round((ownedCount / totalCount) * 100)}% khám phá</p>
      </div>

      {/* Filters */}
      <div className="space-y-2">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Tìm tên anh hùng..."
            className="w-full bg-card/40 border border-white/10 rounded-lg pl-8 pr-3 py-2 text-xs text-foreground placeholder:text-muted-foreground outline-none focus:border-blue-500/50"
          />
        </div>

        {/* Rarity filter */}
        <div className="flex flex-wrap gap-1">
          <button
            onClick={() => setFilterRarity("all")}
            className={cn("text-[10px] px-2 py-0.5 rounded border transition-colors", filterRarity === "all" ? "bg-white/20 border-white/40 text-white" : "border-white/10 text-muted-foreground hover:border-white/20")}
          >Tất cả</button>
          {(["common","rare","epic","legendary","mythic","celestial"] as Rarity[]).map(r => (
            <button
              key={r}
              onClick={() => setFilterRarity(r === filterRarity ? "all" : r)}
              className={cn("text-[10px] px-2 py-0.5 rounded border transition-colors", RARITY_BG_CLASS[r], filterRarity === r ? RARITY_TEXT_CLASS[r] : "text-muted-foreground")}
            >{RARITY_LABEL[r]}</button>
          ))}
        </div>

        {/* Role filter */}
        <div className="flex flex-wrap gap-1">
          <button
            onClick={() => setFilterRole("all")}
            className={cn("text-[10px] px-2 py-0.5 rounded border transition-colors", filterRole === "all" ? "bg-white/20 border-white/40 text-white" : "border-white/10 text-muted-foreground")}
          >Tất cả</button>
          {ALL_ROLES.map(role => (
            <button
              key={role}
              onClick={() => setFilterRole(role === filterRole ? "all" : role)}
              className={cn("flex items-center gap-1 text-[10px] px-2 py-0.5 rounded border transition-colors", filterRole === role ? ROLE_COLOR[role] : "border-white/10 text-muted-foreground")}
            >
              {ROLE_ICON[role]} {ROLE_LABEL[role]}
            </button>
          ))}
        </div>

        {/* Owned toggle */}
        <button
          onClick={() => setFilterOwned(!filterOwned)}
          className={cn("flex items-center gap-1.5 text-[10px] px-2.5 py-1 rounded-lg border transition-colors", filterOwned ? "bg-green-900/30 border-green-600/50 text-green-400" : "border-white/10 text-muted-foreground")}
        >
          <Star className="size-3" />
          Chỉ hiện anh hùng đã sở hữu
        </button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2">
        {filtered.map(tpl => (
          <CodexHeroCard
            key={tpl.id}
            tpl={tpl}
            owned={ownedTemplateIds.has(tpl.id)}
            onClick={() => setSelectedHeroId(tpl.id)}
          />
        ))}
        {filtered.length === 0 && (
          <div className="col-span-full text-center py-8 text-muted-foreground text-sm">
            Không tìm thấy anh hùng nào
          </div>
        )}
      </div>

      {/* Hero Detail Modal */}
      {selectedHeroId && (
        <HeroDetailPanel heroId={selectedHeroId} onClose={() => setSelectedHeroId(null)} />
      )}
    </div>
  )
}

// ── Main Tab ──────────────────────────────────────────────────────────────────
export function CodexTab() {
  const [view, setView] = useState<"heroes" | "synergy">("heroes")

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <BookOpen className="size-5 text-amber-400" />
        <div>
          <h2 className="font-fantasy text-lg text-foreground">Thư Viện Anh Hùng</h2>
          <p className="text-xs text-muted-foreground">Tra cứu tướng, tộc hệ và sức mạnh tổng hợp</p>
        </div>
      </div>

      {/* Tab switcher */}
      <div className="flex gap-1 bg-black/20 p-1 rounded-lg w-fit">
        <button
          onClick={() => setView("heroes")}
          className={cn("flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all", view === "heroes" ? "bg-card text-foreground shadow" : "text-muted-foreground hover:text-foreground")}
        >
          <Users className="size-3.5" /> Anh Hùng
        </button>
        <button
          onClick={() => setView("synergy")}
          className={cn("flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all", view === "synergy" ? "bg-card text-foreground shadow" : "text-muted-foreground hover:text-foreground")}
        >
          <Globe className="size-3.5" /> Tộc Hệ
        </button>
      </div>

      {view === "heroes" ? <HeroBrowser /> : <SynergyBrowser />}
    </div>
  )
}
