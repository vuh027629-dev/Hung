"use client"

import { useState } from "react"
import { useGameSelector } from "@/lib/game/store"
import { RARITY_TEXT_CLASS, RARITY_BG_CLASS, RARITY_LABEL } from "@/lib/game/rarity"
import type { BattleRecord, BattleHeroSnapshot, Rarity } from "@/lib/game/types"
import { cn } from "@/lib/utils"
import {
  ScrollText, Trophy, Skull, LogOut, ChevronRight, ChevronDown,
  Sword, Shield, Clock, Coins, Gem, X, AlertTriangle, CheckCircle2,
  Users, Zap, BarChart3
} from "lucide-react"

// ── Helpers ───────────────────────────────────────────────────────────────────
function formatTime(ts: number) {
  const d = new Date(ts)
  return d.toLocaleString("vi-VN", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit" })
}

function ResultIcon({ result }: { result: BattleRecord["result"] }) {
  if (result === "victory") return <Trophy className="size-4 text-yellow-400" />
  if (result === "defeat")  return <Skull className="size-4 text-red-400" />
  return <LogOut className="size-4 text-muted-foreground" />
}

function ResultLabel({ result }: { result: BattleRecord["result"] }) {
  const map = { victory: "Chiến Thắng", defeat: "Thất Bại", fled: "Bỏ Chạy" }
  const cls = { victory: "text-yellow-400", defeat: "text-red-400", fled: "text-muted-foreground" }
  return <span className={cn("text-xs font-bold", cls[result])}>{map[result]}</span>
}

function HeroChip({ hero, showHp = false }: { hero: BattleHeroSnapshot; showHp?: boolean }) {
  const rarity = hero.rarity as Rarity
  const hpPct = hero.hpMax > 0 ? Math.round((hero.hpFinal / hero.hpMax) * 100) : 0
  return (
    <div className={cn(
      "flex flex-col items-center gap-0.5 rounded-lg border p-1.5 min-w-[48px] transition-all",
      hero.dead ? "opacity-40 grayscale" : RARITY_BG_CLASS[rarity]
    )}>
      <div className={cn("w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold border", RARITY_BG_CLASS[rarity])}>
        {hero.dead ? "💀" : hero.name[0]}
      </div>
      <span className={cn("text-[9px] font-medium leading-tight text-center w-full truncate", RARITY_TEXT_CLASS[rarity])}>
        {hero.name}
      </span>
      {showHp && !hero.dead && (
        <div className="w-full h-1 rounded-full bg-black/40 overflow-hidden">
          <div
            className={cn("h-full rounded-full", hpPct > 50 ? "bg-green-500" : hpPct > 25 ? "bg-yellow-500" : "bg-red-500")}
            style={{ width: `${hpPct}%` }}
          />
        </div>
      )}
      {showHp && (
        <span className="text-[8px] text-muted-foreground">{hero.dead ? "×" : `${hpPct}%`}</span>
      )}
    </div>
  )
}

// ── Log Entry ─────────────────────────────────────────────────────────────────
function LogLine({ entry }: { entry: { id: string; text: string; kind?: string } }) {
  const kindCls: Record<string, string> = {
    damage:  "text-red-300",
    heal:    "text-green-300",
    status:  "text-yellow-300",
    system:  "text-muted-foreground/60 text-[10px] italic",
    victory: "text-yellow-400 font-bold",
    defeat:  "text-red-400 font-bold",
    info:    "text-blue-300",
  }
  return (
    <p className={cn("text-[11px] leading-snug py-0.5 border-b border-white/5", kindCls[entry.kind ?? ""] ?? "text-foreground/80")}>
      {entry.text}
    </p>
  )
}

// ── Detail Panel (full battle replay) ────────────────────────────────────────
function BattleDetail({ record, onClose }: { record: BattleRecord; onClose: () => void }) {
  const [tab, setTab] = useState<"summary" | "log" | "teams">("summary")

  const playerDead = record.playerTeam.filter(h => h.dead).length
  const enemyDead  = record.enemyTeam.filter(h => h.dead).length

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/75 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg max-h-[92vh] flex flex-col rounded-xl border border-white/10 bg-card shadow-2xl overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className={cn(
          "flex items-center gap-3 p-4 border-b border-white/10 shrink-0",
          record.result === "victory" ? "bg-yellow-900/20" : record.result === "defeat" ? "bg-red-900/20" : "bg-black/20"
        )}>
          <ResultIcon result={record.result} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <ResultLabel result={record.result} />
              <span className="text-xs text-muted-foreground">
                {record.isTower ? `Tháp Tầng ${record.towerFloor}` : record.isPvp ? "PvP" : `Tầng ${record.stage}`}
              </span>
            </div>
            <div className="flex items-center gap-3 mt-0.5 text-[10px] text-muted-foreground flex-wrap">
              <span className="flex items-center gap-1"><Clock className="size-3" />{formatTime(record.timestamp)}</span>
              <span className="flex items-center gap-1"><Zap className="size-3" />{record.rounds} vòng</span>
              {record.goldDelta !== 0 && (
                <span className={cn("flex items-center gap-1", record.goldDelta > 0 ? "text-yellow-400" : "text-red-400")}>
                  <Coins className="size-3" />
                  {record.goldDelta > 0 ? "+" : ""}{record.goldDelta.toLocaleString()}🪙
                </span>
              )}
              {record.gemsEarned > 0 && (
                <span className="flex items-center gap-1 text-cyan-400">
                  <Gem className="size-3" />+{record.gemsEarned}💎
                </span>
              )}
            </div>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-white shrink-0">
            <X className="size-5" />
          </button>
        </div>

        {/* Sub-tabs */}
        <div className="flex border-b border-white/10 shrink-0 bg-black/20">
          {(["summary", "teams", "log"] as const).map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={cn(
                "flex-1 py-2 text-xs font-medium transition-colors",
                tab === t ? "text-foreground border-b-2 border-blue-400" : "text-muted-foreground hover:text-foreground"
              )}
            >
              {t === "summary" ? "📊 Phân Tích" : t === "teams" ? "⚔️ Đội Hình" : "📜 Nhật Ký"}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">

          {tab === "summary" && (
            <>
              {/* Stats */}
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: "Vòng Đấu", value: record.rounds, icon: <Zap className="size-3.5 text-yellow-400" /> },
                  { label: "Quân Ta Còn", value: `${record.playerTeam.length - playerDead}/${record.playerTeam.length}`, icon: <Users className="size-3.5 text-blue-400" /> },
                  { label: "Địch Hạ", value: `${enemyDead}/${record.enemyTeam.length}`, icon: <Skull className="size-3.5 text-red-400" /> },
                ].map(s => (
                  <div key={s.label} className="bg-black/20 rounded-lg p-3 text-center border border-white/10">
                    <div className="flex justify-center mb-1">{s.icon}</div>
                    <p className="text-base font-bold text-foreground">{s.value}</p>
                    <p className="text-[9px] text-muted-foreground">{s.label}</p>
                  </div>
                ))}
              </div>

              {/* Defeat reasons */}
              {record.result === "defeat" && record.defeatReasons.length > 0 && (
                <div className="rounded-xl border border-red-700/40 bg-red-900/15 p-4 space-y-2">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle className="size-4 text-red-400" />
                    <h3 className="text-sm font-bold text-red-300">Lý Do Thất Bại</h3>
                  </div>
                  {record.defeatReasons.map((r, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <span className="text-red-400 mt-0.5 shrink-0">•</span>
                      <p className="text-xs text-foreground/90">{r}</p>
                    </div>
                  ))}
                </div>
              )}

              {/* Victory summary */}
              {record.result === "victory" && (
                <div className="rounded-xl border border-green-700/40 bg-green-900/15 p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle2 className="size-4 text-green-400" />
                    <h3 className="text-sm font-bold text-green-300">Kết Quả Chiến Thắng</h3>
                  </div>
                  <div className="flex gap-4 text-sm">
                    <span className="text-yellow-400">+{record.goldDelta.toLocaleString()}🪙</span>
                    {record.gemsEarned > 0 && <span className="text-cyan-400">+{record.gemsEarned}💎</span>}
                  </div>
                  {playerDead > 0 && (
                    <p className="text-xs text-muted-foreground mt-2">
                      ⚠ {playerDead} anh hùng hi sinh trong trận này
                    </p>
                  )}
                </div>
              )}

              {/* Death breakdown */}
              {record.deathOrder.length > 0 && (
                <div>
                  <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2">Anh Hùng Ngã Xuống</h3>
                  <div className="space-y-1.5">
                    {record.deathOrder.map((tid, i) => {
                      const hero = record.playerTeam.find(h => h.templateId === tid)
                      const killer = record.killedBy[tid]
                      return hero ? (
                        <div key={tid} className="flex items-center gap-2 bg-red-900/10 border border-red-700/20 rounded-lg px-3 py-2">
                          <span className="text-[10px] text-muted-foreground/60 w-4">#{i+1}</span>
                          <span className={cn("text-xs font-medium", RARITY_TEXT_CLASS[hero.rarity as Rarity])}>{hero.name}</span>
                          {killer && (
                            <span className="text-[10px] text-muted-foreground ml-auto">bị hạ bởi <span className="text-red-400">{killer}</span></span>
                          )}
                        </div>
                      ) : null
                    })}
                  </div>
                </div>
              )}

              {/* Synergies */}
              {record.synergiesUsed.length > 0 && (
                <div>
                  <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2">Tộc Hệ Kích Hoạt</h3>
                  <div className="flex flex-wrap gap-1.5">
                    {[...new Set(record.synergiesUsed)].map(s => (
                      <span key={s} className="text-[11px] px-2 py-1 rounded-lg bg-blue-900/30 border border-blue-700/30 text-blue-300">
                        🔷 {s}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          {tab === "teams" && (
            <div className="space-y-4">
              {/* Player team */}
              <div>
                <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2 flex items-center gap-1.5">
                  <Shield className="size-3.5 text-blue-400" /> Đội Của Bạn
                </h3>
                <div className="flex flex-wrap gap-2">
                  {record.playerTeam.map(h => <HeroChip key={h.templateId} hero={h} showHp />)}
                </div>
              </div>

              {/* Enemy team */}
              <div>
                <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2 flex items-center gap-1.5">
                  <Sword className="size-3.5 text-red-400" /> Đội Địch
                </h3>
                <div className="flex flex-wrap gap-2">
                  {record.enemyTeam.map((h, i) => <HeroChip key={i} hero={h} showHp />)}
                </div>
              </div>

              {/* Stat comparison */}
              <div>
                <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2 flex items-center gap-1.5">
                  <BarChart3 className="size-3.5" /> So Sánh Sức Mạnh
                </h3>
                <div className="space-y-2">
                  {[
                    {
                      label: "Trung bình HP",
                      player: Math.round(record.playerTeam.reduce((s,h) => s + h.hpMax, 0) / Math.max(1, record.playerTeam.length)),
                      enemy:  Math.round(record.enemyTeam.reduce((s,h)  => s + h.hpMax, 0)  / Math.max(1, record.enemyTeam.length)),
                    },
                    {
                      label: "Trung bình Level",
                      player: Math.round(record.playerTeam.reduce((s,h) => s + h.level, 0) / Math.max(1, record.playerTeam.length)),
                      enemy:  Math.round(record.enemyTeam.reduce((s,h)  => s + h.level, 0)  / Math.max(1, record.enemyTeam.length)),
                    },
                  ].map(row => {
                    const total = row.player + row.enemy || 1
                    const playerPct = Math.round((row.player / total) * 100)
                    return (
                      <div key={row.label}>
                        <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
                          <span className="text-blue-400">{row.player.toLocaleString()}</span>
                          <span>{row.label}</span>
                          <span className="text-red-400">{row.enemy.toLocaleString()}</span>
                        </div>
                        <div className="h-2 rounded-full bg-black/30 overflow-hidden flex">
                          <div className="bg-blue-500 h-full rounded-l-full" style={{ width: `${playerPct}%` }} />
                          <div className="bg-red-500 h-full rounded-r-full flex-1" />
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          )}

          {tab === "log" && (
            <div>
              <p className="text-[10px] text-muted-foreground mb-3 italic">
                Hiển thị {record.log.length} dòng cuối của trận đấu
              </p>
              <div className="space-y-0 bg-black/30 rounded-lg border border-white/10 p-3 max-h-[50vh] overflow-y-auto">
                {record.log.length === 0 ? (
                  <p className="text-muted-foreground text-xs text-center py-4">Không có dữ liệu nhật ký</p>
                ) : (
                  record.log.map(entry => <LogLine key={entry.id} entry={entry} />)
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ── Battle Row (summary card) ─────────────────────────────────────────────────
function BattleRow({ record, onClick }: { record: BattleRecord; onClick: () => void }) {
  const playerDead = record.playerTeam.filter(h => h.dead).length

  const contextLabel = record.isTower
    ? `🏯 Tầng ${record.towerFloor}`
    : record.isPvp
    ? "⚔️ PvP"
    : `🗡️ Stage ${record.stage}`

  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full rounded-xl border p-3 flex items-center gap-3 text-left transition-all hover:scale-[1.01] active:scale-[0.99]",
        "bg-card/50 hover:bg-card/80",
        record.result === "victory" ? "border-yellow-700/30" : record.result === "defeat" ? "border-red-700/30" : "border-white/10"
      )}
    >
      {/* Result icon */}
      <div className={cn(
        "w-10 h-10 rounded-xl flex items-center justify-center shrink-0",
        record.result === "victory" ? "bg-yellow-900/40" : record.result === "defeat" ? "bg-red-900/40" : "bg-black/30"
      )}>
        <ResultIcon result={record.result} />
      </div>

      {/* Main info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <ResultLabel result={record.result} />
          <span className="text-[10px] text-muted-foreground">{contextLabel}</span>
        </div>
        <div className="flex items-center gap-3 mt-0.5 flex-wrap">
          <span className="text-[10px] text-muted-foreground flex items-center gap-1">
            <Clock className="size-3" />{formatTime(record.timestamp)}
          </span>
          <span className="text-[10px] text-muted-foreground flex items-center gap-1">
            <Zap className="size-3" />{record.rounds} vòng
          </span>
          {record.goldDelta !== 0 && (
            <span className={cn("text-[10px] flex items-center gap-1", record.goldDelta > 0 ? "text-yellow-400" : "text-red-400")}>
              {record.goldDelta > 0 ? "+" : ""}{record.goldDelta.toLocaleString()}🪙
            </span>
          )}
        </div>
        {/* Mini team */}
        <div className="flex gap-0.5 mt-1.5">
          {record.playerTeam.slice(0, 6).map((h, i) => (
            <div
              key={i}
              className={cn(
                "w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-bold border",
                h.dead ? "opacity-30 grayscale bg-muted/20 border-white/10" : `${RARITY_BG_CLASS[h.rarity as Rarity]}`,
              )}
              title={h.name}
            >
              {h.dead ? "×" : h.name[0]}
            </div>
          ))}
          {playerDead > 0 && (
            <span className="text-[9px] text-red-400 ml-1 self-center">({playerDead} hi sinh)</span>
          )}
        </div>
      </div>

      <ChevronRight className="size-4 text-muted-foreground shrink-0" />
    </button>
  )
}

// ── Main Tab ──────────────────────────────────────────────────────────────────
export function BattleLogTab() {
  const history = useGameSelector(s => s.battleHistory ?? [])
  const [selected, setSelected] = useState<BattleRecord | null>(null)
  const [filterResult, setFilterResult] = useState<"all" | "victory" | "defeat">("all")

  const filtered = history.filter(r => filterResult === "all" || r.result === filterResult)

  const wins    = history.filter(r => r.result === "victory").length
  const defeats = history.filter(r => r.result === "defeat").length
  const winRate = history.length > 0 ? Math.round((wins / history.length) * 100) : 0

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <ScrollText className="size-5 text-amber-400" />
        <div>
          <h2 className="font-fantasy text-lg text-foreground">Nhật Ký Chiến Đấu</h2>
          <p className="text-xs text-muted-foreground">Xem lại chi tiết các trận đấu — phân tích lý do thắng/thua</p>
        </div>
      </div>

      {/* Stats */}
      {history.length > 0 && (
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-yellow-900/20 border border-yellow-700/30 rounded-lg p-3 text-center">
            <p className="text-xl font-bold text-yellow-400">{wins}</p>
            <p className="text-[10px] text-muted-foreground">Thắng</p>
          </div>
          <div className="bg-red-900/20 border border-red-700/30 rounded-lg p-3 text-center">
            <p className="text-xl font-bold text-red-400">{defeats}</p>
            <p className="text-[10px] text-muted-foreground">Thua</p>
          </div>
          <div className="bg-card/40 border border-white/10 rounded-lg p-3 text-center">
            <p className="text-xl font-bold text-foreground">{winRate}%</p>
            <p className="text-[10px] text-muted-foreground">Tỉ lệ thắng</p>
          </div>
        </div>
      )}

      {/* Filter */}
      <div className="flex gap-1 bg-black/20 p-1 rounded-lg w-fit">
        {(["all", "victory", "defeat"] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilterResult(f)}
            className={cn(
              "px-3 py-1.5 rounded-md text-xs font-medium transition-all",
              filterResult === f ? "bg-card text-foreground shadow" : "text-muted-foreground hover:text-foreground"
            )}
          >
            {f === "all" ? "Tất Cả" : f === "victory" ? "🏆 Thắng" : "💀 Thua"}
          </button>
        ))}
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 space-y-3">
          <ScrollText className="size-12 mx-auto text-muted-foreground/30" />
          <p className="text-muted-foreground font-fantasy">
            {history.length === 0 ? "Chưa có trận đấu nào được ghi lại" : "Không có trận nào khớp bộ lọc"}
          </p>
          <p className="text-xs text-muted-foreground/60">
            {history.length === 0 ? "Nhật ký sẽ tự động ghi lại từ trận tiếp theo" : ""}
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(r => (
            <BattleRow key={r.id} record={r} onClick={() => setSelected(r)} />
          ))}
        </div>
      )}

      {/* Detail modal */}
      {selected && <BattleDetail record={selected} onClose={() => setSelected(null)} />}
    </div>
  )
}
