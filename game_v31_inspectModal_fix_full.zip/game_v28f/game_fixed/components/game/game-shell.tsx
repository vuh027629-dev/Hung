"use client"

import { useGameSelector } from "@/lib/game/store"
import { checkObjectiveCompletion } from "@/lib/game/quests"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Swords, Sparkles, ShoppingBag, Backpack,
  Users, Brain, Scroll, Feather, Skull, Castle, CalendarDays, Globe,
  BookOpen, ScrollText,
} from "lucide-react"
import { Header } from "./header"
import { CombatScreen } from "./combat-screen"
import dynamic from "next/dynamic"

// Loading fallback nhẹ
function TabLoading() {
  return (
    <div className="flex items-center justify-center py-20 text-muted-foreground text-sm">
      <span className="animate-pulse">Đang tải...</span>
    </div>
  )
}

// next/dynamic cho phép code-split đúng cách trong Next.js App Router
const BattleTab       = dynamic(() => import("./tabs/battle-tab").then(m => m.BattleTab),       { loading: TabLoading, ssr: false })
const RecruitTab      = dynamic(() => import("./tabs/recruit-tab").then(m => m.RecruitTab),     { loading: TabLoading, ssr: false })
const ShopTab         = dynamic(() => import("./tabs/shop-tab").then(m => m.ShopTab),           { loading: TabLoading, ssr: false })
const InventoryTab    = dynamic(() => import("./tabs/inventory-tab").then(m => m.InventoryTab), { loading: TabLoading, ssr: false })
const HeroesTab       = dynamic(() => import("./tabs/heroes-tab").then(m => m.HeroesTab),       { loading: TabLoading, ssr: false })
const StatsTab        = dynamic(() => import("./tabs/stats-tab").then(m => m.StatsTab),         { loading: TabLoading, ssr: false })
const QuestTab        = dynamic(() => import("./tabs/quest-tab").then(m => m.QuestTab),         { loading: TabLoading, ssr: false })
const BlessingPactTab = dynamic(() => import("./tabs/blessing-pact-tab").then(m => m.BlessingPactTab), { loading: TabLoading, ssr: false })
const RaidTab         = dynamic(() => import("./tabs/raid-tab").then(m => m.RaidTab),           { loading: TabLoading, ssr: false })
const TowerTab        = dynamic(() => import("./tabs/tower-tab").then(m => m.TowerTab),         { loading: TabLoading, ssr: false })
const EventTab        = dynamic(() => import("./tabs/event-tab").then(m => m.EventTab),         { loading: TabLoading, ssr: false })
const CommunityTab    = dynamic(() => import("./tabs/community-tab").then(m => m.CommunityTab), { loading: TabLoading, ssr: false })
const CodexTab        = dynamic(() => import("./tabs/codex-tab").then(m => m.CodexTab),         { loading: TabLoading, ssr: false })
const BattleLogTab    = dynamic(() => import("./tabs/battle-log-tab").then(m => m.BattleLogTab),{ loading: TabLoading, ssr: false })

export function GameShell() {
  const statPoints = useGameSelector(s => s.statPoints)
  const skillPoints = useGameSelector(s => s.skillPoints)
  const towerState = useGameSelector(s => s.towerState)
  const isInTower = !!towerState
  const activeEvents = useGameSelector(s => s.activeEvents ?? [])
  const hasCombat = useGameSelector(s => !!s.combat)
  const battleHistoryCount = useGameSelector(s => (s.battleHistory ?? []).length)
  const claimableCount = useGameSelector(s => {
    const qs = s.questState
    return qs
      ? (qs.active ?? []).filter(q => !q.completed && checkObjectiveCompletion(q.objective, s, qs)).length
      : 0
  })

  return (
    <main className="min-h-screen flex flex-col w-full overflow-x-hidden">
      <Header />

      <div className="flex-1 w-full max-w-7xl mx-auto px-2 sm:px-3 py-3 min-w-0 overflow-x-hidden">
        <Tabs defaultValue="battle" className="space-y-3 w-full min-w-0">
          <TabsList className="tab-list-ornate grid grid-cols-7 sm:grid-cols-14 h-auto gap-0.5 p-1">
            <TabsTrigger value="battle" disabled={isInTower} className="tab-trigger-grid">
              <Swords className="size-4 text-orange-400" />
              <span>Chiến Đấu</span>
            </TabsTrigger>
            <TabsTrigger value="recruit" disabled={isInTower} className="tab-trigger-grid">
              <Sparkles className="size-4 text-violet-400" />
              <span>Triệu Hồi</span>
            </TabsTrigger>
            <TabsTrigger value="shop" disabled={isInTower} className="tab-trigger-grid">
              <ShoppingBag className="size-4 text-amber-400" />
              <span>Cửa Hàng</span>
            </TabsTrigger>
            <TabsTrigger value="inventory" disabled={isInTower} className="tab-trigger-grid">
              <Backpack className="size-4 text-emerald-400" />
              <span>Kho Đồ</span>
            </TabsTrigger>
            <TabsTrigger value="heroes" disabled={isInTower} className="tab-trigger-grid">
              <Users className="size-4 text-blue-400" />
              <span>Anh Hùng</span>
            </TabsTrigger>
            <TabsTrigger value="codex" disabled={isInTower} className="tab-trigger-grid">
              <BookOpen className="size-4 text-amber-400" />
              <span>Thư Viện</span>
            </TabsTrigger>
            <TabsTrigger value="stats" disabled={isInTower} className="tab-trigger-grid">
              <Brain className="size-4 text-cyan-400" />
              <span>Kỹ Năng</span>
              {(statPoints > 0 || skillPoints > 0) && (
                <span className="tab-dot-notify bg-primary" />
              )}
            </TabsTrigger>
            <TabsTrigger value="quests" disabled={isInTower} className="tab-trigger-grid">
              <Scroll className="size-4 text-yellow-400" />
              <span>Nhiệm Vụ</span>
              {claimableCount > 0 && (
                <span className="tab-dot-notify bg-green-500" />
              )}
            </TabsTrigger>
            <TabsTrigger value="blessings" disabled={isInTower} className="tab-trigger-grid">
              <Feather className="size-4 text-sky-300" />
              <span>Phúc & Kèo</span>
            </TabsTrigger>
            <TabsTrigger value="raid" disabled={isInTower} className="tab-trigger-grid">
              <Skull className="size-4 text-red-400" />
              <span>Raid Boss</span>
            </TabsTrigger>
            <TabsTrigger value="tower" className="tab-trigger-grid">
              <Castle className="size-4 text-violet-400" />
              <span>Tháp</span>
              {towerState && (
                <span className="tab-dot-notify bg-orange-500" />
              )}
            </TabsTrigger>
            <TabsTrigger value="events" disabled={isInTower} className="tab-trigger-grid">
              <CalendarDays className="size-4 text-amber-300" />
              <span>Sự Kiện</span>
              {activeEvents.length > 0 && (
                <span className="tab-dot-notify bg-red-500" />
              )}
            </TabsTrigger>
            <TabsTrigger value="battlelog" disabled={isInTower} className="tab-trigger-grid">
              <ScrollText className="size-4 text-rose-400" />
              <span>Nhật Ký</span>
              {battleHistoryCount > 0 && (
                <span className="tab-dot-notify bg-rose-500" />
              )}
            </TabsTrigger>
            <TabsTrigger value="community" disabled={isInTower} className="tab-trigger-grid">
              <Globe className="size-4 text-sky-400" />
              <span>Cộng Đồng</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="battle"><div className="tab-bg-base tab-bg-battle p-4"><BattleTab /></div></TabsContent>
          <TabsContent value="recruit"><div className="tab-bg-base tab-bg-recruit p-4"><RecruitTab /></div></TabsContent>
          <TabsContent value="shop"><div className="tab-bg-base tab-bg-shop p-4"><ShopTab /></div></TabsContent>
          <TabsContent value="inventory"><div className="tab-bg-base tab-bg-inventory p-4"><InventoryTab /></div></TabsContent>
          <TabsContent value="heroes"><div className="tab-bg-base tab-bg-heroes p-4"><HeroesTab /></div></TabsContent>
          <TabsContent value="codex"><div className="tab-bg-base tab-bg-heroes p-4"><CodexTab /></div></TabsContent>
          <TabsContent value="stats"><div className="tab-bg-base tab-bg-stats p-4"><StatsTab /></div></TabsContent>
          <TabsContent value="quests"><div className="tab-bg-base tab-bg-quests p-4"><QuestTab /></div></TabsContent>
          <TabsContent value="blessings"><div className="tab-bg-base tab-bg-blessings p-4"><BlessingPactTab /></div></TabsContent>
          <TabsContent value="raid"><div className="tab-bg-base tab-bg-raid p-4"><RaidTab /></div></TabsContent>
          <TabsContent value="tower"><div className="tab-bg-base tab-bg-tower p-4"><TowerTab /></div></TabsContent>
          <TabsContent value="events"><div className="tab-bg-base tab-bg-quests p-4"><EventTab /></div></TabsContent>
          <TabsContent value="battlelog"><div className="tab-bg-base tab-bg-battle p-4"><BattleLogTab /></div></TabsContent>
          <TabsContent value="community"><div className="tab-bg-base tab-bg-stats p-4"><CommunityTab /></div></TabsContent>
        </Tabs>
      </div>

      {hasCombat && <CombatScreen />}

      <footer className="w-full max-w-7xl mx-auto px-2 sm:px-4 py-3 text-center overflow-hidden">
        <div className="ornate-divider mb-2">
          <div className="ornate-divider-gem" />
          <div className="ornate-divider-gem" />
          <div className="ornate-divider-gem" />
        </div>
        <p className="text-[10px] text-muted-foreground/40 tracking-widest uppercase font-mono">
          AETHERIA — Fantasy Turn-Based Saga · Auto-save local · Cloud Save qua tài khoản
        </p>
      </footer>
    </main>
  )
}
